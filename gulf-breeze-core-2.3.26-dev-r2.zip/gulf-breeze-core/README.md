# Gulf Breeze Core 2.3.26 Development

## Core 2.3.26 enrollment configuration foundation

- Revision 2 normalizes fields absent from a legacy flat configuration to their declared schema defaults, preserving the initial provider profile as version 1 and preventing new default-backed fields from being stored blank.
- Makes the public phone, student-support email, and legal/compliance email required provider-profile fields.
- Adds a versioned provider-profile envelope with schema version, profile version, UTC effective/update timestamps, updater user ID, and SHA-256 profile hash.
- Adds the stable read-only `gb_core_provider_profile()` API and immutable `gb_core_provider_profile_snapshot()` payload for contracts, orders, compliance records, and future certificate modules.
- Adds default locale, enabled locales, and environment label to the authoritative Core configuration.
- Preserves the existing flat `gb_config` field keys so installed catalog, curriculum, and shortcode integrations remain backward compatible.

Authored for Gulf Breeze Driving School / Rodney Crawford.

## Core 2.3.25.1 responsive instructional media — Wave 1H revision 1

- Corrects the live-only audit classification found after the initial Wave 1H refresh by explicitly identifying each interactive visual lab as guided practice.
- Makes the Curriculum Blueprint guided-practice audit recognize the visual practice already present in Lessons 1–5; the diagrams, captions, interactions, lesson text, timing markers, assessments, and course structure are otherwise unchanged.
- Retains the exact 46-lesson / 330-minute instructional ledger and Under Construction protection.

Authored for Gulf Breeze Driving School / Rodney Crawford.

## Core 2.3.25 responsive instructional media — Wave 1H

- Completes the Adult English media audit by adding 16 interactive, locally hosted vector states to all nine Topic 4.1.1–4.1.2 lessons (`adult_en_001`–`adult_en_009`).
- Covers the safe-driver learning cycle, ordered course flow, instructional-time categories, valid course-record evidence, reduced-risk responsibility, the Texas licensing path, license authority, status restoration, vehicle legal readiness, liability coverage, and the voluntary Texas Driving with Disability pathways.
- Uses the established mobile-first road-lab system with large touch controls, one-column small-phone behavior, readable HTML captions, responsive SVG diagrams, accessible labels, and no hover-only information.
- Adds no generic licensing video; the Texas-specific administrative material remains grounded in current official course text and maintainable diagrams.
- Preflights all nine lesson placements and timers, the exact Core 2.3.10 timing-rebalance marker in every lesson, and the complete 9-section / 56-item / 46-lesson / 10-quiz / 330-minute structure before the first write.
- Refreshes idempotently through a dedicated Wave 1H media marker, rolls back if course identity or structure changes, and leaves all assessments, official sources, course order, and Under Construction protection unchanged.

Authored for Gulf Breeze Driving School / Rodney Crawford.

## Core 2.3.24 responsive instructional media — Wave 1G

- Preserves the ten official FHWA sign graphics already installed in Topic 4.1.9 and adds ten application-focused visual states across its three instructional-review lessons.
- Adds a Conduite Facile lane-change demonstration to `adult_en_045` as clearly labeled optional enrichment outside the 20-minute timer; Texas course text remains controlling for Texas law.
- Preflights the exact Core 2.3.2 duration-hardening blocks, lesson placement, and timers before changing any Topic 4.1.9 lesson.
- Leaves the separately controlled final assessment, its zero-seat-time status, all question banks, and the 46-lesson / 330-minute ledger unchanged.

## Core 2.3.23.1 responsive instructional media — Wave 1F corrected checkpoint

- Adds 13 interactive, locally hosted vector states to the five non-video Topic 4.1.8 lessons (`adult_en_038`–`adult_en_042`).
- Covers the four-part risk formula, compounding risk, unattended-child prevention, visual/manual/cognitive distraction, park-before-phone behavior, fatigue, headlight-limited stopping paths, traction and blowout recovery, speed/aggression chains, correct belt positioning, trafficking indicators, and safe reporting.
- Adds the user-approved “From One Second to the Next” texting documentary to `adult_en_039`, beginning at 1:32 and clearly labeled optional enrichment outside the seven-minute lesson timer and completion requirements.
- Uses the established responsive road-lab system with large touch controls, one-column small-phone layout, readable HTML captions, responsive 720×520 SVG diagrams, and no hover-only information.
- Preflights all five lesson placements and timers, then preserves the exact Core 2.3.10 timing-rebalance block in `adult_en_038` and the Core 2.3.4 duration-hardening blocks in `adult_en_039`–`adult_en_042` before the first write. The separate unattended-child compliance block in `adult_en_038` is also preserved.
- Leaves the required 12-minute TPWD water-safety lesson (`adult_en_043`) unchanged and refuses to refresh unless its timer, official player, fallback link, section placement, and immediately following reviewed four-question video check match the verified contract.
- Preserves Waves 1A–1E, all required-video gates, course structure, and the locked 46-lesson / 330-minute instructional ledger.

## Core 2.3.22 responsive instructional media — Wave 1E

- Adds 13 interactive, locally hosted vector states to the five non-video Topic 4.1.7 lessons (`adult_en_032`–`adult_en_036`).
- Covers vulnerable-road-user searches, bicycle and motorcycle decisions, truck blind areas and turns, oversize loads, work-zone routing and flaggers, crash response, Good Samaritan limits, road-rage escape, towing checks, and carbon-monoxide response.
- Uses the established responsive road-lab system with 48-pixel desktop controls, 50-pixel small-phone controls, one-column mobile layout, readable captions, and accessible SVG labels.
- Preflights all five installed lesson shells and preserves their exact Core 2.3.3 duration-hardening blocks before the first write.
- Also preserves the separate Core 2.3.0 litter-prevention block in `adult_en_036`.
- Leaves the required 16-minute CSEA lesson (`adult_en_037`) unchanged and refuses to refresh unless its timer, official player, fallback link, section placement, and immediately following reviewed four-question video check match the verified contract.
- Preserves Waves 1A–1D, official sign galleries, all timers, course structure, and the locked 46-lesson / 330-minute instructional ledger.

## Core 2.3.21 responsive instructional media — Wave 1D

- Adds five mobile-first interactive visual labs with 12 labeled states to Topic 4.1.6 lessons 27–31.
- Covers pre-use transportation planning, impairment pathways, Texas intoxication definitions, medication warnings, separate legal processes, under-21 rules, consequence chains, and safe intervention.
- Adds the user-approved 26:44 MADD “Lives Affected” presentation to Lesson 28 as clearly labeled optional enrichment beginning at 1:31, outside required seat time and completion gates.
- Adds a safe Topic 4.1.6 refresh action that preflights and preserves every existing duration-hardening block before changing any lesson.
- Preserves Waves 1A–1C, official sign galleries, all timers, required-video gates, course structure, and the locked 330-minute instructional ledger.

## Core 2.3.20 responsive instructional media — Wave 1C

- Adds five mobile-first interactive visual labs to Topic 4.1.5 lessons 22–26.
- Covers following and stopping space, blind zones and lane changes, turn paths and communication, passing sight distance, backing, hill parking, freeway merging, and breakdown protection.
- Adds 16 labeled visual states with essential explanations kept in responsive HTML captions.
- Preserves Wave 1A, Wave 1B, official sign galleries, lesson timers, course structure, and all existing course items.
- Keeps optional supplemental video work outside this checkpoint so it introduces no new timing or video-gate decision.

## Core 2.3.19 responsive instructional media — Wave 1B

- Adds one responsive, touch-controlled visual lab to each Adult English Topic 4.1.4 lesson, `adult_en_016` through `adult_en_021`.
- Adds 18 visual states covering complete device reading, lawful STOP positions, pre-curve preparation, sign-family purpose and temporary work-zone routing, steady/flashing/dark signals, and pavement-marking application.
- Preserves the existing official FHWA sign galleries and their source attribution.
- Uses the Wave 1A mobile-first system: essential explanations outside SVG artwork, 48–50 pixel controls, keyboard-visible focus, no hover-only content, responsive SVG sizing, and a one-column layout below 520 pixels.
- Preserves every lesson title, objective, timer, source link, curriculum position, quiz, and the locked 330-minute total.
- Does not rewrite course content automatically. After installation, an administrator deliberately reapplies Topic 4.1.4 from the Curriculum Blueprint to place the new labs into the six live lessons.

Authored for Gulf Breeze Driving School / Rodney Crawford.

## Core 2.3.18 responsive instructional media — Wave 1A

- Adds a reusable Gulf Breeze roadway-diagram system for Adult English Topic 4.1.3.
- Adds three touch-controlled visual steps to each of lessons `adult_en_010` through `adult_en_015` (18 responsive scenario states total).
- Covers blocked intersections, four-way-stop arrival order, left-turn yielding, hidden pedestrians, school-bus/Move Over decisions, and railroad-crossing clearance and escape.
- Uses mobile-first controls with a 48–50 pixel touch target, no hover-only information, no horizontal scrolling, and full-width responsive SVG presentation.
- Keeps essential explanations outside the SVG so they remain readable on small phones and available to assistive technology.
- Preserves all existing lesson titles, instructional text, timers, sign galleries, source links, curriculum order, and assessment mappings.
- Does not run an automatic content rewrite. After installation, an administrator deliberately reapplies Topic 4.1.3 from the Curriculum Blueprint to place the visuals into the six live lessons.

Authored for Gulf Breeze Driving School / Rodney Crawford.

## Core 2.3.11 Course Flow enforcement repair

Repairs the live LearnPress integration for the Adult English regulated course. The secure timer now resolves the current lesson from the queried LearnPress object and verified course-section attachment instead of depending on a brittle runtime global. Required timing metadata fails closed. The timer hides and intercepts both Complete and Next until server-confirmed active time is satisfied. Server-side sequential enforcement blocks sidebar access and direct URLs unless the immediately preceding item is validly complete; a timed lesson requires a matching completed Gulf Breeze seat-time record rather than LearnPress completion alone.

Core 2.0.0 preserves the verified Adult English curriculum at 46 instructional lessons and 330 minutes. Its automatic migration adds seven zero-seat-time participation-check shells, one after each Topic 4.1.2–4.1.8 section, so Course Mastery Gate checks can occur without skipping an instructional lesson or placing internal question banks in the visible curriculum.

The course remains a draft and Under Construction protection remains unchanged. The migration does not import question banks, create mastery mappings, enroll users, change configuration values, or publish the course.

Core 2.1.0 adds two dedicated zero-seat-time video-check shells and verifies their positions immediately after the Topic 4.1.7 CSEA video and Topic 4.1.8 recreational-water-safety video. This placement is required by Video Quiz Gate and leaves each topic participation check after the video check.

Core 2.1.1 corrects initialization of the LearnPress course and section service when upgrading an installation whose 2.0.0 migration was already complete. The recovery is idempotent and safely reuses any video-check shell created before the interrupted 2.1.0 migration.


Core 2.2.0 corrects the post-import video-check placement. It promotes the two reviewed imported four-question video banks into the Adult English course immediately after the required CSEA and recreational-water-safety videos, retires rather than deletes the empty 2.1 placeholder quizzes, preserves any existing Video Quiz Gate mapping that referenced a placeholder, and refuses to finalize unless the regulated ledger remains exactly 46 instructional lessons / 330 minutes.


## Core 2.2.1

Corrects the production-only LearnPress curriculum-cache edge case discovered during the 2.2.0 video-bank migration. The 2.2.0 migration could retire a placeholder directly in the database and then call LearnPress `add_items_section()`, whose cached curriculum could silently reinsert that retired placeholder. Core 2.2.1 places each already-reviewed imported video bank directly into its verified target section, explicitly reorders the section, verifies the placeholder is absent, and preserves the locked 46-lesson / 330-minute instructional ledger.

## Core 2.3.0 development hardening

Adds explicit Gulf Breeze instruction for three May 2026 POI course-wide subjects missing from the prior installed lesson content: anatomical gifts, litter prevention, and leaving children unattended in vehicles. The retry-safe migration updates three existing lesson records without adding a lesson or changing a timer, verifies the Adult English ledger remains exactly 46 lessons / 330 minutes, and corrects crosswalk labels that previously understated 4.1.5.1(J) and 4.1.7.1(M).

This remains a development build. It must not be published or deployed until the full Adult English objective, instructional-duration, assessment, video-enforcement, accessibility, migration, and ownership audits pass.

## Core 2.3.1 development hardening

Expands all five Topic 4.1.6 lessons with substantive instruction, Texas-law distinctions, impairment analysis, medication and combination safety, consequence mapping, decision scenarios, and guided safe-ride/intervention practice. The development duration screen now requires each Topic 4.1.6 lesson to support at least 120 readable words per assigned minute before qualitative activity credit. No timer or lesson count changes.

## Core 2.3.2 development hardening

Rebuilds the three Topic 4.1.9 instructional-review lessons as a highway-sign observation workshop, a traffic-law application workshop, and a comprehensive licensing-readiness decision lab. The migration refuses to complete unless every lesson contains at least 120 readable words per assigned minute; the sign lesson additionally requires at least ten instructional sign graphics. The 52-minute Topic 4.1.9 allocation is unchanged, and the separately controlled final assessment remains zero seat time.

## Core 2.3.3 development hardening

Topic 4.1.7 non-video duration hardening with strict installed-content word screening.

## Core 2.3.4 development hardening

Topic 4.1.8 non-video duration hardening with strict installed-content word screening.

## Core 2.3.5 development hardening

Topic 4.1.5 duration hardening for speed and stopping, lane use, turning and communication, passing, and freeway/emergency/work-zone procedures. The retry-safe migration requires exactly five expansions, verifies every installed lesson at 120 readable words per assigned minute, and refuses to finalize unless the Adult English ledger remains 46 lessons and 330 minutes.

## Core 2.3.6 development hardening

Topic 4.1.4 duration and visual-observation hardening for all six traffic-control-device lessons. Each lesson now requires substantive device comparison, prediction, and roadway-application work; the migration preserves the installed sign galleries, verifies at least 120 readable words per assigned minute, and refuses to finalize unless the Adult English ledger remains 46 lessons and 330 minutes.

## Core 2.3.7 development hardening

Topic 4.1.3 duration hardening for right-of-way, traditional and nontraditional intersections, turns and roadway entry, pedestrians and school crossings, school buses and emergency/roadside vehicles, and railroad crossings. The migration requires exactly six expansions, remeasures installed content at 120 readable words per assigned minute, and preserves the 46-lesson / 330-minute ledger.

## Core 2.3.8 development hardening

Topic 4.1.2 duration hardening for Texas driver-license application pathways, license classes and credential limits, suspension/revocation/renewal and individualized reinstatement, vehicle registration and the post-2025 inspection framework, financial responsibility, and the Texas Driving with Disability Program. The migration requires exactly five ordered expansions, resolves each lesson by its Gulf Breeze blueprint key, replaces only its own retry marker, screens installed content at 120 readable words per assigned minute, and refuses to finalize unless the Adult English ledger remains exactly 46 lessons / 330 minutes.

## Core 2.3.9 development hardening

Topic 4.1.1 qualitative and duration hardening for course purpose, active online study, identity and participation-record integrity, assessment conduct, lifelong learning, and repeatable reduced-risk decision making. The migration requires exactly four ordered expansions, replaces only its own retry marker, screens every installed lesson at 120 readable words per assigned minute, and preserves the 46-lesson / 330-minute ledger.

Expands all five non-video Topic 4.1.7 lessons with roadway-user cooperation, large-vehicle interaction, work-zone decisions, crash-scene duties, and aggression/cargo/towing/carbon-monoxide/litter instruction. The retry-safe migration refuses to finalize unless every affected lesson contains at least 120 readable words per assigned minute and the regulated ledger remains exactly 46 lessons / 330 minutes.

This checkpoint does not resolve CSEA video playback enforcement. The separate Video Quiz Gate review found that the installed gate verifies LearnPress completion state rather than actual media playback. A Gulf Breeze-only playback-evidence implementation and formal PHP/runtime testing remain release blockers.

## Core 2.3.10 controlled student-path testing

Adds an administrator-managed allowlist of WordPress user IDs for internal browser testing. An approved tester may open only regulated course objects mapped to a course whose registry status is `Internal testing`. Administrators retain their existing access, while every other visitor or authenticated user continues to receive a 404.

This checkpoint does not grant administrative capabilities, make an approval claim, alter Under Construction settings, change course publication, or change the regulated 46-lesson / 330-minute ledger.

## Core 2.3.14 LearnPress course-model synchronization repair

Repairs the verified LearnPress 4.4.4 two-store section-description failure. Core 2.3.13 wrote and reread `learnpress_sections`, but LearnPress's course editors rendered the denormalized CourseModel JSON stored in `learnpress_courses`; clearing the ordinary model cache did not rebuild that stored course structure. Core 2.3.14 updates each of the nine regulated sections through LearnPress's native `CourseSectionModel` and `CoursePostModel` save path, then proves a fresh CourseModel contains the exact student-facing descriptions before marking the migration complete.

The migration fails closed unless Course #21 retains exactly nine sections, 46 lessons, 10 quizzes, and the identical ordered 56-item curriculum signature. It is retry-safe after a partial interruption, preserves course and lesson content except for the previously approved exact private-self-check replacement, and leaves publication, enrollment, timing, access, Under Construction, and licensing status unchanged.

## Core 2.3.15 Topic 4.1.7 duration-resume correction

Corrects the verified five-word shortfall in the `adult_en_032` Topic 4.1.7 hardening source. The existing fail-closed `2.3.3` curriculum migration can now satisfy the strict 120-readable-words-per-assigned-minute screen and continue through the already-defined `2.3.4`–`2.3.9` hardening sequence.

The resumed sequence remains additive and retry-safe. It must preserve the published course, all nine sections, the exact ordered 46-lesson/10-quiz/56-item curriculum identity, the locked 330-minute ledger, public section descriptions, closed comments and pings, controlled tester access, and Under Construction status.

The LearnPress cache-refresh helper now invalidates model and post caches without rewriting the parent course status. An existing draft remains draft, while a course published for protected internal testing remains published.

## Core 2.3.16 bounded migration recovery

Revision 2 expands the `adult_en_034` work-zone lesson so the real protected-site baseline clears its seven-minute, 840-readable-word duration screen with a substantive safety margin. The regression suite now recreates that exact 285-word pre-hardening baseline so a disposable fixture cannot conceal the production boundary.

Permanently removes curriculum and privacy migrations from ordinary `wp-admin` request execution. Administrator requests now perform only a constant-time scheduling check; the actual work runs in background events protected by one atomic database lock.

Each background curriculum run advances at most one versioned checkpoint, records its exact target and result, and schedules the next checkpoint separately. A failed checkpoint waits before retrying, repeated failures receive a longer cooldown, and a stale-lock watchdog safely resumes work after an interrupted or fatal request. Concurrent workers cannot enter the migration body together.

This corrects the Core 2.3.15 failure mode in which multiple administrator requests could simultaneously repeat the unfinished 2.3.3–2.3.9 content-hardening chain. No threshold, lesson content, course status, timer, access rule, privacy rule, or Under Construction behavior is relaxed.

## Core 2.3.17 Adult English timing rebalance

Adds the bounded `2.3.10` curriculum checkpoint for the 18 lessons identified by the installed-content timing audit: lessons 1–16, 18, and 38. The checkpoint replaces or trims only the previously expanded timing blocks, preserves all lesson timers and required objectives, and requires every affected lesson to contain between 120 and 150 readable words per assigned minute.

The migration preflights all 18 proposed lesson bodies before the first write and rolls back prior writes if an update or preservation check fails. It refuses to finalize unless the Adult English course retains its status and registry mapping, all existing sign galleries, nine sections, the exact ordered 56-item curriculum, 46 lessons, 10 quizzes, and the locked 330 instructional minutes. This development build does not change Under Construction, publish a release, or install itself on the live site.
