<?php
/**
 * Plugin Name: Gulf Breeze MFA & Compliance
 * Description: Bilingual, mobile-first TOTP MFA, recovery, direct-route enforcement, and TDLR-oriented student compliance audit.
 * Version: 0.1.0-dev-r2
 * Author: Gulf Breeze Driving School / Rodney Crawford
 * Text Domain: gulf-breeze-mfa
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Gulf_Breeze_MFA_Compliance {
	const VERSION = '0.1.0-dev-r2';
	const OPTION_OWNER_ID = 'gb_mfa_owner_immune_user_id';
	const OPTION_SETTINGS = 'gb_mfa_settings';
	const DB_VERSION = '1.0';
	const META_SECRET = '_gb_mfa_secret_enc';
	const META_PENDING = '_gb_mfa_pending_enc';
	const META_CREATED = '_gb_mfa_secret_created_utc';
	const META_VERIFIED_AT = '_gb_mfa_verified_at';
	const META_VERIFIED_UNTIL = '_gb_mfa_verified_until';
	const META_SESSION = '_gb_mfa_session_hash';
	const META_FAILS = '_gb_mfa_fail_count';
	const META_LOCK = '_gb_mfa_lock_until';
	const META_RECOVERY = '_gb_mfa_recovery_hashes';
	const META_RESET_NOTICE = '_gb_mfa_reset_notice';
	const META_LANGUAGE = '_gb_mfa_language';
	const CAP_AUDIT = 'gb_view_student_compliance';

	private static $instance;
	private $events_table;
	private $student_requirement_cache = array();

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		global $wpdb;
		$this->events_table = $wpdb->prefix . 'gb_mfa_events';

		add_shortcode( 'gb_mfa_enroll', array( $this, 'shortcode_enroll' ) );
		add_shortcode( 'gb_mfa_verify', array( $this, 'shortcode_verify' ) );
		add_shortcode( 'gb_mfa_recovery', array( $this, 'shortcode_recovery' ) );
		add_action( 'template_redirect', array( $this, 'handle_language_switch' ), -20 );
		add_action( 'template_redirect', array( $this, 'guard_public_instructor_profile' ), -15 );
		add_action( 'template_redirect', array( $this, 'guard_frontend' ), -10 );
		add_filter( 'login_redirect', array( $this, 'guard_login_redirect' ), 20, 3 );
		add_filter( 'rest_pre_dispatch', array( $this, 'guard_rest' ), 1, 3 );
		add_action( 'admin_init', array( $this, 'guard_direct_actions' ), -20 );
		add_action( 'wp_logout', array( $this, 'clear_logout_verification' ), 10, 1 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'init', array( $this, 'mark_known_exam_checkpoints' ), 30 );

		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'admin_post_gb_mfa_student_action', array( $this, 'handle_admin_student_action' ) );
		add_action( 'admin_post_gb_mfa_export_csv', array( $this, 'export_csv' ) );
		add_action( 'admin_post_gb_mfa_export_pdf', array( $this, 'export_pdf' ) );
		add_action( 'admin_post_gb_mfa_save_settings', array( $this, 'save_settings' ) );

		add_filter( 'gb_mfa_is_verified', array( $this, 'filter_is_verified' ), 10, 2 );
		add_filter( 'gb_mfa_require_recent', array( $this, 'filter_require_recent' ), 10, 3 );
		add_filter( 'learn-press/course/instructor-name', array( $this, 'public_instructor_name' ), 20, 2 );
		add_filter( 'learn-press/course/instructor-html', array( $this, 'public_instructor_html' ), 20, 4 );
		add_filter( 'learn-press/course-tabs', array( $this, 'public_course_tabs' ), 20, 1 );
		add_filter( 'get_the_author_display_name', array( $this, 'public_author_display_name' ), 20, 3 );
	}

	public static function activate() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table = $wpdb->prefix . 'gb_mfa_events';
		$charset = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			event_type varchar(64) NOT NULL,
			result varchar(32) NOT NULL DEFAULT '',
			method varchar(32) NOT NULL DEFAULT '',
			reason text NULL,
			course_id bigint(20) unsigned NULL,
			item_id bigint(20) unsigned NULL,
			actor_user_id bigint(20) unsigned NULL,
			ip_address varchar(64) NOT NULL DEFAULT '',
			user_agent varchar(255) NOT NULL DEFAULT '',
			language varchar(5) NOT NULL DEFAULT 'en',
			context_json longtext NULL,
			created_at_utc datetime NOT NULL,
			PRIMARY KEY (id),
			KEY user_created (user_id,created_at_utc),
			KEY event_type (event_type),
			KEY course_id (course_id)
		) {$charset};";
		dbDelta( $sql );
		update_option( 'gb_mfa_db_version', self::DB_VERSION, false );

		$admin = get_role( 'administrator' );
		if ( $admin ) {
			$admin->add_cap( self::CAP_AUDIT );
		}
		if ( ! get_option( self::OPTION_OWNER_ID ) ) {
			$activator = get_current_user_id();
			if ( $activator && user_can( $activator, 'manage_options' ) ) {
				add_option( self::OPTION_OWNER_ID, absint( $activator ), '', false );
			}
		}
		add_option( self::OPTION_SETTINGS, array(
			'verify_ttl_minutes' => 60,
			'checkpoint_minutes' => 30,
			'max_attempts' => 6,
			'lock_minutes' => 30,
		), '', false );
		self::ensure_page( 'mfa-enroll', 'Student Verification Setup', '[gb_mfa_enroll]' );
		self::ensure_page( 'mfa-verify', 'Student Verification', '[gb_mfa_verify]' );
		self::ensure_page( 'mfa-recovery', 'Restore Student Verification', '[gb_mfa_recovery]' );
	}

	private static function ensure_page( $slug, $title, $content ) {
		if ( get_page_by_path( $slug ) ) {
			return;
		}
		wp_insert_post( array(
			'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $slug,
			'post_title' => $title, 'post_content' => $content,
			'comment_status' => 'closed', 'ping_status' => 'closed',
		) );
	}

	private function settings() {
		$defaults = array( 'verify_ttl_minutes' => 60, 'checkpoint_minutes' => 30, 'max_attempts' => 6, 'lock_minutes' => 30 );
		return wp_parse_args( (array) get_option( self::OPTION_SETTINGS, array() ), $defaults );
	}

	public function owner_user_id() {
		if ( defined( 'GB_MFA_OWNER_USER_ID' ) && absint( GB_MFA_OWNER_USER_ID ) ) {
			return absint( GB_MFA_OWNER_USER_ID );
		}
		return absint( get_option( self::OPTION_OWNER_ID, 0 ) );
	}

	public function is_owner_immune( $user_id = 0 ) {
		$user_id = $user_id ? absint( $user_id ) : get_current_user_id();
		return $user_id > 0 && $user_id === $this->owner_user_id();
	}

	public function student_requires_mfa( $user_id = 0 ) {
		global $wpdb;
		$user_id = $user_id ? absint( $user_id ) : get_current_user_id();
		if ( ! $user_id || $this->is_owner_immune( $user_id ) ) {
			return false;
		}
		if ( isset( $this->student_requirement_cache[ $user_id ] ) ) {
			return $this->student_requirement_cache[ $user_id ];
		}
		$required = (bool) get_user_meta( $user_id, 'gb_mfa_required', true );
		if ( ! $required ) {
			$table = $wpdb->prefix . 'learnpress_user_items';
			$required = (bool) $wpdb->get_var( $wpdb->prepare(
				"SELECT item_id FROM {$table} WHERE user_id = %d AND item_type = 'lp_course' LIMIT 1",
				$user_id
			) );
		}
		$required = (bool) apply_filters( 'gb_mfa_student_requires_mfa', $required, $user_id );
		$this->student_requirement_cache[ $user_id ] = $required;
		return $required;
	}

	private function is_student_account_path( $path ) {
		$path = '/' . ltrim( strtolower( (string) $path ), '/' );
		if ( preg_match( '#^/my-account/customer-logout(?:/|$)#', $path ) ) {
			return false;
		}
		return (bool) preg_match( '#^/my-account(?:/|$)#', $path );
	}

	public function guard_public_instructor_profile() {
		if ( is_admin() || ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) ) {
			return;
		}
		$path = strtolower( (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ) );
		if ( preg_match( '#^/instructor(?:/|$)#', $path ) ) {
			wp_safe_redirect( home_url( '/courses/' ), 302 );
			exit;
		}
	}

	public function public_instructor_name( $name, $course_id = 0 ) {
		return is_admin() ? $name : 'Gulf Breeze Driving School';
	}

	public function public_instructor_html( $html, $context = null, $instructor = null, $with_avatar = false ) {
		if ( is_admin() ) {
			return $html;
		}
		$provider = '<span class="gb-course-provider">Gulf Breeze Driving School</span>';
		if ( is_array( $html ) ) {
			return array(
				'wrapper' => '<div class="gb-course-provider-wrap">',
				'content' => $provider,
				'wrapper_end' => '</div>',
			);
		}
		return $provider;
	}

	public function public_course_tabs( $tabs ) {
		if ( ! is_admin() && is_array( $tabs ) ) {
			unset( $tabs['instructor'] );
		}
		return $tabs;
	}

	public function public_author_display_name( $name, $user_id = 0, $original_user_id = 0 ) {
		if ( is_admin() ) {
			return $name;
		}
		$post_id = get_queried_object_id();
		$post_type = $post_id ? get_post_type( $post_id ) : '';
		return in_array( $post_type, array( 'lp_course', 'lp_lesson', 'lp_quiz' ), true ) ? 'Gulf Breeze Driving School' : $name;
	}

	private function language( $user_id = 0 ) {
		$user_id = $user_id ? absint( $user_id ) : get_current_user_id();
		$lang = $user_id ? get_user_meta( $user_id, self::META_LANGUAGE, true ) : '';
		if ( ! $lang && $user_id ) {
			foreach ( array( 'gb_course_language', 'gb_preferred_language', 'preferred_language' ) as $key ) {
				$value = strtolower( (string) get_user_meta( $user_id, $key, true ) );
				if ( in_array( $value, array( 'es', 'spanish', 'espanol', 'español' ), true ) ) {
					$lang = 'es';
					break;
				}
			}
		}
		return 'es' === $lang ? 'es' : 'en';
	}

	private function text( $key, $lang = '' ) {
		$lang = $lang ?: $this->language();
		$copy = array(
			'login' => array( 'en' => 'Please log in to continue.', 'es' => 'Inicia sesión para continuar.' ),
			'why_title' => array( 'en' => 'Protect your student record', 'es' => 'Protege tu expediente de estudiante' ),
			'why' => array( 'en' => 'Texas requires us to confirm that the enrolled student is the person completing the course. An authenticator app creates a six-digit code on your phone. This normally takes about two minutes.', 'es' => 'Texas exige que confirmemos que el estudiante inscrito es quien completa el curso. Una aplicación de autenticación crea un código de seis dígitos en tu teléfono. Normalmente toma unos dos minutos.' ),
			'profile_title' => array( 'en' => 'Step 1: Confirm student information', 'es' => 'Paso 1: Confirma la información del estudiante' ),
			'setup_title' => array( 'en' => 'Step 2: Set up your authenticator', 'es' => 'Paso 2: Configura tu autenticador' ),
			'app_help_title' => array( 'en' => 'First, make sure you have an authenticator app', 'es' => 'Primero, asegúrate de tener una aplicación de autenticación' ),
			'app_help_intro' => array( 'en' => 'An authenticator app is separate from Gulf Breeze. It creates the six-digit code on your phone. We do not send this code by text message or email.', 'es' => 'Una aplicación de autenticación es independiente de Gulf Breeze. Crea el código de seis dígitos en tu teléfono. No enviamos este código por mensaje de texto ni por correo electrónico.' ),
			'app_have' => array( 'en' => 'Already have Google Authenticator, Microsoft Authenticator, or another app that creates six-digit codes? Keep it open and continue below.', 'es' => '¿Ya tienes Google Authenticator, Microsoft Authenticator u otra aplicación que crea códigos de seis dígitos? Déjala abierta y continúa abajo.' ),
			'app_need' => array( 'en' => 'I need to install an authenticator app', 'es' => 'Necesito instalar una aplicación de autenticación' ),
			'app_install_help' => array( 'en' => 'Choose one free app and use the official store button for your phone. After installation, return to this Gulf Breeze page. Keep this page open.', 'es' => 'Elige una aplicación gratuita y usa el botón de la tienda oficial para tu teléfono. Después de instalarla, regresa a esta página de Gulf Breeze. Mantén esta página abierta.' ),
			'app_store' => array( 'en' => 'Apple App Store', 'es' => 'Apple App Store' ),
			'play_store' => array( 'en' => 'Google Play', 'es' => 'Google Play' ),
			'progress_profile' => array( 'en' => 'Student details', 'es' => 'Datos del estudiante' ),
			'progress_app' => array( 'en' => 'Authenticator', 'es' => 'Autenticador' ),
			'progress_recovery' => array( 'en' => 'Recovery codes', 'es' => 'Códigos de recuperación' ),
			'same_phone' => array( 'en' => 'I am using this phone', 'es' => 'Estoy usando este teléfono' ),
			'other_device' => array( 'en' => 'I can scan with another device', 'es' => 'Puedo escanear con otro dispositivo' ),
			'copy_key' => array( 'en' => 'Copy setup key', 'es' => 'Copiar clave de configuración' ),
			'copied' => array( 'en' => 'Copied', 'es' => 'Copiada' ),
			'code_label' => array( 'en' => 'Current six-digit code', 'es' => 'Código actual de seis dígitos' ),
			'code_help' => array( 'en' => 'Open your authenticator app and enter the current code. We did not email or text this code.', 'es' => 'Abre tu aplicación de autenticación e ingresa el código actual. No enviamos este código por correo electrónico ni por mensaje de texto.' ),
			'verify' => array( 'en' => 'Verify and finish setup', 'es' => 'Verificar y terminar la configuración' ),
			'verify_title' => array( 'en' => 'Student identity verification', 'es' => 'Verificación de identidad del estudiante' ),
			'continue' => array( 'en' => 'Continue to my course', 'es' => 'Continuar a mi curso' ),
			'recovery_title' => array( 'en' => 'Save your recovery codes', 'es' => 'Guarda tus códigos de recuperación' ),
			'recovery_help' => array( 'en' => 'Each code works one time. Store them somewhere private. They cannot be shown again.', 'es' => 'Cada código funciona una sola vez. Guárdalos en un lugar privado. No se pueden mostrar de nuevo.' ),
			'copy_all' => array( 'en' => 'Copy all codes', 'es' => 'Copiar todos los códigos' ),
			'download' => array( 'en' => 'Download codes', 'es' => 'Descargar códigos' ),
			'invalid' => array( 'en' => 'That code did not match. Use the newest code shown in your authenticator app and try again.', 'es' => 'Ese código no coincide. Usa el código más reciente que aparece en tu aplicación e inténtalo de nuevo.' ),
			'time_help' => array( 'en' => 'If codes keep failing, make sure your phone date and time are set automatically.', 'es' => 'Si los códigos siguen fallando, verifica que la fecha y hora del teléfono estén configuradas automáticamente.' ),
			'locked' => array( 'en' => 'Too many incorrect attempts. Please wait %d minutes, use a recovery code, or contact student support.', 'es' => 'Hubo demasiados intentos incorrectos. Espera %d minutos, usa un código de recuperación o comunícate con apoyo estudiantil.' ),
			'recovery_link' => array( 'en' => 'Use a recovery code', 'es' => 'Usar un código de recuperación' ),
			'recovery_enter' => array( 'en' => 'Enter one unused recovery code. After it is accepted, you will set up the authenticator again.', 'es' => 'Ingresa un código de recuperación que no hayas usado. Después de aceptarlo, configurarás nuevamente el autenticador.' ),
			'restore' => array( 'en' => 'Restore access', 'es' => 'Restaurar acceso' ),
			'reset_notice' => array( 'en' => 'Your previous verification setup was reset. Delete the old Gulf Breeze entry from your authenticator app before adding the new one.', 'es' => 'Tu configuración anterior fue restablecida. Elimina la entrada anterior de Gulf Breeze de tu aplicación antes de agregar la nueva.' ),
			'trouble_title' => array( 'en' => 'If the code does not work', 'es' => 'Si el código no funciona' ),
			'trouble_steps' => array( 'en' => 'Use the newest code shown in the app and make sure your phone date and time are set automatically. Delete an old Gulf Breeze entry only when this page says your setup was reset.', 'es' => 'Usa el código más reciente que aparece en la aplicación y verifica que la fecha y hora del teléfono estén configuradas automáticamente. Elimina una entrada anterior de Gulf Breeze solamente cuando esta página indique que tu configuración fue restablecida.' ),
		);
		return isset( $copy[ $key ][ $lang ] ) ? $copy[ $key ][ $lang ] : $key;
	}

	public function handle_language_switch() {
		if ( ! is_user_logged_in() || empty( $_GET['gb_mfa_lang'] ) || empty( $_GET['_gblang'] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_gblang'] ) ), 'gb_mfa_lang' ) ) {
			return;
		}
		$lang = 'es' === sanitize_key( $_GET['gb_mfa_lang'] ) ? 'es' : 'en';
		update_user_meta( get_current_user_id(), self::META_LANGUAGE, $lang );
		wp_safe_redirect( remove_query_arg( array( 'gb_mfa_lang', '_gblang' ) ) );
		exit;
	}

	private function language_toggle() {
		$lang = $this->language();
		$target = 'es' === $lang ? 'en' : 'es';
		$label = 'es' === $lang ? 'English' : 'Español';
		$url = wp_nonce_url( add_query_arg( 'gb_mfa_lang', $target ), 'gb_mfa_lang', '_gblang' );
		return '<a class="gb-mfa-language" href="' . esc_url( $url ) . '" hreflang="' . esc_attr( $target ) . '">' . esc_html( $label ) . '</a>';
	}

	private function render_progress( $active, $lang ) {
		$labels = array(
			1 => $this->text( 'progress_profile', $lang ),
			2 => $this->text( 'progress_app', $lang ),
			3 => $this->text( 'progress_recovery', $lang ),
		);
		$html = '<ol class="gb-mfa-progress" aria-label="' . esc_attr( 'es' === $lang ? 'Progreso de configuración' : 'Setup progress' ) . '">';
		foreach ( $labels as $step => $label ) {
			$current = $step === absint( $active ) ? ' aria-current="step"' : '';
			$state = $step < absint( $active ) ? ' is-complete' : ( $step === absint( $active ) ? ' is-current' : '' );
			$html .= '<li class="gb-mfa-progress-item' . $state . '"' . $current . '><span>' . esc_html( $step ) . '</span><small>' . esc_html( $label ) . '</small></li>';
		}
		return $html . '</ol>';
	}

	private function profile_fields() {
		return array(
			'gb_student_legal_name' => array( 'Full legal name', 'Nombre legal completo', 'text' ),
			'gb_student_dob' => array( 'Date of birth', 'Fecha de nacimiento', 'date' ),
			'gb_student_phone' => array( 'Student phone', 'Teléfono del estudiante', 'tel' ),
			'gb_student_address1' => array( 'Street address', 'Domicilio', 'text' ),
			'gb_student_city' => array( 'City', 'Ciudad', 'text' ),
			'gb_student_state' => array( 'State', 'Estado', 'text' ),
			'gb_student_zip' => array( 'ZIP code', 'Código postal', 'text' ),
		);
	}

	private function profile_value( $user_id, $key ) {
		$value = get_user_meta( $user_id, $key, true );
		if ( '' !== (string) $value ) {
			return (string) $value;
		}
		$legacy = array(
			'gb_student_legal_name' => 'ds_student_full_name', 'gb_student_dob' => 'ds_student_dob',
			'gb_student_address1' => 'ds_student_address1', 'gb_student_city' => 'ds_student_city',
			'gb_student_state' => 'ds_student_state', 'gb_student_zip' => 'ds_student_zip',
		);
		return isset( $legacy[ $key ] ) ? (string) get_user_meta( $user_id, $legacy[ $key ], true ) : '';
	}

	private function profile_complete( $user_id ) {
		foreach ( array_keys( $this->profile_fields() ) as $key ) {
			if ( '' === trim( $this->profile_value( $user_id, $key ) ) ) {
				return false;
			}
		}
		return true;
	}

	private function save_profile( $user_id ) {
		$errors = array();
		foreach ( $this->profile_fields() as $key => $definition ) {
			$value = isset( $_POST[ $key ] ) ? trim( sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) ) : '';
			if ( '' === $value ) {
				$errors[] = $key;
				continue;
			}
			if ( 'gb_student_dob' === $key && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ) {
				$errors[] = $key;
				continue;
			}
			if ( 'gb_student_state' === $key && ! preg_match( '/^[A-Za-z]{2}$/', $value ) ) {
				$errors[] = $key;
				continue;
			}
			if ( 'gb_student_zip' === $key && ! preg_match( '/^\d{5}(?:-\d{4})?$/', $value ) ) {
				$errors[] = $key;
				continue;
			}
			update_user_meta( $user_id, $key, 'gb_student_state' === $key ? strtoupper( $value ) : $value );
		}
		if ( ! $errors ) {
			update_user_meta( $user_id, 'gb_identity_profile_updated_at_utc', gmdate( 'Y-m-d H:i:s' ) );
			$this->log_event( $user_id, 'profile_confirmed', 'success', 'profile', '' );
		} else {
			$this->log_event( $user_id, 'profile_rejected', 'blocked', 'profile', 'Required student information was missing or invalid.', array( 'fields' => $errors ) );
		}
		return $errors;
	}

	private function key_material() {
		$source = ( defined( 'AUTH_KEY' ) ? AUTH_KEY : '' ) . ( defined( 'SECURE_AUTH_KEY' ) ? SECURE_AUTH_KEY : '' ) . ( defined( 'LOGGED_IN_SALT' ) ? LOGGED_IN_SALT : '' );
		return $source ? hash( 'sha256', $source . '|gulf-breeze-mfa-v2', true ) : '';
	}

	private function encrypt( $plain ) {
		$key = $this->key_material();
		if ( ! $key || ! function_exists( 'openssl_encrypt' ) ) {
			return '';
		}
		$iv = random_bytes( 12 );
		$tag = '';
		$cipher = openssl_encrypt( $plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, 'gb-mfa-v2', 16 );
		return false === $cipher ? '' : 'v2:' . base64_encode( $iv . $tag . $cipher );
	}

	private function decrypt( $encoded ) {
		if ( 0 !== strpos( (string) $encoded, 'v2:' ) ) {
			return '';
		}
		$raw = base64_decode( substr( $encoded, 3 ), true );
		$key = $this->key_material();
		if ( false === $raw || strlen( $raw ) < 29 || ! $key ) {
			return '';
		}
		$iv = substr( $raw, 0, 12 );
		$tag = substr( $raw, 12, 16 );
		$cipher = substr( $raw, 28 );
		$plain = openssl_decrypt( $cipher, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, 'gb-mfa-v2' );
		return false === $plain ? '' : $plain;
	}

	private function generate_secret( $length = 32 ) {
		$alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
		$secret = '';
		for ( $i = 0; $i < $length; $i++ ) {
			$secret .= $alphabet[ random_int( 0, 31 ) ];
		}
		return $secret;
	}

	private function base32_decode( $value ) {
		$value = strtoupper( preg_replace( '/[^A-Z2-7]/', '', (string) $value ) );
		$alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
		$bits = '';
		for ( $i = 0; $i < strlen( $value ); $i++ ) {
			$bits .= str_pad( decbin( strpos( $alphabet, $value[ $i ] ) ), 5, '0', STR_PAD_LEFT );
		}
		$bytes = '';
		for ( $i = 0; $i + 8 <= strlen( $bits ); $i += 8 ) {
			$bytes .= chr( bindec( substr( $bits, $i, 8 ) ) );
		}
		return $bytes;
	}

	private function totp( $secret, $timestamp ) {
		$counter = (int) floor( $timestamp / 30 );
		$message = pack( 'N*', 0 ) . pack( 'N*', $counter );
		$hash = hash_hmac( 'sha1', $message, $this->base32_decode( $secret ), true );
		$offset = ord( substr( $hash, -1 ) ) & 0x0f;
		$value = unpack( 'N', substr( $hash, $offset, 4 ) )[1] & 0x7fffffff;
		return str_pad( (string) ( $value % 1000000 ), 6, '0', STR_PAD_LEFT );
	}

	private function verify_totp( $secret, $code ) {
		$code = preg_replace( '/\D/', '', (string) $code );
		if ( ! preg_match( '/^\d{6}$/', $code ) ) {
			return false;
		}
		$now = time();
		for ( $window = -1; $window <= 1; $window++ ) {
			if ( hash_equals( $this->totp( $secret, $now + ( $window * 30 ) ), $code ) ) {
				return true;
			}
		}
		return false;
	}

	private function session_hash() {
		$token = function_exists( 'wp_get_session_token' ) ? wp_get_session_token() : '';
		return $token ? hash_hmac( 'sha256', $token, wp_salt( 'auth' ) ) : '';
	}

	private function has_enrolled( $user_id ) {
		return '' !== (string) get_user_meta( $user_id, self::META_SECRET, true );
	}

	public function is_verified( $user_id = 0, $fresh_minutes = 0 ) {
		$user_id = $user_id ? absint( $user_id ) : get_current_user_id();
		if ( $this->is_owner_immune( $user_id ) ) {
			return true;
		}
		if ( ! $user_id || time() >= absint( get_user_meta( $user_id, self::META_VERIFIED_UNTIL, true ) ) ) {
			return false;
		}
		if ( ! hash_equals( (string) get_user_meta( $user_id, self::META_SESSION, true ), $this->session_hash() ) ) {
			return false;
		}
		$verified_at = absint( get_user_meta( $user_id, self::META_VERIFIED_AT, true ) );
		return ! $fresh_minutes || $verified_at >= time() - ( absint( $fresh_minutes ) * 60 );
	}

	public function filter_is_verified( $verified, $user_id ) {
		return $this->is_verified( $user_id );
	}

	public function filter_require_recent( $verified, $user_id, $minutes ) {
		return $this->is_verified( $user_id, $minutes );
	}

	private function mark_verified( $user_id, $method, $context = array() ) {
		$settings = $this->settings();
		$now = time();
		update_user_meta( $user_id, self::META_VERIFIED_AT, $now );
		update_user_meta( $user_id, self::META_VERIFIED_UNTIL, $now + absint( $settings['verify_ttl_minutes'] ) * 60 );
		update_user_meta( $user_id, self::META_SESSION, $this->session_hash() );
		delete_user_meta( $user_id, self::META_FAILS );
		delete_user_meta( $user_id, self::META_LOCK );
		$this->log_event( $user_id, 'mfa_verified', 'success', $method, '', $context );
	}

	private function fail_attempt( $user_id, $context = array() ) {
		$settings = $this->settings();
		$fails = absint( get_user_meta( $user_id, self::META_FAILS, true ) ) + 1;
		if ( $fails >= absint( $settings['max_attempts'] ) ) {
			update_user_meta( $user_id, self::META_LOCK, time() + absint( $settings['lock_minutes'] ) * 60 );
			delete_user_meta( $user_id, self::META_FAILS );
			$this->log_event( $user_id, 'mfa_lockout', 'locked', 'totp', 'Maximum verification attempts reached.', $context );
			return;
		}
		update_user_meta( $user_id, self::META_FAILS, $fails );
		$this->log_event( $user_id, 'mfa_verification_failed', 'failed', 'totp', 'Code did not match.', $context );
	}

	private function is_locked( $user_id ) {
		return time() < absint( get_user_meta( $user_id, self::META_LOCK, true ) );
	}

	private function safe_return( $fallback = '' ) {
		$fallback = $fallback ?: home_url( '/my-account/' );
		$value = isset( $_REQUEST['return'] ) ? rawurldecode( sanitize_text_field( wp_unslash( $_REQUEST['return'] ) ) ) : '';
		return wp_validate_redirect( $value, $fallback );
	}

	private function enrollment_url( $return = '' ) {
		$url = home_url( '/mfa-enroll/' );
		return $return ? add_query_arg( 'return', rawurlencode( $return ), $url ) : $url;
	}

	private function verification_url( $return = '' ) {
		$url = home_url( '/mfa-verify/' );
		return $return ? add_query_arg( 'return', rawurlencode( $return ), $url ) : $url;
	}

	private function current_url() {
		$host = sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ?? '' ) );
		$uri = esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ?? '/' ) );
		return ( is_ssl() ? 'https://' : 'http://' ) . $host . $uri;
	}

	private function protected_context() {
		$post_id = get_queried_object_id();
		$type = $post_id ? get_post_type( $post_id ) : '';
		$protected = in_array( $type, array( 'lp_course', 'lp_lesson', 'lp_quiz' ), true );
		$path = strtolower( (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ) );
		if ( preg_match( '#/(certificates?|course-certificate|student-certificate)(/|$)#', $path ) ) {
			$protected = true;
		}
		if ( $this->is_student_account_path( $path ) && $this->student_requires_mfa() ) {
			$protected = true;
		}
		$protected = (bool) apply_filters( 'gb_mfa_protected_request', $protected, $post_id, $type, $path );
		$course_id = 'lp_course' === $type ? $post_id : 0;
		if ( ! $course_id && function_exists( 'learn_press_get_course_id' ) && $post_id ) {
			$course_id = absint( learn_press_get_course_id( $post_id ) );
		}
		$fresh = 'lp_quiz' === $type && in_array( get_post_meta( $post_id, '_gb_mfa_checkpoint', true ), array( 'permit_exam', 'final_exam', 'certificate' ), true );
		return array( 'protected' => $protected, 'post_id' => absint( $post_id ), 'course_id' => absint( $course_id ), 'fresh' => $fresh );
	}

	public function guard_frontend() {
		if ( is_admin() || ! is_user_logged_in() || $this->is_owner_immune() ) {
			return;
		}
		if ( is_page( array( 'mfa-enroll', 'mfa-verify', 'mfa-recovery' ) ) ) {
			return;
		}
		$context = $this->protected_context();
		if ( ! $context['protected'] ) {
			return;
		}
		$user_id = get_current_user_id();
		$return = $this->current_url();
		if ( ! $this->has_enrolled( $user_id ) ) {
			$this->log_event( $user_id, 'mfa_required', 'blocked', 'enrollment', 'Protected course access requires enrollment.', $context );
			wp_safe_redirect( $this->enrollment_url( $return ) );
			exit;
		}
		$fresh_minutes = $context['fresh'] ? absint( $this->settings()['checkpoint_minutes'] ) : 0;
		if ( $this->is_locked( $user_id ) || ! $this->is_verified( $user_id, $fresh_minutes ) ) {
			$this->log_event( $user_id, 'mfa_challenge', 'required', $context['fresh'] ? 'checkpoint' : 'session', '', $context );
			wp_safe_redirect( $this->verification_url( $return ) );
			exit;
		}
	}

	public function guard_login_redirect( $redirect_to, $requested, $user ) {
		if ( ! $user instanceof WP_User || $this->is_owner_immune( $user->ID ) ) {
			return $redirect_to;
		}
		if ( $this->student_requires_mfa( $user->ID ) && ! $this->is_verified( $user->ID ) ) {
			return $this->has_enrolled( $user->ID ) ? $this->verification_url( $requested ?: $redirect_to ) : $this->enrollment_url( $requested ?: $redirect_to );
		}
		return $redirect_to;
	}

	public function guard_rest( $result, $server, $request ) {
		if ( ! is_user_logged_in() || $this->is_owner_immune() ) {
			return $result;
		}
		$route = strtolower( $request->get_route() );
		$protected = (bool) preg_match( '#/(learnpress|lp|gulf-breeze)/(.*)(course|lesson|quiz|progress|seat|certificate)#', $route );
		$protected = (bool) apply_filters( 'gb_mfa_protected_rest_route', $protected, $route, $request );
		if ( $protected && ! $this->is_verified() ) {
			$this->log_event( get_current_user_id(), 'rest_access_blocked', 'blocked', 'session', 'Unverified protected REST request.', array( 'route' => $route ) );
			return new WP_Error( 'gb_mfa_required', 'Student verification is required.', array( 'status' => 403, 'verify_url' => $this->verification_url() ) );
		}
		return $result;
	}

	public function guard_direct_actions() {
		if ( ! is_user_logged_in() || $this->is_owner_immune() ) {
			return;
		}
		$action = sanitize_key( $_REQUEST['action'] ?? '' );
		if ( ! $action ) {
			return;
		}
		$exact = array( 'gb_seat_start', 'gb_seat_heartbeat', 'gb_seat_complete', 'gb_cert_download' );
		$protected = in_array( $action, $exact, true ) || (bool) preg_match( '/(learnpress|course|lesson|quiz|progress|certificate)/', $action );
		$protected = (bool) apply_filters( 'gb_mfa_protected_action', $protected, $action );
		if ( $protected && ! $this->is_verified() ) {
			$this->log_event( get_current_user_id(), 'direct_action_blocked', 'blocked', 'session', 'Unverified protected action.', array( 'action' => $action ) );
			if ( wp_doing_ajax() ) {
				wp_send_json_error( array( 'message' => 'Student verification is required.', 'verify_url' => $this->verification_url() ), 403 );
			}
			wp_safe_redirect( $this->verification_url( wp_get_referer() ?: home_url( '/' ) ) );
			exit;
		}
	}

	public function clear_logout_verification( $user_id = 0 ) {
		$user_id = absint( $user_id );
		if ( ! $user_id ) {
			return;
		}
		delete_user_meta( $user_id, self::META_VERIFIED_AT );
		delete_user_meta( $user_id, self::META_VERIFIED_UNTIL );
		delete_user_meta( $user_id, self::META_SESSION );
	}

	public function mark_known_exam_checkpoints() {
		if ( get_option( 'gb_mfa_known_checkpoint_version' ) === self::VERSION ) {
			return;
		}
		$finals = get_posts( array(
			'post_type' => 'lp_quiz', 'post_status' => array( 'draft', 'pending', 'private', 'publish' ),
			'meta_key' => '_gb_assessment_key', 'meta_value' => 'adult_en_final',
			'posts_per_page' => 20, 'fields' => 'ids',
		) );
		foreach ( $finals as $quiz_id ) {
			update_post_meta( absint( $quiz_id ), '_gb_mfa_checkpoint', 'final_exam' );
		}
		if ( $finals ) {
			update_option( 'gb_mfa_known_checkpoint_version', self::VERSION, false );
		}
	}

	public function enqueue_assets() {
		if ( ! is_page( array( 'mfa-enroll', 'mfa-verify', 'mfa-recovery' ) ) ) {
			return;
		}
		wp_enqueue_style( 'gb-mfa', plugin_dir_url( __FILE__ ) . 'assets/mfa.css', array(), self::VERSION );
		wp_enqueue_script( 'jquery-qrcode', plugin_dir_url( __FILE__ ) . 'assets/jquery.qrcode.min.js', array( 'jquery' ), '1.0', true );
		wp_enqueue_script( 'gb-mfa', plugin_dir_url( __FILE__ ) . 'assets/mfa.js', array( 'jquery-qrcode' ), self::VERSION, true );
		wp_localize_script( 'gb-mfa', 'GBMFA', array( 'copied' => $this->text( 'copied' ), 'downloadName' => 'gulf-breeze-recovery-codes.txt' ) );
	}

	private function render_profile_form( $errors = array() ) {
		$user_id = get_current_user_id();
		$lang = $this->language();
		$html = '<section class="gb-mfa-card">' . $this->render_progress( 1, $lang ) . '<h2>' . esc_html( $this->text( 'profile_title', $lang ) ) . '</h2>';
		if ( $errors ) {
			$html .= '<div class="gb-mfa-error" role="alert">' . esc_html( 'es' === $lang ? 'Completa correctamente todos los campos.' : 'Please complete every field correctly.' ) . '</div>';
		}
		$html .= '<form method="post" class="gb-mfa-form"><input type="hidden" name="gb_mfa_action" value="save_profile">';
		$html .= wp_nonce_field( 'gb_mfa_profile', 'gb_mfa_nonce', true, false );
		foreach ( $this->profile_fields() as $key => $definition ) {
			$label = 'es' === $lang ? $definition[1] : $definition[0];
			$value = $this->profile_value( $user_id, $key );
			$extra = 'gb_student_state' === $key ? ' maxlength="2" autocapitalize="characters"' : ( 'gb_student_zip' === $key ? ' inputmode="numeric"' : '' );
			$html .= '<label><span>' . esc_html( $label ) . '</span><input type="' . esc_attr( $definition[2] ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" required' . $extra . '></label>';
		}
		$html .= '<button class="gb-mfa-primary" type="submit">' . esc_html( 'es' === $lang ? 'Guardar y continuar' : 'Save and continue' ) . '</button></form></section>';
		return $html;
	}

	private function render_recovery_codes( $codes, $return ) {
		$lang = $this->language();
		$plain = implode( "\n", $codes );
		$html = '<div class="gb-mfa-shell">' . $this->language_toggle() . '<section class="gb-mfa-card gb-mfa-success">' . $this->render_progress( 3, $lang );
		$html .= '<div class="gb-mfa-step">✓</div><h1>' . esc_html( $this->text( 'recovery_title', $lang ) ) . '</h1><p>' . esc_html( $this->text( 'recovery_help', $lang ) ) . '</p>';
		$html .= '<pre id="gb-mfa-recovery-codes" class="gb-mfa-codes">' . esc_html( $plain ) . '</pre>';
		$html .= '<div class="gb-mfa-actions"><button type="button" class="gb-mfa-secondary" data-copy-target="#gb-mfa-recovery-codes">' . esc_html( $this->text( 'copy_all', $lang ) ) . '</button>';
		$html .= '<button type="button" class="gb-mfa-secondary" data-download-target="#gb-mfa-recovery-codes">' . esc_html( $this->text( 'download', $lang ) ) . '</button></div>';
		$html .= '<a class="gb-mfa-primary gb-mfa-link-button" href="' . esc_url( $return ) . '">' . esc_html( $this->text( 'continue', $lang ) ) . '</a></section></div>';
		return $html;
	}

	public function shortcode_enroll() {
		if ( ! is_user_logged_in() ) {
			return '<p>' . esc_html( $this->text( 'login' ) ) . '</p>';
		}
		if ( $this->is_owner_immune() ) {
			return '<p>Owner account is permanently exempt from student MFA.</p>';
		}
		$user_id = get_current_user_id();
		$lang = $this->language();
		$return = $this->safe_return();
		$errors = array();
		if ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) && 'save_profile' === ( $_POST['gb_mfa_action'] ?? '' ) ) {
			if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['gb_mfa_nonce'] ?? '' ) ), 'gb_mfa_profile' ) ) {
				$errors[] = 'nonce';
			} else {
				$errors = $this->save_profile( $user_id );
			}
		}
		if ( ! $this->profile_complete( $user_id ) ) {
			return '<div class="gb-mfa-shell">' . $this->language_toggle() . '<section class="gb-mfa-card"><h1>' . esc_html( $this->text( 'why_title', $lang ) ) . '</h1><p>' . esc_html( $this->text( 'why', $lang ) ) . '</p></section>' . $this->render_profile_form( $errors ) . '</div>';
		}
		if ( $this->has_enrolled( $user_id ) ) {
			return $this->is_verified( $user_id ) ? '<div class="gb-mfa-shell"><section class="gb-mfa-card"><h1>✓</h1><p>' . esc_html( 'es' === $lang ? 'La verificación ya está configurada.' : 'Verification is already set up.' ) . '</p><a class="gb-mfa-primary gb-mfa-link-button" href="' . esc_url( $return ) . '">' . esc_html( $this->text( 'continue', $lang ) ) . '</a></section></div>' : '<script>location.href=' . wp_json_encode( $this->verification_url( $return ) ) . ';</script>';
		}
		$pending = $this->decrypt( get_user_meta( $user_id, self::META_PENDING, true ) );
		if ( ! $pending ) {
			$pending = $this->generate_secret();
			$encrypted = $this->encrypt( $pending );
			if ( ! $encrypted ) {
				return '<div class="gb-mfa-error">Secure verification storage is unavailable. Course access remains blocked.</div>';
			}
			update_user_meta( $user_id, self::META_PENDING, $encrypted );
			$this->log_event( $user_id, 'mfa_enrollment_started', 'started', 'totp', '' );
		}
		$error = '';
		if ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) && 'confirm_totp' === ( $_POST['gb_mfa_action'] ?? '' ) ) {
			if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['gb_mfa_nonce'] ?? '' ) ), 'gb_mfa_enroll' ) ) {
				$error = 'session';
			} elseif ( $this->verify_totp( $pending, $_POST['gb_mfa_code'] ?? '' ) ) {
				$encrypted = $this->encrypt( $pending );
				if ( ! $encrypted ) {
					return '<div class="gb-mfa-error">Secure verification storage is unavailable. Course access remains blocked.</div>';
				}
				update_user_meta( $user_id, self::META_SECRET, $encrypted );
				update_user_meta( $user_id, self::META_CREATED, gmdate( 'Y-m-d H:i:s' ) );
				delete_user_meta( $user_id, self::META_PENDING );
				delete_user_meta( $user_id, self::META_RESET_NOTICE );
				$codes = $this->new_recovery_codes( $user_id );
				$this->mark_verified( $user_id, 'totp-enrollment' );
				$this->log_event( $user_id, 'mfa_enrolled', 'success', 'totp', 'Authenticator enrollment completed.' );
				return $this->render_recovery_codes( $codes, $return );
			} else {
				$error = 'invalid';
				$this->fail_attempt( $user_id, array( 'stage' => 'enrollment' ) );
			}
		}
		$user = wp_get_current_user();
		$issuer = 'Gulf Breeze Driving School';
		$label = $issuer . ':' . $user->user_email;
		$otpauth = 'otpauth://totp/' . rawurlencode( $label ) . '?secret=' . rawurlencode( $pending ) . '&issuer=' . rawurlencode( $issuer ) . '&algorithm=SHA1&digits=6&period=30';
		$reset = get_user_meta( $user_id, self::META_RESET_NOTICE, true );
		$html = '<div class="gb-mfa-shell">' . $this->language_toggle();
		$html .= '<section class="gb-mfa-card"><h1>' . esc_html( $this->text( 'why_title', $lang ) ) . '</h1><p>' . esc_html( $this->text( 'why', $lang ) ) . '</p></section>';
		$html .= '<section class="gb-mfa-card">' . $this->render_progress( 2, $lang ) . '<h2>' . esc_html( $this->text( 'setup_title', $lang ) ) . '</h2>';
		if ( $reset ) {
			$html .= '<div class="gb-mfa-warning" role="status">' . esc_html( $this->text( 'reset_notice', $lang ) ) . '</div>';
		}
		if ( $error ) {
			$html .= '<div class="gb-mfa-error" role="alert">' . esc_html( 'session' === $error ? ( 'es' === $lang ? 'La sesión venció. Actualiza la página.' : 'Your session expired. Refresh the page.' ) : $this->text( 'invalid', $lang ) ) . '</div>';
		}
		$html .= '<aside class="gb-mfa-app-guide"><h3>' . esc_html( $this->text( 'app_help_title', $lang ) ) . '</h3><p>' . esc_html( $this->text( 'app_help_intro', $lang ) ) . '</p><p>' . esc_html( $this->text( 'app_have', $lang ) ) . '</p><details><summary>' . esc_html( $this->text( 'app_need', $lang ) ) . '</summary><p>' . esc_html( $this->text( 'app_install_help', $lang ) ) . '</p><div class="gb-mfa-app-options">';
		$stores = array(
			'Google Authenticator' => array( 'https://apps.apple.com/us/app/google-authenticator/id388497605', 'https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2' ),
			'Microsoft Authenticator' => array( 'https://apps.apple.com/us/app/microsoft-authenticator/id983156458', 'https://play.google.com/store/apps/details?id=com.azure.authenticator' ),
		);
		foreach ( $stores as $app => $links ) {
			$html .= '<div class="gb-mfa-app-option"><strong>' . esc_html( $app ) . '</strong><div><a class="gb-mfa-store" href="' . esc_url( $links[0] ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $this->text( 'app_store', $lang ) ) . '</a><a class="gb-mfa-store" href="' . esc_url( $links[1] ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $this->text( 'play_store', $lang ) ) . '</a></div></div>';
		}
		$html .= '</div></details></aside>';
		$html .= '<div class="gb-mfa-methods" role="tablist"><button type="button" class="gb-mfa-method is-active" data-mfa-panel="same-phone" role="tab" aria-controls="same-phone" aria-selected="true">' . esc_html( $this->text( 'same_phone', $lang ) ) . '</button><button type="button" class="gb-mfa-method" data-mfa-panel="scan-code" role="tab" aria-controls="scan-code" aria-selected="false">' . esc_html( $this->text( 'other_device', $lang ) ) . '</button></div>';
		$html .= '<div id="same-phone" class="gb-mfa-panel is-active" role="tabpanel"><ol><li>' . esc_html( 'es' === $lang ? 'Instala o abre Google Authenticator, Microsoft Authenticator u otra aplicación de autenticación.' : 'Install or open Google Authenticator, Microsoft Authenticator, or another authenticator app.' ) . '</li><li>' . esc_html( 'es' === $lang ? 'En Google, toca + y luego Ingresar una clave de configuración. En Microsoft, toca +, Otra cuenta y luego ingresa el código manualmente.' : 'In Google, tap +, then Enter a setup key. In Microsoft, tap +, Other account, then enter the code manually.' ) . '</li><li>' . esc_html( 'es' === $lang ? 'Usa Gulf Breeze Driving School como nombre de la cuenta.' : 'Use Gulf Breeze Driving School as the account name.' ) . '</li><li>' . esc_html( 'es' === $lang ? 'Toca Copiar clave de configuración abajo y pégala en la aplicación.' : 'Tap Copy setup key below, then paste it into the app.' ) . '</li><li>' . esc_html( 'es' === $lang ? 'Si la aplicación pregunta, elige Basada en tiempo.' : 'If the app asks, choose Time based.' ) . '</li><li>' . esc_html( 'es' === $lang ? 'Regresa a esta página e ingresa el código actual de seis dígitos.' : 'Return to this page and enter the current six-digit code.' ) . '</li></ol><div class="gb-mfa-key-row"><code id="gb-mfa-setup-key">' . esc_html( $pending ) . '</code><button type="button" class="gb-mfa-secondary" data-copy-target="#gb-mfa-setup-key">' . esc_html( $this->text( 'copy_key', $lang ) ) . '</button></div></div>';
		$html .= '<div id="scan-code" class="gb-mfa-panel" role="tabpanel" hidden><ol><li>' . esc_html( 'es' === $lang ? 'Abre la aplicación de autenticación en el otro dispositivo.' : 'Open the authenticator app on the other device.' ) . '</li><li>' . esc_html( 'es' === $lang ? 'Toca + y selecciona Escanear código QR.' : 'Tap + and choose Scan a QR code.' ) . '</li><li>' . esc_html( 'es' === $lang ? 'Escanea este código y luego regresa aquí.' : 'Scan this code, then return here.' ) . '</li></ol><div id="gb-mfa-qr" class="gb-mfa-qr" data-otpauth="' . esc_attr( $otpauth ) . '"></div><details><summary>' . esc_html( 'es' === $lang ? '¿No puedes escanear?' : 'Cannot scan?' ) . '</summary><div class="gb-mfa-key-row"><code>' . esc_html( $pending ) . '</code></div></details></div>';
		$html .= '<form method="post" class="gb-mfa-form gb-mfa-code-form"><input type="hidden" name="gb_mfa_action" value="confirm_totp"><input type="hidden" name="return" value="' . esc_attr( $return ) . '">' . wp_nonce_field( 'gb_mfa_enroll', 'gb_mfa_nonce', true, false );
		$html .= '<label><span>' . esc_html( $this->text( 'code_label', $lang ) ) . '</span><input class="gb-mfa-code" type="text" name="gb_mfa_code" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9 ]{6,8}" maxlength="8" required></label><p class="gb-mfa-help">' . esc_html( $this->text( 'code_help', $lang ) ) . '</p><button class="gb-mfa-primary" type="submit">' . esc_html( $this->text( 'verify', $lang ) ) . '</button></form><aside class="gb-mfa-trouble"><strong>' . esc_html( $this->text( 'trouble_title', $lang ) ) . '</strong><p>' . esc_html( $this->text( 'trouble_steps', $lang ) ) . '</p></aside></section></div>';
		return $html;
	}

	private function new_recovery_codes( $user_id ) {
		$codes = array();
		$hashes = array();
		for ( $i = 0; $i < 8; $i++ ) {
			$raw = strtoupper( wp_generate_password( 10, false, false ) );
			$code = substr( $raw, 0, 5 ) . '-' . substr( $raw, 5, 5 );
			$codes[] = $code;
			$hashes[] = wp_hash_password( $code );
		}
		update_user_meta( $user_id, self::META_RECOVERY, $hashes );
		$this->log_event( $user_id, 'recovery_codes_issued', 'success', 'recovery', 'Eight single-use recovery codes issued.' );
		return $codes;
	}

	public function shortcode_verify() {
		if ( ! is_user_logged_in() ) {
			return '<p>' . esc_html( $this->text( 'login' ) ) . '</p>';
		}
		if ( $this->is_owner_immune() ) {
			return '<p>Owner account is permanently exempt from student MFA.</p>';
		}
		$user_id = get_current_user_id();
		$return = $this->safe_return();
		if ( ! $this->has_enrolled( $user_id ) ) {
			wp_safe_redirect( $this->enrollment_url( $return ) );
			exit;
		}
		$lang = $this->language();
		$error = '';
		if ( $this->is_locked( $user_id ) ) {
			$minutes = max( 1, (int) ceil( ( absint( get_user_meta( $user_id, self::META_LOCK, true ) ) - time() ) / 60 ) );
			$error = sprintf( $this->text( 'locked', $lang ), $minutes );
		} elseif ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) && 'verify_totp' === ( $_POST['gb_mfa_action'] ?? '' ) ) {
			if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['gb_mfa_nonce'] ?? '' ) ), 'gb_mfa_verify' ) ) {
				$error = 'es' === $lang ? 'La sesión venció. Actualiza la página.' : 'Your session expired. Refresh the page.';
			} else {
				$secret = $this->decrypt( get_user_meta( $user_id, self::META_SECRET, true ) );
				if ( $secret && $this->verify_totp( $secret, $_POST['gb_mfa_code'] ?? '' ) ) {
					$this->mark_verified( $user_id, 'totp', array( 'return_url' => $return ) );
					wp_safe_redirect( $return );
					exit;
				}
				$this->fail_attempt( $user_id, array( 'return_url' => $return ) );
				$error = $this->text( 'invalid', $lang );
			}
		}
		if ( $this->is_verified( $user_id ) ) {
			wp_safe_redirect( $return );
			exit;
		}
		$html = '<div class="gb-mfa-shell">' . $this->language_toggle() . '<section class="gb-mfa-card"><h1>' . esc_html( $this->text( 'verify_title', $lang ) ) . '</h1><p>' . esc_html( $this->text( 'code_help', $lang ) ) . '</p>';
		if ( $error ) {
			$html .= '<div class="gb-mfa-error" role="alert">' . esc_html( $error ) . '</div>';
		}
		$html .= '<form method="post" class="gb-mfa-form gb-mfa-code-form"><input type="hidden" name="gb_mfa_action" value="verify_totp"><input type="hidden" name="return" value="' . esc_attr( $return ) . '">' . wp_nonce_field( 'gb_mfa_verify', 'gb_mfa_nonce', true, false );
		$html .= '<label><span>' . esc_html( $this->text( 'code_label', $lang ) ) . '</span><input class="gb-mfa-code" type="text" name="gb_mfa_code" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9 ]{6,8}" maxlength="8" autofocus required></label><p class="gb-mfa-help">' . esc_html( $this->text( 'time_help', $lang ) ) . '</p><button class="gb-mfa-primary" type="submit">' . esc_html( 'es' === $lang ? 'Verificar y continuar' : 'Verify and continue' ) . '</button></form><a class="gb-mfa-recovery-link" href="' . esc_url( add_query_arg( 'return', rawurlencode( $return ), home_url( '/mfa-recovery/' ) ) ) . '">' . esc_html( $this->text( 'recovery_link', $lang ) ) . '</a></section></div>';
		return $html;
	}

	public function shortcode_recovery() {
		if ( ! is_user_logged_in() ) {
			return '<p>' . esc_html( $this->text( 'login' ) ) . '</p>';
		}
		if ( $this->is_owner_immune() ) {
			return '<p>Owner account is permanently exempt from student MFA.</p>';
		}
		$user_id = get_current_user_id();
		$lang = $this->language();
		$return = $this->safe_return();
		$error = '';
		if ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) && 'use_recovery' === ( $_POST['gb_mfa_action'] ?? '' ) ) {
			if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['gb_mfa_nonce'] ?? '' ) ), 'gb_mfa_recovery' ) ) {
				$error = 'es' === $lang ? 'La sesión venció.' : 'Your session expired.';
			} else {
				$code = strtoupper( trim( sanitize_text_field( wp_unslash( $_POST['gb_mfa_recovery_code'] ?? '' ) ) ) );
				$hashes = (array) get_user_meta( $user_id, self::META_RECOVERY, true );
				$matched = false;
				foreach ( $hashes as $index => $hash ) {
					if ( wp_check_password( $code, $hash, $user_id ) ) {
						unset( $hashes[ $index ] );
						$matched = true;
						break;
					}
				}
				if ( $matched ) {
					update_user_meta( $user_id, self::META_RECOVERY, array_values( $hashes ) );
					delete_user_meta( $user_id, self::META_SECRET );
					delete_user_meta( $user_id, self::META_PENDING );
					delete_user_meta( $user_id, self::META_VERIFIED_AT );
					delete_user_meta( $user_id, self::META_VERIFIED_UNTIL );
					delete_user_meta( $user_id, self::META_SESSION );
					update_user_meta( $user_id, self::META_RESET_NOTICE, 1 );
					$this->log_event( $user_id, 'mfa_recovery_used', 'success', 'recovery', 'Single-use recovery code accepted; re-enrollment required.' );
					nocache_headers();
					wp_safe_redirect( $this->enrollment_url( $return ), 303 );
					exit;
				}
				$this->log_event( $user_id, 'mfa_recovery_failed', 'failed', 'recovery', 'Recovery code did not match.' );
				$error = 'es' === $lang ? 'Ese código no es válido o ya fue usado.' : 'That recovery code is invalid or has already been used.';
			}
		}
		$html = '<div class="gb-mfa-shell">' . $this->language_toggle() . '<section class="gb-mfa-card"><h1>' . esc_html( $this->text( 'recovery_link', $lang ) ) . '</h1><p>' . esc_html( $this->text( 'recovery_enter', $lang ) ) . '</p>';
		if ( $error ) {
			$html .= '<div class="gb-mfa-error" role="alert">' . esc_html( $error ) . '</div>';
		}
		$html .= '<form method="post" class="gb-mfa-form"><input type="hidden" name="gb_mfa_action" value="use_recovery"><input type="hidden" name="return" value="' . esc_attr( $return ) . '">' . wp_nonce_field( 'gb_mfa_recovery', 'gb_mfa_nonce', true, false ) . '<label><span>' . esc_html( 'es' === $lang ? 'Código de recuperación' : 'Recovery code' ) . '</span><input type="text" name="gb_mfa_recovery_code" autocomplete="one-time-code" required></label><button class="gb-mfa-primary" type="submit">' . esc_html( $this->text( 'restore', $lang ) ) . '</button></form></section></div>';
		return $html;
	}

	private function log_event( $user_id, $event, $result, $method, $reason = '', $context = array(), $actor_id = 0 ) {
		global $wpdb;
		$course_id = absint( $context['course_id'] ?? 0 );
		$item_id = absint( $context['item_id'] ?? ( $context['post_id'] ?? 0 ) );
		$wpdb->insert( $this->events_table, array(
			'user_id' => absint( $user_id ), 'event_type' => sanitize_key( $event ),
			'result' => sanitize_key( $result ), 'method' => sanitize_key( $method ),
			'reason' => sanitize_textarea_field( $reason ), 'course_id' => $course_id ?: null,
			'item_id' => $item_id ?: null, 'actor_user_id' => $actor_id ? absint( $actor_id ) : null,
			'ip_address' => substr( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '' ) ), 0, 64 ),
			'user_agent' => substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ?? '' ) ), 0, 255 ),
			'language' => $this->language( $user_id ),
			'context_json' => wp_json_encode( $this->sanitize_context( $context ) ),
			'created_at_utc' => gmdate( 'Y-m-d H:i:s' ),
		), array( '%d', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s' ) );
		do_action( 'gb_mfa_event_recorded', absint( $user_id ), sanitize_key( $event ), $context );
	}

	private function sanitize_context( $context ) {
		$allowed = array( 'course_id', 'item_id', 'post_id', 'route', 'action', 'stage', 'return_url', 'fields', 'checkpoint' );
		$clean = array();
		foreach ( $allowed as $key ) {
			if ( ! isset( $context[ $key ] ) ) {
				continue;
			}
			$value = $context[ $key ];
			$clean[ $key ] = is_array( $value ) ? array_map( 'sanitize_key', $value ) : sanitize_text_field( (string) $value );
		}
		return $clean;
	}

	public function admin_menu() {
		add_menu_page( 'Student Compliance', 'Student Compliance', self::CAP_AUDIT, 'gb-student-compliance', array( $this, 'render_admin_audit' ), 'dashicons-shield-alt', 58 );
		add_submenu_page( 'gb-student-compliance', 'MFA Settings', 'MFA Settings', 'manage_options', 'gb-mfa-settings', array( $this, 'render_settings' ) );
	}

	private function admin_action_form( $user_id, $action, $label, $danger = false ) {
		$html = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="gb-mfa-admin-action"><input type="hidden" name="action" value="gb_mfa_student_action"><input type="hidden" name="student_id" value="' . absint( $user_id ) . '"><input type="hidden" name="operation" value="' . esc_attr( $action ) . '">';
		$html .= wp_nonce_field( 'gb_mfa_student_action_' . $action . '_' . $user_id, '_wpnonce', true, false );
		$html .= '<label>Reason <input type="text" name="reason" required></label><button class="button ' . ( $danger ? 'button-secondary' : '' ) . '" type="submit">' . esc_html( $label ) . '</button></form>';
		return $html;
	}

	private function student_data( $user_id ) {
		global $wpdb;
		$events = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->events_table} WHERE user_id=%d ORDER BY created_at_utc DESC LIMIT 1000", $user_id ), ARRAY_A );
		$seat_table = $wpdb->prefix . 'gb_seat_time';
		$seat = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$seat_table} WHERE user_id=%d ORDER BY started_at_utc DESC LIMIT 1000", $user_id ), ARRAY_A );
		$lp_table = $wpdb->prefix . 'learnpress_user_items';
		$lp = $wpdb->get_results( $wpdb->prepare( "SELECT user_item_id,item_id,item_type,status,start_time,end_time,graduation,ref_id FROM {$lp_table} WHERE user_id=%d ORDER BY start_time DESC LIMIT 1000", $user_id ), ARRAY_A );
		$certificate_table = $wpdb->prefix . 'gb_certificate_issuances';
		$certificates = $wpdb->get_results( $wpdb->prepare( "SELECT id,certificate_type,serial_number,course_id,order_id,locale,final_score,final_passed_utc,course_completed_utc,issued_utc,student_download_until_utc,report_due_utc,report_status,email_status,voided_utc,void_reason FROM {$certificate_table} WHERE user_id=%d ORDER BY issued_utc DESC LIMIT 100", $user_id ), ARRAY_A );
		$download_table = $wpdb->prefix . 'gb_certificate_download_log';
		$downloads = $wpdb->get_results( $wpdb->prepare( "SELECT issuance_id,certificate_type,serial_number,actor_user_id,actor_role,outcome,reason,requested_utc FROM {$download_table} WHERE subject_user_id=%d ORDER BY requested_utc DESC LIMIT 500", $user_id ), ARRAY_A );
		return array(
			'events' => is_array( $events ) ? $events : array(),
			'seat' => is_array( $seat ) ? $seat : array(),
			'learnpress' => is_array( $lp ) ? $lp : array(),
			'certificates' => is_array( $certificates ) ? $certificates : array(),
			'certificate_downloads' => is_array( $downloads ) ? $downloads : array(),
		);
	}

	public function render_admin_audit() {
		if ( ! current_user_can( self::CAP_AUDIT ) ) {
			wp_die( 'Not allowed.' );
		}
		$query = sanitize_text_field( wp_unslash( $_GET['student'] ?? '' ) );
		$user = null;
		if ( $query ) {
			$user = is_email( $query ) ? get_user_by( 'email', $query ) : get_user_by( ctype_digit( $query ) ? 'id' : 'login', $query );
		}
		echo '<div class="wrap"><h1>Gulf Breeze Student Compliance</h1><p>MFA identity events, Gulf Breeze seat time, LearnPress progress, recovery/reset history, and exportable inspection evidence.</p><form method="get"><input type="hidden" name="page" value="gb-student-compliance"><input class="regular-text" name="student" value="' . esc_attr( $query ) . '" placeholder="Email, username, or user ID"><button class="button button-primary">Find student</button></form>';
		if ( $query && ! $user ) {
			echo '<div class="notice notice-error"><p>No student found.</p></div></div>';
			return;
		}
		if ( ! $user ) {
			echo '</div>';
			return;
		}
		$data = $this->student_data( $user->ID );
		echo '<h2>Student</h2><table class="widefat striped"><tbody><tr><th>Name</th><td>' . esc_html( $this->profile_value( $user->ID, 'gb_student_legal_name' ) ?: $user->display_name ) . '</td></tr><tr><th>Email</th><td>' . esc_html( $user->user_email ) . '</td></tr><tr><th>User ID</th><td>' . absint( $user->ID ) . '</td></tr><tr><th>MFA enrolled</th><td>' . ( $this->has_enrolled( $user->ID ) ? 'Yes' : 'No' ) . '</td></tr><tr><th>Verified in current session</th><td>' . ( $this->is_verified( $user->ID ) ? 'Yes' : 'No' ) . '</td></tr><tr><th>Owner exemption</th><td>' . ( $this->is_owner_immune( $user->ID ) ? 'Yes — immutable owner account' : 'No' ) . '</td></tr></tbody></table>';
		if ( ! $this->is_owner_immune( $user->ID ) ) {
			echo '<h2>Controlled recovery actions</h2><div style="display:grid;gap:12px;max-width:900px">' . $this->admin_action_form( $user->ID, 'unlock', 'Unlock student' ) . $this->admin_action_form( $user->ID, 'force_reverify', 'Force re-verification' ) . $this->admin_action_form( $user->ID, 'reset', 'Reset MFA enrollment', true ) . '</div>';
		}
		$csv = wp_nonce_url( admin_url( 'admin-post.php?action=gb_mfa_export_csv&student_id=' . $user->ID ), 'gb_mfa_export_csv_' . $user->ID );
		$pdf = wp_nonce_url( admin_url( 'admin-post.php?action=gb_mfa_export_pdf&student_id=' . $user->ID ), 'gb_mfa_export_pdf_' . $user->ID );
		echo '<p><a class="button button-primary" href="' . esc_url( $pdf ) . '">Export inspection packet (PDF)</a> <a class="button" href="' . esc_url( $csv ) . '">Export MFA events (CSV)</a></p>';
		echo '<h2>Gulf Breeze seat time</h2><table class="widefat striped"><thead><tr><th>Course</th><th>Lesson</th><th>Required</th><th>Active</th><th>Started UTC</th><th>Completed UTC</th></tr></thead><tbody>';
		foreach ( $data['seat'] as $row ) {
			echo '<tr><td>' . absint( $row['course_id'] ) . '</td><td>' . absint( $row['lesson_id'] ) . ' — ' . esc_html( get_the_title( $row['lesson_id'] ) ) . '</td><td>' . absint( $row['required_seconds'] ) . '</td><td>' . absint( $row['active_seconds'] ) . '</td><td>' . esc_html( $row['started_at_utc'] ) . '</td><td>' . esc_html( $row['completed_at_utc'] ) . '</td></tr>';
		}
		echo '</tbody></table><h2>LearnPress progress</h2><table class="widefat striped"><thead><tr><th>Type</th><th>Item</th><th>Status</th><th>Grade</th><th>Start</th><th>End</th></tr></thead><tbody>';
		foreach ( $data['learnpress'] as $row ) {
			echo '<tr><td>' . esc_html( $row['item_type'] ) . '</td><td>' . absint( $row['item_id'] ) . ' — ' . esc_html( get_the_title( $row['item_id'] ) ) . '</td><td>' . esc_html( $row['status'] ) . '</td><td>' . esc_html( $row['graduation'] ) . '</td><td>' . esc_html( $row['start_time'] ) . '</td><td>' . esc_html( $row['end_time'] ) . '</td></tr>';
		}
		echo '</tbody></table><h2>Certificate issuance and reporting</h2><table class="widefat striped"><thead><tr><th>Issued UTC</th><th>Type/serial</th><th>Course</th><th>Final</th><th>Completed</th><th>Student access until</th><th>Report</th><th>Email</th><th>Void</th></tr></thead><tbody>';
		foreach ( $data['certificates'] as $row ) {
			echo '<tr><td>' . esc_html( $row['issued_utc'] ) . '</td><td>' . esc_html( $row['certificate_type'] . ' ' . $row['serial_number'] ) . '</td><td>' . absint( $row['course_id'] ) . '</td><td>' . esc_html( $row['final_score'] . '% at ' . $row['final_passed_utc'] ) . '</td><td>' . esc_html( $row['course_completed_utc'] ) . '</td><td>' . esc_html( $row['student_download_until_utc'] ) . '</td><td>' . esc_html( $row['report_status'] . ' / due ' . $row['report_due_utc'] ) . '</td><td>' . esc_html( $row['email_status'] ) . '</td><td>' . esc_html( $row['voided_utc'] ? $row['voided_utc'] . ' — ' . $row['void_reason'] : 'No' ) . '</td></tr>';
		}
		echo '</tbody></table><h2>Certificate download audit</h2><table class="widefat striped"><thead><tr><th>Requested UTC</th><th>Certificate</th><th>Actor role/ID</th><th>Outcome</th><th>Reason</th></tr></thead><tbody>';
		foreach ( $data['certificate_downloads'] as $row ) {
			echo '<tr><td>' . esc_html( $row['requested_utc'] ) . '</td><td>' . esc_html( $row['certificate_type'] . ' ' . $row['serial_number'] ) . '</td><td>' . esc_html( $row['actor_role'] . ' #' . absint( $row['actor_user_id'] ) ) . '</td><td>' . esc_html( $row['outcome'] ) . '</td><td>' . esc_html( $row['reason'] ) . '</td></tr>';
		}
		echo '</tbody></table><h2>MFA and identity event log</h2><table class="widefat striped"><thead><tr><th>UTC</th><th>Event</th><th>Result</th><th>Method</th><th>Reason</th><th>Course/item</th><th>Internal actor ID</th></tr></thead><tbody>';
		foreach ( $data['events'] as $row ) {
			echo '<tr><td>' . esc_html( $row['created_at_utc'] ) . '</td><td>' . esc_html( $row['event_type'] ) . '</td><td>' . esc_html( $row['result'] ) . '</td><td>' . esc_html( $row['method'] ) . '</td><td>' . esc_html( $row['reason'] ) . '</td><td>' . absint( $row['course_id'] ) . '/' . absint( $row['item_id'] ) . '</td><td>' . absint( $row['actor_user_id'] ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	}

	public function handle_admin_student_action() {
		if ( ! current_user_can( self::CAP_AUDIT ) ) {
			wp_die( 'Not allowed.' );
		}
		$user_id = absint( $_POST['student_id'] ?? 0 );
		$operation = sanitize_key( $_POST['operation'] ?? '' );
		$reason = trim( sanitize_textarea_field( wp_unslash( $_POST['reason'] ?? '' ) ) );
		if ( ! $user_id || ! in_array( $operation, array( 'unlock', 'force_reverify', 'reset' ), true ) || ! $reason ) {
			wp_die( 'Student, operation, and reason are required.' );
		}
		check_admin_referer( 'gb_mfa_student_action_' . $operation . '_' . $user_id );
		if ( $this->is_owner_immune( $user_id ) ) {
			wp_die( 'The immutable owner account cannot be changed by student MFA controls.' );
		}
		if ( 'unlock' === $operation ) {
			delete_user_meta( $user_id, self::META_FAILS );
			delete_user_meta( $user_id, self::META_LOCK );
		} elseif ( 'force_reverify' === $operation ) {
			delete_user_meta( $user_id, self::META_VERIFIED_AT );
			delete_user_meta( $user_id, self::META_VERIFIED_UNTIL );
			delete_user_meta( $user_id, self::META_SESSION );
		} else {
			foreach ( array( self::META_SECRET, self::META_PENDING, self::META_CREATED, self::META_VERIFIED_AT, self::META_VERIFIED_UNTIL, self::META_SESSION, self::META_FAILS, self::META_LOCK, self::META_RECOVERY ) as $key ) {
				delete_user_meta( $user_id, $key );
			}
			update_user_meta( $user_id, self::META_RESET_NOTICE, 1 );
		}
		$this->log_event( $user_id, 'admin_' . $operation, 'success', 'administrative', $reason, array(), get_current_user_id() );
		wp_safe_redirect( admin_url( 'admin.php?page=gb-student-compliance&student=' . $user_id ) );
		exit;
	}

	public function render_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		$settings = $this->settings();
		echo '<div class="wrap"><h1>Gulf Breeze MFA Settings</h1><div class="notice notice-info"><p><strong>Immutable owner exemption:</strong> WordPress user ID ' . absint( $this->owner_user_id() ) . '. Student MFA hooks return before evaluating this account. Define <code>GB_MFA_OWNER_USER_ID</code> in wp-config.php to pin the value outside the database.</p></div><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="gb_mfa_save_settings">' . wp_nonce_field( 'gb_mfa_save_settings', '_wpnonce', true, false ) . '<table class="form-table"><tr><th>Normal verification minutes</th><td><input type="number" min="15" max="720" name="verify_ttl_minutes" value="' . absint( $settings['verify_ttl_minutes'] ) . '"></td></tr><tr><th>Exam/certificate freshness minutes</th><td><input type="number" min="5" max="60" name="checkpoint_minutes" value="' . absint( $settings['checkpoint_minutes'] ) . '"></td></tr><tr><th>Attempts before lockout</th><td><input type="number" min="3" max="10" name="max_attempts" value="' . absint( $settings['max_attempts'] ) . '"></td></tr><tr><th>Lockout minutes</th><td><input type="number" min="5" max="120" name="lock_minutes" value="' . absint( $settings['lock_minutes'] ) . '"></td></tr></table><p><button class="button button-primary">Save settings</button></p></form><p>Mark a permit exam, final exam, or certificate checkpoint by setting post meta <code>_gb_mfa_checkpoint</code> to <code>permit_exam</code>, <code>final_exam</code>, or <code>certificate</code>. Certificate modules may also call <code>gb_mfa_require_recent()</code>.</p></div>';
	}

	public function save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'gb_mfa_save_settings' );
		update_option( self::OPTION_SETTINGS, array(
			'verify_ttl_minutes' => min( 720, max( 15, absint( $_POST['verify_ttl_minutes'] ?? 60 ) ) ),
			'checkpoint_minutes' => min( 60, max( 5, absint( $_POST['checkpoint_minutes'] ?? 30 ) ) ),
			'max_attempts' => min( 10, max( 3, absint( $_POST['max_attempts'] ?? 6 ) ) ),
			'lock_minutes' => min( 120, max( 5, absint( $_POST['lock_minutes'] ?? 30 ) ) ),
		), false );
		wp_safe_redirect( admin_url( 'admin.php?page=gb-mfa-settings&updated=1' ) );
		exit;
	}

	public function export_csv() {
		if ( ! current_user_can( self::CAP_AUDIT ) ) {
			wp_die( 'Not allowed.' );
		}
		$user_id = absint( $_GET['student_id'] ?? 0 );
		check_admin_referer( 'gb_mfa_export_csv_' . $user_id );
		$data = $this->student_data( $user_id );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=gulf-breeze-mfa-events-user-' . $user_id . '.csv' );
		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, array( 'id', 'user_id', 'event_type', 'result', 'method', 'reason', 'course_id', 'item_id', 'actor_user_id', 'ip_address', 'user_agent', 'language', 'context_json', 'created_at_utc' ) );
		foreach ( $data['events'] as $row ) {
			fputcsv( $out, $row );
		}
		fclose( $out );
		exit;
	}

	private function pdf_escape( $value ) {
		return str_replace( array( '\\', '(', ')' ), array( '\\\\', '\\(', '\\)' ), (string) $value );
	}

	private function simple_pdf( $lines ) {
		$pages = array_chunk( $lines, 55 );
		$objects = array();
		$add = function( $content ) use ( &$objects ) { $objects[] = $content; return count( $objects ); };
		$font_id = $add( '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>' );
		$page_ids = array();
		$content_ids = array();
		foreach ( $pages as $page ) {
			$stream = "BT\n/F1 9 Tf\n11 TL\n36 806 Td\n";
			foreach ( $page as $line ) {
				$stream .= '(' . $this->pdf_escape( substr( (string) $line, 0, 145 ) ) . ") Tj\nT*\n";
			}
			$stream .= "ET";
			$content_ids[] = $add( '<< /Length ' . strlen( $stream ) . ">>\nstream\n" . $stream . "\nendstream" );
			$page_ids[] = 0;
		}
		$pages_id = count( $objects ) + count( $pages ) + 1;
		foreach ( $pages as $index => $unused ) {
			$page_ids[ $index ] = $add( '<< /Type /Page /Parent ' . $pages_id . ' 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 ' . $font_id . ' 0 R >> >> /Contents ' . $content_ids[ $index ] . ' 0 R >>' );
		}
		$kids = implode( ' ', array_map( function( $id ) { return $id . ' 0 R'; }, $page_ids ) );
		$actual_pages_id = $add( '<< /Type /Pages /Kids [' . $kids . '] /Count ' . count( $page_ids ) . ' >>' );
		$catalog_id = $add( '<< /Type /Catalog /Pages ' . $actual_pages_id . ' 0 R >>' );
		$pdf = "%PDF-1.4\n";
		$offsets = array( 0 );
		foreach ( $objects as $number => $object ) {
			$offsets[ $number + 1 ] = strlen( $pdf );
			$pdf .= ( $number + 1 ) . " 0 obj\n" . $object . "\nendobj\n";
		}
		$xref = strlen( $pdf );
		$pdf .= "xref\n0 " . ( count( $objects ) + 1 ) . "\n0000000000 65535 f \n";
		for ( $i = 1; $i <= count( $objects ); $i++ ) {
			$pdf .= sprintf( "%010d 00000 n \n", $offsets[ $i ] );
		}
		$pdf .= 'trailer' . "\n<< /Size " . ( count( $objects ) + 1 ) . ' /Root ' . $catalog_id . " 0 R >>\nstartxref\n" . $xref . "\n%%EOF";
		return $pdf;
	}

	public function export_pdf() {
		if ( ! current_user_can( self::CAP_AUDIT ) ) {
			wp_die( 'Not allowed.' );
		}
		$user_id = absint( $_GET['student_id'] ?? 0 );
		check_admin_referer( 'gb_mfa_export_pdf_' . $user_id );
		$user = get_user_by( 'id', $user_id );
		if ( ! $user ) {
			wp_die( 'Student not found.' );
		}
		$data = $this->student_data( $user_id );
		$lines = array(
			'GULF BREEZE DRIVING SCHOOL - STUDENT COMPLIANCE INSPECTION PACKET',
			'Generated UTC: ' . gmdate( 'Y-m-d H:i:s' ),
			'Student: ' . ( $this->profile_value( $user_id, 'gb_student_legal_name' ) ?: $user->display_name ),
			'User ID: ' . $user_id, 'Email: ' . $user->user_email,
			'Date of birth: ' . $this->profile_value( $user_id, 'gb_student_dob' ),
			'Phone: ' . $this->profile_value( $user_id, 'gb_student_phone' ),
			'Address: ' . trim( $this->profile_value( $user_id, 'gb_student_address1' ) . ', ' . $this->profile_value( $user_id, 'gb_student_city' ) . ', ' . $this->profile_value( $user_id, 'gb_student_state' ) . ' ' . $this->profile_value( $user_id, 'gb_student_zip' ) ),
			'MFA enrolled: ' . ( $this->has_enrolled( $user_id ) ? 'YES' : 'NO' ), '',
		);
		$lines[] = 'SEAT TIME';
		foreach ( $data['seat'] as $row ) {
			$lines[] = sprintf( 'Course %d | Lesson %d | required %ds | active %ds | start %s | complete %s', $row['course_id'], $row['lesson_id'], $row['required_seconds'], $row['active_seconds'], $row['started_at_utc'], $row['completed_at_utc'] ?: '-' );
		}
		$lines[] = '';
		$lines[] = 'LEARNPRESS PROGRESS / EXAMS';
		foreach ( $data['learnpress'] as $row ) {
			$lines[] = sprintf( '%s %d | %s | grade %s | start %s | end %s', $row['item_type'], $row['item_id'], $row['status'], $row['graduation'], $row['start_time'], $row['end_time'] );
		}
		$lines[] = '';
		$lines[] = 'CERTIFICATE ISSUANCE / REPORTING';
		foreach ( $data['certificates'] as $row ) {
			$lines[] = sprintf( '%s %s | course %d | final %s at %s | complete %s | issued %s | student access %s | report %s due %s | email %s | void %s', $row['certificate_type'], $row['serial_number'], $row['course_id'], $row['final_score'], $row['final_passed_utc'], $row['course_completed_utc'], $row['issued_utc'], $row['student_download_until_utc'], $row['report_status'], $row['report_due_utc'], $row['email_status'], $row['voided_utc'] ?: 'no' );
		}
		$lines[] = '';
		$lines[] = 'CERTIFICATE DOWNLOAD AUDIT';
		foreach ( $data['certificate_downloads'] as $row ) {
			$lines[] = sprintf( '%s | %s %s | %s #%d | %s | %s', $row['requested_utc'], $row['certificate_type'], $row['serial_number'], $row['actor_role'], $row['actor_user_id'], $row['outcome'], $row['reason'] );
		}
		$lines[] = '';
		$lines[] = 'MFA / IDENTITY EVENTS';
		foreach ( $data['events'] as $row ) {
			$lines[] = sprintf( '%s | %s | %s | %s | course %d item %d | actor %d | %s', $row['created_at_utc'], $row['event_type'], $row['result'], $row['method'], $row['course_id'], $row['item_id'], $row['actor_user_id'], $row['reason'] );
		}
		$pdf = $this->simple_pdf( $lines );
		nocache_headers();
		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: attachment; filename=gulf-breeze-inspection-packet-user-' . $user_id . '.pdf' );
		header( 'Content-Length: ' . strlen( $pdf ) );
		echo $pdf;
		exit;
	}
}

function gb_mfa_is_owner_immune( $user_id = 0 ) {
	return Gulf_Breeze_MFA_Compliance::instance()->is_owner_immune( $user_id );
}

function gb_mfa_is_verified( $user_id = 0 ) {
	return Gulf_Breeze_MFA_Compliance::instance()->is_verified( $user_id );
}

function gb_mfa_require_recent( $user_id = 0, $minutes = 30 ) {
	return Gulf_Breeze_MFA_Compliance::instance()->is_verified( $user_id, $minutes );
}

register_activation_hook( __FILE__, array( 'Gulf_Breeze_MFA_Compliance', 'activate' ) );
Gulf_Breeze_MFA_Compliance::instance();
