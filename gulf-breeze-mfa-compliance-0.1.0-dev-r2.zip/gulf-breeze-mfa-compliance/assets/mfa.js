(function () {
  'use strict';

  function textOf(selector) {
    var node = document.querySelector(selector);
    return node ? node.textContent.trim() : '';
  }

  function copyText(value, button) {
    var original = button.textContent;
    var done = function () {
      button.textContent = (window.GBMFA && GBMFA.copied) || 'Copied';
      window.setTimeout(function () { button.textContent = original; }, 1400);
    };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(value).then(done);
      return;
    }
    var area = document.createElement('textarea');
    area.value = value;
    area.setAttribute('readonly', 'readonly');
    area.style.position = 'fixed';
    area.style.opacity = '0';
    document.body.appendChild(area);
    area.select();
    document.execCommand('copy');
    area.remove();
    done();
  }

  document.addEventListener('click', function (event) {
    var method = event.target.closest('[data-mfa-panel]');
    if (method) {
	  document.querySelectorAll('[data-mfa-panel]').forEach(function (button) {
		button.classList.remove('is-active');
		button.setAttribute('aria-selected', 'false');
	  });
	  document.querySelectorAll('.gb-mfa-panel').forEach(function (panel) {
		panel.classList.remove('is-active');
		panel.hidden = true;
	  });
      method.classList.add('is-active');
	  method.setAttribute('aria-selected', 'true');
      var panel = document.getElementById(method.getAttribute('data-mfa-panel'));
	  if (panel) {
		panel.hidden = false;
		panel.classList.add('is-active');
	  }
      return;
    }

    var copy = event.target.closest('[data-copy-target]');
    if (copy) {
      copyText(textOf(copy.getAttribute('data-copy-target')), copy);
      return;
    }

    var download = event.target.closest('[data-download-target]');
    if (download) {
      var value = textOf(download.getAttribute('data-download-target'));
      var blob = new Blob(['Gulf Breeze Driving School recovery codes\n\n' + value + '\n'], { type: 'text/plain;charset=utf-8' });
      var link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = (window.GBMFA && GBMFA.downloadName) || 'gulf-breeze-recovery-codes.txt';
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(link.href);
    }
  });

  document.querySelectorAll('.gb-mfa-code').forEach(function (input) {
    input.addEventListener('input', function () {
      input.value = input.value.replace(/\D/g, '').slice(0, 6);
    });
  });

  var qr = document.getElementById('gb-mfa-qr');
  if (qr && qr.dataset.otpauth && window.jQuery && jQuery.fn.qrcode) {
    jQuery(qr).empty().qrcode({ width: 224, height: 224, text: qr.dataset.otpauth });
  }
})();
