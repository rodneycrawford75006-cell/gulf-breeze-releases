from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parents[1]
php = (root / "gulf-breeze-mfa-compliance.php").read_text(encoding="utf-8")
css = (root / "assets/mfa.css").read_text(encoding="utf-8")
js = (root / "assets/mfa.js").read_text(encoding="utf-8")
qr = (root / "assets/jquery.qrcode.min.js").read_text(encoding="utf-8")

checks = {
    "plugin identity": "Plugin Name: Gulf Breeze MFA & Compliance" in php and "0.1.0-dev-r2" in php,
    "no Drive Smart production branding": "Drive Smart" not in php and "DriveSmart" not in php,
    "owner immunity exact ID": "OPTION_OWNER_ID" in php and "is_owner_immune" in php and "GB_MFA_OWNER_USER_ID" in php,
    "guards check immunity": php.count("$this->is_owner_immune()") >= 5,
    "session-bound verification": "META_SESSION" in php and "session_hash" in php and "hash_equals" in php,
    "authenticated secret encryption": "aes-256-gcm" in php and "gb-mfa-v2" in php,
    "no insecure crypto fallback": "fallback-key" not in php and "aes-256-cbc" not in php.lower(),
    "no external QR request": "api.qrserver.com" not in php and "chart.googleapis" not in php and "quickchart" not in php,
    "local QR library bundled": len(qr) > 10000 and "QRCode" in qr,
    "recovery codes hashed": "wp_hash_password" in php and "wp_check_password" in php,
    "admin reason mandatory": "operation, and reason are required" in php and "name=\"reason\" required" in php,
    "no admin mark-verified bypass": "mark_verified'" not in php and "admin_mark_verified" not in php,
    "direct LearnPress protection": "lp_course" in php and "lp_lesson" in php and "lp_quiz" in php,
    "student enrollment requirement": "student_requires_mfa" in php and "learnpress_user_items" in php and "item_type = 'lp_course'" in php,
    "student account route enforcement": "is_student_account_path" in php and "^/my-account" in php and "customer-logout" in php,
    "seat-time action protection": all(x in php for x in ("gb_seat_start", "gb_seat_heartbeat", "gb_seat_complete")),
    "certificate protection": "gb_cert_download" in php and "certificates?" in php,
    "REST protection": "rest_pre_dispatch" in php and "gb_mfa_protected_rest_route" in php,
    "final checkpoint": "adult_en_final" in php and "_gb_mfa_checkpoint" in php,
    "audit joins Core": "gb_seat_time" in php and "learnpress_user_items" in php,
    "audit joins certificates": "gb_certificate_issuances" in php and "gb_certificate_download_log" in php,
    "bilingual copy": all(x in php for x in ("English", "Español", "Verificación", "recovery")),
    "bilingual install guidance": all(x in php for x in ("Necesito instalar", "Ingresar una clave", "Otra cuenta", "Basada en tiempo", "enter the code manually", "Time based")),
    "official authenticator links": all(x in php for x in ("id388497605", "com.google.android.apps.authenticator2", "id983156458", "com.azure.authenticator")),
    "guided progress": "render_progress" in php and "gb-mfa-progress" in css and "aria-current=\"step\"" in php,
    "mobile styling": "@media (max-width: 600px)" in css and "min-height: 48px" in css,
    "same-phone UX": "same-phone" in php and "Copy setup key" in php,
    "accessible setup method tabs": "aria-selected=\"true\"" in php and "panel.hidden" in js,
    "canonical recovery redirect": "nocache_headers();" in php and "enrollment_url( $return ), 303" in php,
    "public instructor privacy": all(x in php for x in ("guard_public_instructor_profile", "public_instructor_html", "public_course_tabs", "Gulf Breeze Driving School")),
    "numeric code cleanup": "replace(/\\D/g" in js,
    "under construction untouched": not re.search(r"update_option\s*\(\s*['\"](?:ucp|under.?construction)", php, re.I),
    "no raw code audit field": "entered_code" not in php and "code_hash" not in php,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " - " + name)

if failed:
    print("\nFailed checks: " + ", ".join(failed), file=sys.stderr)
    raise SystemExit(1)

print(f"\nPASS - {len(checks)} focused static checks")
