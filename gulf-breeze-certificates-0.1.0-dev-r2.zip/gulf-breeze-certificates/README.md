# Gulf Breeze Certificates 0.1.0-dev-r2

Focused test-mode foundation for ADEE-1317 certificate inventory and delivery.

- Uses mock eight-digit serial numbers beginning with `9`.
- Requires a verified active paid enrollment, a controlled Adult final score of at least 70%, and a completed/passed LearnPress course record.
- Allocates each serial once inside a database transaction and preserves a durable issuance audit.
- Populates the supplied TDLR ADEE-1317 revision 1/24/25 template; page 1 is the DPS copy and page 2 is the school copy.
- Adds a third English or Spanish instruction page without changing the two official template pages.
- Preserves the exact issued PDF in the private issuance database record with template and output SHA-256 hashes; no certificate is stored in a public uploads directory.
- Adds a protected **Certificates** area to the WooCommerce student account.
- Emails and PDF instructions follow the purchased course language (`en-US` or `es-US`).
- Freezes the exact 21-field TDLR Adult completion record at issuance and calculates the 15-calendar-day reporting deadline.
- Exports pending test records as CSV UTF-8 using the official template headers and Adult values (`ADE`, `ADEE`, `ONLINE ADULT`, six classroom hours).
- Leaves observation, behind-the-wheel, laboratory, void, and replacement fields blank as required for the Adult scenario.
- Uses a deliberately invalid `TEST-NOT-FOR-TDLR-...csv` filename and never marks an export as accepted by TDLR.
- Does not automate login or submission to TDLR's Online Licensing System; portal acceptance remains a controlled administrator action.
- Warns administrators below 100 unused serials.
- Every generated document is visibly watermarked **TEST — NOT VALID FOR DPS OR TDLR** and uses `ADEE` plus an isolated mock eight-digit number. Production issuance remains disabled pending provider and certificate approval.
