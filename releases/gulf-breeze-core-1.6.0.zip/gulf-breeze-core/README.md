# Gulf Breeze Core

Permanent modular foundation for the Gulf Breeze course system. Version 0.1.1 includes the central configuration source and verified monitoring of the installed Under Construction protection state.

Missing values render as blank instead of fabricated placeholders. Sensitive credentials and PayPal secrets do not belong in this plugin.

## Use

- PHP: `gb_config_get( 'provider_number' )`
- Shortcode: `[gb_setting key="provider_number"]`

The internal record-retention note is deliberately unavailable through the shortcode.
