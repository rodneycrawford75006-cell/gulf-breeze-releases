# GulfBreeze LearnPress Question Importer v0.1.0

Imports GulfBreeze mastery-question spreadsheets into LearnPress.

## Purpose

This plugin is for creating the question banks that will later feed the GulfBreeze Course Mastery Gate plugin. LearnPress is used as the question/bank storage layer; the future GulfBreeze mastery plugin will control the compliance test flow.

## What it does

- Reads `.xlsx` or `.csv` files with the approved GulfBreeze question-bank columns.
- Creates individual LearnPress `lp_question` posts.
- Creates or reuses the LearnPress `lp_quiz` named in `bank_title`.
- Inserts answer choices into the LearnPress `learnpress_question_answers` table with proper answer `value` fields.
- Marks the correct answer.
- Attaches each question to the quiz/bank.
- Applies safe quiz settings: 70% passing grade, unlimited retakes, one-question pagination, no review, no correct-answer reveal, no instant check.
- Has a preview-only mode so you can validate before writing anything.

## Required columns

- `question_title`
- `question_text`
- `answer_a`
- `answer_b`
- `answer_c`
- `answer_d`
- `correct_answer`
- `bank_title`

Optional but recommended:

- `course_type`
- `module`
- `objective_code`
- `poi_topic`
- `points`
- `question_type`
- `hint`
- `explanation`
- `source_url`

## Workflow

1. Go to WordPress Dashboard → GB Question Importer.
2. Upload the spreadsheet.
3. Run Preview only.
4. If clean, run Import questions and bank.
5. Go to LearnPress → Quizzes and confirm the quiz/bank exists.
6. Add the quiz/bank to the correct course curriculum location manually.

## Safety notes

- Existing questions are matched by exact title.
- By default, existing questions are reused and attached to the bank rather than duplicated.
- The importer does not overwrite existing question text or answers.
- The importer does not insert the bank into a course curriculum automatically.

## v0.1.1

Fixed XLSX parsing for the Teen Module 1 workbook.

### Changed
- Replaced the fragile SimpleXML worksheet reader with a namespace-safe DOMDocument parser.
- Handles the workbook format created for the GulfBreeze mastery-question spreadsheet, including cells written as `t="str"` rather than shared-string indexes.
- Keeps Preview/Import behavior unchanged.

## v0.1.2

Student-facing bank description cleanup.

### Fixed
- Removed the stiff default quiz/bank description: "GulfBreeze imported mastery question bank..."
- New banks now get student-friendly descriptions by default.
- If an existing imported bank still has the old stiff default text, rerunning the importer with v0.1.2 will replace that old text with friendly copy.
- Added optional `bank_description` support. If the workbook includes a `bank_description` column, that text will be used for the LearnPress quiz/bank description.
