<?php
/**
 * Plugin Name: GulfBreeze LearnPress Question Importer
 * Description: Imports GulfBreeze mastery-question spreadsheets into LearnPress as individual questions, creates the mapped quiz/bank, and attaches the questions to that bank.
 * Version: 0.1.2
 * Author: GulfBreeze / Drive Smart
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class GulfBreeze_LP_Question_Importer {
    const VERSION = '0.1.2';
    const MENU_SLUG = 'gb-lp-question-importer';
    const LOG_OPTION = 'gb_lpq_import_logs';

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'admin_menu' ) );
    }

    public function admin_menu() {
        add_menu_page(
            'GulfBreeze LP Question Importer',
            'GB Question Importer',
            'manage_options',
            self::MENU_SLUG,
            array( $this, 'render_admin_page' ),
            'dashicons-upload',
            59
        );
    }

    public function render_admin_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $result = null;
        if ( isset( $_POST['gb_lpq_submit'] ) ) {
            check_admin_referer( 'gb_lpq_import' );
            $result = $this->handle_upload();
        }

        $logs = get_option( self::LOG_OPTION, array() );
        $logs = is_array( $logs ) ? array_slice( array_reverse( $logs ), 0, 8 ) : array();
        ?>
        <div class="wrap gb-lpq-wrap">
            <h1>GulfBreeze LearnPress Question Importer <span style="font-size:14px;font-weight:400;">v<?php echo esc_html( self::VERSION ); ?></span></h1>
            <p>This importer creates LearnPress <strong>Questions</strong>, creates or reuses the LearnPress <strong>quiz/bank</strong> named in the spreadsheet, and attaches the questions to that bank.</p>
            <p><strong>Recommended use:</strong> upload the Teen Module 1 mastery spreadsheet, run <em>Preview only</em> first, then run <em>Import questions and bank</em>.</p>

            <style>
                .gb-lpq-card { background:#fff; border:1px solid #ccd0d4; padding:16px 18px; margin:16px 0; max-width:1200px; }
                .gb-lpq-card h2 { margin-top:0; }
                .gb-lpq-code { font-family:ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; background:#f6f7f7; padding:2px 4px; border-radius:3px; }
                .gb-lpq-small { color:#646970; font-size:12px; }
                .gb-lpq-ok { color:#008a20; font-weight:600; }
                .gb-lpq-warn { color:#996800; font-weight:600; }
                .gb-lpq-bad { color:#b32d2e; font-weight:600; }
                .gb-lpq-table td, .gb-lpq-table th { vertical-align:top; }
                .gb-lpq-summary { display:grid; grid-template-columns:repeat(auto-fit,minmax(190px,1fr)); gap:10px; margin:12px 0; }
                .gb-lpq-summary div { background:#f6f7f7; padding:10px; border-radius:4px; }
            </style>

            <div class="gb-lpq-card">
                <h2>Upload question spreadsheet</h2>
                <form method="post" enctype="multipart/form-data">
                    <?php wp_nonce_field( 'gb_lpq_import' ); ?>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><label for="gb_lpq_file">Spreadsheet file</label></th>
                            <td>
                                <input id="gb_lpq_file" type="file" name="gb_lpq_file" accept=".xlsx,.csv" required />
                                <p class="description">Accepted: .xlsx or .csv. First worksheet is used for .xlsx files.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Mode</th>
                            <td>
                                <label><input type="radio" name="gb_lpq_mode" value="preview" checked /> Preview only — validate the file without writing to the database</label><br />
                                <label><input type="radio" name="gb_lpq_mode" value="import" /> Import questions and bank — creates LearnPress questions, quiz/bank, and quiz-question links</label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Existing questions</th>
                            <td>
                                <label><input type="checkbox" name="gb_lpq_attach_existing" value="1" checked /> If a question title already exists, skip creating a duplicate and attach the existing question to the bank</label>
                                <p class="description">This keeps reruns safe. It does not overwrite existing question text or answers.</p>
                            </td>
                        </tr>
                    </table>
                    <p><button class="button button-primary" name="gb_lpq_submit" value="1">Run Importer</button></p>
                </form>
            </div>

            <?php if ( is_array( $result ) ) : ?>
                <?php $this->render_result( $result ); ?>
            <?php endif; ?>

            <div class="gb-lpq-card">
                <h2>Required spreadsheet columns</h2>
                <p>The importer expects the workbook created for the module mastery bank.</p>
                <table class="widefat striped gb-lpq-table">
                    <thead><tr><th>Required</th><th>Optional but recommended</th></tr></thead>
                    <tbody>
                        <tr>
                            <td><span class="gb-lpq-code">question_title</span>, <span class="gb-lpq-code">question_text</span>, <span class="gb-lpq-code">answer_a</span>, <span class="gb-lpq-code">answer_b</span>, <span class="gb-lpq-code">answer_c</span>, <span class="gb-lpq-code">answer_d</span>, <span class="gb-lpq-code">correct_answer</span>, <span class="gb-lpq-code">bank_title</span></td>
                            <td><span class="gb-lpq-code">course_type</span>, <span class="gb-lpq-code">module</span>, <span class="gb-lpq-code">objective_code</span>, <span class="gb-lpq-code">poi_topic</span>, <span class="gb-lpq-code">points</span>, <span class="gb-lpq-code">question_type</span>, <span class="gb-lpq-code">hint</span>, <span class="gb-lpq-code">explanation</span>, <span class="gb-lpq-code">source_url</span>, <span class="gb-lpq-code">bank_description</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="gb-lpq-card">
                <h2>Recent importer logs</h2>
                <?php if ( empty( $logs ) ) : ?>
                    <p>No imports logged yet.</p>
                <?php else : ?>
                    <table class="widefat striped gb-lpq-table">
                        <thead><tr><th>UTC Time</th><th>Mode</th><th>File</th><th>Rows</th><th>Created Questions</th><th>Existing Questions</th><th>Quiz Banks</th><th>Errors</th></tr></thead>
                        <tbody>
                        <?php foreach ( $logs as $log ) : ?>
                            <tr>
                                <td><?php echo esc_html( $log['time'] ?? '' ); ?></td>
                                <td><?php echo esc_html( $log['mode'] ?? '' ); ?></td>
                                <td><?php echo esc_html( $log['file'] ?? '' ); ?></td>
                                <td><?php echo esc_html( $log['rows'] ?? '' ); ?></td>
                                <td><?php echo esc_html( $log['created_questions'] ?? '' ); ?></td>
                                <td><?php echo esc_html( $log['existing_questions'] ?? '' ); ?></td>
                                <td><?php echo esc_html( $log['quiz_banks'] ?? '' ); ?></td>
                                <td><?php echo esc_html( $log['errors'] ?? '' ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    private function render_result( $result ) {
        $status_class = empty( $result['errors'] ) ? 'gb-lpq-ok' : 'gb-lpq-bad';
        ?>
        <div class="gb-lpq-card">
            <h2>Importer result</h2>
            <p class="<?php echo esc_attr( $status_class ); ?>"><?php echo esc_html( $result['message'] ); ?></p>
            <div class="gb-lpq-summary">
                <div><strong>Mode</strong><br /><?php echo esc_html( $result['mode'] ); ?></div>
                <div><strong>Rows parsed</strong><br /><?php echo esc_html( $result['rows_parsed'] ); ?></div>
                <div><strong>Questions created</strong><br /><?php echo esc_html( $result['created_questions'] ); ?></div>
                <div><strong>Existing questions used</strong><br /><?php echo esc_html( $result['existing_questions'] ); ?></div>
                <div><strong>Banks created/reused</strong><br /><?php echo esc_html( count( $result['banks'] ) ); ?></div>
                <div><strong>Questions attached</strong><br /><?php echo esc_html( $result['attached_questions'] ); ?></div>
            </div>

            <?php if ( ! empty( $result['banks'] ) ) : ?>
                <h3>Quiz / bank summary</h3>
                <table class="widefat striped gb-lpq-table">
                    <thead><tr><th>Bank title</th><th>Quiz ID</th><th>Status</th><th>Questions linked</th></tr></thead>
                    <tbody>
                    <?php foreach ( $result['banks'] as $bank ) : ?>
                        <tr>
                            <td><?php echo esc_html( $bank['title'] ); ?></td>
                            <td><?php echo esc_html( $bank['id'] ?: 'Preview' ); ?></td>
                            <td><?php echo esc_html( $bank['status'] ); ?></td>
                            <td><?php echo esc_html( $bank['count'] ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <p class="gb-lpq-small">After importing, insert the generated LearnPress quiz/bank at the end of the correct module in the course curriculum.</p>
            <?php endif; ?>

            <?php if ( ! empty( $result['row_results'] ) ) : ?>
                <h3>Row details</h3>
                <table class="widefat striped gb-lpq-table">
                    <thead><tr><th>Row</th><th>Question title</th><th>Bank</th><th>Status</th><th>Message</th></tr></thead>
                    <tbody>
                    <?php foreach ( array_slice( $result['row_results'], 0, 100 ) as $row ) : ?>
                        <tr>
                            <td><?php echo esc_html( $row['row'] ); ?></td>
                            <td><?php echo esc_html( $row['question_title'] ); ?></td>
                            <td><?php echo esc_html( $row['bank_title'] ); ?></td>
                            <td><?php echo esc_html( $row['status'] ); ?></td>
                            <td><?php echo esc_html( $row['message'] ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <?php if ( ! empty( $result['errors'] ) ) : ?>
                <h3>Errors</h3>
                <ul>
                    <?php foreach ( $result['errors'] as $error ) : ?>
                        <li class="gb-lpq-bad"><?php echo esc_html( $error ); ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
        <?php
    }

    private function handle_upload() {
        $mode = isset( $_POST['gb_lpq_mode'] ) && 'import' === $_POST['gb_lpq_mode'] ? 'import' : 'preview';
        $attach_existing = ! empty( $_POST['gb_lpq_attach_existing'] );

        $result = array(
            'mode'               => $mode,
            'message'            => '',
            'rows_parsed'        => 0,
            'created_questions'  => 0,
            'existing_questions' => 0,
            'attached_questions' => 0,
            'banks'              => array(),
            'row_results'        => array(),
            'errors'             => array(),
        );

        if ( empty( $_FILES['gb_lpq_file']['tmp_name'] ) || ! is_uploaded_file( $_FILES['gb_lpq_file']['tmp_name'] ) ) {
            $result['errors'][] = 'No upload was received.';
            $result['message']  = 'Upload failed.';
            return $result;
        }

        $file_name = sanitize_file_name( $_FILES['gb_lpq_file']['name'] ?? 'import' );
        $extension = strtolower( pathinfo( $file_name, PATHINFO_EXTENSION ) );
        if ( ! in_array( $extension, array( 'xlsx', 'csv' ), true ) ) {
            $result['errors'][] = 'Only .xlsx and .csv files are supported.';
            $result['message']  = 'Unsupported file type.';
            return $result;
        }

        $parsed = 'xlsx' === $extension ? $this->parse_xlsx( $_FILES['gb_lpq_file']['tmp_name'] ) : $this->parse_csv( $_FILES['gb_lpq_file']['tmp_name'] );
        if ( is_wp_error( $parsed ) ) {
            $result['errors'][] = $parsed->get_error_message();
            $result['message']  = 'Could not read file.';
            return $result;
        }

        $rows = $this->normalize_rows( $parsed, $result['errors'] );
        $result['rows_parsed'] = count( $rows );

        if ( empty( $rows ) ) {
            $result['errors'][] = 'No valid rows were found.';
        }

        $duplicate_titles = $this->find_duplicate_titles( $rows );
        foreach ( $duplicate_titles as $title ) {
            $result['errors'][] = 'Duplicate question title in import file: ' . $title;
        }

        if ( ! empty( $result['errors'] ) || 'preview' === $mode ) {
            $result['banks']       = $this->preview_banks( $rows );
            $result['row_results'] = $this->preview_rows( $rows, $attach_existing );
            $result['message']     = empty( $result['errors'] ) ? 'Preview completed. No database changes were made.' : 'Preview found errors. No database changes were made.';
            $this->log_import( $file_name, $result );
            return $result;
        }

        if ( ! post_type_exists( 'lp_question' ) || ! post_type_exists( 'lp_quiz' ) ) {
            $result['errors'][] = 'LearnPress question/quiz post types are not available. Is LearnPress active?';
            $result['message']  = 'LearnPress is not ready.';
            $this->log_import( $file_name, $result );
            return $result;
        }

        $imported_banks = array();
        foreach ( $rows as $row ) {
            $bank_title = $row['bank_title'];
            if ( ! isset( $imported_banks[ $bank_title ] ) ) {
                $bank = $this->get_or_create_quiz_bank( $bank_title, $row['bank_description'] ?? '' );
                if ( is_wp_error( $bank ) ) {
                    $result['errors'][] = $bank->get_error_message();
                    continue;
                }
                $imported_banks[ $bank_title ] = array(
                    'id'     => $bank['id'],
                    'title'  => $bank_title,
                    'status' => $bank['status'],
                    'count'  => 0,
                );
            }

            $question_id = $this->find_post_by_exact_title( $row['question_title'], 'lp_question' );
            if ( $question_id ) {
                if ( ! $attach_existing ) {
                    $result['row_results'][] = array(
                        'row'            => $row['_row'],
                        'question_title' => $row['question_title'],
                        'bank_title'     => $bank_title,
                        'status'         => 'skipped_existing',
                        'message'        => 'Question already exists and attach-existing was disabled.',
                    );
                    continue;
                }
                $result['existing_questions']++;
            } else {
                $question_id = $this->create_question( $row );
                if ( is_wp_error( $question_id ) ) {
                    $result['errors'][] = 'Row ' . $row['_row'] . ': ' . $question_id->get_error_message();
                    $result['row_results'][] = array(
                        'row'            => $row['_row'],
                        'question_title' => $row['question_title'],
                        'bank_title'     => $bank_title,
                        'status'         => 'error',
                        'message'        => $question_id->get_error_message(),
                    );
                    continue;
                }
                $result['created_questions']++;
            }

            $attached = $this->attach_question_to_quiz( $imported_banks[ $bank_title ]['id'], $question_id );
            if ( is_wp_error( $attached ) ) {
                $result['errors'][] = 'Row ' . $row['_row'] . ': ' . $attached->get_error_message();
                $status = 'error';
                $message = $attached->get_error_message();
            } elseif ( $attached ) {
                $result['attached_questions']++;
                $imported_banks[ $bank_title ]['count']++;
                $status = 'imported';
                $message = 'Question linked to bank.';
            } else {
                $status = 'already_linked';
                $message = 'Question already linked to bank.';
            }

            $result['row_results'][] = array(
                'row'            => $row['_row'],
                'question_title' => $row['question_title'],
                'bank_title'     => $bank_title,
                'status'         => $status,
                'message'        => $message,
            );
        }

        $result['banks'] = array_values( $imported_banks );
        $result['message'] = empty( $result['errors'] ) ? 'Import completed successfully.' : 'Import completed with errors.';
        $this->log_import( $file_name, $result );
        return $result;
    }

    private function parse_csv( $path ) {
        $handle = fopen( $path, 'r' );
        if ( ! $handle ) {
            return new WP_Error( 'gb_lpq_csv_open', 'Could not open CSV file.' );
        }
        $rows = array();
        while ( false !== ( $data = fgetcsv( $handle ) ) ) {
            $rows[] = $data;
        }
        fclose( $handle );
        return $rows;
    }

    private function parse_xlsx( $path ) {
        if ( ! class_exists( 'ZipArchive' ) ) {
            return new WP_Error( 'gb_lpq_no_zip', 'PHP ZipArchive is required to read .xlsx files.' );
        }

        $zip = new ZipArchive();
        if ( true !== $zip->open( $path ) ) {
            return new WP_Error( 'gb_lpq_xlsx_open', 'Could not open .xlsx file.' );
        }

        $shared_strings = array();
        $shared_xml = $zip->getFromName( 'xl/sharedStrings.xml' );
        if ( false !== $shared_xml && class_exists( 'DOMDocument' ) ) {
            $dom = new DOMDocument();
            $loaded = @$dom->loadXML( $shared_xml );
            if ( $loaded ) {
                $xpath = new DOMXPath( $dom );
                foreach ( $xpath->query( '//*[local-name()="si"]' ) as $si ) {
                    $parts = array();
                    foreach ( $xpath->query( './/*[local-name()="t"]', $si ) as $t ) {
                        $parts[] = $t->textContent;
                    }
                    $shared_strings[] = implode( '', $parts );
                }
            }
        }

        $sheet_xml = $zip->getFromName( 'xl/worksheets/sheet1.xml' );
        if ( false === $sheet_xml ) {
            $zip->close();
            return new WP_Error( 'gb_lpq_xlsx_sheet', 'Could not read first worksheet from .xlsx file.' );
        }

        if ( ! class_exists( 'DOMDocument' ) ) {
            $zip->close();
            return new WP_Error( 'gb_lpq_no_dom', 'PHP DOMDocument is required to read .xlsx worksheet XML.' );
        }

        $dom = new DOMDocument();
        $loaded = @$dom->loadXML( $sheet_xml );
        if ( ! $loaded ) {
            $zip->close();
            return new WP_Error( 'gb_lpq_xlsx_xml', 'Could not parse first worksheet XML.' );
        }

        $xpath = new DOMXPath( $dom );
        $rows = array();

        foreach ( $xpath->query( '//*[local-name()="sheetData"]/*[local-name()="row"]' ) as $row ) {
            $values = array();
            $max_index = -1;

            foreach ( $xpath->query( './*[local-name()="c"]', $row ) as $cell ) {
                $ref = $cell->getAttribute( 'r' );
                $index = $this->column_index_from_cell_ref( $ref );
                $max_index = max( $max_index, $index );
                $type = $cell->getAttribute( 't' );
                $value = '';

                if ( 's' === $type ) {
                    $v_node = $xpath->query( './*[local-name()="v"]', $cell )->item( 0 );
                    $v = $v_node ? (int) $v_node->textContent : -1;
                    $value = ( $v >= 0 && isset( $shared_strings[ $v ] ) ) ? $shared_strings[ $v ] : '';
                } elseif ( 'inlineStr' === $type ) {
                    $parts = array();
                    foreach ( $xpath->query( './/*[local-name()="t"]', $cell ) as $t ) {
                        $parts[] = $t->textContent;
                    }
                    $value = implode( '', $parts );
                } else {
                    // Handles t="str", numeric cells, formula cached values, and plain cells.
                    $v_node = $xpath->query( './*[local-name()="v"]', $cell )->item( 0 );
                    $value = $v_node ? $v_node->textContent : '';
                }

                $values[ $index ] = $value;
            }

            if ( $max_index >= 0 ) {
                $full = array();
                for ( $i = 0; $i <= $max_index; $i++ ) {
                    $full[] = isset( $values[ $i ] ) ? $values[ $i ] : '';
                }
                $rows[] = $full;
            }
        }

        $zip->close();

        if ( empty( $rows ) ) {
            return new WP_Error( 'gb_lpq_xlsx_empty_sheet', 'The first worksheet was parsed, but no rows were found.' );
        }

        return $rows;
    }

    private function column_index_from_cell_ref( $ref ) {
        if ( ! preg_match( '/^([A-Z]+)/i', $ref, $matches ) ) {
            return 0;
        }
        $letters = strtoupper( $matches[1] );
        $index = 0;
        for ( $i = 0; $i < strlen( $letters ); $i++ ) {
            $index = $index * 26 + ( ord( $letters[ $i ] ) - 64 );
        }
        return $index - 1;
    }

    private function normalize_rows( $raw_rows, &$errors ) {
        $raw_rows = is_array( $raw_rows ) ? $raw_rows : array();
        if ( empty( $raw_rows ) ) {
            $errors[] = 'Spreadsheet is empty.';
            return array();
        }

        $headers = array_map( array( $this, 'normalize_header' ), $raw_rows[0] );
        $required = array( 'question_title', 'question_text', 'answer_a', 'answer_b', 'answer_c', 'answer_d', 'correct_answer', 'bank_title' );
        foreach ( $required as $header ) {
            if ( ! in_array( $header, $headers, true ) ) {
                $errors[] = 'Missing required column: ' . $header;
            }
        }
        if ( ! empty( $errors ) ) {
            return array();
        }

        $rows = array();
        for ( $i = 1; $i < count( $raw_rows ); $i++ ) {
            $line = $raw_rows[ $i ];
            $assoc = array();
            foreach ( $headers as $index => $key ) {
                if ( '' === $key ) {
                    continue;
                }
                $assoc[ $key ] = isset( $line[ $index ] ) ? trim( (string) $line[ $index ] ) : '';
            }

            if ( ! array_filter( $assoc, 'strlen' ) ) {
                continue;
            }

            $row_errors = $this->validate_row( $assoc, $i + 1 );
            if ( ! empty( $row_errors ) ) {
                foreach ( $row_errors as $error ) {
                    $errors[] = $error;
                }
                continue;
            }

            $assoc['_row'] = $i + 1;
            $assoc['points'] = isset( $assoc['points'] ) && is_numeric( $assoc['points'] ) ? max( 0, (float) $assoc['points'] ) : 1;
            $assoc['question_type'] = 'single_choice';
            $rows[] = $assoc;
        }
        return $rows;
    }

    private function normalize_header( $header ) {
        $header = strtolower( trim( (string) $header ) );
        $header = preg_replace( '/[^a-z0-9]+/', '_', $header );
        return trim( $header, '_' );
    }

    private function validate_row( $row, $row_num ) {
        $errors = array();
        $fields = array( 'question_title', 'question_text', 'answer_a', 'answer_b', 'answer_c', 'answer_d', 'correct_answer', 'bank_title' );
        foreach ( $fields as $field ) {
            if ( empty( $row[ $field ] ) ) {
                $errors[] = 'Row ' . $row_num . ' missing ' . $field . '.';
            }
        }
        $correct = strtoupper( trim( $row['correct_answer'] ?? '' ) );
        if ( ! in_array( $correct, array( 'A', 'B', 'C', 'D' ), true ) ) {
            $errors[] = 'Row ' . $row_num . ' correct_answer must be A, B, C, or D.';
        }
        if ( ! empty( $row['question_type'] ) && 'single_choice' !== strtolower( trim( $row['question_type'] ) ) ) {
            $errors[] = 'Row ' . $row_num . ' question_type must be single_choice for this importer.';
        }
        return $errors;
    }

    private function find_duplicate_titles( $rows ) {
        $seen = array();
        $dupes = array();
        foreach ( $rows as $row ) {
            $key = strtolower( $row['question_title'] );
            if ( isset( $seen[ $key ] ) ) {
                $dupes[ $row['question_title'] ] = true;
            }
            $seen[ $key ] = true;
        }
        return array_keys( $dupes );
    }

    private function preview_banks( $rows ) {
        $banks = array();
        foreach ( $rows as $row ) {
            $title = $row['bank_title'];
            if ( ! isset( $banks[ $title ] ) ) {
                $existing = $this->find_post_by_exact_title( $title, 'lp_quiz' );
                $banks[ $title ] = array(
                    'title'  => $title,
                    'id'     => $existing,
                    'status' => $existing ? 'existing quiz/bank will be reused' : 'new quiz/bank will be created',
                    'count'  => 0,
                );
            }
            $banks[ $title ]['count']++;
        }
        return array_values( $banks );
    }

    private function preview_rows( $rows, $attach_existing ) {
        $out = array();
        foreach ( $rows as $row ) {
            $existing = $this->find_post_by_exact_title( $row['question_title'], 'lp_question' );
            if ( $existing && $attach_existing ) {
                $status = 'existing';
                $message = 'Existing question will be attached to the bank.';
            } elseif ( $existing ) {
                $status = 'skipped';
                $message = 'Existing question would be skipped because attach-existing is off.';
            } else {
                $status = 'new';
                $message = 'Question will be created.';
            }
            $out[] = array(
                'row'            => $row['_row'],
                'question_title' => $row['question_title'],
                'bank_title'     => $row['bank_title'],
                'status'         => $status,
                'message'        => $message,
            );
        }
        return $out;
    }

    private function get_or_create_quiz_bank( $title, $description = '' ) {
        $description = $this->student_friendly_bank_description( $title, $description );

        $existing = $this->find_post_by_exact_title( $title, 'lp_quiz' );
        if ( $existing ) {
            $this->apply_safe_quiz_settings( $existing );

            // v0.1.2: If the bank was created by an older importer with the stiff
            // compliance-facing default text, replace that with student-friendly copy.
            $old_default = 'GulfBreeze imported mastery question bank. This quiz is used as a question bank for a compliance-controlled module mastery plugin.';
            $existing_post = get_post( $existing );
            if ( $existing_post && trim( (string) $existing_post->post_content ) === $old_default ) {
                wp_update_post(
                    array(
                        'ID'           => $existing,
                        'post_content' => $description,
                    )
                );
            }

            return array( 'id' => $existing, 'status' => 'existing' );
        }

        $quiz_id = wp_insert_post(
            array(
                'post_type'    => 'lp_quiz',
                'post_title'   => $title,
                'post_content' => $description,
                'post_status'  => 'publish',
            ),
            true
        );
        if ( is_wp_error( $quiz_id ) || ! $quiz_id ) {
            return new WP_Error( 'gb_lpq_quiz_create', 'Could not create quiz/bank: ' . $title );
        }
        $this->apply_safe_quiz_settings( $quiz_id );
        update_post_meta( $quiz_id, '_gb_lpq_imported_bank', 'yes' );
        update_post_meta( $quiz_id, '_gb_lpq_imported_at_utc', gmdate( 'Y-m-d H:i:s' ) );
        return array( 'id' => $quiz_id, 'status' => 'created' );
    }

    private function student_friendly_bank_description( $title, $description = '' ) {
        $description = trim( (string) $description );
        if ( '' !== $description ) {
            return $description;
        }

        if ( preg_match( '/Teen\s+Module\s+(\d+)\s+Mastery\s+Bank/i', (string) $title, $m ) ) {
            $module = absint( $m[1] );
            return sprintf(
                'This quick check helps you review the most important ideas from Module %d before moving forward. Take your time, think through each situation, and choose the safest answer based on what you learned in the module.',
                $module
            );
        }

        if ( preg_match( '/Adult\s+Topic\s+(\d+)\s+Participation\s+Bank/i', (string) $title, $m ) ) {
            $topic = absint( $m[1] );
            return sprintf(
                'This quick check helps you review the key ideas from Topic %d before moving forward. Take your time, think through each situation, and choose the best answer based on what you learned.',
                $topic
            );
        }

        if ( false !== stripos( (string) $title, 'Final' ) ) {
            return 'This final check helps you review the important traffic law and road sign knowledge from the course. Take your time, read each question carefully, and choose the best answer.';
        }

        return 'This quick check helps you review what you learned before moving forward. Take your time, think through each situation, and choose the best answer.';
    }

    private function apply_safe_quiz_settings( $quiz_id ) {
        update_post_meta( $quiz_id, '_lp_duration', '0' );
        update_post_meta( $quiz_id, '_lp_passing_grade', '70' );
        update_post_meta( $quiz_id, '_lp_instant_check', 'no' );
        update_post_meta( $quiz_id, '_lp_negative_marking', 'no' );
        update_post_meta( $quiz_id, '_lp_minus_skip_questions', 'no' );
        update_post_meta( $quiz_id, '_lp_retake_count', '-1' );
        update_post_meta( $quiz_id, '_lp_pagination', '1' );
        update_post_meta( $quiz_id, '_lp_review', 'no' );
        update_post_meta( $quiz_id, '_lp_show_correct_review', 'no' );
    }

    private function create_question( $row ) {
        $question_id = wp_insert_post(
            array(
                'post_type'    => 'lp_question',
                'post_status'  => 'publish',
                'post_title'   => $row['question_title'],
                'post_content' => $row['question_text'],
            ),
            true
        );
        if ( is_wp_error( $question_id ) || ! $question_id ) {
            return new WP_Error( 'gb_lpq_question_create', 'Could not create question.' );
        }

        update_post_meta( $question_id, '_lp_type', 'single_choice' );
        update_post_meta( $question_id, '_lp_mark', $row['points'] );
        update_post_meta( $question_id, '_gb_lpq_course_type', $row['course_type'] ?? '' );
        update_post_meta( $question_id, '_gb_lpq_module', $row['module'] ?? '' );
        update_post_meta( $question_id, '_gb_lpq_objective_code', $row['objective_code'] ?? '' );
        update_post_meta( $question_id, '_gb_lpq_poi_topic', $row['poi_topic'] ?? '' );
        update_post_meta( $question_id, '_gb_lpq_bank_title', $row['bank_title'] ?? '' );
        update_post_meta( $question_id, '_gb_lpq_source_url', $row['source_url'] ?? '' );
        update_post_meta( $question_id, '_gb_lpq_imported_at_utc', gmdate( 'Y-m-d H:i:s' ) );

        $answers = array(
            'A' => $row['answer_a'],
            'B' => $row['answer_b'],
            'C' => $row['answer_c'],
            'D' => $row['answer_d'],
        );
        $correct = strtoupper( $row['correct_answer'] );

        global $wpdb;
        $table = $wpdb->prefix . 'learnpress_question_answers';
        foreach ( $answers as $letter => $answer_text ) {
            $value = function_exists( 'learn_press_random_value' ) ? learn_press_random_value() : wp_generate_uuid4();
            $inserted = $wpdb->insert(
                $table,
                array(
                    'question_id' => $question_id,
                    'title'       => $answer_text,
                    'value'       => $value,
                    'is_true'     => $letter === $correct ? 'yes' : 'no',
                    'order'       => array_search( $letter, array( 'A', 'B', 'C', 'D' ), true ) + 1,
                ),
                array( '%d', '%s', '%s', '%s', '%d' )
            );
            if ( ! $inserted ) {
                return new WP_Error( 'gb_lpq_answer_insert', 'Created question but failed to insert answer option for ' . $row['question_title'] . '. Database message: ' . $wpdb->last_error );
            }
        }
        return $question_id;
    }

    private function attach_question_to_quiz( $quiz_id, $question_id ) {
        global $wpdb;
        $table = $wpdb->prefix . 'learnpress_quiz_questions';
        $existing = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT quiz_question_id FROM {$table} WHERE quiz_id = %d AND question_id = %d LIMIT 1",
                $quiz_id,
                $question_id
            )
        );
        if ( $existing ) {
            return false;
        }
        $order = (int) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(question_order) FROM {$table} WHERE quiz_id = %d", $quiz_id ) );
        $order++;
        $inserted = $wpdb->insert(
            $table,
            array(
                'quiz_id'        => $quiz_id,
                'question_id'    => $question_id,
                'question_order' => $order,
            ),
            array( '%d', '%d', '%d' )
        );
        if ( ! $inserted ) {
            return new WP_Error( 'gb_lpq_attach_failed', 'Could not attach question to quiz/bank. Database message: ' . $wpdb->last_error );
        }
        return true;
    }

    private function find_post_by_exact_title( $title, $post_type ) {
        global $wpdb;
        $post_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_title = %s AND post_type = %s AND post_status NOT IN ('trash','auto-draft') ORDER BY ID ASC LIMIT 1",
                $title,
                $post_type
            )
        );
        return $post_id ? absint( $post_id ) : 0;
    }

    private function log_import( $file_name, $result ) {
        $logs = get_option( self::LOG_OPTION, array() );
        $logs = is_array( $logs ) ? $logs : array();
        $logs[] = array(
            'time'               => gmdate( 'Y-m-d H:i:s' ),
            'mode'               => $result['mode'] ?? '',
            'file'               => $file_name,
            'rows'               => $result['rows_parsed'] ?? 0,
            'created_questions'  => $result['created_questions'] ?? 0,
            'existing_questions' => $result['existing_questions'] ?? 0,
            'quiz_banks'         => isset( $result['banks'] ) && is_array( $result['banks'] ) ? count( $result['banks'] ) : 0,
            'errors'             => isset( $result['errors'] ) && is_array( $result['errors'] ) ? count( $result['errors'] ) : 0,
        );
        update_option( self::LOG_OPTION, array_slice( $logs, -30 ), false );
    }
}

new GulfBreeze_LP_Question_Importer();
