<?php
/**
 * Plugin Name: GulfBreeze Course Mastery Gate
 * Description: LearnPress module/topic mastery engine for Texas teen AMI and adult online course participation/final exam rules. Uses LearnPress quizzes as question banks and administers GulfBreeze-controlled mastery checks with audit logs. v0.2.0 adds server-enforced adult-final timing, session/browser binding, student attestation, signed question sets, and stable per-attempt answer ordering.
 * Version: 0.2.0
 * Author: GulfBreeze / Drive Smart
 * Text Domain: gulf-breeze-course-mastery-gate
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class GulfBreeze_Course_Mastery_Gate {
    const VERSION         = '0.2.0';
	const FINAL_TIME_LIMIT_SECONDS = 2700;
    const OPTION_MAPS     = 'gbcmg_mappings';
    const OPTION_EVENTS   = 'gbcmg_events';
    const NONCE_SAVE      = 'gbcmg_save_mappings';
    const MENU_SLUG       = 'gb-course-mastery-gate';

    private static $instance = null;
    private $course_items_cache = array();
    private $table_cols_cache = array();

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_menu', array( $this, 'admin_menu' ) );
        add_action( 'admin_post_gbcmg_save_mappings', array( $this, 'handle_save_mappings' ) );
        add_action( 'admin_post_gbcmg_clear_events', array( $this, 'handle_clear_events' ) );
        add_action( 'admin_post_gbcmg_clear_adult_final_lockout', array( $this, 'handle_clear_adult_final_lockout' ) );
        add_action( 'template_redirect', array( $this, 'template_redirect_gate' ), 1 );
        add_action( 'wp_footer', array( $this, 'footer_gate_script' ), 99 );

        // Belt-and-suspenders: suppress correct-answer reveal for mapped bank quizzes.
        foreach ( array(
            'learn-press/quiz/show-correct-answer',
            'learn-press/quiz-show-correct-answer',
            'learn_press_quiz_show_correct_answer',
            'learn-press/quiz/show-explanation',
            'learn-press/quiz-review-questions',
            'learn_press_quiz_review_questions',
            'learn-press/quiz/instant-check',
        ) as $hook ) {
            add_filter( $hook, array( $this, 'force_hide_answer_for_mapped_bank' ), 9999, 3 );
        }
    }

    public static function activate() {
        if ( false === get_option( self::OPTION_MAPS, false ) ) {
            add_option( self::OPTION_MAPS, array(), '', false );
        }
        if ( false === get_option( self::OPTION_EVENTS, false ) ) {
            add_option( self::OPTION_EVENTS, array(), '', false );
        }
    }

    public function admin_menu() {
        add_menu_page(
            'GulfBreeze Course Mastery Gate',
            'Course Mastery Gate',
            'manage_options',
            self::MENU_SLUG,
            array( $this, 'render_admin_page' ),
            'dashicons-welcome-learn-more',
            59
        );
    }

    public function render_admin_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $all_maps    = $this->get_mappings();
        $courses     = $this->get_lp_courses();
        $all_quiz_opts = $this->get_all_quiz_options();
        $events_all  = get_option( self::OPTION_EVENTS, array() );
        $events_all  = is_array( $events_all ) ? $events_all : array();
        $events      = array_slice( array_reverse( $events_all ), 0, 75 );

        $reader_course    = isset( $_GET['gbcmg_reader_course'] ) ? absint( $_GET['gbcmg_reader_course'] ) : 0;
        $report_requested = isset( $_GET['gbcmg_report'] );
        $report_user_id   = isset( $_GET['gbcmg_report_user'] )   ? absint( $_GET['gbcmg_report_user'] )                          : 0;
        $report_course_id = isset( $_GET['gbcmg_report_course'] )  ? absint( $_GET['gbcmg_report_course'] )                       : 0;
        $report_from      = isset( $_GET['gbcmg_report_from'] )    ? sanitize_text_field( wp_unslash( $_GET['gbcmg_report_from'] ) ) : '';
        $report_to        = isset( $_GET['gbcmg_report_to'] )      ? sanitize_text_field( wp_unslash( $_GET['gbcmg_report_to'] ) )   : '';
        $report_events    = $report_requested ? $this->filter_inspection_events( $events_all, $report_user_id, $report_course_id, $report_from, $report_to ) : array();

        // ── Group real (non-blank) mappings by course_id ──────────────────────
        $maps_by_course = array();
        foreach ( $all_maps as $map ) {
            if ( ! $this->mapping_has_any_ids( $map ) ) {
                continue;
            }
            $cid = absint( $map['course_id'] ?? 0 );
            if ( $cid ) {
                $maps_by_course[ $cid ][] = $map;
            }
        }

        // ── Pre-load curriculum items for every course that has mappings ───────
        // item_opts → real curriculum items only (used for start_item_id and next_item_id).
        // Bank dropdowns intentionally use all published LearnPress quizzes so final exam
        // banks do NOT have to be attached to the student-facing curriculum.
        $quiz_opts = array(); // retained for backward-safe fallback; bank selects use $all_quiz_opts.
        $item_opts = array();
        foreach ( array_keys( $maps_by_course ) as $cid ) {
            $quiz_opts[ $cid ] = array();
            $item_opts[ $cid ] = array();
            foreach ( $this->get_course_items( $cid ) as $item ) {
                $iid   = absint( $item['item_id'] );
                $type  = get_post_type( $iid );
                $title = get_the_title( $iid );
                $lbl   = '#' . $iid . ' — ' . $title;
                $item_opts[ $cid ][] = array( 'id' => $iid, 'label' => $lbl, 'type' => $type );
                if ( 'lp_quiz' === $type ) {
                    $quiz_opts[ $cid ][] = array( 'id' => $iid, 'label' => $lbl );
                }
            }
        }

        ?>
        <div class="wrap gbcmg-wrap">
            <h1>GulfBreeze Course Mastery Gate <span style="font-size:14px;font-weight:400;">v<?php echo esc_html( self::VERSION ); ?></span></h1>
            <p>Module/topic mastery engine: LearnPress quizzes as question banks, GulfBreeze-controlled mastery checks with audit logs.</p>

            <?php echo wp_kses_post( $this->render_setup_diagnostics( $all_maps ) ); ?>

            <?php if ( isset( $_GET['gbcmg_saved'] ) ) : ?>
                <div class="notice notice-success is-dismissible"><p>Course mastery mappings saved.</p></div>
            <?php endif; ?>
            <?php if ( isset( $_GET['gbcmg_cleared'] ) ) : ?>
                <div class="notice notice-success is-dismissible"><p>Recent Course Mastery Gate events cleared.</p></div>
            <?php endif; ?>
            <?php if ( isset( $_GET['gbcmg_lockout_cleared'] ) ) : ?>
                <div class="notice notice-success is-dismissible"><p>Final exam lockout cleared for the selected student.</p></div>
            <?php endif; ?>

            <style>
                /* ── base ── */
                .gbcmg-wrap table.widefat td,
                .gbcmg-wrap table.widefat th { vertical-align: top; }
                .gbcmg-small  { color: #646970; font-size: 12px; }
                .gbcmg-code   { font-family: Consolas, Monaco, monospace; background: #f6f7f7; padding: 2px 4px; border-radius: 3px; }
                .gbcmg-ok     { color: #008a20; font-weight: 600; }
                .gbcmg-warn   { color: #996800; font-weight: 600; }
                .gbcmg-bad    { color: #b32d2e; font-weight: 600; }
                .gbcmg-card   { background: #fff; border: 1px solid #c3c4c7; padding: 16px; margin: 16px 0; }
                .gbcmg-validation ul { margin: 4px 0 0 18px; list-style: disc; }

                /* ── health summary ── */
                .gbcmg-health-grid   { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 10px; margin-top: 10px; }
                .gbcmg-health-course { border: 1px solid #dcdcde; border-left: 4px solid #72aee6; background: #fff; padding: 10px 12px; }
                .gbcmg-health-course.gbcmg-health-bad { border-left-color: #d63638; background: #fff8f8; }
                .gbcmg-badge         { display: inline-block; padding: 2px 9px; border-radius: 10px; font-size: 12px; font-weight: 600; }
                .gbcmg-badge-total   { background: #f0f0f1; color: #3c434a; }
                .gbcmg-badge-ok      { background: #d6ffe4; color: #006b2b; }
                .gbcmg-badge-bad     { background: #fde8e8; color: #8b1f1f; }

                /* ── per-course collapsible sections ── */
                .gbcmg-course-section {
                    background: #fff;
                    border: 1px solid #c3c4c7;
                    border-radius: 4px;
                    margin: 14px 0;
                }
                .gbcmg-course-section > summary {
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    padding: 11px 16px;
                    cursor: pointer;
                    user-select: none;
                    border-bottom: 1px solid #e2e4e7;
                    list-style: none;
                }
                .gbcmg-course-section > summary::-webkit-details-marker { display: none; }
                .gbcmg-course-section > summary::before {
                    content: '\25B6';
                    font-size: 11px;
                    color: #646970;
                    transition: transform .15s;
                    flex-shrink: 0;
                }
                .gbcmg-course-section[open] > summary::before { transform: rotate(90deg); }
                .gbcmg-course-section > summary h2 { margin: 0; font-size: 15px; font-weight: 600; flex: 1; }
                .gbcmg-course-badges { display: flex; gap: 6px; flex-shrink: 0; }
                .gbcmg-course-inner  { padding: 0 16px 16px; overflow-x: auto; }

                /* ── mapping table ── */
                .gbcmg-map-table { margin-top: 12px; border-collapse: collapse; min-width: 1120px; }
                .gbcmg-map-table th,
                .gbcmg-map-table td  { padding: 7px 9px; }
                .gbcmg-map-table thead th { background: #f6f7f7; }
                .gbcmg-map-table tbody tr:nth-child(odd) { background: #fafafa; }
                .gbcmg-map-table tbody tr.gbcmg-row-bad td { background: #fff1f1 !important; border-top: 2px solid #d63638; border-bottom: 2px solid #d63638; }
                .gbcmg-map-table tbody tr.gbcmg-row-bad td:first-child { border-left: 4px solid #d63638; }
                .gbcmg-map-table select { max-width: 260px; }
                .gbcmg-input-sm  { width: 70px; }
                .gbcmg-input-lbl { width: 160px; }
                .gbcmg-delete-cell { min-width: 76px; }
                .gbcmg-blank-row td { border-top: 2px dashed #c3c4c7 !important; background: #f6f7f7 !important; }

                /* ── new-course fallback ── */
                .gbcmg-new-course-section { background: #f9f9fb; border-style: dashed; }
                .gbcmg-new-course-section > summary h2 { color: #646970; font-weight: 400; }

                /* ── report ── */
                .gbcmg-report-header { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 6px 24px; margin: 14px 0; }
                .gbcmg-report-table th, .gbcmg-report-table td { font-size: 12px; }
                @media print {
                    body * { visibility: hidden !important; }
                    #gbcmg-student-inspection-report,
                    #gbcmg-student-inspection-report * { visibility: visible !important; }
                    #gbcmg-student-inspection-report { position: absolute; left: 0; top: 0; width: 100%; background: #fff; padding: 0; margin: 0; }
                    #adminmenumain, #wpadminbar, #wpfooter, .notice, .gbcmg-no-print { display: none !important; }
                    #gbcmg-student-inspection-report table { border-collapse: collapse; width: 100%; }
                    #gbcmg-student-inspection-report th,
                    #gbcmg-student-inspection-report td { border: 1px solid #777; padding: 5px; }
                }
            </style>

            <!-- ══════════════════════════════════════════════════════ -->
            <!-- Course Health Summary                                  -->
            <!-- ══════════════════════════════════════════════════════ -->
            <div class="gbcmg-card gbcmg-no-print">
                <h2>Course Health Summary</h2>
                <div class="gbcmg-health-grid">
                    <?php foreach ( $maps_by_course as $hcid => $hmaps ) :
                        $h_ok = $h_bad = $h_blank = 0;
                        foreach ( $hmaps as $hm ) {
                            $v = $this->validate_mapping( $hm );
                            if ( 'ok' === $v['status'] || 'disabled' === $v['status'] ) {
                                $h_ok++;
                            } elseif ( 'bad' === $v['status'] ) {
                                $h_bad++;
                            } else {
                                $h_blank++;
                            }
                        }
                        $h_title = get_the_title( $hcid ) ?: 'Course #' . $hcid;
                    ?>
                        <div class="gbcmg-health-course <?php echo $h_bad ? 'gbcmg-health-bad' : ''; ?>">
                            <strong><?php echo esc_html( $h_title ); ?></strong><br>
                            <span class="gbcmg-small">Course #<?php echo esc_html( $hcid ); ?></span><br>
                            <span class="gbcmg-badge gbcmg-badge-total"><?php echo esc_html( count( $hmaps ) ); ?> mapping<?php echo 1 !== count( $hmaps ) ? 's' : ''; ?></span>
                            <?php if ( $h_ok )    : ?><span class="gbcmg-badge gbcmg-badge-ok"><?php echo esc_html( $h_ok ); ?> ✓</span><?php endif; ?>
                            <?php if ( $h_bad )   : ?><span class="gbcmg-badge gbcmg-badge-bad"><?php echo esc_html( $h_bad ); ?> ✗</span><?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                    <?php if ( empty( $maps_by_course ) ) : ?>
                        <p class="gbcmg-small">No saved mappings yet. Add one below.</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- ══════════════════════════════════════════════════════ -->
            <!-- Mastery Mappings — one collapsible section per course -->
            <!-- Bad courses open automatically; clean ones collapsed.  -->
            <!-- ══════════════════════════════════════════════════════ -->
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <?php wp_nonce_field( self::NONCE_SAVE ); ?>
                <input type="hidden" name="action" value="gbcmg_save_mappings" />

                <?php
                $map_idx      = 0;  // global counter — keeps maps[N][field] unique across all sections
                $unit_type_labels = $this->unit_type_options();

                foreach ( $maps_by_course as $cid => $course_maps ) :
                    $course_title = get_the_title( $cid ) ?: 'Course #' . $cid;
                    $count_ok = $count_bad = 0;
                    foreach ( $course_maps as $cm ) {
                        $cv = $this->validate_mapping( $cm );
                        if ( 'bad' === $cv['status'] ) { $count_bad++; } else { $count_ok++; }
                    }
                    $total = count( $course_maps );
                ?>
                <details class="gbcmg-course-section"<?php echo $count_bad ? ' open' : ''; ?>>
                    <summary>
                        <h2><?php echo esc_html( $course_title ); ?> <span style="font-size:13px;font-weight:400;color:#646970;">#<?php echo esc_html( $cid ); ?></span></h2>
                        <div class="gbcmg-course-badges">
                            <span class="gbcmg-badge gbcmg-badge-total"><?php echo esc_html( $total ); ?> mapping<?php echo 1 !== $total ? 's' : ''; ?></span>
                            <?php if ( $count_ok )  : ?><span class="gbcmg-badge gbcmg-badge-ok"><?php echo esc_html( $count_ok ); ?> ✓</span><?php endif; ?>
                            <?php if ( $count_bad ) : ?><span class="gbcmg-badge gbcmg-badge-bad"><?php echo esc_html( $count_bad ); ?> ✗</span><?php endif; ?>
                        </div>
                    </summary>
                    <div class="gbcmg-course-inner">
                        <p class="gbcmg-small" style="margin-top:10px;">Teen Module 1: 20-question bank, 20 shown. Modules 2–12: 10-question bank, 10 shown. Teen Permit Exam: 15 laws + 15 signs from two separate internal banks. Adult topics: 10-question bank, 10 shown. Adult final: 15 signs + 15 laws from two separate internal banks. Bank quizzes may remain unassigned/not in the curriculum.</p>
                        <table class="widefat gbcmg-map-table">
                            <thead>
                                <tr>
                                    <th>Active</th>
                                    <th>Delete</th>
                                    <th>Label</th>
                                    <th>Rule Type</th>
                                    <th>Unit #</th>
                                    <th>Start Item</th>
                                    <th>Bank Quiz</th>
                                    <th>2nd Bank<br><span class="gbcmg-small">final only</span></th>
                                    <th>Next Item<br><span class="gbcmg-small">0 = auto</span></th>
                                    <th>Questions<br><span class="gbcmg-small">req / show</span></th>
                                    <th>Pass %</th>
                                    <th>Validation</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ( $course_maps as $map ) :
                                $validation = $this->validate_mapping( $map );
                                $row_class  = 'bad' === $validation['status'] ? 'gbcmg-row-bad' : '';
                                $unit_type  = sanitize_key( $map['unit_type'] ?? 'teen_module' );
                            ?>
                                <tr class="<?php echo esc_attr( $row_class ); ?>">
                                    <td>
                                        <input type="hidden" name="maps[<?php echo esc_attr( $map_idx ); ?>][course_id]" value="<?php echo esc_attr( $cid ); ?>" />
                                        <label><input type="checkbox" name="maps[<?php echo esc_attr( $map_idx ); ?>][active]" value="1" <?php checked( ! empty( $map['active'] ) ); ?> /> Active</label>
                                    </td>
                                    <td class="gbcmg-delete-cell">
                                        <label class="gbcmg-small"><input type="checkbox" name="maps[<?php echo esc_attr( $map_idx ); ?>][_delete]" value="1" /> Delete</label>
                                    </td>
                                    <td>
                                        <input class="gbcmg-input-lbl" type="text"
                                            name="maps[<?php echo esc_attr( $map_idx ); ?>][label]"
                                            value="<?php echo esc_attr( $map['label'] ?? '' ); ?>"
                                            placeholder="e.g. Module 1" />
                                    </td>
                                    <td>
                                        <select name="maps[<?php echo esc_attr( $map_idx ); ?>][unit_type]">
                                            <?php foreach ( $unit_type_labels as $utk => $utl ) : ?>
                                                <option value="<?php echo esc_attr( $utk ); ?>" <?php selected( $unit_type, $utk ); ?>><?php echo esc_html( $utl ); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </td>
                                    <td>
                                        <input class="gbcmg-input-sm" type="number" min="0"
                                            name="maps[<?php echo esc_attr( $map_idx ); ?>][unit_number]"
                                            value="<?php echo esc_attr( absint( $map['unit_number'] ?? 0 ) ); ?>" />
                                        <div class="gbcmg-small">0 for finals</div>
                                    </td>
                                    <td>
                                        <?php if ( ! empty( $item_opts[ $cid ] ) ) : ?>
                                            <select name="maps[<?php echo esc_attr( $map_idx ); ?>][start_item_id]">
                                                <option value="0">— module start —</option>
                                                <?php foreach ( $item_opts[ $cid ] as $opt ) : ?>
                                                    <option value="<?php echo esc_attr( $opt['id'] ); ?>" <?php selected( absint( $map['start_item_id'] ?? 0 ), $opt['id'] ); ?>><?php echo esc_html( $opt['label'] ); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        <?php else : ?>
                                            <input class="gbcmg-input-sm" type="number" min="0"
                                                name="maps[<?php echo esc_attr( $map_idx ); ?>][start_item_id]"
                                                value="<?php echo esc_attr( absint( $map['start_item_id'] ?? 0 ) ); ?>" />
                                            <?php if ( ! empty( $map['start_item_id'] ) ) : ?>
                                                <div class="gbcmg-small"><?php echo esc_html( get_the_title( absint( $map['start_item_id'] ) ) ); ?></div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ( ! empty( $all_quiz_opts ) ) : ?>
                                            <select name="maps[<?php echo esc_attr( $map_idx ); ?>][bank_quiz_id]">
                                                <option value="0">— select any LP quiz bank —</option>
                                                <?php foreach ( $all_quiz_opts as $opt ) : ?>
                                                    <option value="<?php echo esc_attr( $opt['id'] ); ?>" <?php selected( absint( $map['bank_quiz_id'] ?? 0 ), $opt['id'] ); ?>><?php echo esc_html( $opt['label'] ); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        <?php else : ?>
                                            <input class="gbcmg-input-sm" type="number" min="0"
                                                name="maps[<?php echo esc_attr( $map_idx ); ?>][bank_quiz_id]"
                                                value="<?php echo esc_attr( absint( $map['bank_quiz_id'] ?? 0 ) ); ?>" />
                                            <?php if ( ! empty( $map['bank_quiz_id'] ) ) : ?>
                                                <div class="gbcmg-small"><?php echo esc_html( get_the_title( absint( $map['bank_quiz_id'] ) ) ); ?></div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ( ! empty( $all_quiz_opts ) ) : ?>
                                            <select name="maps[<?php echo esc_attr( $map_idx ); ?>][second_bank_quiz_id]">
                                                <option value="0">— none —</option>
                                                <?php foreach ( $all_quiz_opts as $opt ) : ?>
                                                    <option value="<?php echo esc_attr( $opt['id'] ); ?>" <?php selected( absint( $map['second_bank_quiz_id'] ?? 0 ), $opt['id'] ); ?>><?php echo esc_html( $opt['label'] ); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        <?php else : ?>
                                            <input class="gbcmg-input-sm" type="number" min="0"
                                                name="maps[<?php echo esc_attr( $map_idx ); ?>][second_bank_quiz_id]"
                                                value="<?php echo esc_attr( absint( $map['second_bank_quiz_id'] ?? 0 ) ); ?>" />
                                            <?php if ( ! empty( $map['second_bank_quiz_id'] ) ) : ?>
                                                <div class="gbcmg-small"><?php echo esc_html( get_the_title( absint( $map['second_bank_quiz_id'] ) ) ); ?></div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <input class="gbcmg-input-sm" type="number" min="0"
                                            name="maps[<?php echo esc_attr( $map_idx ); ?>][next_item_id]"
                                            value="<?php echo esc_attr( absint( $map['next_item_id'] ?? 0 ) ); ?>" />
                                        <?php if ( ! empty( $map['next_item_id'] ) ) : ?>
                                            <div class="gbcmg-small"><?php echo esc_html( get_the_title( absint( $map['next_item_id'] ) ) ); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <label class="gbcmg-small">Req <input class="gbcmg-input-sm" type="number" min="0"
                                            name="maps[<?php echo esc_attr( $map_idx ); ?>][required_bank_size]"
                                            value="<?php echo esc_attr( absint( $map['required_bank_size'] ?? 0 ) ); ?>" /></label><br>
                                        <label class="gbcmg-small">Show <input class="gbcmg-input-sm" type="number" min="0"
                                            name="maps[<?php echo esc_attr( $map_idx ); ?>][questions_to_show]"
                                            value="<?php echo esc_attr( absint( $map['questions_to_show'] ?? 0 ) ); ?>" /></label>
                                    </td>
                                    <td>
                                        <input class="gbcmg-input-sm" type="number" min="0" max="100"
                                            name="maps[<?php echo esc_attr( $map_idx ); ?>][pass_percent]"
                                            value="<?php echo esc_attr( absint( $map['pass_percent'] ?? 70 ) ); ?>" />
                                    </td>
                                    <td class="gbcmg-validation">
                                        <?php echo wp_kses_post( $this->format_validation( $validation ) ); ?>
                                    </td>
                                </tr>
                                <?php $map_idx++; ?>
                            <?php endforeach; ?>

                            <!-- Blank add-row for this course -->
                            <?php
                            $blank = $this->blank_mapping();
                            $blank['course_id'] = $cid;
                            ?>
                            <tr class="gbcmg-blank-row">
                                <td>
                                    <input type="hidden" name="maps[<?php echo esc_attr( $map_idx ); ?>][course_id]" value="<?php echo esc_attr( $cid ); ?>" />
                                    <label><input type="checkbox" name="maps[<?php echo esc_attr( $map_idx ); ?>][active]" value="1" /> Active</label>
                                </td>
                                <td class="gbcmg-delete-cell"><span class="gbcmg-small">—</span></td>
                                <td><input class="gbcmg-input-lbl" type="text" name="maps[<?php echo esc_attr( $map_idx ); ?>][label]" value="" placeholder="New mapping…" /></td>
                                <td>
                                    <select name="maps[<?php echo esc_attr( $map_idx ); ?>][unit_type]">
                                        <?php foreach ( $unit_type_labels as $utk => $utl ) : ?>
                                            <option value="<?php echo esc_attr( $utk ); ?>"><?php echo esc_html( $utl ); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                                <td><input class="gbcmg-input-sm" type="number" min="0" name="maps[<?php echo esc_attr( $map_idx ); ?>][unit_number]" value="0" /></td>
                                <td>
                                    <?php if ( ! empty( $item_opts[ $cid ] ) ) : ?>
                                        <select name="maps[<?php echo esc_attr( $map_idx ); ?>][start_item_id]">
                                            <option value="0">— module start —</option>
                                            <?php foreach ( $item_opts[ $cid ] as $opt ) : ?><option value="<?php echo esc_attr( $opt['id'] ); ?>"><?php echo esc_html( $opt['label'] ); ?></option><?php endforeach; ?>
                                        </select>
                                    <?php else : ?><input class="gbcmg-input-sm" type="number" min="0" name="maps[<?php echo esc_attr( $map_idx ); ?>][start_item_id]" value="0" /><?php endif; ?>
                                </td>
                                <td>
                                    <?php if ( ! empty( $all_quiz_opts ) ) : ?>
                                        <select name="maps[<?php echo esc_attr( $map_idx ); ?>][bank_quiz_id]">
                                            <option value="0">— select any LP quiz bank —</option>
                                            <?php foreach ( $all_quiz_opts as $opt ) : ?><option value="<?php echo esc_attr( $opt['id'] ); ?>"><?php echo esc_html( $opt['label'] ); ?></option><?php endforeach; ?>
                                        </select>
                                    <?php else : ?><input class="gbcmg-input-sm" type="number" min="0" name="maps[<?php echo esc_attr( $map_idx ); ?>][bank_quiz_id]" value="0" /><?php endif; ?>
                                </td>
                                <td>
                                    <?php if ( ! empty( $all_quiz_opts ) ) : ?>
                                        <select name="maps[<?php echo esc_attr( $map_idx ); ?>][second_bank_quiz_id]">
                                            <option value="0">— none —</option>
                                            <?php foreach ( $all_quiz_opts as $opt ) : ?><option value="<?php echo esc_attr( $opt['id'] ); ?>"><?php echo esc_html( $opt['label'] ); ?></option><?php endforeach; ?>
                                        </select>
                                    <?php else : ?><input class="gbcmg-input-sm" type="number" min="0" name="maps[<?php echo esc_attr( $map_idx ); ?>][second_bank_quiz_id]" value="0" /><?php endif; ?>
                                </td>
                                <td><input class="gbcmg-input-sm" type="number" min="0" name="maps[<?php echo esc_attr( $map_idx ); ?>][next_item_id]" value="0" /></td>
                                <td>
                                    <label class="gbcmg-small">Req <input class="gbcmg-input-sm" type="number" min="0" name="maps[<?php echo esc_attr( $map_idx ); ?>][required_bank_size]" value="10" /></label><br>
                                    <label class="gbcmg-small">Show <input class="gbcmg-input-sm" type="number" min="0" name="maps[<?php echo esc_attr( $map_idx ); ?>][questions_to_show]" value="10" /></label>
                                </td>
                                <td><input class="gbcmg-input-sm" type="number" min="0" max="100" name="maps[<?php echo esc_attr( $map_idx ); ?>][pass_percent]" value="70" /></td>
                                <td class="gbcmg-small">Fill in above to add a mapping.</td>
                            </tr>
                            <?php $map_idx++; ?>
                            </tbody>
                        </table>
                    </div><!-- .gbcmg-course-inner -->
                </details>
                <?php endforeach; ?>

                <!-- ── Add mapping for a new or unlisted course ── -->
                <details class="gbcmg-course-section gbcmg-new-course-section">
                    <summary><h2>Add a mapping for a new or unlisted course</h2></summary>
                    <div class="gbcmg-course-inner">
                        <p class="gbcmg-small">Enter the Course ID, then use the Course Item Reader below to look up the item IDs you need. Once saved, the course will appear as its own section above.</p>
                        <table class="widefat gbcmg-map-table">
                            <thead>
                                <tr>
                                    <th>Active</th><th>Label</th><th>Course ID</th><th>Rule Type</th><th>Unit #</th>
                                    <th>Start Item ID</th><th>Bank Quiz ID</th><th>2nd Bank ID<br><span class="gbcmg-small">final only</span></th>
                                    <th>Next Item<br><span class="gbcmg-small">0 = auto</span></th>
                                    <th>Questions<br><span class="gbcmg-small">req / show</span></th>
                                    <th>Pass %</th>
                                </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td><label><input type="checkbox" name="maps[<?php echo esc_attr( $map_idx ); ?>][active]" value="1" /> Active</label></td>
                                <td><input class="gbcmg-input-lbl" type="text" name="maps[<?php echo esc_attr( $map_idx ); ?>][label]" value="" placeholder="e.g. Module 1" /></td>
                                <td><input class="gbcmg-input-sm" type="number" min="0" name="maps[<?php echo esc_attr( $map_idx ); ?>][course_id]" value="0" /></td>
                                <td>
                                    <select name="maps[<?php echo esc_attr( $map_idx ); ?>][unit_type]">
                                        <?php foreach ( $unit_type_labels as $utk => $utl ) : ?>
                                            <option value="<?php echo esc_attr( $utk ); ?>"><?php echo esc_html( $utl ); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                                <td><input class="gbcmg-input-sm" type="number" min="0" name="maps[<?php echo esc_attr( $map_idx ); ?>][unit_number]" value="0" /></td>
                                <td><input class="gbcmg-input-sm" type="number" min="0" name="maps[<?php echo esc_attr( $map_idx ); ?>][start_item_id]" value="0" /></td>
                                <td><input class="gbcmg-input-sm" type="number" min="0" name="maps[<?php echo esc_attr( $map_idx ); ?>][bank_quiz_id]" value="0" /></td>
                                <td><input class="gbcmg-input-sm" type="number" min="0" name="maps[<?php echo esc_attr( $map_idx ); ?>][second_bank_quiz_id]" value="0" /></td>
                                <td><input class="gbcmg-input-sm" type="number" min="0" name="maps[<?php echo esc_attr( $map_idx ); ?>][next_item_id]" value="0" /></td>
                                <td>
                                    <label class="gbcmg-small">Req <input class="gbcmg-input-sm" type="number" min="0" name="maps[<?php echo esc_attr( $map_idx ); ?>][required_bank_size]" value="10" /></label><br>
                                    <label class="gbcmg-small">Show <input class="gbcmg-input-sm" type="number" min="0" name="maps[<?php echo esc_attr( $map_idx ); ?>][questions_to_show]" value="10" /></label>
                                </td>
                                <td><input class="gbcmg-input-sm" type="number" min="0" max="100" name="maps[<?php echo esc_attr( $map_idx ); ?>][pass_percent]" value="70" /></td>
                            </tr>
                            <?php $map_idx++; ?>
                            </tbody>
                        </table>
                    </div>
                </details>

                <p style="margin-top:16px;">
                    <button type="submit" class="button button-primary button-large">Save all mastery mappings</button>
                </p>
            </form>

            <!-- Course Item Reader -->
            <div class="gbcmg-card">
                <h2>Course Item Reader</h2>
                <form class="gbcmg-no-print" method="get">
                    <input type="hidden" name="page" value="<?php echo esc_attr( self::MENU_SLUG ); ?>" />
                    <select name="gbcmg_reader_course">
                        <option value="0">Select a LearnPress course…</option>
                        <?php foreach ( $courses as $course ) : ?>
                            <option value="<?php echo esc_attr( $course->ID ); ?>" <?php selected( $reader_course, $course->ID ); ?>><?php echo esc_html( $course->post_title . ' #' . $course->ID ); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button class="button">Load Course Items</button>
                </form>
                <?php if ( $reader_course ) :
                    $items = $this->get_course_items( $reader_course );
                    ?>
                    <h3><?php echo esc_html( get_the_title( $reader_course ) . ' #' . $reader_course ); ?></h3>
                    <?php if ( empty( $items ) ) : ?>
                        <p>No LearnPress course items found through the standard LearnPress section tables.</p>
                    <?php else : ?>
                        <table class="widefat striped">
                            <thead><tr><th>#</th><th>Section</th><th>Title</th><th>Type</th><th>ID</th><th>Course item URL</th></tr></thead>
                            <tbody>
                            <?php foreach ( $items as $idx => $item ) :
                                $url = $this->get_course_item_url( $reader_course, $item['item_id'] );
                                ?>
                                <tr>
                                    <td><?php echo esc_html( $idx + 1 ); ?></td>
                                    <td><?php echo esc_html( $item['section_name'] ); ?></td>
                                    <td><?php echo esc_html( get_the_title( $item['item_id'] ) ); ?></td>
                                    <td><span class="gbcmg-code"><?php echo esc_html( get_post_type( $item['item_id'] ) ); ?></span></td>
                                    <td><span class="gbcmg-code"><?php echo esc_html( $item['item_id'] ); ?></span></td>
                                    <td><a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener noreferrer">open</a></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <!-- Student Mastery Inspection Report -->
            <div class="gbcmg-card">
                <h2>Student Mastery Inspection Report</h2>
                <p class="gbcmg-small">Print a student-specific module/topic mastery record. Date range uses Texas/Central business dates.</p>
                <form class="gbcmg-no-print" method="get" action="">
                    <input type="hidden" name="page" value="<?php echo esc_attr( self::MENU_SLUG ); ?>" />
                    <input type="hidden" name="gbcmg_report" value="1" />
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><label for="gbcmg_report_user">Student User ID</label></th>
                            <td><input id="gbcmg_report_user" type="number" min="0" name="gbcmg_report_user" value="<?php echo esc_attr( $report_user_id ); ?>" /></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="gbcmg_report_course">Course ID</label></th>
                            <td><input id="gbcmg_report_course" type="number" min="0" name="gbcmg_report_course" value="<?php echo esc_attr( $report_course_id ); ?>" /></td>
                        </tr>
                        <tr>
                            <th scope="row">Date range <span class="gbcmg-small">(Texas/Central)</span></th>
                            <td>
                                <input type="date" name="gbcmg_report_from" value="<?php echo esc_attr( $report_from ); ?>" />
                                to
                                <input type="date" name="gbcmg_report_to" value="<?php echo esc_attr( $report_to ); ?>" />
                            </td>
                        </tr>
                    </table>
                    <p>
                        <button class="button button-primary">Load Report</button>
                        <?php if ( $report_requested ) : ?>
                            <button type="button" class="button" onclick="window.print();">Print Report</button>
                        <?php endif; ?>
                    </p>
                </form>

                <?php if ( $report_requested ) :
                    $student      = $report_user_id ? get_userdata( $report_user_id ) : false;
                    $current_admin = wp_get_current_user();
                    ?>
                    <div id="gbcmg-student-inspection-report">
                        <h2>Drive Smart Driving School C2830</h2>
                        <h3>Course Mastery Inspection Report</h3>
                        <div class="gbcmg-report-header">
                            <div><strong>Generated UTC:</strong> <?php echo esc_html( gmdate( 'Y-m-d H:i:s' ) ); ?></div>
                            <div><strong>Generated by:</strong> <?php echo esc_html( $current_admin && $current_admin->exists() ? $current_admin->display_name . ' (user #' . $current_admin->ID . ')' : 'Administrator' ); ?></div>
                            <div><strong>Student User ID:</strong> <?php echo esc_html( $report_user_id ?: 'Not filtered' ); ?></div>
                            <div><strong>Student Name:</strong> <?php echo esc_html( $student ? $student->display_name : ( $report_user_id ? 'User not found' : 'Not filtered' ) ); ?></div>
                            <div><strong>Student Email:</strong> <?php echo esc_html( $student ? $student->user_email : '' ); ?></div>
                            <div><strong>Course:</strong> <?php echo esc_html( $report_course_id ? $report_course_id . ' — ' . get_the_title( $report_course_id ) : 'Not filtered' ); ?></div>
                            <div><strong>Date Range:</strong> <?php echo esc_html( ( $report_from ?: 'beginning' ) . ' to ' . ( $report_to ?: 'present' ) ); ?> (America/Chicago)</div>
                            <div><strong>UTC Window Used:</strong> <?php echo esc_html( ( $report_from ? $this->report_local_date_to_utc( $report_from, false ) : 'beginning' ) . ' to ' . ( $report_to ? $this->report_local_date_to_utc( $report_to, true ) : 'present' ) ); ?></div>
                            <div><strong>Total Events:</strong> <?php echo esc_html( count( $report_events ) ); ?></div>
                        </div>
                        <?php if ( empty( $report_events ) ) : ?>
                            <p><strong>No matching mastery events found.</strong></p>
                        <?php else : ?>
                            <table class="widefat striped gbcmg-report-table">
                                <thead>
                                    <tr>
                                        <th>UTC Timestamp</th><th>Event</th><th>User</th><th>Course</th>
                                        <th>Rule/Unit</th><th>Bank</th><th>Question</th>
                                        <th>Submitted Answer</th><th>Score</th><th>Result</th><th>Return/Next</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach ( $report_events as $event ) :
                                    $d = isset( $event['details'] ) && is_array( $event['details'] ) ? $event['details'] : array();
                                    ?>
                                    <tr>
                                        <td><?php echo esc_html( $event['time'] ?? '' ); ?></td>
                                        <td><?php echo esc_html( $event['event'] ?? '' ); ?></td>
                                        <td><?php echo esc_html( $event['user_id'] ?? '' ); ?></td>
                                        <td><?php echo esc_html( ( $event['course_id'] ?? '' ) . ( ! empty( $event['course_id'] ) ? ' — ' . get_the_title( absint( $event['course_id'] ) ) : '' ) ); ?></td>
                                        <td><?php echo esc_html( ( $d['unit_type'] ?? '' ) . ' ' . ( $d['unit_number'] ?? '' ) ); ?></td>
                                        <td><?php echo esc_html( ( $event['bank_quiz_id'] ?? '' ) . ( ! empty( $event['bank_quiz_id'] ) ? ' — ' . get_the_title( absint( $event['bank_quiz_id'] ) ) : '' ) ); ?></td>
                                        <td><?php echo esc_html( ! empty( $d['question_id_selected'] ) ? $d['question_id_selected'] . ' — ' . get_the_title( absint( $d['question_id_selected'] ) ) : '' ); ?></td>
                                        <td><?php echo esc_html( trim( (string) ( $d['submitted_answer_id'] ?? '' ) . ( ! empty( $d['submitted_answer_text'] ) ? ' — ' . $d['submitted_answer_text'] : '' ) ) ); ?></td>
                                        <td><?php echo esc_html( isset( $d['score_percent'] ) ? $d['score_percent'] . '%' : '' ); ?></td>
                                        <td><?php echo esc_html( isset( $d['passed'] ) ? ( $d['passed'] ? 'Passed' : 'Failed' ) : '' ); ?></td>
                                        <td><?php echo esc_html( ! empty( $d['return_to_module'] ) ? 'Return to module' : ( ! empty( $d['redirect_to'] ) ? $d['redirect_to'] : '' ) ); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                            <p class="gbcmg-small">This report is generated from GulfBreeze Course Mastery Gate event records. It documents module/topic/final mastery question selection, submitted answers, score, pass/fail result, and required return/retest behavior.</p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Final Exam Lockout Management -->
            <div class="gbcmg-card">
                <h2>Final Exam — Lockout Management</h2>
                <p class="gbcmg-small">Students with teen final or adult final fail count ≥ 3. Use Clear Lockout only after administrative review.</p>
                <?php $lockouts = $this->get_final_lockouts(); ?>
                <?php if ( empty( $lockouts ) ) : ?>
                    <p>No final exam lockouts found.</p>
                <?php else : ?>
                    <table class="widefat striped">
                        <thead><tr><th>Student</th><th>Email</th><th>User ID</th><th>Course</th><th>Final Type</th><th>Mapping</th><th>Fail Count</th><th>Last Failure UTC</th><th>Action</th></tr></thead>
                        <tbody>
                        <?php foreach ( $lockouts as $lock ) : ?>
                            <tr>
                                <td><?php echo esc_html( $lock['student_name'] ); ?></td>
                                <td><?php echo esc_html( $lock['student_email'] ); ?></td>
                                <td><?php echo esc_html( $lock['user_id'] ); ?></td>
                                <td><?php echo esc_html( $lock['course_id'] . ' — ' . get_the_title( absint( $lock['course_id'] ) ) ); ?></td>
                                <td><?php echo esc_html( $lock['unit_type_label'] ); ?></td>
                                <td><span class="gbcmg-code"><?php echo esc_html( $lock['map_id'] ); ?></span></td>
                                <td><?php echo esc_html( $lock['fail_count'] ); ?></td>
                                <td><?php echo esc_html( $lock['failed_at'] ); ?></td>
                                <td>
                                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Clear this final exam lockout?');">
                                        <?php wp_nonce_field( 'gbcmg_clear_adult_final_lockout_' . $lock['user_id'] . '_' . $lock['map_id'] ); ?>
                                        <input type="hidden" name="action"  value="gbcmg_clear_adult_final_lockout" />
                                        <input type="hidden" name="user_id" value="<?php echo esc_attr( $lock['user_id'] ); ?>" />
                                        <input type="hidden" name="map_id"  value="<?php echo esc_attr( $lock['map_id'] ); ?>" />
                                        <button class="button">Clear Lockout</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- Recent Mastery Events -->
            <div class="gbcmg-card">
                <h2>Recent Mastery Events</h2>
                <form class="gbcmg-no-print" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="float:right;" onsubmit="return confirm('Clear recent Course Mastery Gate events?');">
                    <?php wp_nonce_field( 'gbcmg_clear_events' ); ?>
                    <input type="hidden" name="action" value="gbcmg_clear_events" />
                    <button class="button">Clear Events</button>
                </form>
                <?php if ( empty( $events ) ) : ?>
                    <p>No events yet.</p>
                <?php else : ?>
                    <table class="widefat striped">
                        <thead><tr><th>UTC Time</th><th>Event</th><th>User</th><th>Course</th><th>Rule/Unit</th><th>Bank</th><th>Details</th></tr></thead>
                        <tbody>
                        <?php foreach ( $events as $event ) :
                            $d = isset( $event['details'] ) && is_array( $event['details'] ) ? $event['details'] : array();
                            ?>
                            <tr>
                                <td><?php echo esc_html( $event['time'] ?? '' ); ?></td>
                                <td><span class="gbcmg-code"><?php echo esc_html( $event['event'] ?? '' ); ?></span></td>
                                <td><?php echo esc_html( $event['user_id'] ?? '' ); ?></td>
                                <td><?php echo esc_html( ( $event['course_id'] ?? '' ) . ( ! empty( $event['course_id'] ) ? ' — ' . get_the_title( absint( $event['course_id'] ) ) : '' ) ); ?></td>
                                <td><?php echo esc_html( ( $d['unit_type'] ?? '' ) . ' ' . ( $d['unit_number'] ?? '' ) ); ?></td>
                                <td><?php echo esc_html( ( $event['bank_quiz_id'] ?? '' ) . ( ! empty( $event['bank_quiz_id'] ) ? ' — ' . get_the_title( absint( $event['bank_quiz_id'] ) ) : '' ) ); ?></td>
                                <td><pre style="white-space:pre-wrap;max-width:520px;margin:0;"><?php echo esc_html( wp_json_encode( $d, JSON_PRETTY_PRINT ) ); ?></pre></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    private function unit_type_options() {
        return array(
            'teen_module' => 'Teen AMI Module',
            'teen_final'  => 'Teen Comprehensive Final',
            'teen_permit' => 'Teen Permit Exam',
            'adult_topic' => 'Adult Topic 2–8',
            'adult_final' => 'Adult Final Exam',
        );
    }

    public function handle_save_mappings() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Not allowed.' );
        }
        check_admin_referer( self::NONCE_SAVE );

        $raw = isset( $_POST['maps'] ) && is_array( $_POST['maps'] ) ? wp_unslash( $_POST['maps'] ) : array();
        $maps = array();
        foreach ( $raw as $row ) {
            if ( ! empty( $row['_delete'] ) ) {
                continue;
            }
            $map = $this->sanitize_mapping( $row );
            if ( ! $this->mapping_has_any_ids( $map ) ) {
                continue;
            }
            $maps[] = $map;
        }
        update_option( self::OPTION_MAPS, $maps, false );
        wp_safe_redirect( add_query_arg( 'gbcmg_saved', '1', admin_url( 'admin.php?page=' . self::MENU_SLUG ) ) );
        exit;
    }

    public function handle_clear_events() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Not allowed.' );
        }
        check_admin_referer( 'gbcmg_clear_events' );
        update_option( self::OPTION_EVENTS, array(), false );
        wp_safe_redirect( add_query_arg( 'gbcmg_cleared', '1', admin_url( 'admin.php?page=' . self::MENU_SLUG ) ) );
        exit;
    }

    public function handle_clear_adult_final_lockout() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Not allowed.' );
        }

        $user_id = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;
        $map_id  = isset( $_POST['map_id'] ) ? sanitize_key( wp_unslash( $_POST['map_id'] ) ) : '';
        check_admin_referer( 'gbcmg_clear_adult_final_lockout_' . $user_id . '_' . $map_id );

        $map = $this->find_mapping_by_id( $map_id );
        if ( ! $user_id || ! $map || ! in_array( ( $map['unit_type'] ?? '' ), array( 'adult_final', 'teen_final' ), true ) ) {
            wp_die( 'Final lockout mapping not found.' );
        }

        $state = $this->get_mastery_state( $user_id, $map );
        $previous_fail_count = absint( $state['fail_count'] ?? 0 );
        $previous_failed_at  = (string) ( $state['failed_at'] ?? '' );

        $state['fail_count'] = 0;
        $state['failed_at']  = '';
        $state['current_selection'] = array();
        if ( isset( $state['last_result'] ) && is_array( $state['last_result'] ) ) {
            $state['last_result']['admin_unlock_at'] = current_time( 'mysql', true );
            $state['last_result']['admin_unlock_by'] = get_current_user_id();
        }
        $this->set_mastery_state( $user_id, $map, $state );

        $this->log_event( 'final_lockout_cleared_by_admin', $user_id, $map, array(
            'admin_user_id'       => get_current_user_id(),
            'previous_fail_count' => $previous_fail_count,
            'previous_failed_at'  => $previous_failed_at,
        ) );

        wp_safe_redirect( add_query_arg( 'gbcmg_lockout_cleared', '1', admin_url( 'admin.php?page=' . self::MENU_SLUG ) ) );
        exit;
    }

    private function blank_mapping( $unit_type = 'teen_module', $unit_number = 0 ) {
        $defaults = $this->defaults_for_unit( $unit_type, $unit_number );
        return array_merge( array(
            'active'              => 0,
            'label'               => '',
            'course_id'           => 0,
            'unit_type'           => $unit_type,
            'unit_number'         => absint( $unit_number ),
            'start_item_id'       => 0,
            'bank_quiz_id'        => 0,
            'second_bank_quiz_id' => 0,
            'next_item_id'        => 0,
        ), $defaults );
    }

    private function defaults_for_unit( $unit_type, $unit_number ) {
        $unit_number = absint( $unit_number );
        if ( 'teen_module' === $unit_type ) {
            return array(
                'required_bank_size' => ( 1 === $unit_number ? 20 : 10 ),
                'questions_to_show'  => ( 1 === $unit_number ? 20 : 10 ),
                'pass_percent'       => 70,
            );
        }
        if ( 'adult_topic' === $unit_type ) {
            return array(
                'required_bank_size' => 10,
                'questions_to_show'  => 2,
                'pass_percent'       => 70,
            );
        }
        if ( 'teen_final' === $unit_type ) {
            return array(
                'required_bank_size' => 30,
                'questions_to_show'  => 30,
                'pass_percent'       => 70,
            );
        }
        if ( 'adult_final' === $unit_type ) {
            return array(
                'required_bank_size' => 15,
                'questions_to_show'  => 30,
                'pass_percent'       => 70,
            );
        }
        if ( 'teen_permit' === $unit_type ) {
            return array(
                'required_bank_size' => 15,
                'questions_to_show'  => 30,
                'pass_percent'       => 70,
            );
        }
        return array(
            'required_bank_size' => 10,
            'questions_to_show'  => 10,
            'pass_percent'       => 70,
        );
    }

    private function sanitize_mapping( $row ) {
        $unit_type = isset( $row['unit_type'] ) ? sanitize_key( $row['unit_type'] ) : 'teen_module';
        if ( ! in_array( $unit_type, array_keys( $this->unit_type_options() ), true ) ) {
            $unit_type = 'teen_module';
        }
        $unit_number = isset( $row['unit_number'] ) ? absint( $row['unit_number'] ) : 0;
        $defaults = $this->defaults_for_unit( $unit_type, $unit_number );

        return array(
            'active'              => ! empty( $row['active'] ) ? 1 : 0,
            'label'               => isset( $row['label'] ) ? sanitize_text_field( $row['label'] ) : '',
            'course_id'           => isset( $row['course_id'] ) ? absint( $row['course_id'] ) : 0,
            'unit_type'           => $unit_type,
            'unit_number'         => $unit_number,
            'start_item_id'       => isset( $row['start_item_id'] ) ? absint( $row['start_item_id'] ) : 0,
            'bank_quiz_id'        => isset( $row['bank_quiz_id'] ) ? absint( $row['bank_quiz_id'] ) : 0,
            'second_bank_quiz_id' => isset( $row['second_bank_quiz_id'] ) ? absint( $row['second_bank_quiz_id'] ) : 0,
            'next_item_id'        => isset( $row['next_item_id'] ) ? absint( $row['next_item_id'] ) : 0,
            'required_bank_size'  => isset( $row['required_bank_size'] ) ? absint( $row['required_bank_size'] ) : absint( $defaults['required_bank_size'] ),
            'questions_to_show'   => isset( $row['questions_to_show'] ) ? absint( $row['questions_to_show'] ) : absint( $defaults['questions_to_show'] ),
            'pass_percent'        => isset( $row['pass_percent'] ) ? min( 100, max( 0, absint( $row['pass_percent'] ) ) ) : 70,
        );
    }

    private function mapping_has_any_ids( $map ) {
        return ! empty( $map['active'] )
            || ! empty( $map['label'] )
            || ! empty( $map['bank_quiz_id'] )
            || ! empty( $map['second_bank_quiz_id'] )
            || ! empty( $map['start_item_id'] )
            || ! empty( $map['next_item_id'] );
    }

    private function mapping_id( $map ) {
        return substr( hash( 'sha256', implode( ':', array(
            absint( $map['course_id'] ?? 0 ),
            sanitize_key( $map['unit_type'] ?? '' ),
            absint( $map['unit_number'] ?? 0 ),
            absint( $map['bank_quiz_id'] ?? 0 ),
            absint( $map['second_bank_quiz_id'] ?? 0 ),
        ) ) ), 0, 12 );
    }

    private function get_mappings() {
        $maps = get_option( self::OPTION_MAPS, array() );
        return is_array( $maps ) ? $maps : array();
    }

    private function validate_mapping( $map ) {
        $messages = array();
        $status = 'blank';

        if ( ! $this->mapping_has_any_ids( $map ) ) {
            return array( 'status' => 'blank', 'messages' => array( 'Blank row.' ) );
        }

        $status = 'ok';
        $course_id = absint( $map['course_id'] ?? 0 );
        $bank_id = absint( $map['bank_quiz_id'] ?? 0 );
        $second_id = absint( $map['second_bank_quiz_id'] ?? 0 );
        $unit_type = sanitize_key( $map['unit_type'] ?? 'teen_module' );
        $unit_number = absint( $map['unit_number'] ?? 0 );
        $required = absint( $map['required_bank_size'] ?? 0 );
        $show = absint( $map['questions_to_show'] ?? 0 );
        $start_id = absint( $map['start_item_id'] ?? 0 );
        $next_id  = absint( $map['next_item_id'] ?? 0 );
        $course_item_ids = $course_id ? array_map( 'absint', wp_list_pluck( $this->get_course_items( $course_id ), 'item_id' ) ) : array();

        if ( empty( $map['active'] ) ) {
            $messages[] = 'Inactive. This mapping will not fire.';
            $status = 'warn';
        }
        if ( ! $course_id || 'lp_course' !== get_post_type( $course_id ) ) {
            $messages[] = 'Course ID must be a real lp_course.';
            $status = 'bad';
        }
        if ( $start_id ) {
            if ( ! in_array( $start_id, $course_item_ids, true ) ) {
                $messages[] = 'Start item must be an item in this course curriculum.';
                $status = 'bad';
            } else {
                $messages[] = 'Start item is in the course curriculum.';
            }
        }
        if ( $next_id ) {
            if ( ! in_array( $next_id, $course_item_ids, true ) ) {
                $messages[] = 'Next item must be an item in this course curriculum.';
                $status = 'bad';
            } else {
                $messages[] = 'Next item is in the course curriculum.';
            }
        }
        if ( 'teen_module' === $unit_type && ( $unit_number < 1 || $unit_number > 12 ) ) {
            $messages[] = 'Teen module must be 1 through 12.';
            $status = 'bad';
        }
        if ( 'adult_topic' === $unit_type && ( $unit_number < 2 || $unit_number > 8 ) ) {
            $messages[] = 'Adult topic must be 2 through 8.';
            $status = 'bad';
        }
        if ( in_array( $unit_type, array( 'adult_final', 'teen_final', 'teen_permit' ), true ) && ! $start_id ) {
            $messages[] = 'Final exams should use a visible curriculum lesson/quiz as the Start Item trigger.';
            $status = 'bad';
        }

        if ( ! $bank_id || 'lp_quiz' !== get_post_type( $bank_id ) ) {
            $messages[] = 'Bank Quiz ID must be a real lp_quiz.';
            $status = 'bad';
        } else {
            $count = $this->get_quiz_question_count( $bank_id );
            if ( null === $count ) {
                $messages[] = 'Could not count questions in primary bank.';
                $status = 'warn' === $status ? 'warn' : 'warn';
            } elseif ( $count < $required ) {
                $messages[] = 'Primary bank has ' . $count . ' questions; required minimum is ' . $required . '.';
                $status = 'bad';
            } else {
                $messages[] = 'Primary bank has ' . $count . ' questions.';
            }
        }

        if ( in_array( $unit_type, array( 'adult_final', 'teen_permit' ), true ) ) {
            $two_bank_label = ( 'teen_permit' === $unit_type ) ? 'Teen permit exam' : 'Adult final';
            if ( ! $second_id || 'lp_quiz' !== get_post_type( $second_id ) ) {
                $messages[] = $two_bank_label . ' requires a second lp_quiz bank.';
                $status = 'bad';
            } else {
                $count2 = $this->get_quiz_question_count( $second_id );
                if ( null === $count2 || $count2 < $required ) {
                    $messages[] = 'Second bank has ' . ( null === $count2 ? 'unknown' : $count2 ) . ' questions; required minimum is ' . $required . '.';
                    $status = 'bad';
                } else {
                    $messages[] = 'Second bank has ' . $count2 . ' questions.';
                }
            }
            if ( 30 !== $show ) {
                $messages[] = $two_bank_label . ' should administer 30 questions total.';
                $status = 'warn' === $status ? 'warn' : $status;
            }
        } else {
            if ( $show < 1 ) {
                $messages[] = 'Questions to show must be at least 1.';
                $status = 'bad';
            }
            if ( $bank_id && null !== $this->get_quiz_question_count( $bank_id ) && $show > $this->get_quiz_question_count( $bank_id ) ) {
                $messages[] = 'Questions to show exceeds bank size.';
                $status = 'bad';
            }
        }

        if ( $course_id && $bank_id ) {
            if ( in_array( $bank_id, $course_item_ids, true ) ) {
                $messages[] = 'Primary bank is attached to the course curriculum.';
            } else {
                $messages[] = 'Primary bank is internal/not in the curriculum; this is allowed.';
            }
        }
        if ( $course_id && $second_id ) {
            if ( in_array( $second_id, $course_item_ids, true ) ) {
                $messages[] = 'Second bank is attached to the course curriculum.';
            } else {
                $messages[] = 'Second bank is internal/not in the curriculum; this is allowed.';
            }
        }

        if ( empty( $messages ) ) {
            $messages[] = 'OK.';
        }

        return array( 'status' => $status, 'messages' => $messages );
    }

    private function format_validation( $validation ) {
        $status = $validation['status'] ?? 'warn';
        $label = 'WARN';
        $class = 'gbcmg-warn';
        if ( 'ok' === $status ) {
            $label = 'OK';
            $class = 'gbcmg-ok';
        } elseif ( 'bad' === $status ) {
            $label = 'INVALID';
            $class = 'gbcmg-bad';
        } elseif ( 'blank' === $status ) {
            $label = 'BLANK';
            $class = 'gbcmg-small';
        }
        $out = '<div class="' . esc_attr( $class ) . '">' . esc_html( $label ) . '</div>';
        foreach ( (array) ( $validation['messages'] ?? array() ) as $msg ) {
            $out .= '<div class="gbcmg-small">' . esc_html( $msg ) . '</div>';
        }
        return $out;
    }

    private function get_final_lockouts() {
        $out = array();

        foreach ( $this->get_mappings() as $map ) {
            if ( ! in_array( ( $map['unit_type'] ?? '' ), array( 'adult_final', 'teen_final' ), true ) ) {
                continue;
            }

            $state_key = $this->get_mastery_state_key( $map );
            $users = get_users( array(
                'fields'       => array( 'ID', 'display_name', 'user_email' ),
                'number'       => 500,
                'meta_key'     => $state_key,
                'meta_compare' => 'EXISTS',
            ) );

            foreach ( $users as $user ) {
                $state = $this->get_mastery_state( $user->ID, $map );
                $fail_count = absint( $state['fail_count'] ?? 0 );
                if ( $fail_count < 3 ) {
                    continue;
                }

                $out[] = array(
                    'user_id'       => absint( $user->ID ),
                    'student_name'  => $user->display_name,
                    'student_email' => $user->user_email,
                    'course_id'     => absint( $map['course_id'] ?? 0 ),
                    'map_id'        => $this->mapping_id( $map ),
                    'unit_type_label'=> $this->friendly_mastery_title( $map ),
                    'fail_count'    => $fail_count,
                    'failed_at'     => (string) ( $state['failed_at'] ?? '' ),
                );
            }
        }

        return $out;
    }

    private function render_setup_diagnostics( $maps ) {
        $active = 0;
        $ok = 0;
        $bad = 0;
        foreach ( $maps as $map ) {
            if ( empty( $map['active'] ) || ! $this->mapping_has_any_ids( $map ) ) {
                continue;
            }
            $active++;
            $v = $this->validate_mapping( $map );
            if ( 'ok' === ( $v['status'] ?? '' ) || 'warn' === ( $v['status'] ?? '' ) ) {
                $ok++;
            }
            if ( 'bad' === ( $v['status'] ?? '' ) ) {
                $bad++;
            }
        }

        $html = '<div class="notice notice-info" style="padding:12px 14px;">';
        $html .= '<p><strong>Quick setup check:</strong> Active mappings fire only when they have a valid course, a mapped LearnPress quiz bank, and enough questions for the Texas rule profile.</p>';
        $html .= '<p>Active mappings: <strong>' . esc_html( $active ) . '</strong> · Ready/warning: <strong>' . esc_html( $ok ) . '</strong> · Invalid: <strong>' . esc_html( $bad ) . '</strong></p>';
        $html .= '<p class="gbcmg-small">Teen Module 1 requires 20 questions. Teen Modules 2–12 require 10. Teen Permit Exam uses two 15-question banks and administers 15+15. Teen Final uses a 30-question comprehensive bank. Adult Topics 2–8 require 10-bank/2-administered. Adult Final uses two banks and administers 15+15.</p>';
        $html .= '</div>';
        return $html;
    }

    public function template_redirect_gate() {
        if ( is_admin() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
            return;
        }

        if ( isset( $_GET['gbcmg_mastery'] ) ) {
            $this->maybe_render_mastery_page();
            exit;
        }

        if ( ! is_user_logged_in() ) {
            return;
        }

        $ctx = $this->detect_context();
        if ( empty( $ctx['course_id'] ) || empty( $ctx['item_id'] ) ) {
            return;
        }

        $user_id   = get_current_user_id();
        $course_id = absint( $ctx['course_id'] );
        $item_id   = absint( $ctx['item_id'] );
        $maps      = $this->get_active_mappings_for_course( $course_id );
        if ( empty( $maps ) ) {
            return;
        }

        // v0.1.7: Course Mastery Gate only enforces inside the student's actual
        // LearnPress course record. If course context is wrong or the student has
        // no course row, skip rather than risk cross-course bleed.
        if ( ! $this->user_has_lp_course_record( $user_id, $course_id ) ) {
            $first = reset( $maps );
            if ( is_array( $first ) ) {
                $this->log_event( 'skip_gate_no_course_enrollment_record', $user_id, $first, array(
                    'current_item_id' => $item_id,
                    'current_url'     => $this->current_url(),
                    'reason'          => 'No LearnPress course enrollment/progress row found for the resolved course context.',
                ) );
            }
            return;
        }

        foreach ( $maps as $map ) {
            if ( $this->item_triggers_map( $item_id, $map ) ) {
                $validation = $this->validate_mapping( $map );
                if ( 'bad' === ( $validation['status'] ?? '' ) ) {
                    continue;
                }

                $state = $this->get_mastery_state( $user_id, $map );

                if ( ! empty( $state['passed_at'] ) ) {
                    $target = $this->get_map_continue_url( $map, $item_id, $state );
                    $this->log_event( 'redirect_already_passed_start_item_to_next_item', $user_id, $map, array(
                        'current_item_id' => $item_id,
                        'current_url'     => $this->current_url(),
                        'redirect_to'     => $target,
                        'passed_at'       => (string) $state['passed_at'],
                        'reason'          => 'Mastery check already completed. Continue to the next required course item.',
                    ) );
                    wp_safe_redirect( $target );
                    exit;
                }

                $grandfather = $this->maybe_grandfather_existing_progress( $user_id, $map, $course_id, $item_id, $state );
                if ( ! empty( $grandfather['grandfathered'] ) ) {
                    $new_state = $this->get_mastery_state( $user_id, $map );
                    $target = $this->get_map_continue_url( $map, $item_id, $new_state );
                    $this->log_event( 'redirect_grandfathered_start_item_to_next_item', $user_id, $map, array(
                        'current_item_id' => $item_id,
                        'current_url'     => $this->current_url(),
                        'redirect_to'     => $target,
                        'reason'          => 'Existing course progress was grandfathered; continue to the next required course item.',
                    ) );
                    wp_safe_redirect( $target );
                    exit;
                }

                $url = $this->get_mastery_url( $map );
                $this->log_event( 'redirect_start_item_to_custom_mastery', $user_id, $map, array(
                    'current_item_id' => $item_id,
                    'current_url'     => $this->current_url(),
                    'redirect_to'     => $url,
                ) );
                wp_safe_redirect( $url );
                exit;
            }
        }

        // v0.1.7: Failed-forward guard for every rule type, not only teen modules.
        foreach ( $maps as $map ) {
            $validation = $this->validate_mapping( $map );
            if ( 'bad' === ( $validation['status'] ?? '' ) ) {
                continue;
            }

            $state = $this->get_mastery_state( $user_id, $map );
            if ( empty( $state['failed_at'] ) || ! empty( $state['passed_at'] ) ) {
                continue;
            }

            $positions = $this->positions_from_items( $this->get_course_items( $course_id ) );
            $bank_id   = absint( $map['bank_quiz_id'] ?? 0 );
            $second_id = absint( $map['second_bank_quiz_id'] ?? 0 );
            $start_id  = absint( $map['start_item_id'] ?? 0 );
            $gate_pos  = ( $start_id && isset( $positions[ $start_id ] ) ) ? $positions[ $start_id ] : null;
            if ( null === $gate_pos ) {
                $gate_pos = isset( $positions[ $bank_id ] ) ? $positions[ $bank_id ] : null;
                if ( $second_id && isset( $positions[ $second_id ] ) ) {
                    $gate_pos = null === $gate_pos ? $positions[ $second_id ] : max( $gate_pos, $positions[ $second_id ] );
                }
            }

            if ( null !== $gate_pos && isset( $positions[ $item_id ] ) && $positions[ $item_id ] > $gate_pos ) {
                $unit_type = sanitize_key( $map['unit_type'] ?? '' );
                $fail_count = absint( $state['fail_count'] ?? 0 );

                if ( in_array( $unit_type, array( 'adult_final', 'teen_final' ), true ) && $fail_count >= 3 ) {
                    $target = add_query_arg( 'gbcmg_result', 'failed', $this->get_mastery_url( $map ) );
                    $this->log_event( 'redirect_later_item_to_failed_final_result', $user_id, $map, array(
                        'current_item_id' => $item_id,
                        'current_url'     => $this->current_url(),
                        'redirect_to'     => $target,
                        'fail_count'      => $fail_count,
                    ) );
                    wp_safe_redirect( $target );
                    exit;
                }

                $start_id = absint( $map['start_item_id'] ?? 0 );
                $target = $start_id ? $this->get_course_item_url( $course_id, $start_id ) : $this->get_course_item_url( $course_id, $bank_id );
                $this->log_event( 'redirect_later_item_to_failed_review_start', $user_id, $map, array(
                    'current_item_id' => $item_id,
                    'current_url'     => $this->current_url(),
                    'redirect_to'     => $target,
                    'unit_type'       => $unit_type,
                ) );
                wp_safe_redirect( add_query_arg( 'gbcmg_repeat_review', '1', $target ) );
                exit;
            }
        }
    }

    private function maybe_render_mastery_page() {
        if ( ! is_user_logged_in() ) {
            auth_redirect();
            exit;
        }

        if ( 'POST' === strtoupper( $_SERVER['REQUEST_METHOD'] ?? '' ) && ! empty( $_POST['gbcmg_frontend_submit'] ) ) {
            $this->handle_mastery_submit();
            exit;
        }

        $map_id = isset( $_GET['gbcmg_map'] ) ? sanitize_key( wp_unslash( $_GET['gbcmg_map'] ) ) : '';
        $map = $this->find_mapping_by_id( $map_id );
        if ( ! $map || empty( $map['active'] ) ) {
            $this->render_mastery_shell( '<h1>Mastery Check Not Ready</h1><p>We could not load this mastery check. Please return to your course and try again.</p>' );
            exit;
        }

        $validation = $this->validate_mapping( $map );
        if ( 'bad' === ( $validation['status'] ?? '' ) ) {
            $this->render_mastery_shell( '<h1>Mastery Check Not Ready</h1><p>This mastery check is not fully configured yet.</p><p>' . esc_html( implode( ' ', $validation['messages'] ?? array() ) ) . '</p>' );
            exit;
        }

        if ( ! $this->user_has_lp_course_record( get_current_user_id(), absint( $map['course_id'] ) ) ) {
            $this->render_mastery_shell( '<h1>Course Access Needed</h1><p>This mastery check belongs to a course that is not currently active on your account. Please return to your course page and try again.</p>' );
            exit;
        }

        $state = $this->get_mastery_state( get_current_user_id(), $map );

        // v0.1.6: If the student already passed this mastery check (or was
        // grandfathered), don't force them back through the form. Show the
        // pass-result page instead, with a Continue button to the next item.
        if ( ! empty( $state['passed_at'] ) && ! isset( $_GET['gbcmg_result'] ) ) {
            $this->render_mastery_shell( $this->render_mastery_result_page( $map, 'passed' ) );
            exit;
        }

        if ( in_array( ( $map['unit_type'] ?? '' ), array( 'adult_final', 'teen_final' ), true ) && absint( $state['fail_count'] ?? 0 ) >= 3 ) {
            $this->render_mastery_shell( $this->render_mastery_result_page( $map, 'failed' ) );
            exit;
        }

        if ( isset( $_GET['gbcmg_result'] ) ) {
            $result = sanitize_key( wp_unslash( $_GET['gbcmg_result'] ) );
            $this->render_mastery_shell( $this->render_mastery_result_page( $map, $result ) );
            exit;
        }

        $html = $this->render_mastery_form( $map );
        $this->render_mastery_shell( $html );
        exit;
    }

    private function render_mastery_shell( $inner_html ) {
        status_header( 200 );
        nocache_headers();
        ?><!doctype html>
        <html <?php language_attributes(); ?>>
        <head>
            <meta charset="<?php bloginfo( 'charset' ); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>Course Mastery Check</title>
            <?php wp_head(); ?>
            <style>
                .gbcmg-page { max-width: 920px; margin: 32px auto; padding: 24px; background:#fff; border:1px solid #ddd; border-radius:12px; box-shadow:0 2px 10px rgba(0,0,0,.05); font-family: system-ui, -apple-system, Segoe UI, sans-serif; }
                .gbcmg-page h1 { margin-top:0; }
                .gbcmg-question { padding:18px; margin:18px 0; border:1px solid #dcdcde; border-radius:10px; background:#fafafa; }
                .gbcmg-question h3 { margin-top:0; }
                .gbcmg-answer { display:block; padding:10px 12px; margin:8px 0; border:1px solid #dcdcde; border-radius:8px; background:#fff; cursor:pointer; }
                .gbcmg-answer:hover { background:#f0f6fc; }
                .gbcmg-note { color:#555; }
                .gbcmg-small-note { color:#666; font-size:.95em; }
                .gbcmg-button { display:inline-block; padding:12px 18px; border-radius:8px; background:#1d2327; color:#fff !important; text-decoration:none; border:0; cursor:pointer; font-size:16px; }
                .gbcmg-progress { color:#666; font-size:.95em; margin-bottom:16px; }
                .gbcmg-result-box { padding:18px; border-radius:12px; margin:18px 0; border:1px solid #dcdcde; background:#f6f7f7; }
                .gbcmg-result-pass { border-color:#00a32a; background:#f0fff4; }
                .gbcmg-result-fail { border-color:#d63638; background:#fff5f5; }
                .gbcmg-score { font-size:1.2em; font-weight:700; }
            </style>
        </head>
        <body>
        <main class="gbcmg-page">
            <?php echo $inner_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
        </main>
        <?php wp_footer(); ?>
        </body>
        </html><?php
    }

    private function render_mastery_result_page( $map, $result ) {
        $user_id = get_current_user_id();
        $state   = $this->get_mastery_state( $user_id, $map );
        $last    = isset( $state['last_result'] ) && is_array( $state['last_result'] ) ? $state['last_result'] : array();

        $score        = isset( $last['score_percent'] ) ? (float) $last['score_percent'] : 0;
        $correct      = isset( $last['correct_count'] ) ? absint( $last['correct_count'] ) : 0;
        $shown        = isset( $last['shown_count'] ) ? absint( $last['shown_count'] ) : 0;
        $pass_percent = absint( $map['pass_percent'] ?? 70 );
        $attempt      = isset( $last['attempt_no'] ) ? absint( $last['attempt_no'] ) : 1;
        $fail_count   = isset( $last['fail_count'] ) ? absint( $last['fail_count'] ) : 0;
        $next_url     = esc_url( $this->get_map_continue_url( $map, absint( $map['bank_quiz_id'] ), $state ) );
        $review_url   = ! empty( $last['review_url'] ) ? esc_url( $last['review_url'] ) : esc_url( $this->get_course_item_url( absint( $map['course_id'] ), absint( $map['start_item_id'] ?? 0 ) ) );
        $title        = $this->friendly_mastery_title( $map );

        ob_start();

        if ( 'passed' === $result || ! empty( $last['passed'] ) ) :
            ?>
            <h1>Nice work — you passed this mastery check</h1>
            <div class="gbcmg-result-box gbcmg-result-pass">
                <p>You completed <strong><?php echo esc_html( $title ); ?></strong>.</p>
                <p class="gbcmg-score">Score: <?php echo esc_html( $score ); ?>%</p>
                <p>You answered <?php echo esc_html( $correct ); ?> out of <?php echo esc_html( $shown ); ?> question(s) correctly. Passing score: <?php echo esc_html( $pass_percent ); ?>%.</p>
                <p>You may continue to the next part of the course.</p>
            </div>
            <p><a class="gbcmg-button" href="<?php echo $next_url; ?>">Continue Course</a></p>
            <?php
        else :
            $final_lock = ( in_array( ( $map['unit_type'] ?? '' ), array( 'adult_final', 'teen_final' ), true ) && $fail_count >= 3 );
            ?>
            <h1>Review needed before you continue</h1>
            <div class="gbcmg-result-box gbcmg-result-fail">
                <p>You completed <strong><?php echo esc_html( $title ); ?></strong>, but your score was below the required passing score.</p>
                <p class="gbcmg-score">Score: <?php echo esc_html( $score ); ?>%</p>
                <p>You answered <?php echo esc_html( $correct ); ?> out of <?php echo esc_html( $shown ); ?> question(s) correctly. Passing score: <?php echo esc_html( $pass_percent ); ?>%.</p>
                <?php if ( $final_lock ) : ?>
                    <p>You’ve reached the final-attempt limit for this assessment. Please contact the school so we can help you with the next step.</p>
                <?php elseif ( 'teen_module' === ( $map['unit_type'] ?? '' ) ) : ?>
                    <p>Please review this module before retaking the mastery check. When you are ready, try again. Your next attempt will use different questions when available.</p>
                <?php elseif ( 'teen_final' === ( $map['unit_type'] ?? '' ) ) : ?>
                    <p>Please review the course material before retaking the comprehensive final. Your next attempt will use different questions when available.</p>
                <?php elseif ( 'teen_permit' === ( $map['unit_type'] ?? '' ) ) : ?>
                    <p>Please review the permit exam material before retaking the written test. Your next attempt will use different questions when available.</p>
                <?php else : ?>
                    <p>Please review the section before retaking this check. Your next attempt will use different questions when available.</p>
                <?php endif; ?>
            </div>
            <?php if ( $final_lock ) : ?>
                <p><a class="gbcmg-button" href="<?php echo esc_url( get_permalink( absint( $map['course_id'] ) ) ); ?>">Return to Course</a></p>
            <?php else : ?>
                <p><a class="gbcmg-button" href="<?php echo $review_url; ?>">Start Required Review</a></p>
            <?php endif; ?>
            <?php
        endif;

        return ob_get_clean();
    }

    private function is_controlled_final( $map ) {
        return in_array( sanitize_key( $map['unit_type'] ?? '' ), array( 'adult_final', 'teen_final' ), true );
    }

    private function current_session_hash() {
        return hash( 'sha256', (string) wp_get_session_token() );
    }

    private function current_browser_hash() {
        return hash( 'sha256', sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ?? '' ) ) );
    }

    private function question_set_hash( $map, $selection, $attempt ) {
        return hash_hmac( 'sha256', $this->mapping_id( $map ) . '|' . absint( $attempt ) . '|' . implode( ',', array_map( 'absint', (array) $selection ) ), wp_salt( 'auth' ) );
    }

    private function prepare_secure_final_attempt( $user_id, $map, $selection ) {
        $state = $this->get_mastery_state( $user_id, $map );
        $attempt = max( 1, absint( $state['attempt'] ?? 1 ) );
        $expected_hash = $this->question_set_hash( $map, $selection, $attempt );
        if ( empty( $state['attempt_started_at'] ) || ! hash_equals( (string) ( $state['question_set_hash'] ?? '' ), $expected_hash ) ) {
            $state['attempt_started_at'] = time();
            $state['attempt_expires_at'] = time() + self::FINAL_TIME_LIMIT_SECONDS;
            $state['question_set_hash'] = $expected_hash;
            $state['session_hash'] = $this->current_session_hash();
            $state['browser_hash'] = $this->current_browser_hash();
            $state['answer_orders'] = array();
            foreach ( (array) $selection as $question_id ) {
                $answers = $this->get_question_answers( $question_id );
                usort( $answers, function( $left, $right ) use ( $question_id, $attempt ) {
                    $left_key = hash_hmac( 'sha256', $question_id . '|' . $attempt . '|' . (string) $left['id'], wp_salt( 'nonce' ) );
                    $right_key = hash_hmac( 'sha256', $question_id . '|' . $attempt . '|' . (string) $right['id'], wp_salt( 'nonce' ) );
                    return strcmp( $left_key, $right_key );
                } );
                $state['answer_orders'][ absint( $question_id ) ] = array_values( array_map( function( $answer ) { return (string) $answer['id']; }, $answers ) );
            }
            $this->set_mastery_state( $user_id, $map, $state );
            $this->log_event( 'secure_final_attempt_started', $user_id, $map, array(
                'attempt_no' => $attempt,
                'question_set_hash' => $expected_hash,
                'time_limit_seconds' => self::FINAL_TIME_LIMIT_SECONDS,
            ) );
        }
        return $state;
    }

    private function ordered_answers_for_attempt( $question_id, $state ) {
        $answers = $this->get_question_answers( $question_id );
        $order = isset( $state['answer_orders'][ absint( $question_id ) ] ) ? array_map( 'strval', (array) $state['answer_orders'][ absint( $question_id ) ] ) : array();
        if ( empty( $order ) ) return $answers;
        $by_id = array();
        foreach ( $answers as $answer ) $by_id[ (string) $answer['id'] ] = $answer;
        $ordered = array();
        foreach ( $order as $answer_id ) if ( isset( $by_id[ $answer_id ] ) ) $ordered[] = $by_id[ $answer_id ];
        return count( $ordered ) === count( $answers ) ? $ordered : $answers;
    }

    private function render_mastery_form( $map ) {
        $user_id = get_current_user_id();
        $course_id = absint( $map['course_id'] );
        $bank_id = absint( $map['bank_quiz_id'] );
        $unit_type = sanitize_key( $map['unit_type'] );
        $unit_number = absint( $map['unit_number'] );
        $selection = $this->get_or_select_mastery_questions( $user_id, $map );

        if ( empty( $selection ) ) {
            return '<h1>Mastery Check Not Ready</h1><p>No questions could be selected from the mapped bank.</p>';
        }
		$secure_state = $this->is_controlled_final( $map ) ? $this->prepare_secure_final_attempt( $user_id, $map, $selection ) : $this->get_mastery_state( $user_id, $map );

        $title = $this->friendly_mastery_title( $map );
        $action = esc_url( $this->get_mastery_url( $map ) );
        $nonce = wp_create_nonce( 'gbcmg_mastery_' . $this->mapping_id( $map ) );

        ob_start();
        ?>
        <h1><?php echo esc_html( $title ); ?></h1>
        <p class="gbcmg-note">Please answer the mastery questions for this section before moving on. Choose the best answer for each question, then click <strong>Submit Answers</strong>.</p>
        <p class="gbcmg-small-note"><em>Correct answers are not shown after submission. If you do not pass, you will be guided through the required review/retest path.</em></p>
        <div class="gbcmg-progress">
            <?php echo esc_html( count( $selection ) ); ?> question(s) · Passing score: <?php echo esc_html( absint( $map['pass_percent'] ?? 70 ) ); ?>%
        </div>
		<?php if ( $this->is_controlled_final( $map ) ) : ?>
			<div class="gbcmg-result-box"><strong>Time remaining:</strong> <span id="gbcmg-final-clock">45:00</span><br><span class="gbcmg-small-note">The server enforces the 45-minute limit. Continue in this signed-in browser session.</span></div>
		<?php endif; ?>
        <form method="post" action="<?php echo $action; ?>">
            <input type="hidden" name="gbcmg_frontend_submit" value="1" />
            <input type="hidden" name="gbcmg_map" value="<?php echo esc_attr( $this->mapping_id( $map ) ); ?>" />
            <input type="hidden" name="gbcmg_nonce" value="<?php echo esc_attr( $nonce ); ?>" />
            <?php foreach ( $selection as $idx => $question_id ) : ?>
                <?php $question = $this->get_question_data( $question_id ); ?>
                <section class="gbcmg-question">
                    <h3><?php echo esc_html( 'Question ' . ( $idx + 1 ) . ' of ' . count( $selection ) ); ?></h3>
                    <div><?php echo wp_kses_post( $question['content'] ); ?></div>
                    <input type="hidden" name="question_ids[]" value="<?php echo esc_attr( absint( $question_id ) ); ?>" />
					<?php foreach ( $this->ordered_answers_for_attempt( $question_id, $secure_state ) as $answer ) : ?>
                        <label class="gbcmg-answer">
                            <input type="radio" required name="answers[<?php echo esc_attr( absint( $question_id ) ); ?>]" value="<?php echo esc_attr( $answer['id'] ); ?>" />
                            <?php echo esc_html( wp_strip_all_tags( $answer['text'] ) ); ?>
                        </label>
                    <?php endforeach; ?>
                </section>
            <?php endforeach; ?>
			<?php if ( $this->is_controlled_final( $map ) ) : ?>
				<label class="gbcmg-answer"><input type="checkbox" required name="gbcmg_attestation" value="1" /> I certify that I am the registered student and will personally complete this assessment using only the Texas Driver Handbook, my course notes, and assigned course materials. I will not use artificial intelligence, answer-generating websites, search engines, another person, or copied answers.</label>
			<?php endif; ?>
            <button class="gbcmg-button" type="submit">Submit Answers</button>
        </form>
		<?php if ( $this->is_controlled_final( $map ) ) : ?>
		<script>(function(){var end=<?php echo absint( $secure_state['attempt_expires_at'] ?? time() ); ?>*1000,el=document.getElementById('gbcmg-final-clock');function tick(){var left=Math.max(0,Math.floor((end-Date.now())/1000)),m=Math.floor(left/60),s=left%60;el.textContent=String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');if(left>0)setTimeout(tick,1000);}tick();})();</script>
		<?php endif; ?>
        <?php
        return ob_get_clean();
    }

    private function handle_mastery_submit() {
        if ( ! is_user_logged_in() ) {
            auth_redirect();
            exit;
        }

        $map_id = isset( $_POST['gbcmg_map'] ) ? sanitize_key( wp_unslash( $_POST['gbcmg_map'] ) ) : '';
        $map = $this->find_mapping_by_id( $map_id );
        if ( ! $map || empty( $map['active'] ) ) {
            wp_die( 'Mastery mapping not found.' );
        }

        $nonce = isset( $_POST['gbcmg_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['gbcmg_nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'gbcmg_mastery_' . $this->mapping_id( $map ) ) ) {
            wp_die( 'Security check failed.' );
        }

        $user_id = get_current_user_id();
        $course_id = absint( $map['course_id'] );
        $bank_id = absint( $map['bank_quiz_id'] );
        $selected_ids = isset( $_POST['question_ids'] ) && is_array( $_POST['question_ids'] ) ? array_values( array_map( 'absint', wp_unslash( $_POST['question_ids'] ) ) ) : array();
        $posted_answers = isset( $_POST['answers'] ) && is_array( $_POST['answers'] ) ? wp_unslash( $_POST['answers'] ) : array();

        $state = $this->get_mastery_state( $user_id, $map );
        $expected = isset( $state['current_selection'] ) && is_array( $state['current_selection'] ) ? array_values( array_map( 'absint', $state['current_selection'] ) ) : array();

        // Production safety: score exactly the server-selected question set.
        // Do not allow a modified POST to submit fewer questions and pass on a smaller denominator.
        if ( empty( $expected ) ) {
            $this->log_event( 'mastery_submit_blocked', $user_id, $map, array(
                'reason' => 'No active server-side question selection was found for this attempt.',
            ) );
            wp_die( 'This mastery check session could not be verified. Please reload the mastery check and try again.' );
        }

		if ( $this->is_controlled_final( $map ) ) {
			$attempt_no = max( 1, absint( $state['attempt'] ?? 1 ) );
			$security_errors = array();
			if ( empty( $_POST['gbcmg_attestation'] ) ) $security_errors[] = 'Student attestation was not confirmed.';
			if ( empty( $state['attempt_started_at'] ) || empty( $state['attempt_expires_at'] ) ) $security_errors[] = 'The server-side exam timer was not initialized.';
			if ( absint( $state['attempt_expires_at'] ?? 0 ) < time() ) $security_errors[] = 'The server-enforced exam time limit expired.';
			if ( ! hash_equals( (string) ( $state['session_hash'] ?? '' ), $this->current_session_hash() ) ) $security_errors[] = 'The signed-in session changed during the assessment.';
			if ( ! hash_equals( (string) ( $state['browser_hash'] ?? '' ), $this->current_browser_hash() ) ) $security_errors[] = 'The browser identity changed during the assessment.';
			$expected_set_hash = $this->question_set_hash( $map, $expected, $attempt_no );
			if ( ! hash_equals( (string) ( $state['question_set_hash'] ?? '' ), $expected_set_hash ) ) $security_errors[] = 'The signed question set did not verify.';
			if ( $security_errors ) {
				$this->log_event( 'secure_final_submit_blocked', $user_id, $map, array( 'attempt_no' => $attempt_no, 'reasons' => $security_errors ) );
				if ( in_array( 'The server-enforced exam time limit expired.', $security_errors, true ) ) {
					$state['current_selection'] = array();
					$state['attempt_started_at'] = 0;
					$state['attempt_expires_at'] = 0;
					$state['question_set_hash'] = '';
					$state['answer_orders'] = array();
					$this->set_mastery_state( $user_id, $map, $state );
				}
				wp_die( esc_html( implode( ' ', $security_errors ) . ' Return to the course and begin a new verified attempt.' ) );
			}
		}

        $posted_selected_ids = array_values( array_map( 'absint', $selected_ids ) );
        $expected_sorted = $expected;
        $posted_sorted = $posted_selected_ids;
        sort( $expected_sorted );
        sort( $posted_sorted );
        if ( $expected_sorted !== $posted_sorted ) {
            $this->log_event( 'mastery_submit_blocked', $user_id, $map, array(
                'reason'        => 'Submitted question IDs did not match the current server-side question selection.',
                'expected_ids'  => $expected_sorted,
                'submitted_ids' => $posted_sorted,
            ) );
            wp_die( 'This mastery check question set could not be verified. Please reload the mastery check and try again.' );
        }

        $selected_ids = $expected;

        $checked = array();
        $correct_count = 0;

        foreach ( $selected_ids as $qid ) {
            $answer_id = isset( $posted_answers[ $qid ] ) ? sanitize_text_field( (string) $posted_answers[ $qid ] ) : '';
            $answer_info = $this->get_answer_audit_info( $qid, $answer_id );
            $correct = ! empty( $answer_info['correct'] );
            if ( $correct ) {
                $correct_count++;
            }
            $bank_info = $this->get_question_bank_audit_info( $qid, $map );
            $correct_answer_info = $this->get_correct_answer_audit_info( $qid );
            $checked[] = array(
                'question_order'        => count( $checked ) + 1,
                'question_id'           => $qid,
                'question_title'        => get_the_title( $qid ),
                'question_text'         => wp_strip_all_tags( (string) get_post_field( 'post_content', $qid ) ),
                'answer_id'             => $answer_id,
                'answer_text'           => $answer_info['answer_text'],
                'correct'               => $correct ? 1 : 0,
                'correct_answer_ids'    => $correct_answer_info['answer_ids'],
                'correct_answer_texts'  => $correct_answer_info['answer_texts'],
                'bank_quiz_id'          => $bank_info['bank_quiz_id'],
                'bank_title'            => $bank_info['bank_title'],
                'bank_role'             => $bank_info['bank_role'],
            );
            $this->log_event( 'mastery_answer_submitted', $user_id, $map, array(
                'question_id_selected'  => $qid,
                'question_title'        => get_the_title( $qid ),
                'submitted_answer_id'   => $answer_id,
                'submitted_answer_text' => $answer_info['answer_text'],
                'answer_correct'        => $correct,
            ) );
        }

        $shown = count( $selected_ids );
        $score = $shown ? round( ( $correct_count / $shown ) * 100, 2 ) : 0;
        $pass_percent = absint( $map['pass_percent'] ?? 70 );
        $passed = ( $score >= $pass_percent );
        $attempt = max( 1, absint( $state['attempt'] ?? 1 ) );
        $fail_count = absint( $state['fail_count'] ?? 0 );

        $user_item_id = $this->mark_lp_quiz_item_result( $user_id, $map, $passed, array(
            'shown_count'   => $shown,
            'correct_count' => $correct_count,
            'score_percent' => $score,
            'pass_percent'  => $pass_percent,
            'attempt_no'    => $attempt,
            'checked'       => $checked,
            'submitted_at'  => current_time( 'mysql', true ),
        ) );

        $trigger_item_id = absint( $map['start_item_id'] ?? 0 );
        if ( $passed && $trigger_item_id && $trigger_item_id !== $bank_id ) {
            $this->mark_lp_course_item_completed( $user_id, $course_id, $trigger_item_id, true );
        }

        $now = current_time( 'mysql', true );
        if ( $passed ) {
            $next_id = absint( $map['next_item_id'] ?? 0 );
            $anchor_id = $trigger_item_id ? $trigger_item_id : $bank_id;
            if ( ! $next_id ) {
                $next_id = $this->get_next_item_after( $course_id, $anchor_id );
            }
            $next_url = $next_id ? $this->get_course_item_url( $course_id, $next_id ) : $this->get_course_item_url( $course_id, $anchor_id );

            $state['passed_at'] = $now;
            $state['failed_at'] = '';
            $state['fail_count'] = 0;
            $state['current_selection'] = array();
			$state['attempt_started_at'] = 0;
			$state['attempt_expires_at'] = 0;
			$state['question_set_hash'] = '';
			$state['session_hash'] = '';
			$state['browser_hash'] = '';
			$state['answer_orders'] = array();
            $state['attempt'] = $attempt;
            $state['last_result'] = array(
                'passed'        => true,
                'score_percent' => $score,
                'correct_count' => $correct_count,
                'shown_count'   => $shown,
                'attempt_no'    => $attempt,
                'next_url'      => $next_url,
                'user_item_id'  => $user_item_id,
                'completed_at'  => $now,
            );
            $this->set_mastery_state( $user_id, $map, $state );

            $this->log_event( 'mastery_passed', $user_id, $map, array(
                'score_percent' => $score,
                'correct_count' => $correct_count,
                'shown_count'   => $shown,
                'passed'        => true,
                'attempt_no'    => $attempt,
                'redirect_to'   => $next_url,
                'user_item_id'  => $user_item_id,
            ) );
            wp_safe_redirect( add_query_arg( 'gbcmg_result', 'passed', $this->get_mastery_url( $map ) ) );
            exit;
        }

        $fail_count++;
        $state['failed_at'] = $now;
        $state['passed_at'] = '';
        $state['current_selection'] = array();
		$state['attempt_started_at'] = 0;
		$state['attempt_expires_at'] = 0;
		$state['question_set_hash'] = '';
		$state['session_hash'] = '';
		$state['browser_hash'] = '';
		$state['answer_orders'] = array();
        $state['attempt'] = $attempt + 1;
        $state['fail_count'] = $fail_count;
        $this->set_mastery_state( $user_id, $map, $state );

        $start_id = absint( $map['start_item_id'] ?? 0 );
        $return_url = $start_id ? $this->get_course_item_url( $course_id, $start_id ) : $this->get_course_item_url( $course_id, $bank_id );
        $query_arg = 'gbcmg_failed';

        // Final exams: third failed attempt fails/locks for admin review.
        if ( in_array( ( $map['unit_type'] ?? '' ), array( 'adult_final', 'teen_final' ), true ) && $fail_count >= 3 ) {
            $query_arg = 'gbcmg_final_failed';
        }

        $state['last_result'] = array(
            'passed'           => false,
            'score_percent'    => $score,
            'correct_count'    => $correct_count,
            'shown_count'      => $shown,
            'attempt_no'       => $attempt,
            'fail_count'       => $fail_count,
            'return_to_review' => true,
            'review_url'       => add_query_arg( $query_arg, '1', $return_url ),
            'user_item_id'     => $user_item_id,
            'completed_at'     => $now,
        );
        $this->set_mastery_state( $user_id, $map, $state );

        $this->log_event( 'mastery_failed', $user_id, $map, array(
            'score_percent'    => $score,
            'correct_count'    => $correct_count,
            'shown_count'      => $shown,
            'passed'           => false,
            'attempt_no'       => $attempt,
            'fail_count'       => $fail_count,
            'return_to_review' => true,
            'redirect_to'      => $return_url,
            'user_item_id'     => $user_item_id,
        ) );
        wp_safe_redirect( add_query_arg( 'gbcmg_result', 'failed', $this->get_mastery_url( $map ) ) );
        exit;
    }

    private function friendly_mastery_title( $map ) {
        $unit_type = sanitize_key( $map['unit_type'] ?? 'teen_module' );
        $unit_number = absint( $map['unit_number'] ?? 0 );
        if ( 'teen_module' === $unit_type ) {
            return 'Module ' . $unit_number . ' Mastery Check';
        }
        if ( 'adult_topic' === $unit_type ) {
            return 'Adult Course Participation Check — Topic ' . $unit_number;
        }
        if ( 'teen_final' === $unit_type ) {
            return 'Teen Comprehensive Classroom Progress Assessment';
        }
        if ( 'teen_permit' === $unit_type ) {
            return 'Teen Permit Exam';
        }
        if ( 'adult_final' === $unit_type ) {
            return 'Adult Final Exam';
        }
        return 'Course Mastery Check';
    }

    private function expected_selection_count_for_map( $map ) {
        $unit_type = sanitize_key( $map['unit_type'] ?? 'teen_module' );
        if ( in_array( $unit_type, array( 'adult_final', 'teen_permit' ), true ) ) {
            return 30;
        }
        return absint( $map['questions_to_show'] ?? 0 );
    }

    private function get_or_select_mastery_questions( $user_id, $map ) {
        $state = $this->get_mastery_state( $user_id, $map );
        $expected_count = $this->expected_selection_count_for_map( $map );

        // v0.1.15: Loading the mastery page creates and stores current_selection
        // before the student submits. If an admin later changes Questions to Show
        // from 60 to 30, the mapping ID does not change, so the old unsubmitted
        // 60-question set can persist in user meta. Reuse an existing selection
        // only when its size still matches the current map settings.
        if ( ! empty( $state['current_selection'] ) && is_array( $state['current_selection'] ) ) {
            $existing_selection = array_values( array_map( 'absint', $state['current_selection'] ) );
            if ( $expected_count && count( $existing_selection ) === $expected_count ) {
                return $existing_selection;
            }

            $this->log_event( 'mastery_stale_selection_cleared', $user_id, $map, array(
                'existing_count'  => count( $existing_selection ),
                'expected_count'  => $expected_count,
                'reason'          => 'Stored unsubmitted question selection no longer matches current Questions to Show setting.',
            ) );
            $state['current_selection'] = array();
            $this->set_mastery_state( $user_id, $map, $state );
        }

        $unit_type = sanitize_key( $map['unit_type'] ?? 'teen_module' );
        if ( in_array( $unit_type, array( 'adult_final', 'teen_permit' ), true ) ) {
            $two_bank_label = ( 'teen_permit' === $unit_type ) ? 'Teen permit exam' : 'Adult final';
            $two_bank_event_prefix = ( 'teen_permit' === $unit_type ) ? 'teen_permit_exam' : 'adult_final';
            $first_bank  = absint( $map['bank_quiz_id'] );
            $second_bank = absint( $map['second_bank_quiz_id'] );
            $first_count = count( $this->get_quiz_question_ids( $first_bank ) );
            $second_count = count( $this->get_quiz_question_ids( $second_bank ) );

            if ( $first_count < 15 || $second_count < 15 ) {
                $this->log_event( $two_bank_event_prefix . '_delivery_blocked', $user_id, $map, array(
                    'reason'          => $two_bank_label . ' requires both banks to have at least 15 questions at delivery time.',
                    'primary_bank_id' => $first_bank,
                    'primary_count'   => $first_count,
                    'second_bank_id'  => $second_bank,
                    'second_count'    => $second_count,
                ) );
                return array();
            }

            $first_role  = ( 'teen_permit' === $unit_type ) ? 'laws'  : 'signs';
            $second_role = ( 'teen_permit' === $unit_type ) ? 'signs' : 'laws';
            $first = $this->select_from_bank_with_rotation( $user_id, $map, $first_bank, 15, $first_role );
            $second = $this->select_from_bank_with_rotation( $user_id, $map, $second_bank, 15, $second_role );

            if ( count( $first ) !== 15 || count( $second ) !== 15 ) {
                $this->log_event( $two_bank_event_prefix . '_delivery_blocked', $user_id, $map, array(
                    'reason'             => $two_bank_label . ' rotation returned a short question set.',
                    'primary_selected'   => count( $first ),
                    'second_selected'    => count( $second ),
                    'required_each_bank' => 15,
                ) );
                return array();
            }

            $picked = array_merge( $first, $second );
            shuffle( $picked );
        } else {
            $required_show = absint( $map['questions_to_show'] );
            $picked = $this->select_from_bank_with_rotation( $user_id, $map, absint( $map['bank_quiz_id'] ), $required_show, 'primary' );
            if ( count( $picked ) !== $required_show ) {
                $this->log_event( 'mastery_delivery_blocked', $user_id, $map, array(
                    'reason'         => 'Question rotation returned a short question set.',
                    'selected_count' => count( $picked ),
                    'required_count' => $required_show,
                ) );
                return array();
            }
        }

        $state['current_selection'] = $picked;
        $state['attempt'] = max( 1, absint( $state['attempt'] ?? 1 ) );
        $this->set_mastery_state( $user_id, $map, $state );

        $this->log_event( 'mastery_questions_selected', $user_id, $map, array(
            'selected'       => $picked,
            'selected_count' => count( $picked ),
            'attempt_no'     => $state['attempt'],
        ) );

        return $picked;
    }

    private function select_from_bank_with_rotation( $user_id, $map, $bank_id, $count, $bucket = 'primary' ) {
        $bank_id = absint( $bank_id );
        $count = absint( $count );
        $all = $this->get_quiz_question_ids( $bank_id );
        if ( empty( $all ) || ! $count ) {
            return array();
        }

        $state = $this->get_mastery_state( $user_id, $map );
        $seen_key = 'seen_' . sanitize_key( $bucket ) . '_' . $bank_id;
        $seen = isset( $state[ $seen_key ] ) && is_array( $state[ $seen_key ] ) ? array_values( array_map( 'absint', $state[ $seen_key ] ) ) : array();
        $unseen = array_values( array_diff( $all, $seen ) );
        $seen_before_count = count( $seen );
        $unseen_before_count = count( $unseen );
        $rotation_reset = false;
        $phase_one = array();
        $phase_two = array();

        shuffle( $unseen );
        if ( count( $unseen ) >= $count ) {
            $phase_one = array_slice( $unseen, 0, $count );
            $new_seen = array_values( array_unique( array_merge( $seen, $phase_one ) ) );
        } else {
            // Exhaust all remaining unseen questions first. Only after that do we
            // reset the pool to fill the rest of the attempt.
            $phase_one = $unseen;
            $remaining_needed = $count - count( $phase_one );
            $reset_pool = array_values( array_diff( $all, $phase_one ) );
            shuffle( $reset_pool );
            $phase_two = array_slice( $reset_pool, 0, min( $remaining_needed, count( $reset_pool ) ) );
            $rotation_reset = true;
            $new_seen = array_values( array_unique( $phase_two ) );
        }

        $picked = array_values( array_filter( array_merge( $phase_one, $phase_two ) ) );
        shuffle( $picked );

        $state[ $seen_key ] = $new_seen;
        $this->set_mastery_state( $user_id, $map, $state );

        $this->log_event( 'mastery_question_pool_picked', $user_id, $map, array(
            'bucket'                => $bucket,
            'bank_id'               => $bank_id,
            'selected'              => $picked,
            'phase_one_unseen'      => $phase_one,
            'phase_two_after_reset' => $phase_two,
            'bank_size'             => count( $all ),
            'seen_before'           => $seen_before_count,
            'unseen_before'         => $unseen_before_count,
            'seen_after'            => count( $state[ $seen_key ] ),
            'rotation_reset'        => $rotation_reset,
        ) );

        return $picked;
    }

    private function get_question_data( $question_id ) {
        $post = get_post( $question_id );
        return array(
            'id'      => absint( $question_id ),
            'title'   => $post ? $post->post_title : '',
            'content' => $post ? apply_filters( 'the_content', $post->post_content ) : '',
        );
    }

    private function get_answer_audit_info( $question_id, $answer_id ) {
        $info = array(
            'answer_id'   => (string) $answer_id,
            'answer_text' => '',
            'correct'     => false,
        );
        foreach ( $this->get_question_answers( $question_id ) as $answer ) {
            if ( (string) $answer['id'] === (string) $answer_id ) {
                $info['answer_text'] = wp_strip_all_tags( (string) $answer['text'] );
                $info['correct'] = ! empty( $answer['is_true'] );
                break;
            }
        }
        return $info;
    }

    private function get_correct_answer_audit_info( $question_id ) {
        $info = array(
            'answer_ids'   => array(),
            'answer_texts' => array(),
        );
        foreach ( $this->get_question_answers( $question_id ) as $answer ) {
            if ( ! empty( $answer['is_true'] ) ) {
                $info['answer_ids'][] = (string) $answer['id'];
                $info['answer_texts'][] = wp_strip_all_tags( (string) $answer['text'] );
            }
        }
        return $info;
    }

    private function get_question_bank_audit_info( $question_id, $map ) {
        $question_id = absint( $question_id );
        $out = array(
            'bank_quiz_id' => 0,
            'bank_title'   => '',
            'bank_role'    => '',
        );
        $banks = array(
            'primary'   => absint( $map['bank_quiz_id'] ?? 0 ),
            'secondary' => absint( $map['second_bank_quiz_id'] ?? 0 ),
        );
        foreach ( $banks as $role => $bank_id ) {
            if ( ! $bank_id ) {
                continue;
            }
            $question_ids = array_map( 'absint', $this->get_quiz_question_ids( $bank_id ) );
            if ( in_array( $question_id, $question_ids, true ) ) {
                $out['bank_quiz_id'] = $bank_id;
                $out['bank_title'] = get_the_title( $bank_id );
                $out['bank_role'] = $role;
                return $out;
            }
        }
        return $out;
    }

    private function get_quiz_question_ids( $quiz_id ) {
        global $wpdb;
        $quiz_id = absint( $quiz_id );
        if ( ! $quiz_id ) {
            return array();
        }
        $table = $wpdb->prefix . 'learnpress_quiz_questions';
        if ( $this->table_exists( $table ) ) {
            $cols = $this->table_columns( $table );
            if ( in_array( 'quiz_id', $cols, true ) && in_array( 'question_id', $cols, true ) ) {
                $order_col = '';
                foreach ( array( 'question_order', 'order', 'sort_order', 'ID', 'id' ) as $candidate ) {
                    if ( in_array( $candidate, $cols, true ) ) {
                        $order_col = $candidate;
                        break;
                    }
                }
                $order_sql = $order_col ? " ORDER BY `{$order_col}` ASC" : '';
                $ids = $wpdb->get_col( $wpdb->prepare( "SELECT question_id FROM {$table} WHERE quiz_id = %d{$order_sql}", $quiz_id ) );
                $ids = array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
                if ( $ids ) {
                    return $ids;
                }
            }
        }
        foreach ( array( '_lp_questions', '_quiz_questions', '_lp_quiz_questions' ) as $key ) {
            $raw = get_post_meta( $quiz_id, $key, true );
            if ( empty( $raw ) ) {
                continue;
            }
            $maybe = is_array( $raw ) ? $raw : maybe_unserialize( $raw );
            if ( ! is_array( $maybe ) ) {
                $maybe = json_decode( (string) $raw, true );
            }
            if ( is_array( $maybe ) ) {
                $ids = array();
                foreach ( $maybe as $k => $v ) {
                    if ( is_numeric( $v ) ) {
                        $ids[] = absint( $v );
                    } elseif ( is_numeric( $k ) ) {
                        $ids[] = absint( $k );
                    } elseif ( is_array( $v ) && ! empty( $v['id'] ) ) {
                        $ids[] = absint( $v['id'] );
                    }
                }
                $ids = array_values( array_unique( array_filter( $ids ) ) );
                if ( $ids ) {
                    return $ids;
                }
            }
        }
        return array();
    }

    private function get_quiz_question_count( $quiz_id ) {
        return count( $this->get_quiz_question_ids( $quiz_id ) );
    }

    private function get_question_answers( $question_id ) {
        global $wpdb;
        $question_id = absint( $question_id );
        $answers = array();

        $table = $wpdb->prefix . 'learnpress_question_answers';
        if ( $this->table_exists( $table ) ) {
            $cols = $this->table_columns( $table );
            if ( in_array( 'question_id', $cols, true ) ) {
                $id_col = '';
                foreach ( array( 'question_answer_id', 'answer_id', 'id', 'ID' ) as $candidate ) {
                    if ( in_array( $candidate, $cols, true ) ) { $id_col = $candidate; break; }
                }
                $text_col = '';
                foreach ( array( 'title', 'answer_title', 'text', 'content', 'value' ) as $candidate ) {
                    if ( in_array( $candidate, $cols, true ) ) { $text_col = $candidate; break; }
                }
                $true_col = '';
                foreach ( array( 'is_true', 'is_correct', 'correct' ) as $candidate ) {
                    if ( in_array( $candidate, $cols, true ) ) { $true_col = $candidate; break; }
                }
                $order_col = '';
                foreach ( array( 'question_answer_order', 'answer_order', 'order', 'sort_order' ) as $candidate ) {
                    if ( in_array( $candidate, $cols, true ) ) { $order_col = $candidate; break; }
                }
                if ( $id_col && $text_col ) {
                    $order_sql = $order_col ? " ORDER BY `{$order_col}` ASC" : '';
                    $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE question_id = %d{$order_sql}", $question_id ), ARRAY_A );
                    foreach ( (array) $rows as $row ) {
                        $raw_true = $true_col && isset( $row[ $true_col ] ) ? strtolower( (string) $row[ $true_col ] ) : '';
                        $answers[] = array(
                            'id'      => (string) $row[ $id_col ],
                            'text'    => (string) $row[ $text_col ],
                            'is_true' => in_array( $raw_true, array( '1', 'yes', 'true', 'on', 'y' ), true ),
                        );
                    }
                    if ( $answers ) {
                        return $answers;
                    }
                }
            }
        }

        foreach ( array( '_lp_answers', '_question_answers', 'answers' ) as $key ) {
            $raw = get_post_meta( $question_id, $key, true );
            if ( empty( $raw ) ) {
                continue;
            }
            $maybe = is_array( $raw ) ? $raw : maybe_unserialize( $raw );
            if ( ! is_array( $maybe ) ) {
                $maybe = json_decode( (string) $raw, true );
            }
            if ( is_array( $maybe ) ) {
                foreach ( $maybe as $idx => $row ) {
                    if ( ! is_array( $row ) ) {
                        continue;
                    }
                    $id = isset( $row['id'] ) ? $row['id'] : ( isset( $row['answer_id'] ) ? $row['answer_id'] : $idx );
                    $text = isset( $row['title'] ) ? $row['title'] : ( isset( $row['text'] ) ? $row['text'] : ( isset( $row['value'] ) ? $row['value'] : '' ) );
                    $truth = '';
                    foreach ( array( 'is_true', 'is_correct', 'correct' ) as $tk ) {
                        if ( isset( $row[ $tk ] ) ) { $truth = strtolower( (string) $row[ $tk ] ); break; }
                    }
                    $answers[] = array(
                        'id'      => (string) $id,
                        'text'    => (string) $text,
                        'is_true' => in_array( $truth, array( '1', 'yes', 'true', 'on', 'y' ), true ),
                    );
                }
                if ( $answers ) {
                    return $answers;
                }
            }
        }

        return array();
    }

    private function force_hide_answer_for_mapped_bank( $value = false, $quiz = 0 ) {
        $candidate_ids = array();
        if ( is_numeric( $quiz ) ) {
            $candidate_ids[] = absint( $quiz );
        } elseif ( is_object( $quiz ) ) {
            if ( method_exists( $quiz, 'get_id' ) ) {
                $candidate_ids[] = absint( $quiz->get_id() );
            } elseif ( ! empty( $quiz->ID ) ) {
                $candidate_ids[] = absint( $quiz->ID );
            }
        }
        $queried = get_queried_object_id();
        if ( $queried ) {
            $candidate_ids[] = absint( $queried );
        }
        foreach ( array( 'quiz_id', 'id', 'item_id' ) as $key ) {
            if ( isset( $_REQUEST[ $key ] ) ) {
                $candidate_ids[] = absint( wp_unslash( $_REQUEST[ $key ] ) );
            }
        }

        foreach ( array_unique( array_filter( $candidate_ids ) ) as $candidate_id ) {
            if ( $this->is_mapped_bank_id( $candidate_id ) ) {
                return false;
            }
        }
        return $value;
    }

    private function find_mapping_by_id( $map_id ) {
        $map_id = sanitize_key( $map_id );
        foreach ( $this->get_mappings() as $map ) {
            if ( $this->mapping_id( $map ) === $map_id ) {
                return $map;
            }
        }
        return null;
    }

    private function get_active_mappings_for_course( $course_id ) {
        $course_id = absint( $course_id );
        $out = array();
        foreach ( $this->get_mappings() as $map ) {
            if ( empty( $map['active'] ) || absint( $map['course_id'] ?? 0 ) !== $course_id ) {
                continue;
            }
            $out[] = $map;
        }
        return $out;
    }

    private function item_triggers_map( $item_id, $map ) {
        $item_id = absint( $item_id );
        $start_id = absint( $map['start_item_id'] ?? 0 );
        if ( $start_id && $item_id === $start_id ) {
            return true;
        }
        // Backward compatibility and safety: if a mapped bank is still attached
        // to the curriculum or opened directly, route it through the custom gate.
        return $this->item_is_map_bank( $item_id, $map );
    }

    private function item_is_map_bank( $item_id, $map ) {
        $item_id = absint( $item_id );
        if ( $item_id && $item_id === absint( $map['bank_quiz_id'] ?? 0 ) ) {
            return true;
        }
        if ( 'adult_final' === ( $map['unit_type'] ?? '' ) && $item_id && $item_id === absint( $map['second_bank_quiz_id'] ?? 0 ) ) {
            return true;
        }
        return false;
    }

    private function get_mastery_url( $map ) {
        $course_url = get_permalink( absint( $map['course_id'] ) );
        if ( ! $course_url ) {
            $course_url = home_url( '/' );
        }
        return add_query_arg( array(
            'gbcmg_mastery' => '1',
            'gbcmg_map'     => $this->mapping_id( $map ),
        ), $course_url );
    }

    private function get_mastery_state_key( $map ) {
        return '_gbcmg_state_' . $this->mapping_id( $map );
    }

    private function get_mastery_state( $user_id, $map ) {
        $state = get_user_meta( absint( $user_id ), $this->get_mastery_state_key( $map ), true );
        return is_array( $state ) ? $state : array();
    }

    private function set_mastery_state( $user_id, $map, $state ) {
        update_user_meta( absint( $user_id ), $this->get_mastery_state_key( $map ), is_array( $state ) ? $state : array() );
    }

    private function is_mapped_bank_id( $quiz_id ) {
        $quiz_id = absint( $quiz_id );
        if ( ! $quiz_id ) { return false; }
        foreach ( $this->get_mappings() as $map ) {
            if ( empty( $map['active'] ) ) { continue; }
            if ( $quiz_id === absint( $map['bank_quiz_id'] ?? 0 ) ) { return true; }
            if ( $quiz_id === absint( $map['second_bank_quiz_id'] ?? 0 ) ) { return true; }
        }
        return false;
    }

    private function is_grandfatherable_state( $state ) {
        if ( empty( $state ) || ! is_array( $state ) ) { return true; }
        if ( ! empty( $state['passed_at'] ) || ! empty( $state['failed_at'] ) ) { return false; }
        if ( ! empty( $state['last_result'] ) ) { return false; }
        if ( absint( $state['fail_count'] ?? 0 ) > 0 ) { return false; }
        // A stale current_selection/seen pool means the student opened the form but
        // did not submit a real pass/fail attempt. It is safe to grandfather only
        // if independent LearnPress later/completed evidence exists.
        return true;
    }

    private function lp_row_completed_or_passed( $row ) {
        if ( empty( $row ) || ! is_array( $row ) || empty( $row['user_item_id'] ) ) { return false; }
        $status     = isset( $row['status'] ) ? strtolower( (string) $row['status'] ) : '';
        $graduation = isset( $row['graduation'] ) ? strtolower( (string) $row['graduation'] ) : '';
        return ( in_array( $status, array( 'completed', 'finished', 'passed' ), true ) || in_array( $graduation, array( 'passed', 'completed' ), true ) );
    }

    private function maybe_grandfather_existing_progress( $user_id, $map, $course_id, $current_item_id, $state ) {
        if ( ! $this->is_grandfatherable_state( $state ) ) {
            return array( 'grandfathered' => false );
        }

        $course_id = absint( $course_id );
        $bank_ids = array_filter( array_unique( array_map( 'absint', array(
            $map['bank_quiz_id'] ?? 0,
            $map['second_bank_quiz_id'] ?? 0,
        ) ) ) );

        foreach ( $bank_ids as $bank_id ) {
            $lp_row = $this->get_lp_item_state( $user_id, $course_id, $bank_id );
            if ( $this->lp_row_completed_or_passed( $lp_row ) ) {
                return $this->stamp_grandfathered_state( $user_id, $map, $state, array(
                    'reason'          => 'bank_quiz_completed_before_gbcmg_state',
                    'current_item_id' => absint( $current_item_id ),
                    'bank_quiz_id'    => $bank_id,
                    'lp_status'       => isset( $lp_row['status'] ) ? strtolower( (string) $lp_row['status'] ) : '',
                    'lp_graduation'   => isset( $lp_row['graduation'] ) ? strtolower( (string) $lp_row['graduation'] ) : '',
                    'lp_user_item_id' => absint( $lp_row['user_item_id'] ?? 0 ),
                ) );
            }
        }

        $positions = $this->positions_from_items( $this->get_course_items( $course_id ) );
        $start_id = absint( $map['start_item_id'] ?? 0 );
        $gate_pos = ( $start_id && isset( $positions[ $start_id ] ) ) ? $positions[ $start_id ] : null;
        if ( null === $gate_pos ) {
            foreach ( $bank_ids as $bank_id ) {
                if ( isset( $positions[ $bank_id ] ) ) {
                    $gate_pos = null === $gate_pos ? $positions[ $bank_id ] : max( $gate_pos, $positions[ $bank_id ] );
                }
            }
        }
        if ( null === $gate_pos ) {
            return array( 'grandfathered' => false );
        }

        foreach ( $this->get_course_items( $course_id ) as $item ) {
            $candidate_id = absint( $item['item_id'] ?? 0 );
            if ( ! $candidate_id || ! isset( $positions[ $candidate_id ] ) || $positions[ $candidate_id ] <= $gate_pos ) {
                continue;
            }
            $lp_row = $this->get_lp_item_state( $user_id, $course_id, $candidate_id );
            if ( $this->lp_row_completed_or_passed( $lp_row ) ) {
                return $this->stamp_grandfathered_state( $user_id, $map, $state, array(
                    'reason'               => 'later_course_item_completed_after_bank',
                    'current_item_id'      => absint( $current_item_id ),
                    'bank_position'        => $gate_pos,
                    'later_completed_item' => array(
                        'item_id'    => $candidate_id,
                        'position'   => $positions[ $candidate_id ],
                        'title'      => get_the_title( $candidate_id ),
                        'status'     => isset( $lp_row['graduation'] ) && $lp_row['graduation'] ? (string) $lp_row['graduation'] : (string) ( $lp_row['status'] ?? '' ),
                        'updated_at' => (string) ( $lp_row['update_time'] ?? ( $lp_row['updated_at'] ?? '' ) ),
                    ),
                ) );
            }
        }

        return array( 'grandfathered' => false );
    }

    private function stamp_grandfathered_state( $user_id, $map, $state, $details ) {
        $now = current_time( 'mysql', true );
        $state['passed_at']          = $now;
        $state['failed_at']          = '';
        $state['fail_count']         = 0;
        $state['current_selection']  = array();
        $state['grandfathered']      = 1;
        $state['grandfathered_at']   = $now;
        $state['grandfather_reason'] = sanitize_key( $details['reason'] ?? 'existing_course_progress' );
        $state['last_result'] = array(
            'passed'        => true,
            'score_percent' => 100,
            'correct_count' => 0,
            'shown_count'   => 0,
            'attempt_no'    => absint( $state['attempt'] ?? 1 ),
            'next_url'      => $this->get_map_continue_url( $map, absint( $details['current_item_id'] ?? 0 ), $state ),
            'completed_at'  => $now,
            'grandfathered' => 1,
        );
        $this->set_mastery_state( $user_id, $map, $state );
        $this->log_event( 'mapping_grandfathered_existing_progress', $user_id, $map, $details );
        return array( 'grandfathered' => true, 'details' => $details );
    }

    private function get_map_continue_url( $map, $current_item_id = 0, $state = array() ) {
        if ( ! empty( $state['last_result'] ) && is_array( $state['last_result'] ) && ! empty( $state['last_result']['next_url'] ) ) {
            return esc_url_raw( $state['last_result']['next_url'] );
        }
        $course_id = absint( $map['course_id'] );
        $next_id = absint( $map['next_item_id'] ?? 0 );
        if ( ! $next_id ) {
            $anchor_id = absint( $current_item_id );
            if ( ! $anchor_id ) {
                $anchor_id = absint( $map['start_item_id'] ?? 0 );
            }
            if ( ! $anchor_id ) {
                $anchor_id = absint( $map['bank_quiz_id'] ?? 0 );
            }
            $next_id = $this->get_next_item_after( $course_id, $anchor_id );
        }
        if ( $next_id ) {
            return $this->get_course_item_url( $course_id, $next_id );
        }
        $fallback_id = absint( $map['start_item_id'] ?? 0 );
        if ( ! $fallback_id ) {
            $fallback_id = absint( $map['bank_quiz_id'] ?? 0 );
        }
        return $fallback_id ? $this->get_course_item_url( $course_id, $fallback_id ) : get_permalink( $course_id );
    }

    private function user_has_lp_course_record( $user_id, $course_id ) {
        global $wpdb;
        $user_id = absint( $user_id );
        $course_id = absint( $course_id );
        if ( ! $user_id || ! $course_id ) { return false; }
        $table = $wpdb->prefix . 'learnpress_user_items';
        if ( ! $this->table_exists( $table ) ) { return true; }
        $cols = $this->table_columns( $table );
        if ( ! in_array( 'user_id', $cols, true ) || ! in_array( 'item_id', $cols, true ) ) { return true; }
        $sql = "SELECT user_item_id FROM {$table} WHERE user_id = %d AND item_id = %d";
        $args = array( $user_id, $course_id );
        if ( in_array( 'item_type', $cols, true ) ) {
            $sql .= " AND item_type = %s";
            $args[] = 'lp_course';
        }
        $sql .= " ORDER BY user_item_id DESC LIMIT 1";
        return (bool) $wpdb->get_var( $wpdb->prepare( $sql, $args ) );
    }

    private function detect_context() {
        $course_id = 0;
        $item_id   = 0;
        $path_course_id = $this->detect_course_id_from_request_path();
        if ( $path_course_id ) {
            $course_id = $path_course_id;
        }

        if ( function_exists( 'learn_press_get_course_id' ) ) {
            $maybe = learn_press_get_course_id();
            if ( $maybe && ! $course_id ) { $course_id = absint( $maybe ); }
        }
        if ( function_exists( 'learn_press_get_course' ) && ! $course_id ) {
            $course = learn_press_get_course();
            if ( is_object( $course ) && method_exists( $course, 'get_id' ) ) {
                $course_id = absint( $course->get_id() );
            }
        }

        $queried = get_queried_object_id();
        if ( $queried && in_array( get_post_type( $queried ), array( 'lp_course', 'lp_lesson', 'lp_quiz' ), true ) ) {
            if ( 'lp_course' === get_post_type( $queried ) ) {
                if ( ! $course_id ) { $course_id = absint( $queried ); }
                $item_id = $this->detect_item_id_from_request( $course_id );
            } else {
                $item_id = absint( $queried );
                if ( ! $course_id ) {
                    $course_id = $this->find_course_for_item( $item_id );
                }
            }
        }

        if ( ! $item_id && $course_id ) {
            $item_id = $this->detect_item_id_from_request( $course_id );
        }

        // Standard LearnPress course URLs are the most reliable course context.
        if ( $path_course_id ) {
            $course_id = $path_course_id;
        }

        return array( 'course_id' => absint( $course_id ), 'item_id' => absint( $item_id ) );
    }

    private function detect_course_id_from_request_path() {
        $path = trim( (string) wp_parse_url( $this->current_url(), PHP_URL_PATH ), '/' );
        if ( '' === $path ) { return 0; }
        $segments = array_values( array_filter( explode( '/', $path ), 'strlen' ) );
        $idx = array_search( 'courses', $segments, true );
        if ( false === $idx || empty( $segments[ $idx + 1 ] ) ) {
            return 0;
        }
        $slug = sanitize_title( rawurldecode( $segments[ $idx + 1 ] ) );
        if ( ! $slug ) { return 0; }
        $post = get_page_by_path( $slug, OBJECT, 'lp_course' );
        return $post && ! empty( $post->ID ) ? absint( $post->ID ) : 0;
    }

    private function detect_item_id_from_request( $course_id ) {
        $path = trim( (string) wp_parse_url( $this->current_url(), PHP_URL_PATH ), '/' );
        $segments = array_map( 'sanitize_title', array_map( 'rawurldecode', array_values( array_filter( explode( '/', $path ), 'strlen' ) ) ) );
        $items = $this->get_course_items( $course_id );
        foreach ( $items as $item ) {
            $slug = get_post_field( 'post_name', $item['item_id'] );
            if ( $slug && in_array( sanitize_title( $slug ), $segments, true ) ) {
                return absint( $item['item_id'] );
            }
        }
        return 0;
    }


    private function get_all_quiz_options() {
        $out = array();
        if ( ! post_type_exists( 'lp_quiz' ) ) {
            return $out;
        }
        $quizzes = get_posts( array(
            'post_type'        => 'lp_quiz',
            'post_status'      => array( 'publish', 'private', 'draft' ),
            'numberposts'      => 1000,
            'orderby'          => 'title',
            'order'            => 'ASC',
            'suppress_filters' => false,
        ) );
        foreach ( $quizzes as $quiz ) {
            $out[] = array(
                'id'    => absint( $quiz->ID ),
                'label' => '#' . absint( $quiz->ID ) . ' — ' . $quiz->post_title,
            );
        }
        return $out;
    }

    private function get_lp_courses() {
        if ( ! post_type_exists( 'lp_course' ) ) {
            return array();
        }
        return get_posts( array(
            'post_type'        => 'lp_course',
            'post_status'      => array( 'publish', 'private', 'draft' ),
            'numberposts'      => 200,
            'orderby'          => 'title',
            'order'            => 'ASC',
            'suppress_filters' => false,
        ) );
    }

    private function get_course_items( $course_id ) {
        global $wpdb;
        $course_id = absint( $course_id );
        if ( ! $course_id ) {
            return array();
        }
        if ( isset( $this->course_items_cache[ $course_id ] ) ) {
            return $this->course_items_cache[ $course_id ];
        }

        $sections_table = $wpdb->prefix . 'learnpress_sections';
        $items_table = $wpdb->prefix . 'learnpress_section_items';
        $out = array();

        if ( $this->table_exists( $sections_table ) && $this->table_exists( $items_table ) ) {
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT s.section_id, s.section_name, s.section_order, si.item_id, si.item_order
                 FROM {$sections_table} s
                 INNER JOIN {$items_table} si ON si.section_id = s.section_id
                 WHERE s.section_course_id = %d
                 ORDER BY s.section_order ASC, si.item_order ASC, si.section_item_id ASC",
                $course_id
            ), ARRAY_A );
            foreach ( (array) $rows as $row ) {
                $out[] = array(
                    'section_id'    => absint( $row['section_id'] ),
                    'section_name'  => sanitize_text_field( $row['section_name'] ),
                    'section_order' => intval( $row['section_order'] ),
                    'item_id'       => absint( $row['item_id'] ),
                    'item_order'    => intval( $row['item_order'] ),
                );
            }
        }
        $this->course_items_cache[ $course_id ] = $out;
        return $out;
    }

    private function positions_from_items( $items ) {
        $positions = array();
        foreach ( array_values( $items ) as $idx => $item ) {
            $positions[ absint( $item['item_id'] ) ] = $idx;
        }
        return $positions;
    }

    private function get_next_item_after( $course_id, $item_id ) {
        $items = $this->get_course_items( $course_id );
        $ids = wp_list_pluck( $items, 'item_id' );
        $idx = array_search( absint( $item_id ), array_map( 'absint', $ids ), true );
        if ( false !== $idx && isset( $ids[ $idx + 1 ] ) ) {
            return absint( $ids[ $idx + 1 ] );
        }
        return 0;
    }

    private function find_course_for_item( $item_id ) {
        foreach ( $this->get_lp_courses() as $course ) {
            foreach ( $this->get_course_items( $course->ID ) as $item ) {
                if ( absint( $item['item_id'] ) === absint( $item_id ) ) {
                    return absint( $course->ID );
                }
            }
        }
        return 0;
    }

    private function get_course_item_url( $course_id, $item_id ) {
        $course_id = absint( $course_id );
        $item_id = absint( $item_id );
        $candidates = array();
        $home_root = trailingslashit( home_url( '/' ) );

        $course_url = get_permalink( $course_id );
        $slug = get_post_field( 'post_name', $item_id );
        $type = get_post_type( $item_id );
        if ( $course_url && $slug && in_array( $type, array( 'lp_lesson', 'lp_quiz' ), true ) ) {
            $path = 'lp_quiz' === $type ? 'quizzes' : 'lessons';
            $candidates[] = trailingslashit( $course_url ) . trailingslashit( $path ) . trailingslashit( $slug );
        }

        if ( function_exists( 'learn_press_get_course_item_permalink' ) ) {
            $url = learn_press_get_course_item_permalink( $course_id, $item_id );
            if ( $url ) { $candidates[] = $url; }
        }
        if ( function_exists( 'learn_press_get_course_item_url' ) ) {
            $url = learn_press_get_course_item_url( $course_id, $item_id );
            if ( $url ) { $candidates[] = $url; }
        }
        if ( function_exists( 'learn_press_get_item_link' ) ) {
            $url = learn_press_get_item_link( $item_id, $course_id );
            if ( $url ) { $candidates[] = $url; }
        }
        $plain = get_permalink( $item_id );
        if ( $plain ) { $candidates[] = $plain; }

        foreach ( $candidates as $candidate ) {
            $candidate = esc_url_raw( $candidate );
            if ( ! $candidate ) { continue; }
            if ( trailingslashit( $candidate ) === $home_root && $item_id !== absint( get_option( 'page_on_front' ) ) ) {
                continue;
            }
            return $candidate;
        }
        return $course_url ? $course_url : home_url( '/' );
    }

    private function mark_lp_quiz_item_result( $user_id, $map, $passed, $details = array() ) {
        global $wpdb;
        $user_id   = absint( $user_id );
        $course_id = absint( $map['course_id'] ?? 0 );
        $quiz_id   = absint( $map['bank_quiz_id'] ?? 0 );
        if ( ! $user_id || ! $course_id || ! $quiz_id ) {
            return 0;
        }

        $now          = current_time( 'mysql', true );
        $shown        = max( 1, absint( $details['shown_count'] ?? 1 ) );
        $correct      = absint( $details['correct_count'] ?? 0 );
        $score        = isset( $details['score_percent'] ) ? floatval( $details['score_percent'] ) : ( $passed ? 100 : 0 );
        $checked      = isset( $details['checked'] ) && is_array( $details['checked'] ) ? $details['checked'] : array();
        $mapping_id   = $this->mapping_id( $map );
        $submitted_at = ! empty( $details['submitted_at'] ) ? (string) $details['submitted_at'] : $now;

        $result = array(
            'gbcmg_mastery'   => 1,
            'gbcmg_version'   => self::VERSION,
            'status'          => 'completed',
            'graduation'      => $passed ? 'passed' : 'failed',
            'result'          => $passed ? 'passed' : 'failed',
            'score'           => $score,
            'user_mark'       => $correct,
            'question_count'  => $shown,
            'question_correct'=> $correct,
            'question_wrong'  => $shown - $correct,
            'question_empty'  => 0,
            'checked'         => $checked,
            'time'            => $submitted_at,
            'attempt_no'      => absint( $details['attempt_no'] ?? 0 ),
            'pass_percent'    => absint( $details['pass_percent'] ?? 0 ),
            'mapping_id'      => $mapping_id,
            'course_id'       => $course_id,
            'bank_quiz_id'    => $quiz_id,
            'second_bank_quiz_id' => absint( $map['second_bank_quiz_id'] ?? 0 ),
        );

        $attempt_detail = array(
            'gbcmg_attempt_detail' => 1,
            'gbcmg_version'        => self::VERSION,
            'user_id'              => $user_id,
            'course_id'            => $course_id,
            'mapping_id'           => $mapping_id,
            'mapping_label'        => sanitize_text_field( $map['label'] ?? '' ),
            'unit_type'            => sanitize_key( $map['unit_type'] ?? '' ),
            'unit_number'          => absint( $map['unit_number'] ?? 0 ),
            'bank_quiz_id'         => $quiz_id,
            'bank_title'           => get_the_title( $quiz_id ),
            'second_bank_quiz_id'  => absint( $map['second_bank_quiz_id'] ?? 0 ),
            'second_bank_title'    => get_the_title( absint( $map['second_bank_quiz_id'] ?? 0 ) ),
            'start_item_id'        => absint( $map['start_item_id'] ?? 0 ),
            'next_item_id'         => absint( $map['next_item_id'] ?? 0 ),
            'attempt_no'           => absint( $details['attempt_no'] ?? 0 ),
            'submitted_at'         => $submitted_at,
            'passed'               => $passed ? 1 : 0,
            'result'               => $passed ? 'passed' : 'failed',
            'score_percent'        => $score,
            'correct_count'        => $correct,
            'shown_count'          => $shown,
            'pass_percent'         => absint( $details['pass_percent'] ?? 0 ),
            'questions'            => $checked,
            'checked'              => $checked,
        );

        // Always write the durable user_meta fallback. Grade Book can read this directly.
        $user_meta_detail_key  = '_gbcmg_attempt_detail_' . $mapping_id;
        $user_meta_history_key = '_gbcmg_attempt_history_' . $mapping_id;
        update_user_meta( $user_id, $user_meta_detail_key, $attempt_detail );
        $user_history = get_user_meta( $user_id, $user_meta_history_key, true );
        if ( ! is_array( $user_history ) ) {
            $user_history = array();
        }
        $user_history[] = $attempt_detail;
        update_user_meta( $user_id, $user_meta_history_key, $user_history );

        /*
         * v0.1.14: Internal bank quizzes must not be inserted as completed
         * LearnPress course items. If they are, LearnPress counts them in course
         * progress and can show impossible states like 18/11 quizzes completed.
         * Only write a LearnPress user_item row when the selected bank quiz is
         * actually attached to the course curriculum.
         */
        $bank_is_curriculum_item = $this->is_course_curriculum_item( $course_id, $quiz_id );
        if ( ! $bank_is_curriculum_item ) {
            $this->purge_internal_bank_lp_item_rows( $user_id, $course_id, array(
                $quiz_id,
                absint( $map['second_bank_quiz_id'] ?? 0 ),
            ) );
            $this->log_event( 'mastery_attempt_detail_stored', $user_id, $map, array(
                'user_item_id'              => 0,
                'storage'                   => 'user_meta_only_internal_bank',
                'bank_quiz_id'              => $quiz_id,
                'bank_is_curriculum_item'   => false,
                'checked_count'             => count( $checked ),
                'question_detail_present'   => ! empty( $checked ),
                'user_meta_detail_key'      => $user_meta_detail_key,
                'user_meta_history_key'     => $user_meta_history_key,
            ) );
            return 0;
        }

        $table = $wpdb->prefix . 'learnpress_user_items';
        if ( ! $this->table_exists( $table ) ) {
            return 0;
        }
        $cols = $this->table_columns( $table );
        if ( ! in_array( 'user_id', $cols, true ) || ! in_array( 'item_id', $cols, true ) ) {
            return 0;
        }

        $existing = $this->get_lp_item_state( $user_id, $course_id, $quiz_id );
        $user_item_id = absint( $existing['user_item_id'] ?? 0 );
        $data = array();
        foreach ( array( 'user_id' => $user_id, 'item_id' => $quiz_id, 'item_type' => 'lp_quiz', 'ref_id' => $course_id, 'ref_type' => 'lp_course' ) as $col => $val ) {
            if ( in_array( $col, $cols, true ) ) {
                $data[ $col ] = $val;
            }
        }
        if ( in_array( 'status', $cols, true ) ) {
            $data['status'] = 'completed';
        }
        if ( in_array( 'graduation', $cols, true ) ) {
            $data['graduation'] = $passed ? 'passed' : 'failed';
        }
        if ( in_array( 'access_level', $cols, true ) ) {
            $data['access_level'] = 50;
        }
        foreach ( array( 'end_time', 'graduation_time', 'update_time', 'updated_at' ) as $tc ) {
            if ( in_array( $tc, $cols, true ) ) {
                $data[ $tc ] = $now;
            }
        }
        if ( ! $user_item_id ) {
            foreach ( array( 'start_time', 'created_at' ) as $tc ) {
                if ( in_array( $tc, $cols, true ) ) {
                    $data[ $tc ] = $now;
                }
            }
            if ( in_array( 'parent_id', $cols, true ) ) {
                $data['parent_id'] = $this->find_course_user_item_id( $user_id, $course_id );
            }
        }

        if ( $user_item_id && in_array( 'user_item_id', $cols, true ) ) {
            $wpdb->update( $table, $data, array( 'user_item_id' => $user_item_id ) );
        } else {
            $wpdb->insert( $table, $data );
            $user_item_id = absint( $wpdb->insert_id );
        }

        if ( $user_item_id ) {
            $meta_results = array();
            $meta_results['result'] = $this->upsert_lp_user_itemmeta( $user_item_id, 'result', $result );
            $meta_results['grade'] = $this->upsert_lp_user_itemmeta( $user_item_id, 'grade', $passed ? 'passed' : 'failed' );
            $meta_results['score'] = $this->upsert_lp_user_itemmeta( $user_item_id, 'score', $score );
            $meta_results['_gbcmg_mastery_result'] = $this->upsert_lp_user_itemmeta( $user_item_id, '_gbcmg_mastery_result', $result );
            $meta_results['_gbcmg_attempt_detail'] = $this->upsert_lp_user_itemmeta( $user_item_id, '_gbcmg_attempt_detail', $attempt_detail );
            $meta_results['_gbcmg_attempt_history'] = $this->append_lp_user_itemmeta_history( $user_item_id, '_gbcmg_attempt_history', $attempt_detail );
            $this->log_event( 'mastery_attempt_detail_stored', $user_id, $map, array(
                'user_item_id'              => $user_item_id,
                'storage'                   => 'learnpress_curriculum_bank_item',
                'itemmeta_item_id_column'   => $this->lp_user_itemmeta_item_id_column(),
                'checked_count'             => count( $checked ),
                'question_detail_present'   => ! empty( $checked ),
                'meta_write_results'        => $meta_results,
                'user_meta_detail_key'      => $user_meta_detail_key,
                'user_meta_history_key'     => $user_meta_history_key,
            ) );
        }
        return $user_item_id;
    }

    private function is_course_curriculum_item( $course_id, $item_id ) {
        $item_id = absint( $item_id );
        if ( ! $course_id || ! $item_id ) {
            return false;
        }
        foreach ( $this->get_course_items( $course_id ) as $item ) {
            if ( absint( $item['item_id'] ?? 0 ) === $item_id ) {
                return true;
            }
        }
        return false;
    }

    private function purge_internal_bank_lp_item_rows( $user_id, $course_id, $bank_ids ) {
        global $wpdb;
        $user_id   = absint( $user_id );
        $course_id = absint( $course_id );
        $bank_ids  = array_values( array_unique( array_filter( array_map( 'absint', (array) $bank_ids ) ) ) );
        if ( ! $user_id || ! $course_id || empty( $bank_ids ) ) {
            return array();
        }

        $internal_bank_ids = array();
        foreach ( $bank_ids as $bank_id ) {
            if ( $bank_id && ! $this->is_course_curriculum_item( $course_id, $bank_id ) ) {
                $internal_bank_ids[] = $bank_id;
            }
        }
        if ( empty( $internal_bank_ids ) ) {
            return array();
        }

        $ui = $wpdb->prefix . 'learnpress_user_items';
        if ( ! $this->table_exists( $ui ) ) {
            return array();
        }
        $cols = $this->table_columns( $ui );
        if ( ! in_array( 'user_item_id', $cols, true ) || ! in_array( 'user_id', $cols, true ) || ! in_array( 'item_id', $cols, true ) ) {
            return array();
        }

        $where = array( 'user_id = %d' );
        $args  = array( $user_id );
        if ( in_array( 'ref_id', $cols, true ) ) {
            $where[] = 'ref_id = %d';
            $args[]  = $course_id;
        }
        if ( in_array( 'ref_type', $cols, true ) ) {
            $where[] = 'ref_type = %s';
            $args[]  = 'lp_course';
        }
        if ( in_array( 'item_type', $cols, true ) ) {
            $where[] = 'item_type = %s';
            $args[]  = 'lp_quiz';
        }
        $placeholders = implode( ',', array_fill( 0, count( $internal_bank_ids ), '%d' ) );
        $where[] = "item_id IN ({$placeholders})";
        $args = array_merge( $args, $internal_bank_ids );

        $sql = "SELECT user_item_id, item_id FROM {$ui} WHERE " . implode( ' AND ', $where );
        $rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
        if ( empty( $rows ) ) {
            return array();
        }

        $user_item_ids = array_values( array_unique( array_filter( array_map( 'absint', wp_list_pluck( $rows, 'user_item_id' ) ) ) ) );
        if ( empty( $user_item_ids ) ) {
            return array();
        }

        $deleted_meta = 0;
        $uim = $wpdb->prefix . 'learnpress_user_itemmeta';
        if ( $this->table_exists( $uim ) ) {
            $uim_col = $this->lp_user_itemmeta_item_id_column();
            if ( $uim_col ) {
                $in = implode( ',', array_fill( 0, count( $user_item_ids ), '%d' ) );
                $deleted_meta = absint( $wpdb->query( $wpdb->prepare( "DELETE FROM {$uim} WHERE {$uim_col} IN ({$in})", $user_item_ids ) ) );
            }
        }

        $in = implode( ',', array_fill( 0, count( $user_item_ids ), '%d' ) );
        $deleted_items = absint( $wpdb->query( $wpdb->prepare( "DELETE FROM {$ui} WHERE user_item_id IN ({$in})", $user_item_ids ) ) );

        return array(
            'bank_ids'       => $internal_bank_ids,
            'user_item_ids'  => $user_item_ids,
            'deleted_items'  => $deleted_items,
            'deleted_meta'   => $deleted_meta,
        );
    }

    private function mark_lp_course_item_completed( $user_id, $course_id, $item_id, $passed = true ) {
        global $wpdb;
        $user_id   = absint( $user_id );
        $course_id = absint( $course_id );
        $item_id   = absint( $item_id );
        if ( ! $user_id || ! $course_id || ! $item_id ) {
            return 0;
        }
        $item_type = get_post_type( $item_id );
        if ( ! in_array( $item_type, array( 'lp_lesson', 'lp_quiz' ), true ) ) {
            return 0;
        }

        $table = $wpdb->prefix . 'learnpress_user_items';
        if ( ! $this->table_exists( $table ) ) {
            return 0;
        }
        $cols = $this->table_columns( $table );
        if ( ! in_array( 'user_id', $cols, true ) || ! in_array( 'item_id', $cols, true ) ) {
            return 0;
        }

        $existing = $this->get_lp_item_state( $user_id, $course_id, $item_id );
        $user_item_id = absint( $existing['user_item_id'] ?? 0 );
        $now = current_time( 'mysql', true );
        $data = array();
        foreach ( array( 'user_id' => $user_id, 'item_id' => $item_id, 'item_type' => $item_type, 'ref_id' => $course_id, 'ref_type' => 'lp_course' ) as $col => $val ) {
            if ( in_array( $col, $cols, true ) ) {
                $data[ $col ] = $val;
            }
        }
        if ( in_array( 'status', $cols, true ) ) {
            $data['status'] = 'completed';
        }
        if ( in_array( 'graduation', $cols, true ) ) {
            $data['graduation'] = $passed ? 'passed' : 'failed';
        }
        if ( in_array( 'access_level', $cols, true ) ) {
            $data['access_level'] = 50;
        }
        foreach ( array( 'end_time', 'graduation_time', 'update_time', 'updated_at' ) as $tc ) {
            if ( in_array( $tc, $cols, true ) ) {
                $data[ $tc ] = $now;
            }
        }
        if ( ! $user_item_id ) {
            foreach ( array( 'start_time', 'created_at' ) as $tc ) {
                if ( in_array( $tc, $cols, true ) ) {
                    $data[ $tc ] = $now;
                }
            }
            if ( in_array( 'parent_id', $cols, true ) ) {
                $data['parent_id'] = $this->find_course_user_item_id( $user_id, $course_id );
            }
        }

        if ( $user_item_id && in_array( 'user_item_id', $cols, true ) ) {
            $wpdb->update( $table, $data, array( 'user_item_id' => $user_item_id ) );
        } else {
            $wpdb->insert( $table, $data );
            $user_item_id = absint( $wpdb->insert_id );
        }

        if ( $user_item_id ) {
            $this->upsert_lp_user_itemmeta( $user_item_id, '_gbcmg_trigger_completed', array(
                'completed_by' => 'gulf_breeze_course_mastery_gate',
                'completed_at' => $now,
            ) );
        }

        return $user_item_id;
    }

    private function get_lp_item_state( $user_id, $course_id, $item_id ) {
        global $wpdb;
        $table = $wpdb->prefix . 'learnpress_user_items';
        $out = array( 'user_item_id' => 0 );
        if ( ! $this->table_exists( $table ) ) { return $out; }
        $cols = $this->table_columns( $table );
        $where = array( 'user_id = %d', 'item_id = %d' );
        $args = array( absint( $user_id ), absint( $item_id ) );
        if ( in_array( 'ref_id', $cols, true ) ) {
            $where[] = 'ref_id = %d';
            $args[] = absint( $course_id );
        }
        $sql = "SELECT * FROM {$table} WHERE " . implode( ' AND ', $where ) . " ORDER BY user_item_id DESC LIMIT 10";
        $rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
        if ( empty( $rows ) ) { return $out; }

        foreach ( (array) $rows as $row ) {
            $status     = isset( $row['status'] ) ? strtolower( (string) $row['status'] ) : '';
            $graduation = isset( $row['graduation'] ) ? strtolower( (string) $row['graduation'] ) : '';
            if ( in_array( $status, array( 'completed', 'finished', 'passed' ), true ) || in_array( $graduation, array( 'passed', 'completed' ), true ) ) {
                return $row;
            }
        }

        return is_array( $rows[0] ) ? $rows[0] : $out;
    }

    private function find_course_user_item_id( $user_id, $course_id ) {
        global $wpdb;
        $table = $wpdb->prefix . 'learnpress_user_items';
        if ( ! $this->table_exists( $table ) ) { return 0; }
        $cols = $this->table_columns( $table );
        if ( ! in_array( 'user_id', $cols, true ) || ! in_array( 'item_id', $cols, true ) ) { return 0; }
        return absint( $wpdb->get_var( $wpdb->prepare( "SELECT user_item_id FROM {$table} WHERE user_id = %d AND item_id = %d ORDER BY user_item_id DESC LIMIT 1", absint( $user_id ), absint( $course_id ) ) ) );
    }

    private function lp_user_itemmeta_item_id_column() {
        global $wpdb;
        $table = $wpdb->prefix . 'learnpress_user_itemmeta';
        if ( ! $this->table_exists( $table ) ) { return ''; }
        $cols = $this->table_columns( $table );

        // LearnPress installs most commonly use learnpress_user_item_id, but
        // some migrations/forks have used user_item_id. v0.1.11 detects this
        // instead of silently failing storage on sites with the alternate name.
        if ( in_array( 'learnpress_user_item_id', $cols, true ) ) { return 'learnpress_user_item_id'; }
        if ( in_array( 'user_item_id', $cols, true ) ) { return 'user_item_id'; }
        return '';
    }

    private function upsert_lp_user_itemmeta( $user_item_id, $meta_key, $meta_value ) {
        global $wpdb;
        $table = $wpdb->prefix . 'learnpress_user_itemmeta';
        if ( ! $this->table_exists( $table ) ) { return false; }
        $item_col = $this->lp_user_itemmeta_item_id_column();
        if ( ! $item_col ) { return false; }

        $user_item_id = absint( $user_item_id );
        $meta_key = (string) $meta_key;
        $existing_id = $wpdb->get_var( $wpdb->prepare( "SELECT meta_id FROM {$table} WHERE `{$item_col}` = %d AND meta_key = %s LIMIT 1", $user_item_id, $meta_key ) );
        $value = maybe_serialize( $meta_value );
        if ( $existing_id ) {
            $ok = $wpdb->update( $table, array( 'meta_value' => $value ), array( 'meta_id' => absint( $existing_id ) ) );
            return ( false !== $ok );
        }

        $ok = $wpdb->insert( $table, array(
            $item_col => $user_item_id,
            'meta_key' => $meta_key,
            'meta_value' => $value,
        ) );
        return ( false !== $ok );
    }

    private function append_lp_user_itemmeta_history( $user_item_id, $meta_key, $entry ) {
        global $wpdb;
        $table = $wpdb->prefix . 'learnpress_user_itemmeta';
        if ( ! $this->table_exists( $table ) ) { return false; }
        $item_col = $this->lp_user_itemmeta_item_id_column();
        if ( ! $item_col ) { return false; }

        $user_item_id = absint( $user_item_id );
        $meta_key = (string) $meta_key;
        $existing = $wpdb->get_var( $wpdb->prepare( "SELECT meta_value FROM {$table} WHERE `{$item_col}` = %d AND meta_key = %s LIMIT 1", $user_item_id, $meta_key ) );
        $history = array();
        if ( null !== $existing && '' !== $existing ) {
            $maybe = maybe_unserialize( $existing );
            if ( is_array( $maybe ) ) {
                $history = $maybe;
            }
        }
        $history[] = $entry;
        // v0.1.12: retain full mastery attempt history for inspection records.
        return $this->upsert_lp_user_itemmeta( $user_item_id, $meta_key, $history );
    }

    private function table_exists( $table ) {
        global $wpdb;
        $like = $wpdb->esc_like( $table );
        return ( $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) ) );
    }

    private function table_columns( $table ) {
        global $wpdb;
        if ( isset( $this->table_cols_cache[ $table ] ) ) { return $this->table_cols_cache[ $table ]; }
        $cols = array();
        if ( $this->table_exists( $table ) ) {
            $rows = $wpdb->get_results( "SHOW COLUMNS FROM {$table}", ARRAY_A );
            foreach ( (array) $rows as $row ) {
                if ( ! empty( $row['Field'] ) ) { $cols[] = $row['Field']; }
            }
        }
        $this->table_cols_cache[ $table ] = $cols;
        return $cols;
    }

    private function current_url() {
        $scheme = is_ssl() ? 'https://' : 'http://';
        $host = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : parse_url( home_url(), PHP_URL_HOST );
        $uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
        return esc_url_raw( $scheme . $host . $uri );
    }

    private function get_report_timezone() {
        return new DateTimeZone( 'America/Chicago' );
    }

    private function report_local_date_to_utc( $date, $end_of_day = false ) {
        $date = (string) $date;
        if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) { return ''; }
        $time = $end_of_day ? '23:59:59' : '00:00:00';
        try {
            $dt = new DateTimeImmutable( $date . ' ' . $time, $this->get_report_timezone() );
            return $dt->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
        } catch ( Exception $e ) {
            return $date . ' ' . $time;
        }
    }

    private function filter_inspection_events( $events, $user_id = 0, $course_id = 0, $from = '', $to = '' ) {
        $events = is_array( $events ) ? $events : array();
        $user_id = absint( $user_id );
        $course_id = absint( $course_id );
        $from_utc = $this->report_local_date_to_utc( $from, false );
        $to_utc = $this->report_local_date_to_utc( $to, true );
        $out = array();
        foreach ( $events as $event ) {
            if ( ! is_array( $event ) ) { continue; }
            if ( $user_id && absint( $event['user_id'] ?? 0 ) !== $user_id ) { continue; }
            if ( $course_id && absint( $event['course_id'] ?? 0 ) !== $course_id ) { continue; }
            $time = (string) ( $event['time'] ?? '' );
            if ( $from_utc && $time && strcmp( $time, $from_utc ) < 0 ) { continue; }
            if ( $to_utc && $time && strcmp( $time, $to_utc ) > 0 ) { continue; }
            $out[] = $event;
        }
        return array_reverse( $out );
    }

    private function log_event( $event, $user_id, $map, $details = array() ) {
        $events = get_option( self::OPTION_EVENTS, array() );
        if ( ! is_array( $events ) ) { $events = array(); }
        $details = is_array( $details ) ? $details : array();
        $details = array_merge( array(
            'audit_utc'       => gmdate( 'Y-m-d H:i:s' ),
            'student_user_id' => absint( $user_id ),
            'course_id'       => absint( $map['course_id'] ?? 0 ),
            'unit_type'       => sanitize_key( $map['unit_type'] ?? '' ),
            'unit_number'     => absint( $map['unit_number'] ?? 0 ),
            'bank_quiz_id'    => absint( $map['bank_quiz_id'] ?? 0 ),
            'second_bank_quiz_id' => absint( $map['second_bank_quiz_id'] ?? 0 ),
        ), $details );
        $events[] = array(
            'time'         => gmdate( 'Y-m-d H:i:s' ),
            'event'        => sanitize_key( $event ),
            'user_id'      => absint( $user_id ),
            'course_id'    => absint( $map['course_id'] ?? 0 ),
            'bank_quiz_id' => absint( $map['bank_quiz_id'] ?? 0 ),
            'map_id'       => $this->mapping_id( $map ),
            'details'      => $details,
        );
        if ( count( $events ) > 1000 ) {
            $events = array_slice( $events, -1000 );
        }
        update_option( self::OPTION_EVENTS, $events, false );
    }

    public function footer_gate_script() {
        if ( is_admin() || ! is_user_logged_in() ) { return; }
        $ctx = $this->detect_context();
        if ( empty( $ctx['course_id'] ) ) { return; }
        if ( ! $this->user_has_lp_course_record( get_current_user_id(), absint( $ctx['course_id'] ) ) ) { return; }
        $maps = $this->get_active_mappings_for_course( absint( $ctx['course_id'] ) );
        $payload = array();
        foreach ( $maps as $map ) {
            if ( 'bad' === ( $this->validate_mapping( $map )['status'] ?? '' ) ) { continue; }
            $bank = absint( $map['bank_quiz_id'] ?? 0 );
            $slug = get_post_field( 'post_name', $bank );
            if ( $slug ) {
                $payload[] = array( 'slug' => $slug, 'url' => $this->get_mastery_url( $map ) );
            }
        }
        if ( empty( $payload ) ) { return; }
        ?>
        <script>
        (function(){
            var maps = <?php echo wp_json_encode( $payload ); ?>;
            function rewrite(){
                document.querySelectorAll('a[href]').forEach(function(a){
                    var href = a.getAttribute('href') || '';
                    maps.forEach(function(m){
                        if (!m.slug) { return; }
                        try {
                            var path = new URL(href, window.location.origin).pathname;
                            path = path.replace(/\/+$/, '') + '/';
                            var marker = '/quizzes/' + m.slug + '/';
                            if (path.indexOf(marker) !== -1) {
                                a.setAttribute('href', m.url);
                            }
                        } catch(e) {}
                    });
                });
            }
            rewrite();
            new MutationObserver(rewrite).observe(document.documentElement,{childList:true,subtree:true});
        })();
        </script>
        <?php
    }
}

register_activation_hook( __FILE__, array( 'GulfBreeze_Course_Mastery_Gate', 'activate' ) );
add_action( 'plugins_loaded', array( 'GulfBreeze_Course_Mastery_Gate', 'instance' ) );
