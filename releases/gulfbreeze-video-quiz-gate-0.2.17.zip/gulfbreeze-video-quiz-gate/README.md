# GulfBreeze Video Quiz Gate v0.2.33

## v0.2.33

- Replaces the WordPress Plugins-screen description with a concise statement of the plugin's actual purpose.
- No gate logic, mappings, student progress, validation behavior, audit data, or reconciliation behavior was changed.



## v0.2.32 — Active-course strict mode and retired-course closeout

This release carries forward all v0.2.31 repairs for course #7301 and adds two hard-separated policies.

### Active strict courses

Courses `7301`, `6772`, and `7391` use strict verified-attempt handling:

- No automatic grandfather pass can be created.
- A genuine passing question record plus a verified LearnPress completed/passed row is required.
- If a genuine stored passing attempt exists but its LearnPress row is missing, the plugin may rebuild the row automatically, verifies it immediately, and rolls the new row back if recognition fails.
- A private pass with no attempt and no LearnPress row stops on the controlled review page instead of redirecting in a loop.
- Existing **Require Quiz**, **Rebuild From Verified Attempt**, and individual **Documented Administrator Exemption** actions remain available.

### Retired legacy courses

Courses `1641` and `1410` use a separate administrator-controlled closeout tool:

- Installation and activation change no student.
- The preview is read-only.
- A record is eligible only when the required video is verified complete, no scored video-check attempt exists, no LearnPress quiz row exists, and a genuine completed course item is verified after the gate.
- Only checked eligible records are changed.
- The action creates a completed/exempted LearnPress sequence row, preserves all existing progress, backs up the pre-repair evidence, and stores the exact later completed item used to support the decision.
- The front-office evidence note reads **Documented retired-course legacy exemption — no scored attempt** and includes the supporting later progress, administrator, timestamp, reason, course/gate IDs, mapping fingerprint, policy version, and backup reference.
- Students with no verified later completion are not batch-exempted; they remain for a quiz or individual review.
- The retired-course tool rejects active course IDs even if a form request is altered.

### Front-office workflow only

The plugin does not transmit or upload records to TDLR. It prepares accurate stored evidence for Drive Smart to review and provide to the front office for certificate processing.

### Preserved v0.2.31 states

- Johanna Juarez #780 remains **Quiz required by administrator** until she actually passes quiz #8006.
- Cymone Williams #745 remains a **Documented administrator exemption** with her existing LearnPress completion row.
- Existing gate mappings remain in `gbvqg_gates`.
- Seat-time enforcement, the Complete-button timer, MFA, Course Mastery Gate, and the video Next/Continue guard are unchanged.



## v0.2.31 — Safe grandfather mismatch repair and audit

This release addresses the verified Johanna Juarez Avalos failure pattern:

- Video Quiz Gate private state said the Signs check was passed/grandfathered.
- No scored validation attempt existed.
- No LearnPress completion row existed for quiz #8006.
- Sequential Drip therefore kept Hour 3 locked and the two plugins created a redirect loop.

### Safety behavior

- Activation changes no student, quiz, gate mapping, seat-time record, or LearnPress row.
- Existing gate mappings remain in the same `gbvqg_gates` option.
- Both automatic grandfather-creation paths were removed. Course position alone can no longer create a private pass.
- A private pass/grandfather flag without a verified attempt, LearnPress completion, or documented manual exemption is classified as an **Unverified legacy grandfather mismatch**.
- The mismatch is sent to a controlled review page instead of bouncing between the quiz and next lesson.
- Existing later course progress is detected read-only and held for administrator review rather than automatically grandfathered or reset.
- A correct answer is not treated as fully passed until LearnPress immediately confirms both completed and passed. If that confirmation fails, the answer evidence is retained for a targeted rebuild and the next lesson is not falsely unlocked.

### Admin tools

The new **Gate State Mismatch Audit & Targeted Repair** card provides:

1. Read-only analysis for one student and one gate.
2. A read-only audit of saved current-student Video Quiz Gate states.
3. **Require This Quiz** — clears only the selected student's unsupported private pass/grandfather values and stores a persistent quiz-required marker. It does not alter the completed video, prior lessons, timer records, or other students.
4. **Rebuild From Verified Attempt** — available only when real passing question evidence exists and no LearnPress quiz row exists.
5. **Grant Documented Exemption** — an explicit administrator action requiring a written reason. It records an exemption, not a scored quiz attempt, and refuses to overwrite an existing LearnPress quiz row.

Every repair creates a per-student backup and audit event before changing the selected state. Read-only analysis and audit create no student changes.

### Johanna procedure

1. Install v0.2.31 as a replacement for the existing plugin.
2. Open **Video Quiz Gate → Gate State Mismatch Audit & Targeted Repair**.
3. Enter Student User ID `780`.
4. Select **Module 1 Signs — Course #7301 / Quiz #8006**.
5. Confirm the classification is **Unverified legacy grandfather mismatch**.
6. Click **Require This Quiz**.
7. Johanna may return at any later time. Her completed Signs video remains saved, and the required Signs video-check questions will open normally.
8. After she answers correctly, the plugin requires immediate LearnPress completed/passed recognition before Hour 3 is treated as unlocked.

Do not use Course Progress Fix for Johanna before she takes the required Signs quiz.


## v0.2.30 — Verified navigation and progress diagnostics

- Preserves the existing `gbvqg_gates` option and all saved gate mappings.
- Verifies server-side video completion before routing an AJAX-created Next/Continue button to the custom video check.
- Records the LearnPress quiz rows before and after the custom pass/fail write, the database result/error, and what LearnPress recognizes.
- Records a next-item progress probe before Sequential Drip can redirect a student, so a stuck student can be inspected before Course Progress Fix changes the evidence.
- Adds an explicit Remove checkbox for deleting accidental gate mappings such as Course ID 1.
- Does not automatically run the uncertain post-pass repair; it preserves evidence for the next real failure.

This is a targeted patch over v0.2.9.

## What v0.2.9 changed

v0.2.9 stops relying on the LearnPress quiz renderer for video-check questions. The mapped LearnPress quiz is used as the question bank, while the plugin provides its own one-question validation screen.

## What v0.2.10 fixes

v0.2.9 could still allow a later gate's native LearnPress quiz page to display when an earlier gate in the same course had already been passed. The loop stopped after Gate 1 returned `allow`, so Gate 2 never got a chance to intercept its own quiz page.

v0.2.10 keeps evaluating later gates when an earlier gate simply returns a neutral `allow` decision. This lets Gate 2 intercept Video 2 / Quiz 2 correctly and route the student to the plugin-controlled validation question page instead of the native LearnPress quiz screen.

## Expected event log after this patch

When the student clicks Next from the video or lands on the mapped LearnPress quiz page, Recent Gate Events should show entries such as:

- `redirect_lp_quiz_to_custom_validation`
- `redirect_later_item_to_required_quiz`
- `validation_question_selected`
- `validation_answer_correct`
- `validation_answer_wrong`

If the student still sees the LearnPress native page with `Question 1 of 4`, then the current item is not being detected and the next step is to log the detected request path/current item on template redirect.

## Installation

Upload/install the ZIP as the same `gulfbreeze-video-quiz-gate` plugin folder, or replace the existing plugin file with `gulfbreeze-video-quiz-gate.php`.


## v0.2.11

Patch release for the custom validation-page route introduced in v0.2.9.

### Fixed
- Corrected the front-end JavaScript redirect URL escaping bug where `&` could become `&#038;` inside `window.location.href`.
- Added a self-healing fallback for old malformed validation URLs like:
  `?gbvqg_validation=1&#038;gbvqg_gate=...`
- Keeps the v0.2.9/v0.2.10 custom validation approach:
  the mapped LearnPress quiz is used as the question bank, but the student sees the plugin-controlled one-question validation page instead of the native LearnPress 4-question quiz renderer.

### Why this mattered
The broken escaped URL caused the student to land on:

`Video Check Unavailable — This video-check gate is not active or could not be found.`

because PHP received `gbvqg_validation=1` but not the `gbvqg_gate` value.


## v0.2.12

Patch release for the custom validation question page.

### Fixed
- The one-question validation form now posts back to the same front-end validation URL instead of `wp-admin/admin-post.php`.
- Course item redirects are hardened so a pass/wrong result should route to the mapped next item or video lesson, not the website homepage.
- Added `validation_submit_received` event logging so submit attempts are visible in Recent Gate Events.
- Added a note on the validation page: refreshing the page intentionally keeps the same selected question for the current attempt.

### Expected behavior
- Refreshing the validation page does **not** select a new question. That prevents a student from refreshing until they get an easier question.
- A new rotated question is selected after the student submits a wrong answer and is sent back to rewatch the video.


## v0.2.13

Student-facing wording update for the custom validation page.

### Changed
- Replaced the legal/admin-sounding validation-page text with friendlier student wording.
- Kept the compliance behavior unchanged:
  - one question only
  - no correct-answer reveal
  - refresh keeps the same question for the current attempt
  - wrong answer returns the student to the video
  - next attempt receives a different question


## v0.2.14

Inspector-friendly audit enhancement.

### Added
- Recent Gate Events now includes dedicated columns for:
  - UTC timestamp
  - student user ID
  - course ID
  - video lesson ID
  - quiz bank ID
  - question ID selected
  - submitted answer choice
  - whether the answer was correct or incorrect
  - whether the student was returned to the video
  - attempt / rewatch cycle
- Event details now preserve richer audit data for validation question selection and submission.
- Wrong-answer events explicitly log `returned_to_video: true` and the redirect target.
- Question-selection events identify when the next question was selected after a required rewatch.

### Unchanged
- One question is administered per video-check attempt.
- The question bank still comes from the mapped LearnPress quiz.
- A wrong answer returns the student to the video.
- The next attempt rotates to a different question until the bank is exhausted.
- Correct answers are not shown to the student.


## v0.2.15

Adds a printable Student Inspection Report section.

### Added
- New **Student Inspection Report** card on the Video Quiz Gate admin page.
- Filters by student user ID, course ID, and optional UTC date range.
- Print button that prints only the inspection report area.
- Report header includes:
  - generated UTC timestamp
  - generated-by admin
  - student user ID
  - student name
  - student email
  - course ID/title
  - date range
  - total matching events
- Report table includes:
  - UTC timestamp
  - event
  - student user ID
  - course ID
  - video lesson ID
  - quiz bank ID
  - question ID selected
  - submitted answer choice
  - correct / incorrect
  - returned to video
  - attempt / rewatch cycle

### Unchanged
- The student-facing Quick Video Check flow remains the same as v0.2.13/v0.2.14.


## v0.2.16

Inspection report date-range fix.

### Fixed
- The Student Inspection Report date fields are now treated as site-local calendar dates and converted to UTC before matching stored event timestamps.
- This prevents evening Texas/site-time events from being excluded simply because the stored UTC timestamp falls on the next UTC date.
- The printed report now shows both:
  - the selected site-date range
  - the UTC window actually used for matching

### Example
If an event happens Monday evening in Texas but is stored as Tuesday UTC, selecting Monday in the report date range will still include the event.


## v0.2.17

Inspection report timezone correction for Drive Smart.

### Fixed
- Student Inspection Report date fields now use Texas/Central business dates (`America/Chicago`) instead of relying on the WordPress site timezone.
- This matters because the staging site reported its WordPress timezone as `+00:00`, so events stored at `2026-04-28 02:xx UTC` were excluded when filtering for the Texas business date `2026-04-27`.
- The printed report now clearly shows:
  - selected Texas/Central business date range
  - UTC window used for matching
  - current WordPress site timezone for awareness

### Example
A validation event that occurs on April 27 in Texas but is stored as April 28 UTC will be included when the report date range is April 27.

## v0.2.19

Student-facing result screen improvement.

### Changed
- After submitting a video-check answer, students now see a clear pass/fail result page instead of being silently redirected.
- The result page shows the score percentage and how many questions were answered correctly.
- Failed attempts explain why the student must return to the video before retaking the check.
- Correct answers are still not shown.


## v0.2.19

- Adds forward-only/grandfather behavior for existing or in-progress students.
- If a student is already beyond a mapped video-check quiz, has completed the video lesson, and has no GulfBreeze gate state or validation-quiz record, the gate is automatically marked passed/grandfathered.
- New students who reach the video/validation step after activation still follow the gate normally.

## v0.2.21

Production admin hardening only. Student-side gate behavior is unchanged.

### Added
- Automatic backup of `gbvqg_gates` before every save.
- Restore Last Backup button.
- Export Gate Settings JSON button.
- Course Health Summary at the top of the admin page.
- Clean course sections collapse by default; sections with invalid gates open automatically.
- Invalid rows are visually louder.
- Each gate now displays the expected next curriculum item after the video versus the mapped quiz bank.

### Not changed
- Front-end validation flow.
- Question rotation/selection.
- Pass/fail handling.
- Student audit event structure.

## v0.2.22

Patch release for revisiting already-passed video-check bank quizzes.

### Fixed
- After a student passes the plugin-controlled video validation, direct access to the mapped LearnPress bank quiz now redirects forward to the next curriculum item instead of showing the native LearnPress quiz/result screen.
- This prevents the confusing native LearnPress `0% / Failed / 0 of 0` display that could appear when a student went back to a video and clicked Next again after already passing the video check.
- Existing plugin pass state remains authoritative; a later native LearnPress bank/result-page visit will not downgrade a previously passed video gate to failed.

### Unchanged
- Student validation behavior is unchanged for new attempts.
- Wrong answers still return the student to the video according to the configured failure behavior.
- Admin settings, gate mappings, audit logs, export/restore tools, and inspection reports are unchanged.


## v0.2.23

Patch release for legacy / already-in-progress students who were already past a newly mapped video gate before the Video Quiz Gate plugin created its own per-gate state.

### Fixed
- Allows grandfathering when the only existing GBVQG state is sequence-only state, such as `sequence_started_at` and `sequence_details`.
- Sequence-only state is not treated as a real quiz attempt, failure, pass, or rewatch cycle.
- Prevents older students from being forced backward to a newly added video-check question when they had already completed the video and were already past the mapped video-check quiz.
- Improves LearnPress lesson completion detection when duplicate lesson rows exist. For lessons only, the plugin now checks recent LearnPress user-item rows and prefers the newest completed/passed row instead of allowing a newer blank/started duplicate row to hide the completed record.
- Keeps existing protection for actual attempts: submitted validation attempts, failures, passes, rewatch state, and already-grandfathered state still prevent this legacy bypass path.

### Why this mattered
An older student could complete the video before the gate existed, revisit the video or a later course item after the gate was activated, and receive only a sequence marker in GBVQG state. Earlier versions required the state to be completely empty before grandfathering, so the sequence marker could block the grandfather rule and strand the student behind a new gate.

### Testing target
After installing on staging, test with an older adult-course student who is already past Water Safety / SB 30 video gates. The expected event is:

- `gate_grandfathered_existing_video_completion`

The student should be allowed to continue forward instead of seeing a locked/enroll/native LearnPress quiz screen.

## v0.2.26
- Tightens course-context matching so a video gate only fires when the current course is known and exactly matches the gate row course ID.
- If course context cannot be resolved, the plugin now skips enforcement instead of relying on curriculum membership alone.
- This hardens against cross-course bleed where a configured Teen/Classroom gate could affect an unconfigured Adult course page.

## v0.2.25

Patch release for legacy / already-in-progress students who still hit a protected/enroll screen after v0.2.23/v0.2.24-style grandfather handling.

### Fixed
- Adds URL path-aware course detection. When the current LearnPress URL contains `/courses/{course-slug}/...`, the plugin now prefers that course ID instead of guessing from shared/reused lesson or quiz IDs.
- Adds an enrollment-record safety check before enforcing a gate. If the current user does not have a LearnPress course record for the gate's course, GBVQG skips that gate instead of redirecting the student into an unenrolled course/quiz path.
- Adds later-progress grandfather protection. If a student completed the video lesson and already has completed course items after the mapped video-check quiz, the gate is marked passed/grandfathered before redirecting to the source bank or validation page.
- Later-progress grandfathering does not override a real custom validation attempt. If the student actually submitted a plugin-controlled video-check answer and failed it, the normal rewatch/retake path remains intact.

### New events
- `gate_grandfathered_existing_later_progress`
- `skip_gate_no_course_enrollment_record`


## v0.2.29

Retry rotation patch for failed video-validation attempts.

### Fixed
- A failed video-check retake no longer reuses the exact same question/order when a fresh draw is possible.
- The attempt-specific question pool is now used even when the configured `Show` count equals the full bank size.
- If the full bank must be shown, the retake order is reshuffled/rotated so it does not repeat the exact same order from the prior failed attempt.
- Refreshing the same attempt remains stable because the picked question pool is still stored by attempt number.

### Unchanged
- Student pass/fail rules.
- Return-to-video / rewatch behavior.
- All-attempt history storage from v0.2.28.
- Grade Book reporting integration.
