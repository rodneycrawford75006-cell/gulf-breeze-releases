# Gulf Breeze Core

Permanent modular foundation for the Gulf Breeze course and compliance system.

Version 1.8.0 adds a read-only Adult English timer audit covering all 46 lesson records and the exact 330-minute instructional ledger. The audit reports required and installed timer metadata, LearnPress course attachment, duplicate or missing records, content status, topic totals, overall totals, curriculum migration status, and a nonce-protected administrator CSV export.

The release does not change student timer records, course content, lesson completion, public visibility, licensing data, or Under Construction protection.

Missing legal or business configuration values remain blank. Sensitive credentials and payment secrets do not belong in this plugin or its public release package.
