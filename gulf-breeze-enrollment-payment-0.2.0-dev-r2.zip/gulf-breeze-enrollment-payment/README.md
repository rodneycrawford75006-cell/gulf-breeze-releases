# Gulf Breeze Enrollment & Payment 0.2.0-dev-r2

Architectural reset based on a proven native WooCommerce checkout boundary.

## Transaction ownership

- WooCommerce owns the cart, checkout form, order creation, PayPal handoff, and confirmation URL.
- PayPal Payments owns button placement and gateway behavior through its settings.
- This plugin renders and validates the bilingual agreement inside classic WooCommerce checkout.
- The plugin assumes payment responsibility by removing the Catalog plugin's known development-stage payment locks after both plugins load; it does not change catalog mappings or cart data.
- The agreement snapshot is written atomically to the WooCommerce order. There is no separate agreement-page redirect, reusable contract cookie, checkout URL filter, cart initialization, or PayPal-location filter.
- Student account creation and LearnPress enrollment occur only after WooCommerce confirms payment.
- Full refunds and payment reversals revoke course access but retain the user and order records, allowing a later repurchase with the same email.

## Student account and email correction

- A paid order is linked to the student WordPress/WooCommerce account before ordinary processing/completed emails render.
- The administrator new-order email identifies the student separately from the purchaser and reports account/enrollment state.
- The purchaser receipt includes the student login email and a signed-agreement copy.
- The student receives a separate bilingual onboarding email with a secure one-time **Create my password** link, course information, login location, and signed-agreement copy.
- A self-purchasing student also receives a **Create my password** button on the native WooCommerce confirmation page. The button requires the valid paid order key and a server-signed request; no old password is required.
- The plugin records whether WordPress mail accepted or rejected the onboarding message. Delivery still requires a correctly configured site mailer.
- Duplicate payment callbacks cannot send duplicate onboarding messages.

## Protected-site test method

Keep Under Construction enabled. Use the already-whitelisted `Gulf Breeze Test Student` only as the protected-site access shell, then enter a completely new student email in checkout. The order is deliberately kept unassigned until verified payment, so the access-shell account does not become the course owner. After payment, the fresh student account is created, the order is linked to it, and the password-creation flow can be tested without pre-creating or whitelisting that student.

## Deliberately deferred

MFA is not part of this checkpoint. It will be attached only after the native contract-to-payment path passes one protected-site Sandbox purchase. This keeps identity security downstream from payment instead of coupling it to checkout.

## Required site configuration before purchase testing

- WooCommerce Checkout page uses `[woocommerce_checkout]`.
- WooCommerce PayPal Payments Sandbox mode is enabled.
- PayPal button locations are limited to Checkout; Cart, Mini Cart, Product, and Express placements are disabled.
- Under Construction remains enabled.
- A dependable WordPress mailer must be configured before email-delivery acceptance testing. The current site default mail transport is not a delivery guarantee.
