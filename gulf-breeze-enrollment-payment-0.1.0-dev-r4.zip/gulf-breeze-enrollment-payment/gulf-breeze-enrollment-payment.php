<?php
/**
 * Plugin Name: Gulf Breeze Enrollment & Payment
 * Description: Contract-first bilingual enrollment, PayPal Sandbox verification, paid-only LearnPress access, MFA, refund controls, and private order diagnostics for Gulf Breeze Driving School.
 * Version: 0.1.0-dev-r4
 * Author: Gulf Breeze Driving School / Rodney Crawford
 * Text Domain: gulf-breeze-enrollment-payment
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Gulf_Breeze_Enrollment_Payment {
	const VERSION = '0.1.0-dev-r4';
	const SCHEMA_VERSION = '1.0';
	const CONTRACT_VERSION = 'DEV-0.1.0';
	const COOKIE = 'gb_ep_contract';
	const CONTRACT_PAGE_OPTION = 'gb_ep_contract_page_id';
	const MFA_PAGE_OPTION = 'gb_ep_mfa_page_id';
	const CHECKOUT_MODE_OPTION = 'gb_ep_checkout_mode';
	const META_CONTRACT_ID = '_gb_ep_contract_id';
	const META_STATE = '_gb_ep_state';
	const META_LOCALE = '_gb_ep_locale';
	const META_COURSE_ID = '_gb_ep_course_id';
	const META_STUDENT_USER_ID = '_gb_ep_student_user_id';
	const META_CAPTURE_ID = '_gb_ep_paypal_capture_id';
	const META_PROCESSED = '_gb_ep_enrollment_processed';
	const META_REVOKED = '_gb_ep_access_revoked';
	const USER_MFA_SECRET = '_gb_ep_mfa_secret';
	const USER_MFA_RECOVERY = '_gb_ep_mfa_recovery';
	const USER_MFA_ENROLLED = '_gb_ep_mfa_enrolled';
	const USER_MFA_SESSION = '_gb_ep_mfa_session_until';
	const USER_REVOKED_COURSES = '_gb_ep_revoked_courses';

	private static $instance;

	public static function instance() {
		if ( ! self::$instance ) { self::$instance = new self(); }
		return self::$instance;
	}

	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'dependencies' ) );
		add_action( 'plugins_loaded', array( $this, 'take_checkout_control' ), 20 );
		add_action( 'init', array( __CLASS__, 'enforce_classic_checkout_page' ), 20 );
		add_shortcode( 'gb_enrollment_contract', array( $this, 'contract_shortcode' ) );
		add_shortcode( 'gb_mfa_setup', array( $this, 'mfa_shortcode' ) );
		add_action( 'admin_post_gb_ep_contract', array( $this, 'save_contract' ) );
		add_action( 'admin_post_nopriv_gb_ep_contract', array( $this, 'save_contract' ) );
		add_action( 'template_redirect', array( $this, 'handle_frontend_contract_submission' ), 1 );
		add_action( 'admin_post_gb_ep_mfa', array( $this, 'save_mfa' ) );
		add_action( 'admin_post_gb_ep_mfa_reset', array( $this, 'admin_reset_mfa' ) );
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'validate_checkout' ), 5, 2 );
		add_action( 'woocommerce_checkout_create_order', array( $this, 'attach_contract' ), 5, 2 );
		add_action( 'woocommerce_checkout_order_created', array( $this, 'bind_contract_order' ), 5 );
		add_filter( 'woocommerce_available_payment_gateways', array( $this, 'paypal_only' ), PHP_INT_MAX );
		add_filter( 'woocommerce_paypal_payments_gateway_title', array( $this, 'payment_title' ), 20, 2 );
		add_filter( 'woocommerce_paypal_payments_pay_later_messaging_enabled', '__return_false', PHP_INT_MAX );
		add_filter( 'woocommerce_paypal_payments_pay_later_enabled', '__return_false', PHP_INT_MAX );
		add_action( 'woocommerce_payment_complete', array( $this, 'process_verified_payment' ), 20 );
		add_action( 'woocommerce_order_status_processing', array( $this, 'process_verified_payment' ), 20 );
		add_action( 'woocommerce_order_status_completed', array( $this, 'process_verified_payment' ), 20 );
		add_action( 'woocommerce_order_status_refunded', array( $this, 'revoke_full_refund' ), 10 );
		add_action( 'woocommerce_order_status_cancelled', array( $this, 'record_nonpaid_state' ), 10 );
		add_action( 'woocommerce_order_status_failed', array( $this, 'record_nonpaid_state' ), 10 );
		add_action( 'woocommerce_order_refunded', array( $this, 'handle_refund' ), 10, 2 );
		add_action( 'template_redirect', array( $this, 'enforce_mfa_and_revocation' ), 3 );
		add_action( 'admin_menu', array( $this, 'admin_menu' ), 40 );
		add_action( 'rest_api_init', array( $this, 'rest_routes' ) );
		add_filter( 'rest_pre_dispatch', array( $this, 'block_store_api_checkout' ), 5, 3 );
		add_filter( 'render_block', array( $this, 'remove_express_checkout_blocks' ), 5, 2 );
		add_filter( 'woocommerce_get_checkout_url', array( $this, 'contract_first_checkout_url' ), 50 );
		add_action( 'template_redirect', array( $this, 'redirect_unsigned_checkout' ), 4 );
		add_action( 'wp_enqueue_scripts', array( $this, 'assets' ) );
	}

	private static function provision_page( $option, $slug, $title, $shortcode ) {
		$page_id = absint( get_option( $option ) );
		$page = $page_id ? get_post( $page_id ) : null;
		if ( ! $page || 'page' !== $page->post_type || 'trash' === $page->post_status ) { $page = get_page_by_path( $slug, OBJECT, 'page' ); }
		if ( $page && 'trash' !== $page->post_status ) { $page_id = absint( $page->ID ); }
		else {
			$page_id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $slug, 'post_title' => $title, 'post_content' => $shortcode ), true );
			if ( is_wp_error( $page_id ) ) { return 0; }
		}
		if ( ! has_shortcode( (string) get_post_field( 'post_content', $page_id ), trim( $shortcode, '[]' ) ) ) { wp_update_post( array( 'ID' => $page_id, 'post_content' => $shortcode ) ); }
		update_option( $option, absint( $page_id ), false );
		return absint( $page_id );
	}

	public static function activate() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$contracts = $wpdb->prefix . 'gb_ep_contracts';
		$events = $wpdb->prefix . 'gb_ep_events';
		dbDelta( "CREATE TABLE {$contracts} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			token_hash CHAR(64) NOT NULL,
			status VARCHAR(32) NOT NULL DEFAULT 'signed_unpaid',
			locale VARCHAR(8) NOT NULL,
			product_id BIGINT UNSIGNED NOT NULL,
			course_id BIGINT UNSIGNED NOT NULL,
			order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			student_email_hash CHAR(64) NOT NULL,
			snapshot LONGTEXT NOT NULL,
			snapshot_hash CHAR(64) NOT NULL,
			signed_at_utc DATETIME NOT NULL,
			created_at_utc DATETIME NOT NULL,
			PRIMARY KEY (id), UNIQUE KEY token_hash (token_hash), KEY order_id (order_id), KEY status (status), KEY student_email_hash (student_email_hash)
		) {$charset};" );
		dbDelta( "CREATE TABLE {$events} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			contract_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			event_type VARCHAR(64) NOT NULL,
			result VARCHAR(24) NOT NULL,
			details LONGTEXT NULL,
			created_at_utc DATETIME NOT NULL,
			PRIMARY KEY (id), KEY order_id (order_id), KEY contract_id (contract_id), KEY event_type (event_type), KEY created_at_utc (created_at_utc)
		) {$charset};" );
		add_option( 'gb_ep_environment', 'sandbox', '', false );
		add_option( 'gb_ep_schema_version', self::SCHEMA_VERSION, '', false );
		self::provision_page( self::CONTRACT_PAGE_OPTION, 'enrollment-agreement', 'Enrollment Agreement / Contrato de inscripción', '[gb_enrollment_contract]' );
		self::provision_page( self::MFA_PAGE_OPTION, 'mfa-setup', 'Account Security / Seguridad de la cuenta', '[gb_mfa_setup]' );
		self::enforce_classic_checkout_page();
	}

	public static function enforce_classic_checkout_page() {
		if ( 'sandbox' !== get_option( 'gb_ep_environment', 'sandbox' ) || ! function_exists( 'wc_get_page_id' ) ) { return false; }
		$page_id = absint( wc_get_page_id( 'checkout' ) );
		if ( ! $page_id || 'trash' === get_post_status( $page_id ) ) { return false; }
		$content = (string) get_post_field( 'post_content', $page_id );
		if ( has_shortcode( $content, 'woocommerce_checkout' ) ) {
			update_option( self::CHECKOUT_MODE_OPTION, 'classic-r4:' . $page_id, false );
			return true;
		}
		if ( ! has_block( 'woocommerce/checkout', $content ) ) { return false; }
		$updated = wp_update_post( array( 'ID' => $page_id, 'post_content' => '[woocommerce_checkout]' ), true );
		if ( is_wp_error( $updated ) ) { return false; }
		update_option( self::CHECKOUT_MODE_OPTION, 'classic-r4:' . $page_id, false );
		return true;
	}

	public function dependencies() {
		if ( is_admin() && ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'gb_core_provider_profile' ) ) ) {
			add_action( 'admin_notices', function() {
				echo '<div class="notice notice-error"><p><strong>Gulf Breeze Enrollment &amp; Payment:</strong> WooCommerce and Gulf Breeze Core 2.3.26 or newer are required.</p></div>';
			} );
		}
	}

	public function take_checkout_control() {
		if ( ! class_exists( 'Gulf_Breeze_Catalog_Cart' ) || 'sandbox' !== get_option( 'gb_ep_environment', 'sandbox' ) ) { return; }
		$catalog = Gulf_Breeze_Catalog_Cart::instance();
		remove_action( 'template_redirect', array( $catalog, 'block_checkout_stage' ), 2 );
		remove_action( 'wp_loaded', array( $catalog, 'block_payment_ajax' ), -999 );
		remove_action( 'woocommerce_checkout_process', array( $catalog, 'reject_locked_checkout' ) );
		remove_action( 'woocommerce_after_checkout_validation', array( $catalog, 'reject_locked_checkout_validation' ), 10 );
		remove_filter( 'woocommerce_available_payment_gateways', array( $catalog, 'disable_payment_gateways' ), PHP_INT_MAX );
		remove_filter( 'woocommerce_cart_needs_payment', array( $catalog, 'disable_cart_payment_requirement' ), PHP_INT_MAX );
		remove_filter( 'rest_pre_dispatch', array( $catalog, 'block_store_api_checkout' ), 10 );
		remove_filter( 'render_block', array( $catalog, 'render_checkout_lock' ), 20 );
		remove_action( 'wp_head', array( $catalog, 'checkout_lock_styles' ), 99 );
		remove_action( 'wp_footer', array( $catalog, 'checkout_lock_script' ), 99 );
	}

	public function block_store_api_checkout( $result, $server, $request ) {
		$route = method_exists( $request, 'get_route' ) ? $request->get_route() : '';
		if ( false !== strpos( $route, '/wc/store/' ) && false !== strpos( $route, '/checkout' ) ) {
			return new WP_Error( 'gb_ep_classic_contract_required', 'Please continue through the Gulf Breeze signed enrollment agreement.', array( 'status' => 403 ) );
		}
		return $result;
	}

	public function remove_express_checkout_blocks( $content, $block ) {
		if ( 'sandbox' !== get_option( 'gb_ep_environment', 'sandbox' ) || ! $this->current_cart_item() ) { return $content; }
		$name = sanitize_text_field( $block['blockName'] ?? '' );
		if ( in_array( $name, array( 'woocommerce/checkout-express-payment-block', 'woocommerce/cart-express-payment-block' ), true ) ) { return ''; }
		return $content;
	}

	private function contract_page_url() {
		$page_id = absint( get_option( self::CONTRACT_PAGE_OPTION ) );
		return $page_id && 'publish' === get_post_status( $page_id ) ? get_permalink( $page_id ) : home_url( '/enrollment-agreement/' );
	}

	public function contract_first_checkout_url( $url ) {
		if ( $this->current_contract() ) { return $url; }
		return $this->current_cart_item() ? $this->contract_page_url() : $url;
	}

	public function redirect_unsigned_checkout() {
		if ( is_admin() || ! function_exists( 'is_checkout' ) || ! is_checkout() || ( function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( 'order-received' ) ) || $this->current_contract() || ! $this->current_cart_item() ) { return; }
		wp_safe_redirect( $this->contract_page_url() );
		exit;
	}

	private function t( $locale, $en, $es ) { return 'es-US' === $locale ? $es : $en; }
	private function now() { return gmdate( 'Y-m-d H:i:s' ); }
	private function contracts_table() { global $wpdb; return $wpdb->prefix . 'gb_ep_contracts'; }
	private function events_table() { global $wpdb; return $wpdb->prefix . 'gb_ep_events'; }

	private function locale() {
		$locale = isset( $_COOKIE['gb_enrollment_locale'] ) ? sanitize_text_field( wp_unslash( $_COOKIE['gb_enrollment_locale'] ) ) : 'en-US';
		return in_array( $locale, array( 'en-US', 'es-US' ), true ) ? $locale : 'en-US';
	}

	private function ensure_woocommerce_cart() {
		if ( ! function_exists( 'WC' ) || ! WC() ) { return false; }
		try {
			if ( ! WC()->session && method_exists( WC(), 'initialize_session' ) ) { WC()->initialize_session(); }
			if ( ! WC()->customer && class_exists( 'WC_Customer' ) ) { WC()->customer = new WC_Customer( get_current_user_id(), true ); }
			if ( ! WC()->cart && method_exists( WC(), 'initialize_cart' ) ) { WC()->initialize_cart(); }
		} catch ( Throwable $error ) { return false; }
		return WC()->session && WC()->cart;
	}

	private function current_cart_item() {
		if ( ! $this->ensure_woocommerce_cart() ) { return false; }
		$items = WC()->cart->get_cart();
		if ( 1 !== count( $items ) ) { return false; }
		$item = reset( $items );
		$product_id = absint( $item['product_id'] ?? 0 );
		$course_id = absint( get_post_meta( $product_id, '_gb_learnpress_course_id', true ) );
		$catalog_key = sanitize_key( get_post_meta( $product_id, '_gb_catalog_key', true ) );
		$locale = sanitize_text_field( get_post_meta( $product_id, '_gb_enrollment_locale', true ) );
		if ( ! $product_id || ! $course_id || ! $catalog_key || ! in_array( $locale, array( 'en-US', 'es-US' ), true ) ) { return false; }
		return array( 'item' => $item, 'product_id' => $product_id, 'course_id' => $course_id, 'catalog_key' => $catalog_key, 'locale' => $locale );
	}

	public function contract_shortcode() {
		$cart = $this->current_cart_item();
		$locale = $cart ? $cart['locale'] : $this->locale();
		if ( ! $cart ) { return '<div class="gb-ep-message" role="alert">' . esc_html( $this->t( $locale, 'Choose exactly one mapped course before starting enrollment.', 'Seleccione exactamente un curso asignado antes de comenzar la inscripción.' ) ) . '</div>'; }
		$product = wc_get_product( $cart['product_id'] );
		$profile = function_exists( 'gb_core_provider_profile' ) ? gb_core_provider_profile() : array();
		$action = esc_url( get_permalink( get_queried_object_id() ) ?: $this->contract_page_url() );
		ob_start(); ?>
		<section class="gb-ep" lang="<?php echo 'es-US' === $locale ? 'es' : 'en'; ?>">
			<div class="gb-ep-banner">DEVELOPMENT / SAMPLE DATA · PAYPAL SANDBOX</div>
			<h2><?php echo esc_html( $this->t( $locale, 'Enrollment agreement — before payment', 'Contrato de inscripción — antes del pago' ) ); ?></h2>
			<ol class="gb-ep-steps"><li><?php echo esc_html( $this->t( $locale, 'Student', 'Estudiante' ) ); ?></li><li><?php echo esc_html( $this->t( $locale, 'Purchaser', 'Comprador' ) ); ?></li><li><?php echo esc_html( $this->t( $locale, 'Agreement', 'Contrato' ) ); ?></li><li><?php echo esc_html( $this->t( $locale, 'PayPal Sandbox', 'PayPal Sandbox' ) ); ?></li></ol>
			<div class="gb-ep-summary"><strong><?php echo esc_html( $product->get_name() ); ?></strong><br><?php echo wp_kses_post( $product->get_price_html() ); ?><br><?php echo esc_html( $profile['public_name'] ?? 'Gulf Breeze Driving School' ); ?></div>
			<form method="post" action="<?php echo $action; ?>" class="gb-ep-form">
				<input type="hidden" name="gb_ep_contract_submit" value="1"><input type="hidden" name="product_id" value="<?php echo esc_attr( $cart['product_id'] ); ?>"><input type="hidden" name="locale" value="<?php echo esc_attr( $locale ); ?>">
				<?php wp_nonce_field( 'gb_ep_contract', 'gb_ep_nonce' ); ?>
				<fieldset><legend><?php echo esc_html( $this->t( $locale, 'Student information', 'Información del estudiante' ) ); ?></legend>
				<label><?php echo esc_html( $this->t( $locale, 'Student legal name', 'Nombre legal del estudiante' ) ); ?><input required name="student_name" autocomplete="name"></label>
				<label><?php echo esc_html( $this->t( $locale, 'Student email', 'Correo electrónico del estudiante' ) ); ?><input required type="email" name="student_email" autocomplete="email"></label>
				<label><?php echo esc_html( $this->t( $locale, 'Date of birth', 'Fecha de nacimiento' ) ); ?><input required type="date" name="student_dob"></label></fieldset>
				<fieldset><legend><?php echo esc_html( $this->t( $locale, 'Purchaser or parent/guardian', 'Comprador o padre/madre/tutor' ) ); ?></legend>
				<label><?php echo esc_html( $this->t( $locale, 'Purchaser legal name', 'Nombre legal del comprador' ) ); ?><input required name="purchaser_name" autocomplete="billing name"></label>
				<label><?php echo esc_html( $this->t( $locale, 'Purchaser email', 'Correo electrónico del comprador' ) ); ?><input required type="email" name="purchaser_email" autocomplete="billing email"></label>
				<label><input type="checkbox" name="purchaser_is_student" value="1"> <?php echo esc_html( $this->t( $locale, 'The purchaser is the student', 'El comprador es el estudiante' ) ); ?></label></fieldset>
				<fieldset><legend><?php echo esc_html( $this->t( $locale, 'Electronic signatures', 'Firmas electrónicas' ) ); ?></legend>
				<div class="gb-ep-contract-text"><?php echo wp_kses_post( $this->contract_text( $locale, $profile, $product ) ); ?></div>
				<label><?php echo esc_html( $this->t( $locale, 'Student signature — type the legal name', 'Firma del estudiante — escriba el nombre legal' ) ); ?><input required name="student_signature"></label>
				<label><?php echo esc_html( $this->t( $locale, 'Parent/guardian signature when the student is under 18', 'Firma del padre, madre o tutor cuando el estudiante es menor de 18 años' ) ); ?><input name="guardian_signature"></label>
				<label><input required type="checkbox" name="consent" value="1"> <?php echo esc_html( $this->t( $locale, 'I consent to use electronic records and signatures and confirm the information is accurate.', 'Acepto el uso de registros y firmas electrónicas y confirmo que la información es correcta.' ) ); ?></label></fieldset>
				<button type="submit"><?php echo esc_html( $this->t( $locale, 'Sign agreement and continue to payment', 'Firmar el contrato y continuar al pago' ) ); ?></button>
			</form>
		</section><?php
		return ob_get_clean();
	}

	public function handle_frontend_contract_submission() {
		if ( 'POST' === strtoupper( sanitize_text_field( $_SERVER['REQUEST_METHOD'] ?? '' ) ) && ! empty( $_POST['gb_ep_contract_submit'] ) ) { $this->save_contract(); }
	}

	private function contract_text( $locale, $profile, $product ) {
		$name = esc_html( $profile['legal_name'] ?? '' );
		$provider = esc_html( $profile['provider_number'] ?? '' );
		$phone = esc_html( $profile['phone'] ?? '' );
		$email = esc_html( $profile['support_email'] ?? '' );
		$course = esc_html( $product->get_name() );
		$price = wp_kses_post( $product->get_price_html() );
		$complaint = esc_html( 'es-US' === $locale ? ( $profile['tdlr_complaint_text_es'] ?? '' ) : ( $profile['tdlr_complaint_text_en'] ?? '' ) );
		if ( 'es-US' === $locale ) {
			return "<p><strong>{$name}</strong> · Proveedor {$provider} · {$phone} · {$email}</p><p>Curso: <strong>{$course}</strong>. Precio total actual: {$price}. La identidad del curso, su idioma, el precio y la asignación a LearnPress provienen del catálogo autorizado y quedan guardados en la copia firmada.</p><p>Este contrato se firma antes del pago. El acceso solo se concede después de que el servidor confirme la captura de PayPal Sandbox. El estudiante debe completar personalmente la instrucción, los tiempos, las verificaciones de identidad y las evaluaciones. La finalización depende de cumplir todos los requisitos del curso; no se promete una licencia ni un certificado antes de cumplirlos.</p><p>Se incorporan las versiones vigentes de las políticas de cancelación/reembolso, privacidad y quejas. Un reembolso total, contracargo o reversión elimina el acceso al curso afectado, pero los registros obligatorios se conservan para fines administrativos y de cumplimiento. Aviso de quejas: {$complaint}</p><p>Al firmar, el estudiante y, cuando corresponda, el padre, madre o tutor confirman que revisaron el curso, el precio, el idioma, las obligaciones, la política de reembolso, el procedimiento de quejas, el uso de registros electrónicos y la exactitud de la información proporcionada.</p>";
		}
		return "<p><strong>{$name}</strong> · Provider {$provider} · {$phone} · {$email}</p><p>Course: <strong>{$course}</strong>. Current total price: {$price}. The course identity, language, price, and LearnPress mapping come from the authorized catalog and are frozen in the signed copy.</p><p>This agreement is signed before payment. Access is granted only after the server confirms the PayPal Sandbox capture. The student must personally complete the instruction, required time, identity checks, and assessments. Completion depends on satisfying every course requirement; no license or certificate is promised before completion.</p><p>The current cancellation/refund, privacy, and grievance policies are incorporated. A full refund, chargeback, or reversal removes access to the affected course while required administrative and compliance records are retained. Complaint notice: {$complaint}</p><p>By signing, the student and, when applicable, parent or guardian confirm they reviewed the course, price, language, obligations, refund policy, grievance process, electronic-record consent, and accuracy of the information supplied.</p>";
	}

	public function save_contract() {
		if ( ! isset( $_POST['gb_ep_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['gb_ep_nonce'] ) ), 'gb_ep_contract' ) ) { wp_die( 'Invalid enrollment request.', 403 ); }
		$cart = $this->current_cart_item();
		$product_id = absint( $_POST['product_id'] ?? 0 );
		if ( ! $cart || $product_id !== $cart['product_id'] ) { wp_die( 'The selected course changed. Return to the catalog and try again.', 400 ); }
		$locale = $cart['locale'];
		$student_name = sanitize_text_field( wp_unslash( $_POST['student_name'] ?? '' ) );
		$student_email = sanitize_email( wp_unslash( $_POST['student_email'] ?? '' ) );
		$student_dob = sanitize_text_field( wp_unslash( $_POST['student_dob'] ?? '' ) );
		$purchaser_name = sanitize_text_field( wp_unslash( $_POST['purchaser_name'] ?? '' ) );
		$purchaser_email = sanitize_email( wp_unslash( $_POST['purchaser_email'] ?? '' ) );
		$student_signature = sanitize_text_field( wp_unslash( $_POST['student_signature'] ?? '' ) );
		$guardian_signature = sanitize_text_field( wp_unslash( $_POST['guardian_signature'] ?? '' ) );
		$dob = DateTime::createFromFormat( 'Y-m-d', $student_dob, new DateTimeZone( 'UTC' ) );
		$age = $dob ? $dob->diff( new DateTime( 'now', new DateTimeZone( 'UTC' ) ) )->y : -1;
		if ( ! $student_name || ! is_email( $student_email ) || ! $purchaser_name || ! is_email( $purchaser_email ) || ! $dob || $student_signature !== $student_name || ( $age < 18 && ! $guardian_signature ) || empty( $_POST['consent'] ) ) {
			wp_die( esc_html( $this->t( $locale, 'The agreement is incomplete. Check every required field and make sure the student signature exactly matches the legal name.', 'El contrato está incompleto. Revise todos los campos obligatorios y asegúrese de que la firma del estudiante coincida exactamente con su nombre legal.' ) ), 400 );
		}
		$product = wc_get_product( $product_id );
		$profile = gb_core_provider_profile();
		$snapshot = array(
			'schema_version' => self::SCHEMA_VERSION, 'contract_version' => (string) ( $profile['contract_version'] ?? self::CONTRACT_VERSION ), 'locale' => $locale,
			'provider_profile' => $profile, 'provider_profile_hash' => (string) ( $profile['profile_hash'] ?? '' ),
			'catalog' => array( 'catalog_key' => $cart['catalog_key'], 'product_id' => $product_id, 'course_id' => $cart['course_id'], 'course_name' => $product->get_name(), 'price' => wc_format_decimal( $product->get_price(), 2 ), 'currency' => get_woocommerce_currency() ),
			'student' => array( 'legal_name' => $student_name, 'email' => $student_email, 'dob' => $student_dob ),
			'purchaser' => array( 'legal_name' => $purchaser_name, 'email' => $purchaser_email, 'is_student' => ! empty( $_POST['purchaser_is_student'] ) ),
			'signatures' => array( 'student' => $student_signature, 'guardian' => $guardian_signature, 'provider' => (string) ( $profile['certificate_signer_name'] ?? '' ) ),
			'terms_html' => $this->contract_text( $locale, $profile, $product ),
			'evidence' => array( 'signed_at_utc' => gmdate( 'c' ), 'ip_hash' => hash_hmac( 'sha256', sanitize_text_field( $_SERVER['REMOTE_ADDR'] ?? '' ), wp_salt( 'auth' ) ), 'user_agent_hash' => hash( 'sha256', sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ?? '' ) ) ),
		);
		$json = wp_json_encode( $snapshot, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		$hash = hash( 'sha256', $json );
		$token = bin2hex( random_bytes( 32 ) );
		global $wpdb;
		$wpdb->insert( $this->contracts_table(), array( 'token_hash' => hash( 'sha256', $token ), 'status' => 'signed_unpaid', 'locale' => $locale, 'product_id' => $product_id, 'course_id' => $cart['course_id'], 'student_email_hash' => hash( 'sha256', strtolower( $student_email ) ), 'snapshot' => $json, 'snapshot_hash' => $hash, 'signed_at_utc' => $this->now(), 'created_at_utc' => $this->now() ), array( '%s','%s','%s','%d','%d','%s','%s','%s','%s','%s' ) );
		$id = absint( $wpdb->insert_id );
		$this->audit( 'contract_signed', 'success', array( 'snapshot_hash' => $hash, 'locale' => $locale ), 0, $id );
		setcookie( self::COOKIE, $id . '.' . $token, array( 'expires' => time() + DAY_IN_SECONDS, 'path' => COOKIEPATH ?: '/', 'domain' => COOKIE_DOMAIN, 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax' ) );
		wp_safe_redirect( wc_get_checkout_url() ); exit;
	}

	private function current_contract() {
		$cookie = isset( $_COOKIE[ self::COOKIE ] ) ? sanitize_text_field( wp_unslash( $_COOKIE[ self::COOKIE ] ) ) : '';
		if ( ! preg_match( '/^(\d+)\.([a-f0-9]{64})$/', $cookie, $m ) ) { return false; }
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . $this->contracts_table() . ' WHERE id=%d AND token_hash=%s', absint( $m[1] ), hash( 'sha256', $m[2] ) ), ARRAY_A );
		return $row && 'signed_unpaid' === $row['status'] ? $row : false;
	}

	public function validate_checkout( $data, $errors ) {
		$contract = $this->current_contract(); $cart = $this->current_cart_item();
		if ( ! $contract || ! $cart || absint( $contract['product_id'] ) !== $cart['product_id'] || absint( $contract['course_id'] ) !== $cart['course_id'] ) {
			$errors->add( 'gb_ep_contract', $this->t( $cart['locale'] ?? $this->locale(), 'Complete and sign the enrollment agreement before payment.', 'Complete y firme el contrato de inscripción antes del pago.' ) );
		}
	}

	public function attach_contract( $order, $data ) {
		$contract = $this->current_contract(); if ( ! $contract ) { throw new Exception( 'Enrollment agreement required.' ); }
		$snapshot = json_decode( $contract['snapshot'], true );
		$order->update_meta_data( self::META_CONTRACT_ID, absint( $contract['id'] ) );
		$order->update_meta_data( self::META_STATE, 'signed_awaiting_payment' );
		$order->update_meta_data( self::META_LOCALE, $contract['locale'] );
		$order->update_meta_data( self::META_COURSE_ID, absint( $contract['course_id'] ) );
		$order->update_meta_data( '_gb_ep_snapshot_hash', $contract['snapshot_hash'] );
		$order->set_billing_email( sanitize_email( $snapshot['purchaser']['email'] ?? '' ) );
	}

	public function bind_contract_order( $order ) {
		$contract_id = absint( $order->get_meta( self::META_CONTRACT_ID ) );
		if ( ! $contract_id ) { return; }
		global $wpdb;
		$wpdb->update( $this->contracts_table(), array( 'order_id' => $order->get_id(), 'status' => 'order_created_unpaid' ), array( 'id' => $contract_id, 'order_id' => 0 ), array( '%d','%s' ), array( '%d','%d' ) );
		$this->audit( 'order_created', 'unpaid', array( 'payment_method' => $order->get_payment_method() ), $order->get_id(), $contract_id );
	}

	public function paypal_only( $gateways ) {
		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) { return $gateways; }
		$allowed = array( 'ppcp-gateway', 'ppcp-credit-card-gateway' );
		foreach ( array_keys( $gateways ) as $id ) { if ( ! in_array( $id, $allowed, true ) ) { unset( $gateways[ $id ] ); } }
		return $gateways;
	}

	public function payment_title( $title, $gateway ) { return false !== stripos( $title, 'later' ) ? 'PayPal' : $title; }

	private function verified_payment( $order, $contract ) {
		if ( ! $order || ! $order->is_paid() || 'sandbox' !== get_option( 'gb_ep_environment', 'sandbox' ) ) { return new WP_Error( 'not_paid', 'Payment is not a verified Sandbox capture.' ); }
		if ( ! in_array( $order->get_payment_method(), array( 'ppcp-gateway', 'ppcp-credit-card-gateway' ), true ) ) { return new WP_Error( 'gateway', 'Only PayPal Sandbox payment methods are accepted.' ); }
		$transaction = sanitize_text_field( $order->get_transaction_id() );
		if ( ! $transaction ) { return new WP_Error( 'capture', 'The PayPal capture reference is missing.' ); }
		$snapshot = json_decode( $contract['snapshot'], true );
		if ( ! hash_equals( $contract['snapshot_hash'], hash( 'sha256', $contract['snapshot'] ) ) || $order->get_currency() !== ( $snapshot['catalog']['currency'] ?? '' ) || abs( (float) $order->get_total() - (float) ( $snapshot['catalog']['price'] ?? -1 ) ) > 0.009 ) { return new WP_Error( 'mismatch', 'The signed course, amount, currency, or snapshot does not match.' ); }
		return $transaction;
	}

	private function enroll_learnpress_course( $user_id, $course_id, $order_id ) {
		if ( ! class_exists( '\\LearnPress\\Models\\UserItems\\UserCourseModel' ) || ! defined( 'LP_COURSE_CPT' ) ) { return false; }
		try {
			$model_class = '\\LearnPress\\Models\\UserItems\\UserCourseModel';
			$existing = $model_class::find( $user_id, $course_id, true );
			if ( $existing && method_exists( $existing, 'has_enrolled_or_finished' ) && $existing->has_enrolled_or_finished() ) { return true; }
			$user_course = new $model_class();
			$user_course->user_id = $user_id;
			$user_course->item_id = $course_id;
			$user_course->item_type = LP_COURSE_CPT;
			$user_course->status = 'enrolled';
			$user_course->graduation = 'in-progress';
			$user_course->ref_id = $order_id;
			$user_course->ref_type = 'woocommerce_order';
			$user_course->start_time = gmdate( 'Y-m-d H:i:s' );
			$user_course->save();
			return $user_course->get_user_item_id() > 0;
		} catch ( Throwable $error ) {
			return false;
		}
	}

	public function process_verified_payment( $order_id ) {
		$order = wc_get_order( $order_id ); if ( ! $order || 'yes' === $order->get_meta( self::META_PROCESSED ) ) { return; }
		$contract_id = absint( $order->get_meta( self::META_CONTRACT_ID ) ); if ( ! $contract_id ) { return; }
		global $wpdb; $contract = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . $this->contracts_table() . ' WHERE id=%d AND order_id=%d', $contract_id, $order_id ), ARRAY_A ); if ( ! $contract ) { return; }
		$verified = $this->verified_payment( $order, $contract );
		if ( is_wp_error( $verified ) ) { $order->update_meta_data( self::META_STATE, 'payment_verification_failed' ); $order->save(); $this->audit( 'payment_verification', 'failed', array( 'reason' => $verified->get_error_code() ), $order_id, $contract_id ); return; }
		$snapshot = json_decode( $contract['snapshot'], true );
		$email = sanitize_email( $snapshot['student']['email'] ?? '' );
		$user = get_user_by( 'email', $email ); $created = false;
		if ( ! $user ) { $password = wp_generate_password( 24, true ); $uid = wc_create_new_customer( $email, '', $password ); if ( is_wp_error( $uid ) ) { $this->audit( 'account', 'failed', array( 'reason' => $uid->get_error_code() ), $order_id, $contract_id ); return; } $user = get_user_by( 'id', $uid ); $created = true; }
		$user_id = absint( $user->ID ); $course_id = absint( $contract['course_id'] );
		update_user_meta( $user_id, 'gb_preferred_locale', $contract['locale'] );
		update_user_meta( $user_id, '_gb_ep_active_course_' . $course_id, $order_id );
		$active_courses = array_unique( array_merge( array_filter( array_map( 'absint', (array) get_user_meta( $user_id, '_gb_ep_active_courses', true ) ) ), array( $course_id ) ) );
		update_user_meta( $user_id, '_gb_ep_active_courses', $active_courses );
		update_user_meta( $user_id, '_gb_ep_account_state', 'active' );
		$revoked = array_filter( array_map( 'absint', (array) get_user_meta( $user_id, self::USER_REVOKED_COURSES, true ) ) );
		update_user_meta( $user_id, self::USER_REVOKED_COURSES, array_values( array_diff( $revoked, array( $course_id ) ) ) );
		$enrolled = $this->enroll_learnpress_course( $user_id, $course_id, $order_id );
		if ( ! $enrolled ) { update_user_meta( $user_id, '_gb_ep_account_state', 'dormant' ); $order->update_meta_data( self::META_STATE, 'learnpress_enrollment_failed' ); $order->save(); $this->audit( 'learnpress_enrollment', 'failed', array( 'course_id' => $course_id ), $order_id, $contract_id, $user_id ); return; }
		$order->update_meta_data( self::META_CAPTURE_ID, $verified ); $order->update_meta_data( self::META_STUDENT_USER_ID, $user_id ); $order->update_meta_data( self::META_PROCESSED, 'yes' ); $order->update_meta_data( self::META_STATE, 'paid_enrolled_mfa_required' ); $order->save();
		$wpdb->update( $this->contracts_table(), array( 'status' => 'paid_enrolled' ), array( 'id' => $contract_id ), array( '%s' ), array( '%d' ) );
		$this->audit( 'payment_and_enrollment', 'success', array( 'capture_hash' => hash( 'sha256', $verified ), 'course_id' => $course_id, 'account' => $created ? 'created' : 'linked' ), $order_id, $contract_id, $user_id );
		$this->send_notifications( $order, $snapshot, $user_id, $created );
	}

	private function send_notifications( $order, $snapshot, $user_id, $created ) {
		$locale = $snapshot['locale']; $student_email = sanitize_email( $snapshot['student']['email'] );
		$subject = $this->t( $locale, 'Your Gulf Breeze enrollment is ready', 'Su inscripción de Gulf Breeze está lista' );
		$body = $this->t( $locale, 'Payment was confirmed. Sign in, complete MFA, and then open your course. Your signed agreement reference is ', 'Se confirmó el pago. Inicie sesión, complete la verificación MFA y luego abra su curso. La referencia de su contrato firmado es ' ) . sanitize_text_field( $order->get_meta( '_gb_ep_snapshot_hash' ) ) . "\n\n" . wp_strip_all_tags( $snapshot['terms_html'] ?? '' ) . "\n\n" . $this->t( $locale, 'Student signature: ', 'Firma del estudiante: ' ) . sanitize_text_field( $snapshot['signatures']['student'] ?? '' ) . "\n" . $this->t( $locale, 'Signed at: ', 'Firmado el: ' ) . sanitize_text_field( $snapshot['evidence']['signed_at_utc'] ?? '' );
		wp_mail( $student_email, $subject, $body );
		$admin_body = 'Gulf Breeze enrollment processed. Order ' . $order->get_id() . '; student user ' . $user_id . '; account ' . ( $created ? 'created' : 'linked' ) . '; contract hash ' . sanitize_text_field( $order->get_meta( '_gb_ep_snapshot_hash' ) ) . '. View private Order Health for details.';
		wp_mail( get_option( 'admin_email' ), 'Gulf Breeze enrollment processed', $admin_body );
	}

	public function handle_refund( $order_id, $refund_id ) {
		$order = wc_get_order( $order_id ); if ( ! $order ) { return; }
		if ( (float) $order->get_remaining_refund_amount() <= 0.009 ) { $this->revoke_order_access( $order, 'full_refund', $refund_id ); }
		elseif ( apply_filters( 'gb_ep_partial_refund_cancels_enrollment', false, $order_id, $refund_id ) ) { $this->revoke_order_access( $order, 'partial_refund_admin_cancel', $refund_id ); }
		else { $this->audit( 'partial_refund', 'recorded_no_revocation', array( 'refund_id' => absint( $refund_id ) ), $order_id, absint( $order->get_meta( self::META_CONTRACT_ID ) ), absint( $order->get_meta( self::META_STUDENT_USER_ID ) ) ); }
	}

	public function revoke_full_refund( $order_id ) { $order = wc_get_order( $order_id ); if ( $order ) { $this->revoke_order_access( $order, 'full_refund', 0 ); } }
	public function record_nonpaid_state( $order_id ) { $order = wc_get_order( $order_id ); if ( $order ) { if ( 'yes' === $order->get_meta( self::META_PROCESSED ) ) { $this->revoke_order_access( $order, 'cancelled' === $order->get_status() ? 'payment_reversal' : 'chargeback_or_failed_capture', 0 ); } else { $this->audit( 'nonpaid_order', 'no_access', array( 'status' => $order->get_status() ), $order_id, absint( $order->get_meta( self::META_CONTRACT_ID ) ) ); } } }

	private function revoke_order_access( $order, $classification, $evidence_id ) {
		if ( 'yes' === $order->get_meta( self::META_REVOKED ) ) { return; }
		$user_id = absint( $order->get_meta( self::META_STUDENT_USER_ID ) ); $course_id = absint( $order->get_meta( self::META_COURSE_ID ) ); if ( ! $user_id || ! $course_id ) { return; }
		$revoked = array_unique( array_merge( array_filter( array_map( 'absint', (array) get_user_meta( $user_id, self::USER_REVOKED_COURSES, true ) ) ), array( $course_id ) ) ); update_user_meta( $user_id, self::USER_REVOKED_COURSES, $revoked ); delete_user_meta( $user_id, '_gb_ep_active_course_' . $course_id );
		$active_courses = array_values( array_diff( array_filter( array_map( 'absint', (array) get_user_meta( $user_id, '_gb_ep_active_courses', true ) ) ), array( $course_id ) ) ); update_user_meta( $user_id, '_gb_ep_active_courses', $active_courses ); if ( ! $active_courses ) { update_user_meta( $user_id, '_gb_ep_account_state', 'dormant' ); delete_user_meta( $user_id, self::USER_MFA_SESSION ); }
		if ( function_exists( 'learn_press_get_user' ) ) { $lp_user = learn_press_get_user( $user_id ); if ( $lp_user && method_exists( $lp_user, 'withdraw' ) ) { $lp_user->withdraw( $course_id ); } }
		$order->update_meta_data( self::META_REVOKED, 'yes' ); $order->update_meta_data( self::META_STATE, 'access_revoked_' . sanitize_key( $classification ) ); $order->save();
		$this->audit( 'access_revoked', 'success', array( 'classification' => $classification, 'evidence_id' => absint( $evidence_id ), 'course_id' => $course_id ), $order->get_id(), absint( $order->get_meta( self::META_CONTRACT_ID ) ), $user_id );
	}

	public function enforce_mfa_and_revocation() {
		if ( is_admin() || current_user_can( 'manage_options' ) || ! is_user_logged_in() || ! is_singular( array( 'lp_course','lp_lesson','lp_quiz' ) ) ) { return; }
		$user_id = get_current_user_id(); $object_id = get_queried_object_id(); $course_id = 'lp_course' === get_post_type( $object_id ) ? $object_id : absint( get_post_meta( $object_id, '_lp_course', true ) );
		$revoked = array_map( 'absint', (array) get_user_meta( $user_id, self::USER_REVOKED_COURSES, true ) );
		if ( in_array( $course_id, $revoked, true ) ) { wp_die( esc_html( $this->t( get_user_meta( $user_id, 'gb_preferred_locale', true ), 'This course is not currently available in your account. Contact student support for help.', 'Este curso no está disponible actualmente en su cuenta. Comuníquese con apoyo al estudiante para recibir ayuda.' ) ), 403 ); }
		if ( get_user_meta( $user_id, '_gb_ep_active_course_' . $course_id, true ) && time() > absint( get_user_meta( $user_id, self::USER_MFA_SESSION, true ) ) ) { $page = absint( get_option( self::MFA_PAGE_OPTION ) ); wp_safe_redirect( $page ? get_permalink( $page ) : home_url( '/mfa-setup/' ) ); exit; }
	}

	private function encrypt( $plain ) { $key = hash( 'sha256', wp_salt( 'auth' ), true ); $iv = random_bytes( 16 ); return base64_encode( $iv . openssl_encrypt( $plain, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv ) ); }
	private function decrypt( $encoded ) { $raw = base64_decode( $encoded, true ); if ( ! $raw || strlen( $raw ) < 17 ) { return ''; } $key = hash( 'sha256', wp_salt( 'auth' ), true ); return (string) openssl_decrypt( substr( $raw, 16 ), 'aes-256-cbc', $key, OPENSSL_RAW_DATA, substr( $raw, 0, 16 ) ); }
	private function base32_secret() { $alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $bytes=random_bytes(20); $bits=''; foreach(str_split($bytes) as $c){$bits.=str_pad(decbin(ord($c)),8,'0',STR_PAD_LEFT);} $out=''; foreach(str_split($bits,5) as $chunk){$out.=$alphabet[bindec(str_pad($chunk,5,'0'))];} return $out; }
	private function base32_decode( $secret ) { $alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $bits=''; foreach(str_split(strtoupper($secret)) as $c){$p=strpos($alphabet,$c); if(false===$p){return '';} $bits.=str_pad(decbin($p),5,'0',STR_PAD_LEFT);} $out=''; foreach(str_split($bits,8) as $chunk){if(strlen($chunk)===8){$out.=chr(bindec($chunk));}} return $out; }
	private function totp( $secret, $time = null ) { $counter=(int)floor(($time?:time())/30); $bin=pack('N*',0).pack('N*',$counter); $hash=hash_hmac('sha1',$bin,$this->base32_decode($secret),true); $offset=ord(substr($hash,-1))&15; $value=unpack('N',substr($hash,$offset,4))[1]&0x7fffffff; return str_pad((string)($value%1000000),6,'0',STR_PAD_LEFT); }
	private function verify_totp( $secret, $code ) { foreach(array(-1,0,1) as $w){if(hash_equals($this->totp($secret,time()+($w*30)),preg_replace('/\D/','',(string)$code))){return true;}} return false; }

	public function mfa_shortcode() {
		if ( ! is_user_logged_in() ) { return '<p>Please sign in to continue.</p>'; }
		$user_id=get_current_user_id(); $locale=get_user_meta($user_id,'gb_preferred_locale',true); if(!in_array($locale,array('en-US','es-US'),true)){$locale='en-US';} $enrolled=(bool)get_user_meta($user_id,self::USER_MFA_ENROLLED,true);
		$secret=$this->decrypt(get_user_meta($user_id,self::USER_MFA_SECRET,true)); if(!$secret){$secret=$this->base32_secret(); update_user_meta($user_id,self::USER_MFA_SECRET,$this->encrypt($secret));}
		$issuer=rawurlencode('Gulf Breeze Driving School'); $label=rawurlencode('Gulf Breeze:'.wp_get_current_user()->user_email); $uri="otpauth://totp/{$label}?secret=".rawurlencode($secret)."&issuer={$issuer}&digits=6&period=30";
		ob_start(); ?><section class="gb-ep gb-mfa" <?php echo $enrolled?'':'data-gb-mfa-uri="'.esc_attr($uri).'"'; ?> lang="<?php echo 'es-US'===$locale?'es':'en'; ?>"><h2><?php echo esc_html($this->t($locale,$enrolled?'Verify your identity':'Protect your course account',$enrolled?'Verifique su identidad':'Proteja su cuenta del curso')); ?></h2><?php if(!$enrolled): ?><ol class="gb-ep-steps"><li><?php echo esc_html($this->t($locale,'Choose a setup method','Elija un método')); ?></li><li><?php echo esc_html($this->t($locale,'Add Gulf Breeze','Agregue Gulf Breeze')); ?></li><li><?php echo esc_html($this->t($locale,'Enter the six-digit code','Ingrese el código de seis dígitos')); ?></li></ol><p><?php echo esc_html($this->t($locale,'If this page is open on a computer, scan the QR code with your authenticator app. If this page is on your phone, copy the manual key and paste it into the app. Never send this key by email or text.','Si esta página está abierta en una computadora, escanee el código QR con su aplicación de autenticación. Si está usando el teléfono, copie la clave manual y péguela en la aplicación. Nunca envíe esta clave por correo electrónico ni mensaje de texto.')); ?></p><div id="gb-mfa-qr" aria-label="MFA QR code"></div><div class="gb-mfa-key"><code id="gb-mfa-secret"><?php echo esc_html($secret); ?></code><button type="button" data-gb-copy><?php echo esc_html($this->t($locale,'Copy manual key','Copiar clave manual')); ?></button></div><?php endif; ?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="gb_ep_mfa"><?php wp_nonce_field('gb_ep_mfa','gb_ep_nonce'); ?><label><?php echo esc_html($this->t($locale,$enrolled?'Six-digit code or one recovery code':'Six-digit code',$enrolled?'Código de seis dígitos o un código de recuperación':'Código de seis dígitos')); ?><input name="code" inputmode="text" autocomplete="one-time-code" pattern="[A-Za-z0-9]{6,12}" maxlength="12" required></label><button type="submit"><?php echo esc_html($this->t($locale,'Verify and continue','Verificar y continuar')); ?></button></form><details><summary><?php echo esc_html($this->t($locale,'Code not working?','¿El código no funciona?')); ?></summary><p><?php echo esc_html($this->t($locale,'Turn on automatic date and time on your phone, wait for a new code, and try again. You may use one saved recovery code. Contact support for a secure reset if needed.','Active la fecha y hora automáticas en su teléfono, espere un código nuevo e inténtelo otra vez. Puede usar uno de sus códigos de recuperación guardados. Comuníquese con apoyo para un restablecimiento seguro si lo necesita.')); ?></p></details></section><?php return ob_get_clean();
	}

	public function save_mfa() {
		if(!is_user_logged_in()||!isset($_POST['gb_ep_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['gb_ep_nonce'])),'gb_ep_mfa')){wp_die('Invalid MFA request.',403);} $user_id=get_current_user_id(); $secret=$this->decrypt(get_user_meta($user_id,self::USER_MFA_SECRET,true)); $code=strtoupper(sanitize_text_field(wp_unslash($_POST['code']??''))); $valid=$secret&&$this->verify_totp($secret,$code);$recovery_used=false;$hashes=(array)get_user_meta($user_id,self::USER_MFA_RECOVERY,true);if(!$valid&&$hashes){foreach($hashes as $index=>$hash){if(wp_check_password($code,$hash)){$valid=true;$recovery_used=true;unset($hashes[$index]);update_user_meta($user_id,self::USER_MFA_RECOVERY,array_values($hashes));break;}}}if(!$valid){ $this->audit('mfa_verify','failed',array('reason'=>'invalid_or_expired_code'),0,0,$user_id); wp_die('That code could not be verified. Check automatic time and try a new code.',400); }
		$first=!get_user_meta($user_id,self::USER_MFA_ENROLLED,true);$codes=array();if($first){$hashes=array();for($i=0;$i<8;$i++){$c=strtoupper(wp_generate_password(10,false,false));$codes[]=$c;$hashes[]=wp_hash_password($c);}update_user_meta($user_id,self::USER_MFA_RECOVERY,$hashes);update_user_meta($user_id,self::USER_MFA_ENROLLED,$this->now());}update_user_meta($user_id,self::USER_MFA_SESSION,time()+12*HOUR_IN_SECONDS);$this->audit('mfa_verify','success',array('recovery_codes_issued'=>$first?8:0,'recovery_code_used'=>$recovery_used),0,0,$user_id); if($first){wp_die('<h1>MFA verified</h1><p>Save these one-time recovery codes in a secure place. They will not be shown again.</p><pre>'.esc_html(implode("\n",$codes)).'</pre><p><a href="'.esc_url(home_url('/my-account/')).'">Continue</a></p>','MFA verified',array('response'=>200));}wp_safe_redirect(home_url('/my-account/'));exit;
	}

	public function admin_reset_mfa() { if(!current_user_can('manage_options')){wp_die('Access denied.',403);} check_admin_referer('gb_ep_mfa_reset');$user_id=absint($_POST['user_id']??0);$reason=sanitize_textarea_field(wp_unslash($_POST['reason']??''));if(!$user_id||strlen($reason)<10){wp_die('A private reason of at least 10 characters is required.',400);}delete_user_meta($user_id,self::USER_MFA_SECRET);delete_user_meta($user_id,self::USER_MFA_RECOVERY);delete_user_meta($user_id,self::USER_MFA_ENROLLED);delete_user_meta($user_id,self::USER_MFA_SESSION);$this->audit('mfa_admin_reset','success',array('reason'=>$reason,'admin_user_id'=>get_current_user_id()),0,0,$user_id);wp_safe_redirect(wp_get_referer()?:admin_url());exit; }

	public function assets() { if ( has_shortcode( get_post_field( 'post_content', get_queried_object_id() ), 'gb_enrollment_contract' ) || has_shortcode( get_post_field( 'post_content', get_queried_object_id() ), 'gb_mfa_setup' ) ) { wp_enqueue_style('gb-ep',plugins_url('assets/enrollment.css',__FILE__),array(),self::VERSION);wp_enqueue_script('gb-ep-qr',plugins_url('assets/qr-bundle.js',__FILE__),array(),self::VERSION,true);wp_enqueue_script('gb-ep',plugins_url('assets/enrollment.js',__FILE__),array('gb-ep-qr'),self::VERSION,true); } }

	private function audit( $event, $result, $details=array(), $order_id=0, $contract_id=0, $user_id=0 ) { global $wpdb;$safe=$details;foreach(array('secret','password','token','code') as $forbidden){unset($safe[$forbidden]);}$wpdb->insert($this->events_table(),array('order_id'=>absint($order_id),'contract_id'=>absint($contract_id),'user_id'=>absint($user_id),'event_type'=>sanitize_key($event),'result'=>sanitize_key($result),'details'=>wp_json_encode($safe,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),'created_at_utc'=>$this->now()),array('%d','%d','%d','%s','%s','%s','%s')); }

	public function admin_menu() { add_submenu_page('woocommerce','Gulf Breeze Order Health','Gulf Breeze Order Health','manage_woocommerce','gb-order-health',array($this,'render_order_health')); }
	public function rest_routes() { register_rest_route('gulf-breeze/v1','/order-health/(?P<id>\d+)',array('methods'=>'GET','callback'=>array($this,'rest_order_health'),'permission_callback'=>function(){return current_user_can('manage_woocommerce');})); }
	public function rest_order_health( $request ) { return rest_ensure_response($this->order_health(absint($request['id']))); }
	private function order_health( $order_id ) { $order=wc_get_order($order_id);if(!$order){return array('status'=>'not_found');}global $wpdb;$events=$wpdb->get_results($wpdb->prepare('SELECT event_type,result,details,created_at_utc FROM '.$this->events_table().' WHERE order_id=%d ORDER BY id ASC',$order_id),ARRAY_A);return array('order_id'=>$order_id,'status'=>$order->get_status(),'payment_method'=>$order->get_payment_method(),'transaction_present'=>(bool)$order->get_transaction_id(),'contract_id'=>absint($order->get_meta(self::META_CONTRACT_ID)),'snapshot_hash'=>sanitize_text_field($order->get_meta('_gb_ep_snapshot_hash')),'state'=>sanitize_key($order->get_meta(self::META_STATE)),'student_user_id'=>absint($order->get_meta(self::META_STUDENT_USER_ID)),'course_id'=>absint($order->get_meta(self::META_COURSE_ID)),'events'=>$events); }
	public function render_order_health() { if(!current_user_can('manage_woocommerce')){return;}global $wpdb;$since24=gmdate('Y-m-d H:i:s',time()-DAY_IN_SECONDS);$since7=gmdate('Y-m-d H:i:s',time()-7*DAY_IN_SECONDS);$c24=absint($wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM '.$this->events_table().' WHERE created_at_utc >= %s',$since24)));$c7=absint($wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM '.$this->events_table().' WHERE created_at_utc >= %s',$since7)));echo '<div class="wrap"><h1>Gulf Breeze Order Health</h1><p><strong>Administrator only.</strong> Reports mask payment references and never expose credentials, MFA secrets, recovery codes, or other students.</p><table class="widefat striped"><tbody><tr><th>Environment</th><td>'.esc_html(strtoupper(get_option('gb_ep_environment','sandbox'))).'</td></tr><tr><th>Events — last 24 hours</th><td>'.esc_html($c24).'</td></tr><tr><th>Events — last 7 days</th><td>'.esc_html($c7).'</td></tr><tr><th>Plugin version</th><td>'.esc_html(self::VERSION).'</td></tr></tbody></table><p>Use the administrator REST endpoint <code>/wp-json/gulf-breeze/v1/order-health/ORDER_ID</code> for a masked per-order timeline.</p></div>'; }
}

register_activation_hook( __FILE__, array( 'Gulf_Breeze_Enrollment_Payment', 'activate' ) );
Gulf_Breeze_Enrollment_Payment::instance();
