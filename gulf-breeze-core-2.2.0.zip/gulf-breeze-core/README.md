# Gulf Breeze Core 2.2.0

Core 2.0.0 preserves the verified Adult English curriculum at 46 instructional lessons and 330 minutes. Its automatic migration adds seven zero-seat-time participation-check shells, one after each Topic 4.1.2–4.1.8 section, so Course Mastery Gate checks can occur without skipping an instructional lesson or placing internal question banks in the visible curriculum.

The course remains a draft and Under Construction protection remains unchanged. The migration does not import question banks, create mastery mappings, enroll users, change configuration values, or publish the course.

Core 2.1.0 adds two dedicated zero-seat-time video-check shells and verifies their positions immediately after the Topic 4.1.7 CSEA video and Topic 4.1.8 recreational-water-safety video. This placement is required by Video Quiz Gate and leaves each topic participation check after the video check.

Core 2.1.1 corrects initialization of the LearnPress course and section service when upgrading an installation whose 2.0.0 migration was already complete. The recovery is idempotent and safely reuses any video-check shell created before the interrupted 2.1.0 migration.


Core 2.2.0 corrects the post-import video-check placement. It promotes the two reviewed imported four-question video banks into the Adult English course immediately after the required CSEA and recreational-water-safety videos, retires rather than deletes the empty 2.1 placeholder quizzes, preserves any existing Video Quiz Gate mapping that referenced a placeholder, and refuses to finalize unless the regulated ledger remains exactly 46 instructional lessons / 330 minutes.
