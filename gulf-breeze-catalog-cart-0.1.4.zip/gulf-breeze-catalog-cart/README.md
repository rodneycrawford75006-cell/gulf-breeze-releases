# Gulf Breeze Catalog & Cart 0.1.4

Development checkpoint for the protected catalog-and-cart stage.

## Included

- English/Spanish mobile-first course catalog via `[gb_course_catalog]`
- Four fixed program identities
- Explicit WooCommerce product → LearnPress course mapping
- Persistent `en-US` / `es-US` enrollment-language selection
- One course, one student, quantity-one cart enforcement
- Sample WooCommerce product creation for protected testing
- Visible sample/Sandbox markers
- Checkout-stage lock that:
  - removes Cart and WooCommerce Blocks checkout controls
  - suppresses express-payment surfaces and available gateways
  - rejects classic checkout validation
  - rejects WooCommerce Store API checkout writes
  - blocks PayPal payment/order WooCommerce AJAX actions
  - hides PayPal Pay Later promotional messaging while checkout is locked
  - redirects direct checkout-page visits back to the cart
  - uses bounded cart cleanup passes so WooCommerce re-rendering cannot create a browser loop

## Intentionally excluded

- student and purchaser forms
- contract or electronic signature
- checkout and PayPal capture
- user creation or LearnPress enrollment
- MFA
- course completion or certificates

Under Construction is neither enabled nor disabled by this plugin. It must remain enabled independently on the protected site.
