<?php
/**
 * Plugin Name: Gulf Breeze Catalog & Cart
 * Description: Bilingual course catalog, authoritative WooCommerce-to-LearnPress mapping, and regulated single-course cart for Gulf Breeze Driving School.
 * Version: 0.1.4
 * Author: Gulf Breeze Driving School / Rodney Crawford
 * Text Domain: gulf-breeze-catalog-cart
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Gulf_Breeze_Catalog_Cart {
	const VERSION        = '0.1.4';
	const OPTION         = 'gb_catalog_cart_registry';
	const NOTICE_OPTION  = 'gb_catalog_cart_notice';
	const PAGE           = 'gulf-breeze-catalog-cart';
	const NONCE_ACTION   = 'gb_catalog_cart_admin';
	const COOKIE_LOCALE  = 'gb_enrollment_locale';

	private static $instance;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'admin_menu' ), 30 );
		add_action( 'admin_post_gb_catalog_save', array( $this, 'save_registry' ) );
		add_action( 'admin_post_gb_catalog_create_sample', array( $this, 'create_sample_catalog' ) );
		add_action( 'template_redirect', array( $this, 'capture_locale' ), 1 );
		add_shortcode( 'gb_course_catalog', array( $this, 'catalog_shortcode' ) );
		add_filter( 'woocommerce_add_to_cart_validation', array( $this, 'validate_add_to_cart' ), 20, 5 );
		add_filter( 'woocommerce_add_cart_item_data', array( $this, 'add_cart_item_data' ), 20, 3 );
		add_filter( 'woocommerce_get_item_data', array( $this, 'display_cart_item_data' ), 20, 2 );
		add_action( 'woocommerce_before_calculate_totals', array( $this, 'force_single_quantity' ), 20 );
		add_action( 'woocommerce_check_cart_items', array( $this, 'validate_cart_integrity' ) );
		add_action( 'template_redirect', array( $this, 'block_checkout_stage' ), 2 );
		add_action( 'wp_loaded', array( $this, 'block_payment_ajax' ), -999 );
		add_action( 'woocommerce_checkout_process', array( $this, 'reject_locked_checkout' ) );
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'reject_locked_checkout_validation' ), 10, 2 );
		add_filter( 'woocommerce_available_payment_gateways', array( $this, 'disable_payment_gateways' ), PHP_INT_MAX );
		add_filter( 'woocommerce_cart_needs_payment', array( $this, 'disable_cart_payment_requirement' ), PHP_INT_MAX );
		add_filter( 'rest_pre_dispatch', array( $this, 'block_store_api_checkout' ), 10, 3 );
		add_filter( 'render_block', array( $this, 'render_checkout_lock' ), 20, 2 );
		add_action( 'wp_head', array( $this, 'checkout_lock_styles' ), 99 );
		add_action( 'wp_footer', array( $this, 'checkout_lock_script' ), 99 );
		add_filter( 'woocommerce_product_is_purchasable', array( $this, 'mapped_products_only' ), 20, 2 );
	}

	private function checkout_locked() {
		$registry = $this->registry();
		return 'locked' === sanitize_key( $registry['checkout_stage'] ?? 'locked' );
	}

	private function checkout_lock_message() {
		return 'Checkout is disabled for this development stage. Your course will remain in the cart. / El pago está desactivado durante esta etapa de desarrollo. Su curso permanecerá en el carrito.';
	}

	private function checkout_lock_markup() {
		return '<div class="gb-checkout-lock-notice" role="status"><strong>' . esc_html( $this->checkout_lock_message() ) . '</strong></div>';
	}

	public static function definitions() {
		return array(
			'adult_6h_en' => array(
				'label' => 'Adult 6-Hour Driver Education — English',
				'short_label' => 'Adult 6-Hour Course',
				'locale' => 'en-US',
				'program_type' => 'adult_6h_en',
				'core_course_key' => 'adult_en',
				'sample_price' => '36.00',
				'description' => 'Six-hour online adult driver education course in English.',
			),
			'adult_6h_es' => array(
				'label' => 'Curso de educación vial para adultos de 6 horas — Español',
				'short_label' => 'Curso para adultos de 6 horas',
				'locale' => 'es-US',
				'program_type' => 'adult_6h_es',
				'core_course_key' => 'adult_es',
				'sample_price' => '36.00',
				'description' => 'Curso en línea de educación vial para adultos, de seis horas y completamente en español.',
			),
			'teen_parent_taught_en' => array(
				'label' => 'Teen Parent-Taught Driver Education — English',
				'short_label' => 'Teen Parent-Taught Course',
				'locale' => 'en-US',
				'program_type' => 'teen_parent_taught_en',
				'core_course_key' => 'ptde_en',
				'sample_price' => '150.00',
				'description' => 'Online classroom course for an eligible Texas parent-taught driver education student.',
			),
			'teen_parent_taught_es' => array(
				'label' => 'Educación vial para adolescentes impartida por padres — Español',
				'short_label' => 'Curso para adolescentes impartido por padres',
				'locale' => 'es-US',
				'program_type' => 'teen_parent_taught_es',
				'core_course_key' => 'ptde_es',
				'sample_price' => '150.00',
				'description' => 'Curso teórico en línea para estudiantes elegibles del programa de educación vial impartida por padres en Texas.',
			),
		);
	}

	private function default_registry() {
		$rows = array();
		foreach ( self::definitions() as $key => $definition ) {
			$rows[ $key ] = array(
				'product_id' => 0,
				'course_id' => 0,
				'enabled' => 0,
			);
		}
		return array(
			'schema_version' => 1,
			'profile_version' => 1,
			'environment' => 'sandbox',
			'checkout_stage' => 'locked',
			'updated_at_utc' => '',
			'updated_by_user_id' => 0,
			'rows' => $rows,
		);
	}

	public function registry() {
		$stored = get_option( self::OPTION, array() );
		$registry = wp_parse_args( is_array( $stored ) ? $stored : array(), $this->default_registry() );
		$registry['rows'] = wp_parse_args( isset( $registry['rows'] ) && is_array( $registry['rows'] ) ? $registry['rows'] : array(), $this->default_registry()['rows'] );
		return $registry;
	}

	public function admin_menu() {
		add_submenu_page(
			'gulf-breeze-configuration',
			'Catalog & Cart',
			'Catalog & Cart',
			'manage_options',
			self::PAGE,
			array( $this, 'render_admin_page' )
		);
	}

	private function assert_admin_request() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to change the Gulf Breeze catalog.', 'gulf-breeze-catalog-cart' ), esc_html__( 'Access denied', 'gulf-breeze-catalog-cart' ), array( 'response' => 403 ) );
		}
		check_admin_referer( self::NONCE_ACTION );
	}

	public function save_registry() {
		$this->assert_admin_request();
		$submitted = isset( $_POST['registry'] ) && is_array( $_POST['registry'] ) ? wp_unslash( $_POST['registry'] ) : array();
		$current = $this->registry();
		$rows = array();
		$seen_products = array();

		foreach ( self::definitions() as $key => $definition ) {
			$row = isset( $submitted[ $key ] ) && is_array( $submitted[ $key ] ) ? $submitted[ $key ] : array();
			$product_id = absint( $row['product_id'] ?? 0 );
			$course_id = absint( $row['course_id'] ?? 0 );
			$enabled = ! empty( $row['enabled'] ) ? 1 : 0;
			$error = '';

			if ( $product_id && ( 'product' !== get_post_type( $product_id ) || in_array( $product_id, $seen_products, true ) ) ) {
				$error = 'Each mapping requires a unique valid WooCommerce product.';
				$product_id = 0;
				$enabled = 0;
			}
			if ( $course_id && 'lp_course' !== get_post_type( $course_id ) ) {
				$error = 'Each mapping requires a valid LearnPress course.';
				$course_id = 0;
				$enabled = 0;
			}
			if ( $enabled && ( ! $product_id || ! $course_id ) ) {
				$error = 'A row cannot be enabled until both sides are mapped.';
				$enabled = 0;
			}
			if ( $product_id ) {
				$seen_products[] = $product_id;
				update_post_meta( $product_id, '_gb_catalog_key', $key );
				update_post_meta( $product_id, '_gb_program_type', $definition['program_type'] );
				update_post_meta( $product_id, '_gb_enrollment_locale', $definition['locale'] );
				update_post_meta( $product_id, '_gb_learnpress_course_id', $course_id );
			}
			$rows[ $key ] = compact( 'product_id', 'course_id', 'enabled', 'error' );
		}

		$registry = array(
			'schema_version' => 1,
			'profile_version' => absint( $current['profile_version'] ) + 1,
			'environment' => 'sandbox',
			'checkout_stage' => 'locked',
			'updated_at_utc' => gmdate( 'c' ),
			'updated_by_user_id' => get_current_user_id(),
			'rows' => $rows,
		);
		update_option( self::OPTION, $registry, false );
		$this->set_notice( 'Catalog mapping saved. Checkout remains locked and PayPal remains in Sandbox.' );
		$this->redirect_admin();
	}

	public function create_sample_catalog() {
		$this->assert_admin_request();
		if ( ! class_exists( 'WooCommerce' ) || ! class_exists( 'WC_Product_Simple' ) ) {
			$this->set_notice( 'WooCommerce must be active before sample products can be created.', 'error' );
			$this->redirect_admin();
		}

		$registry = $this->registry();
		$core_registry = get_option( 'gb_course_registry', array() );
		$created = 0;

		foreach ( self::definitions() as $key => $definition ) {
			$row = $registry['rows'][ $key ];
			$product_id = absint( $row['product_id'] ?? 0 );
			if ( ! $product_id || 'product' !== get_post_type( $product_id ) ) {
				$existing = get_posts( array(
					'post_type' => 'product',
					'post_status' => array( 'publish', 'draft', 'private' ),
					'meta_key' => '_gb_catalog_key',
					'meta_value' => $key,
					'fields' => 'ids',
					'numberposts' => 1,
				) );
				$product_id = $existing ? absint( $existing[0] ) : 0;
			}
			if ( ! $product_id ) {
				$product = new WC_Product_Simple();
				$product->set_name( $definition['label'] . ' — SAMPLE' );
				$product->set_status( 'publish' );
				$product->set_catalog_visibility( 'visible' );
				$product->set_regular_price( $definition['sample_price'] );
				$product->set_price( $definition['sample_price'] );
				$product->set_sold_individually( true );
				$product->set_virtual( true );
				$product->set_description( $definition['description'] . ' SAMPLE — NOT VALID FOR OFFICIAL USE.' );
				$product_id = $product->save();
				$created++;
			}
			$course_id = absint( $core_registry[ $definition['core_course_key'] ]['learnpress_course_id'] ?? 0 );
			update_post_meta( $product_id, '_gb_catalog_key', $key );
			update_post_meta( $product_id, '_gb_program_type', $definition['program_type'] );
			update_post_meta( $product_id, '_gb_enrollment_locale', $definition['locale'] );
			update_post_meta( $product_id, '_gb_learnpress_course_id', $course_id );
			$registry['rows'][ $key ] = array(
				'product_id' => $product_id,
				'course_id' => $course_id,
				'enabled' => $course_id ? 1 : 0,
				'error' => $course_id ? '' : 'Sample product created; map the LearnPress course before enabling.',
			);
		}

		$registry['profile_version'] = absint( $registry['profile_version'] ) + 1;
		$registry['environment'] = 'sandbox';
		$registry['checkout_stage'] = 'locked';
		$registry['updated_at_utc'] = gmdate( 'c' );
		$registry['updated_by_user_id'] = get_current_user_id();
		update_option( self::OPTION, $registry, false );
		$this->set_notice( sprintf( '%d sample product(s) created. Under Construction is unchanged; checkout remains locked.', $created ) );
		$this->redirect_admin();
	}

	private function set_notice( $message, $type = 'success' ) {
		update_option( self::NOTICE_OPTION, array( 'message' => sanitize_text_field( $message ), 'type' => $type ), false );
	}

	private function redirect_admin() {
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE ) );
		exit;
	}

	public function render_admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$registry = $this->registry();
		$products = get_posts( array( 'post_type' => 'product', 'post_status' => array( 'publish', 'draft', 'private' ), 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		$courses = get_posts( array( 'post_type' => 'lp_course', 'post_status' => array( 'publish', 'draft', 'private', 'pending' ), 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		$notice = get_option( self::NOTICE_OPTION, array() );
		delete_option( self::NOTICE_OPTION );
		?>
		<div class="wrap">
			<h1>Gulf Breeze Catalog & Cart</h1>
			<?php if ( ! empty( $notice['message'] ) ) : ?><div class="notice notice-<?php echo 'error' === ( $notice['type'] ?? '' ) ? 'error' : 'success'; ?> inline"><p><?php echo esc_html( $notice['message'] ); ?></p></div><?php endif; ?>
			<div class="notice notice-warning inline"><p><strong>DEVELOPMENT / SAMPLE DATA · PAYPAL SANDBOX · CHECKOUT LOCKED</strong><br>Under Construction is not changed by this module. This stage ends at the shopping cart.</p></div>
			<p>Each regulatory identity is fixed. Mapping is explicit and is never inferred from a product title.</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="gb_catalog_save">
				<?php wp_nonce_field( self::NONCE_ACTION ); ?>
				<table class="widefat striped"><thead><tr><th>Course identity</th><th>Locale</th><th>WooCommerce product</th><th>LearnPress course</th><th>Available</th><th>Status</th></tr></thead><tbody>
				<?php foreach ( self::definitions() as $key => $definition ) : $row = $registry['rows'][ $key ]; ?>
				<tr>
					<td><strong><?php echo esc_html( $definition['label'] ); ?></strong><br><code><?php echo esc_html( $definition['program_type'] ); ?></code></td>
					<td><?php echo esc_html( $definition['locale'] ); ?></td>
					<td><select name="registry[<?php echo esc_attr( $key ); ?>][product_id]"><option value="0">Not mapped</option><?php foreach ( $products as $product ) : ?><option value="<?php echo esc_attr( $product->ID ); ?>" <?php selected( absint( $row['product_id'] ?? 0 ), $product->ID ); ?>><?php echo esc_html( $product->post_title . ' (#' . $product->ID . ')' ); ?></option><?php endforeach; ?></select></td>
					<td><select name="registry[<?php echo esc_attr( $key ); ?>][course_id]"><option value="0">Not mapped</option><?php foreach ( $courses as $course ) : ?><option value="<?php echo esc_attr( $course->ID ); ?>" <?php selected( absint( $row['course_id'] ?? 0 ), $course->ID ); ?>><?php echo esc_html( $course->post_title . ' (#' . $course->ID . ')' ); ?></option><?php endforeach; ?></select></td>
					<td><label><input type="checkbox" name="registry[<?php echo esc_attr( $key ); ?>][enabled]" value="1" <?php checked( ! empty( $row['enabled'] ) ); ?>> Enabled</label></td>
					<td><?php echo ! empty( $row['error'] ) ? '<span style="color:#b32d2e">' . esc_html( $row['error'] ) . '</span>' : ( ! empty( $row['enabled'] ) ? '<strong style="color:#16752a">Ready for catalog/cart testing</strong>' : 'Disabled' ); ?></td>
				</tr>
				<?php endforeach; ?>
				</tbody></table>
				<?php submit_button( 'Save catalog mapping' ); ?>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="gb_catalog_create_sample">
				<?php wp_nonce_field( self::NONCE_ACTION ); ?>
				<?php submit_button( 'Create or repair sample catalog', 'secondary' ); ?>
			</form>
			<p>Place <code>[gb_course_catalog]</code> on the protected catalog page. Sample products are published only so authorized testers can use them behind Under Construction.</p>
		</div>
		<?php
	}

	private function current_locale() {
		$locale = isset( $_COOKIE[ self::COOKIE_LOCALE ] ) ? sanitize_text_field( wp_unslash( $_COOKIE[ self::COOKIE_LOCALE ] ) ) : 'en-US';
		return in_array( $locale, array( 'en-US', 'es-US' ), true ) ? $locale : 'en-US';
	}

	public function capture_locale() {
		if ( empty( $_GET['gb_locale'] ) ) {
			return;
		}
		$locale = sanitize_text_field( wp_unslash( $_GET['gb_locale'] ) );
		if ( ! in_array( $locale, array( 'en-US', 'es-US' ), true ) ) {
			return;
		}
		setcookie( self::COOKIE_LOCALE, $locale, array( 'expires' => time() + MONTH_IN_SECONDS, 'path' => COOKIEPATH ?: '/', 'domain' => COOKIE_DOMAIN, 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax' ) );
		$_COOKIE[ self::COOKIE_LOCALE ] = $locale;
	}

	public function catalog_shortcode() {
		$locale = $this->current_locale();
		$is_es = 'es-US' === $locale;
		$registry = $this->registry();
		$catalog_url = remove_query_arg( 'gb_locale' );
		ob_start();
		?>
		<section class="gb-catalog" lang="<?php echo $is_es ? 'es' : 'en'; ?>">
			<style>.gb-catalog{max-width:1120px;margin:24px auto;padding:0 16px;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#183248}.gb-sample{background:#7a281f;color:#fff;padding:10px 14px;border-radius:10px;font-weight:800;text-align:center}.gb-language{display:flex;gap:10px;flex-wrap:wrap;margin:18px 0}.gb-language a{display:inline-block;padding:11px 16px;border:2px solid #0b5d79;border-radius:999px;text-decoration:none;font-weight:700}.gb-language a[aria-current="true"]{background:#0b5d79;color:#fff}.gb-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:18px}.gb-card{border:1px solid #c9d8df;border-radius:16px;padding:20px;background:#fff;box-shadow:0 5px 18px rgba(24,50,72,.08)}.gb-card h3{margin-top:0}.gb-card .gb-price{font-size:1.35rem;font-weight:800}.gb-card a.gb-add{display:block;text-align:center;background:#0b5d79;color:#fff;padding:13px 16px;border-radius:10px;text-decoration:none;font-weight:800}.gb-card .gb-disabled{background:#edf1f3;padding:12px;border-radius:10px}.gb-cart-link{margin:22px 0;text-align:right}.gb-cart-link a{font-weight:800}</style>
			<div class="gb-sample">SAMPLE — NOT VALID FOR OFFICIAL USE · PAYPAL SANDBOX</div>
			<h2><?php echo $is_es ? 'Seleccione su curso y el idioma' : 'Choose your course and language'; ?></h2>
			<p><?php echo $is_es ? 'El idioma seleccionado se guardará con la inscripción. Verifique que el curso sea para el estudiante correcto antes de agregarlo al carrito.' : 'The selected language will be saved with the enrollment. Confirm that the course is for the correct student before adding it to the cart.'; ?></p>
			<nav class="gb-language" aria-label="<?php echo $is_es ? 'Idioma de inscripción' : 'Enrollment language'; ?>">
				<a href="<?php echo esc_url( add_query_arg( 'gb_locale', 'en-US', $catalog_url ) ); ?>" aria-current="<?php echo $is_es ? 'false' : 'true'; ?>">English</a>
				<a href="<?php echo esc_url( add_query_arg( 'gb_locale', 'es-US', $catalog_url ) ); ?>" aria-current="<?php echo $is_es ? 'true' : 'false'; ?>">Español</a>
			</nav>
			<div class="gb-grid">
			<?php foreach ( self::definitions() as $key => $definition ) : if ( $definition['locale'] !== $locale ) continue; $row = $registry['rows'][ $key ]; $product = ! empty( $row['product_id'] ) && function_exists( 'wc_get_product' ) ? wc_get_product( absint( $row['product_id'] ) ) : false; ?>
				<article class="gb-card">
					<h3><?php echo esc_html( $definition['short_label'] ); ?></h3>
					<p><?php echo esc_html( $definition['description'] ); ?></p>
					<?php if ( $product && ! empty( $row['enabled'] ) && absint( $row['course_id'] ?? 0 ) ) : ?>
						<p class="gb-price"><?php echo wp_kses_post( $product->get_price_html() ); ?></p>
						<a class="gb-add" href="<?php echo esc_url( add_query_arg( array( 'add-to-cart' => $product->get_id(), 'quantity' => 1, 'gb_locale' => $definition['locale'] ), wc_get_cart_url() ) ); ?>"><?php echo $is_es ? 'Agregar al carrito' : 'Add to cart'; ?></a>
					<?php else : ?>
						<p class="gb-disabled"><?php echo $is_es ? 'Este curso todavía no está disponible para pruebas.' : 'This course is not yet available for testing.'; ?></p>
					<?php endif; ?>
				</article>
			<?php endforeach; ?>
			</div>
			<?php if ( function_exists( 'WC' ) && WC()->cart && ! WC()->cart->is_empty() ) : ?><p class="gb-cart-link"><a href="<?php echo esc_url( wc_get_cart_url() ); ?>"><?php echo $is_es ? 'Ver carrito' : 'View cart'; ?></a></p><?php endif; ?>
		</section>
		<?php
		return ob_get_clean();
	}

	private function mapping_for_product( $product_id ) {
		$product_id = absint( $product_id );
		foreach ( $this->registry()['rows'] as $key => $row ) {
			if ( absint( $row['product_id'] ?? 0 ) === $product_id && ! empty( $row['enabled'] ) && absint( $row['course_id'] ?? 0 ) ) {
				return array_merge( array( 'key' => $key ), self::definitions()[ $key ], $row );
			}
		}
		return false;
	}

	public function mapped_products_only( $purchasable, $product ) {
		if ( ! $product || ! get_post_meta( $product->get_id(), '_gb_catalog_key', true ) ) {
			return $purchasable;
		}
		return (bool) $this->mapping_for_product( $product->get_id() );
	}

	public function validate_add_to_cart( $passed, $product_id, $quantity, $variation_id = 0, $variations = array() ) {
		$mapping = $this->mapping_for_product( $product_id );
		if ( ! $mapping ) {
			wc_add_notice( 'This course is not available. / Este curso no está disponible.', 'error' );
			return false;
		}
		if ( absint( $quantity ) !== 1 ) {
			wc_add_notice( 'Only one course may be purchased for one student at a time. / Solo se puede comprar un curso para un estudiante a la vez.', 'error' );
			return false;
		}
		if ( function_exists( 'WC' ) && WC()->cart && ! WC()->cart->is_empty() ) {
			foreach ( WC()->cart->get_cart() as $item ) {
				if ( absint( $item['product_id'] ?? 0 ) !== absint( $product_id ) ) {
					wc_add_notice( 'Complete or remove the course already in the cart before selecting another. / Complete o elimine el curso que ya está en el carrito antes de seleccionar otro.', 'error' );
					return false;
				}
			}
		}
		return $passed;
	}

	public function add_cart_item_data( $data, $product_id, $variation_id ) {
		$mapping = $this->mapping_for_product( $product_id );
		if ( ! $mapping ) {
			return $data;
		}
		$data['gb_catalog_mapping'] = array(
			'catalog_key' => $mapping['key'],
			'program_type' => $mapping['program_type'],
			'locale' => $mapping['locale'],
			'product_id' => absint( $mapping['product_id'] ),
			'course_id' => absint( $mapping['course_id'] ),
			'registry_version' => absint( $this->registry()['profile_version'] ),
		);
		return $data;
	}

	public function display_cart_item_data( $data, $cart_item ) {
		$mapping = $cart_item['gb_catalog_mapping'] ?? array();
		if ( ! $mapping ) {
			return $data;
		}
		$is_es = 'es-US' === ( $mapping['locale'] ?? '' );
		$data[] = array( 'key' => $is_es ? 'Idioma del curso' : 'Course language', 'value' => $is_es ? 'Español' : 'English' );
		$data[] = array( 'key' => $is_es ? 'Estudiante' : 'Student', 'value' => $is_es ? 'Se proporcionará en el siguiente paso' : 'Will be provided in the next stage' );
		return $data;
	}

	public function force_single_quantity( $cart ) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return;
		foreach ( $cart->get_cart() as $cart_item_key => $item ) {
			if ( ! empty( $item['gb_catalog_mapping'] ) && absint( $item['quantity'] ) !== 1 ) {
				$cart->set_quantity( $cart_item_key, 1, false );
			}
		}
	}

	public function validate_cart_integrity() {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) return;
		$regulated = 0;
		foreach ( WC()->cart->get_cart() as $item ) {
			if ( ! empty( $item['gb_catalog_mapping'] ) ) $regulated++;
		}
		if ( $regulated > 1 || ( $regulated && WC()->cart->get_cart_contents_count() > 1 ) ) {
			wc_add_notice( 'This cart must contain exactly one course for one student. / Este carrito debe contener exactamente un curso para un estudiante.', 'error' );
		}
	}

	public function disable_payment_gateways( $gateways ) {
		if ( ! $this->checkout_locked() ) {
			return $gateways;
		}
		if ( is_admin() && ! wp_doing_ajax() ) {
			return $gateways;
		}
		return array();
	}

	public function disable_cart_payment_requirement( $needs_payment ) {
		return $this->checkout_locked() ? false : $needs_payment;
	}

	public function reject_locked_checkout() {
		if ( $this->checkout_locked() && function_exists( 'wc_add_notice' ) ) {
			wc_add_notice( $this->checkout_lock_message(), 'error' );
		}
	}

	public function reject_locked_checkout_validation( $data, $errors ) {
		if ( $this->checkout_locked() && is_object( $errors ) && method_exists( $errors, 'add' ) ) {
			$errors->add( 'gb_checkout_locked', $this->checkout_lock_message() );
		}
	}

	public function block_store_api_checkout( $result, $server, $request ) {
		if ( ! $this->checkout_locked() || ! is_object( $request ) || ! method_exists( $request, 'get_route' ) ) {
			return $result;
		}

		$route  = (string) $request->get_route();
		$method = strtoupper( (string) $request->get_method() );
		if ( ! in_array( $method, array( 'GET', 'HEAD', 'OPTIONS' ), true ) && preg_match( '#^/wc/store/v[0-9]+/checkout(?:/|$)#', $route ) ) {
			return new WP_Error(
				'gb_checkout_locked',
				$this->checkout_lock_message(),
				array( 'status' => 423 )
			);
		}
		return $result;
	}

	public function block_payment_ajax() {
		if ( ! $this->checkout_locked() || empty( $_REQUEST['wc-ajax'] ) ) {
			return;
		}
		$action = sanitize_key( wp_unslash( $_REQUEST['wc-ajax'] ) );
		if ( preg_match( '/(?:ppc|paypal).*(?:order|payment|capture|approve|process|return)/', $action ) ) {
			wp_send_json_error(
				array(
					'code' => 'gb_checkout_locked',
					'message' => $this->checkout_lock_message(),
				),
				423
			);
		}
	}

	public function render_checkout_lock( $block_content, $block ) {
		if ( ! $this->checkout_locked() || ! function_exists( 'is_cart' ) || ! is_cart() ) {
			return $block_content;
		}
		$block_name = sanitize_text_field( $block['blockName'] ?? '' );
		if ( in_array( $block_name, array( 'woocommerce/proceed-to-checkout-block', 'woocommerce/cart-express-payment-block' ), true ) ) {
			return 'woocommerce/proceed-to-checkout-block' === $block_name ? $this->checkout_lock_markup() : '';
		}
		return $block_content;
	}

	public function checkout_lock_styles() {
		if ( ! $this->checkout_locked() || ! function_exists( 'is_cart' ) || ! is_cart() ) {
			return;
		}
		?>
		<style id="gb-checkout-lock-styles">
			.wc-block-cart__payment-options,
			.wp-block-woocommerce-proceed-to-checkout-block,
			.wc-block-cart__submit,
			.wc-proceed-to-checkout,
			.ppcp-messages,
			[id^="zoid-paypal-message-"],
			iframe[title^="PayPal Message"] { display: none !important; }
			.gb-checkout-lock-notice { margin: 18px 0; padding: 14px 16px; border: 2px solid #7a281f; border-radius: 10px; background: #fff4f2; color: #512018; line-height: 1.45; }
		</style>
		<?php
	}

	public function checkout_lock_script() {
		if ( ! $this->checkout_locked() || ! function_exists( 'is_cart' ) || ! is_cart() ) {
			return;
		}
		$markup = $this->checkout_lock_markup();
		?>
		<script id="gb-checkout-lock-script">
		(function () {
			var selectors = '.wc-block-cart__payment-options,.wp-block-woocommerce-proceed-to-checkout-block,.wc-block-cart__submit,.wc-proceed-to-checkout,.ppcp-messages,[id^="zoid-paypal-message-"],iframe[title^="PayPal Message"]';
			var notice = <?php echo wp_json_encode( $markup ); ?>;
			function enforceLock() {
				document.querySelectorAll(selectors).forEach(function (element) { element.remove(); });
				var sidebar = document.querySelector('.wc-block-cart__sidebar,.cart_totals');
				if (sidebar && !document.querySelector('.gb-checkout-lock-notice')) {
					sidebar.insertAdjacentHTML('beforeend', notice);
				}
			}
			enforceLock();
			if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', enforceLock);
			window.setTimeout(enforceLock, 500);
			window.setTimeout(enforceLock, 1500);
			window.setTimeout(enforceLock, 3000);
		}());
		</script>
		<?php
	}

	public function block_checkout_stage() {
		if ( ! $this->checkout_locked() || ! function_exists( 'is_checkout' ) || ! is_checkout() || is_wc_endpoint_url( 'order-received' ) ) return;
		wp_safe_redirect( add_query_arg( 'gb_stage_locked', '1', wc_get_cart_url() ) );
		exit;
	}
}

Gulf_Breeze_Catalog_Cart::instance();

function gb_catalog_cart_mapping( $catalog_key = '' ) {
	$registry = Gulf_Breeze_Catalog_Cart::instance()->registry();
	if ( '' === $catalog_key ) {
		return $registry;
	}
	return $registry['rows'][ sanitize_key( $catalog_key ) ] ?? null;
}
