=== Gulf Breeze Test Student Fixtures ===
Contributors: gulfbreeze
Requires at least: 6.5
Requires PHP: 8.0
Stable tag: 0.1.0-dev-r1

Administrator-only test fixture generator for the Gulf Breeze course and certificate stack.

Safety rules:

* Requires Under Construction to be enabled.
* Requires Gulf Breeze Certificates to be in test mode.
* Requires the exact WooCommerce, LearnPress, enrollment, and mastery dependencies.
* Creates only non-administrator accounts marked `_gb_ep_test_account=yes`.
* Creates zero-dollar synthetic completed orders with no PayPal transaction.
* Uses the real certificate eligibility data contracts; it does not call or bypass certificate issuance.
* Inserts simulated mastery metadata directly so certificate issuance remains under the normal reconciliation action.

Fixture states:

1. Purchased and enrolled only.
2. Mid-course progress.
3. Adult final passed while the course remains incomplete.
4. Course completed while the Adult final is missing.
5. English certificate eligible.
6. Spanish certificate eligible.

After creating a batch, confirm the four negative controls remain unissued. Then use GB Certificates > Reconcile Eligible Completions. Exactly the two eligible fixture students should receive test certificates.

