<?php
/**
 * Plugin Name: Gulf Breeze Test Student Fixtures
 * Description: Administrator-only test-mode sample students for controlled enrollment, progress, mastery, certificate, email, and reporting validation.
 * Version: 0.1.0-dev-r1
 * Author: Gulf Breeze Driving School / Rodney Crawford
 * Text Domain: gulf-breeze-test-student-fixtures
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Gulf_Breeze_Test_Student_Fixtures {
	const VERSION = '0.1.0-dev-r1';
	const PAGE_SLUG = 'gb-test-student-fixtures';
	const CONFIRMATION = 'CREATE SAMPLE STUDENTS';
	const MARKER = '_gb_ep_test_account';
	const FIXTURE_MARKER = '_gb_test_fixture';

	private static $instance;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'admin_post_gb_create_test_student_fixtures', array( $this, 'handle_create' ) );
		add_action( 'admin_notices', array( $this, 'test_mode_notice' ) );
	}

	public function admin_menu() {
		add_management_page(
			'Gulf Breeze Test Student Fixtures',
			'GB Test Student Fixtures',
			'manage_options',
			self::PAGE_SLUG,
			array( $this, 'render_page' )
		);
	}

	public function test_mode_notice() {
		if ( ! current_user_can( 'manage_options' ) || empty( $_GET['page'] ) || self::PAGE_SLUG !== sanitize_key( wp_unslash( $_GET['page'] ) ) ) {
			return;
		}
		echo '<div class="notice notice-warning"><p><strong>TEST DATA ONLY:</strong> This tool creates synthetic students, zero-dollar completed test orders, simulated LearnPress progress, and simulated mastery evidence. It cannot create production certificates or payment evidence.</p></div>';
	}

	private function under_construction_enabled() {
		$options = get_option( 'ucp_options', array() );
		return is_array( $options ) && ! empty( $options['status'] );
	}

	private function preflight_errors() {
		$errors = array();
		if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_create_order' ) ) {
			$errors[] = 'WooCommerce is unavailable.';
		}
		if ( ! class_exists( '\\LearnPress\\Models\\UserItems\\UserCourseModel' ) || ! defined( 'LP_COURSE_CPT' ) ) {
			$errors[] = 'The required LearnPress course model is unavailable.';
		}
		if ( ! class_exists( 'Gulf_Breeze_Enrollment_Payment' ) ) {
			$errors[] = 'Gulf Breeze Enrollment & Payment is unavailable.';
		}
		if ( ! class_exists( 'GulfBreeze_Course_Mastery_Gate' ) ) {
			$errors[] = 'GulfBreeze Course Mastery Gate is unavailable.';
		}
		if ( ! class_exists( 'Gulf_Breeze_Certificates' ) || ! defined( 'Gulf_Breeze_Certificates::MODE' ) || 'test' !== Gulf_Breeze_Certificates::MODE ) {
			$errors[] = 'Gulf Breeze Certificates is unavailable or is not in test mode.';
		}
		if ( ! $this->under_construction_enabled() ) {
			$errors[] = 'Under Construction must be enabled before fixtures can be created.';
		}
		foreach ( array( 'adult_en', 'adult_es' ) as $course_key ) {
			$course_id = $this->course_id( $course_key );
			if ( ! $course_id ) {
				$errors[] = 'No published LearnPress course is mapped to ' . $course_key . '.';
			} elseif ( ! $this->adult_final_map( $course_id ) ) {
				$errors[] = 'No active Adult final mastery map exists for course #' . $course_id . '.';
			}
		}
		return $errors;
	}

	private function course_id( $course_key ) {
		$ids = get_posts(
			array(
				'post_type' => 'lp_course',
				'post_status' => 'publish',
				'posts_per_page' => 1,
				'fields' => 'ids',
				'meta_key' => '_gb_course_key',
				'meta_value' => sanitize_key( $course_key ),
				'orderby' => 'ID',
				'order' => 'ASC',
			)
		);
		return empty( $ids ) ? 0 : absint( $ids[0] );
	}

	private function mapping_id( $map ) {
		return substr( hash( 'sha256', implode( ':', array(
			absint( $map['course_id'] ?? 0 ),
			sanitize_key( $map['unit_type'] ?? '' ),
			absint( $map['unit_number'] ?? 0 ),
			absint( $map['bank_quiz_id'] ?? 0 ),
			absint( $map['second_bank_quiz_id'] ?? 0 ),
		) ) ), 0, 12 );
	}

	private function adult_final_map( $course_id ) {
		$maps = get_option( 'gbcmg_mappings', array() );
		foreach ( is_array( $maps ) ? $maps : array() as $map ) {
			if ( ! empty( $map['active'] ) && 'adult_final' === sanitize_key( $map['unit_type'] ?? '' ) && absint( $map['course_id'] ?? 0 ) === absint( $course_id ) ) {
				return $map;
			}
		}
		return array();
	}

	private function profiles() {
		return array(
			array( 'slug' => 'enrolled', 'label' => 'Purchased and enrolled only', 'course_key' => 'adult_en', 'progress' => 0, 'final' => false, 'complete' => false ),
			array( 'slug' => 'mid-course', 'label' => 'Mid-course progress', 'course_key' => 'adult_en', 'progress' => 50, 'final' => false, 'complete' => false ),
			array( 'slug' => 'final-only', 'label' => 'Final passed; course incomplete', 'course_key' => 'adult_en', 'progress' => 85, 'final' => true, 'complete' => false ),
			array( 'slug' => 'complete-no-final', 'label' => 'Course complete; final missing', 'course_key' => 'adult_en', 'progress' => 100, 'final' => false, 'complete' => true ),
			array( 'slug' => 'eligible-en', 'label' => 'Certificate eligible — English', 'course_key' => 'adult_en', 'progress' => 100, 'final' => true, 'complete' => true, 'recipient' => 'english' ),
			array( 'slug' => 'eligible-es', 'label' => 'Certificate eligible — Spanish', 'course_key' => 'adult_es', 'progress' => 100, 'final' => true, 'complete' => true, 'recipient' => 'spanish' ),
		);
	}

	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$errors = $this->preflight_errors();
		$result = get_transient( 'gb_fixture_result_' . get_current_user_id() );
		if ( false !== $result ) {
			delete_transient( 'gb_fixture_result_' . get_current_user_id() );
		}
		echo '<div class="wrap"><h1>Gulf Breeze Test Student Fixtures</h1>';
		echo '<p>Create one clearly marked sample student at each controlled progress point. This does not run a six-hour course and does not weaken the production eligibility rules.</p>';
		if ( $errors ) {
			echo '<div class="notice notice-error"><p><strong>Creation is blocked:</strong></p><ul>';
			foreach ( $errors as $error ) {
				echo '<li>' . esc_html( $error ) . '</li>';
			}
			echo '</ul></div>';
		}
		if ( is_array( $result ) ) {
			$this->render_result( $result );
		}
		echo '<h2>Fixture set</h2><table class="widefat striped" style="max-width:1050px"><thead><tr><th>Sample</th><th>Course progress</th><th>Adult final</th><th>Certificate expected</th></tr></thead><tbody>';
		foreach ( $this->profiles() as $profile ) {
			echo '<tr><td>' . esc_html( $profile['label'] ) . '</td><td>' . esc_html( $profile['progress'] . '%' ) . '</td><td>' . esc_html( $profile['final'] ? 'Passed (simulated test evidence)' : 'Not passed' ) . '</td><td>' . esc_html( $profile['final'] && $profile['complete'] ? 'Eligible' : 'Blocked' ) . '</td></tr>';
		}
		echo '</tbody></table>';
		echo '<h2>Create a new batch</h2><p>Optional recipient addresses apply only to the two certificate-eligible students. Leave them blank to use non-deliverable <code>.invalid</code> addresses, then edit the student before certificate reconciliation.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'gb_create_test_student_fixtures' );
		echo '<input type="hidden" name="action" value="gb_create_test_student_fixtures">';
		echo '<table class="form-table"><tbody>';
		echo '<tr><th><label for="gb_fixture_en_email">English eligible email</label></th><td><input class="regular-text" type="email" id="gb_fixture_en_email" name="english_email"><p class="description">Optional; must not already belong to a WordPress user.</p></td></tr>';
		echo '<tr><th><label for="gb_fixture_es_email">Spanish eligible email</label></th><td><input class="regular-text" type="email" id="gb_fixture_es_email" name="spanish_email"><p class="description">Optional; must be different from the English address.</p></td></tr>';
		echo '<tr><th><label for="gb_fixture_confirm">Confirmation</label></th><td><input class="regular-text" type="text" id="gb_fixture_confirm" name="confirmation" required><p class="description">Type <code>' . esc_html( self::CONFIRMATION ) . '</code> exactly.</p></td></tr>';
		echo '</tbody></table>';
		submit_button( 'Create six sample students', 'primary', 'submit', false, $errors ? array( 'disabled' => 'disabled' ) : array() );
		echo '</form>';
		echo '<p><strong>Safety:</strong> every account is non-administrator, marked disposable, added to internal tester access, and paired only with a zero-dollar synthetic order. No PayPal transaction is created. Existing users, orders, progress, certificates, and Under Construction settings are never changed.</p></div>';
	}

	private function render_result( $result ) {
		if ( ! empty( $result['error'] ) ) {
			echo '<div class="notice notice-error"><p><strong>Fixture batch stopped:</strong> ' . esc_html( $result['error'] ) . '</p></div>';
		}
		if ( empty( $result['rows'] ) ) {
			return;
		}
		echo '<div class="notice notice-success"><p><strong>Test fixture batch ' . esc_html( $result['batch'] ) . ' created.</strong> The two eligible rows are ready for the normal Certificates reconciliation; the other four must remain blocked.</p></div>';
		echo '<table class="widefat striped" style="max-width:1200px"><thead><tr><th>Stage</th><th>Student</th><th>Email</th><th>Order</th><th>Course</th><th>Expected</th></tr></thead><tbody>';
		foreach ( $result['rows'] as $row ) {
			echo '<tr><td>' . esc_html( $row['label'] ) . '</td><td><a href="' . esc_url( get_edit_user_link( $row['user_id'] ) ) . '">#' . esc_html( $row['user_id'] ) . ' ' . esc_html( $row['name'] ) . '</a></td><td>' . esc_html( $row['email'] ) . '</td><td><a href="' . esc_url( admin_url( 'post.php?post=' . absint( $row['order_id'] ) . '&action=edit' ) ) . '">#' . esc_html( $row['order_id'] ) . '</a></td><td>#' . esc_html( $row['course_id'] ) . '</td><td>' . esc_html( $row['expected'] ) . '</td></tr>';
		}
		echo '</tbody></table>';
		echo '<p><strong>Next focused check:</strong> verify the four negative controls remain unissued, then use <a href="' . esc_url( admin_url( 'admin.php?page=gb-certificates' ) ) . '">GB Certificates</a> → Reconcile Eligible Completions. Exactly two new test certificates should issue.</p>';
	}

	public function handle_create() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Administrator permission is required.', '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'gb_create_test_student_fixtures' );
		$confirmation = sanitize_text_field( wp_unslash( $_POST['confirmation'] ?? '' ) );
		if ( self::CONFIRMATION !== $confirmation ) {
			wp_die( 'Fixture creation blocked: the confirmation phrase did not match.', '', array( 'response' => 400 ) );
		}
		$errors = $this->preflight_errors();
		if ( $errors ) {
			wp_die( esc_html( implode( ' ', $errors ) ), '', array( 'response' => 400 ) );
		}
		$recipients = array(
			'english' => sanitize_email( wp_unslash( $_POST['english_email'] ?? '' ) ),
			'spanish' => sanitize_email( wp_unslash( $_POST['spanish_email'] ?? '' ) ),
		);
		foreach ( $recipients as $recipient ) {
			if ( $recipient && ( ! is_email( $recipient ) || email_exists( $recipient ) ) ) {
				wp_die( 'A recipient email is invalid or already belongs to a WordPress user.', '', array( 'response' => 400 ) );
			}
		}
		if ( $recipients['english'] && $recipients['spanish'] && strtolower( $recipients['english'] ) === strtolower( $recipients['spanish'] ) ) {
			wp_die( 'The English and Spanish eligible students require different email addresses.', '', array( 'response' => 400 ) );
		}
		$result = $this->create_batch( $recipients );
		set_transient( 'gb_fixture_result_' . get_current_user_id(), $result, 10 * MINUTE_IN_SECONDS );
		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE_SLUG, 'gb_fixture_created' => 1 ), admin_url( 'tools.php' ) ) );
		exit;
	}

	private function create_batch( $recipients ) {
		$batch = gmdate( 'Ymd-His' ) . '-' . strtolower( wp_generate_password( 4, false, false ) );
		$rows = array();
		$mail_filters = array(
			'woocommerce_email_enabled_new_order',
			'woocommerce_email_enabled_customer_on_hold_order',
			'woocommerce_email_enabled_customer_processing_order',
			'woocommerce_email_enabled_customer_completed_order',
			'woocommerce_email_enabled_customer_invoice',
		);
		foreach ( $mail_filters as $filter ) {
			add_filter( $filter, '__return_false', 999 );
		}
		try {
			foreach ( $this->profiles() as $index => $profile ) {
				$course_id = $this->course_id( $profile['course_key'] );
				$recipient_key = $profile['recipient'] ?? '';
				$email = $recipient_key && ! empty( $recipients[ $recipient_key ] )
					? $recipients[ $recipient_key ]
					: 'gb-fixture-' . $batch . '-' . $profile['slug'] . '@test.invalid';
				$row = $this->create_fixture( $batch, $index + 1, $profile, $course_id, $email );
				if ( is_wp_error( $row ) ) {
					return array( 'batch' => $batch, 'rows' => $rows, 'error' => $row->get_error_message() );
				}
				$rows[] = $row;
			}
		} finally {
			foreach ( $mail_filters as $filter ) {
				remove_filter( $filter, '__return_false', 999 );
			}
		}
		return array( 'batch' => $batch, 'rows' => $rows, 'error' => '' );
	}

	private function create_fixture( $batch, $index, $profile, $course_id, $email ) {
		$names = array(
			array( 'Avery', 'Sample', 'female', '1991-02-14' ),
			array( 'Jordan', 'Progress', 'male', '1988-06-09' ),
			array( 'Taylor', 'Final', 'female', '1994-11-23' ),
			array( 'Morgan', 'Complete', 'male', '1985-04-18' ),
			array( 'Casey', 'English', 'female', '1990-01-15' ),
			array( 'Riley', 'Espanol', 'male', '1992-09-27' ),
		);
		$name = $names[ $index - 1 ];
		$display_name = $name[0] . ' ' . $name[1];
		$username = sanitize_user( 'gb-fixture-' . $batch . '-' . $profile['slug'], true );
		$user_id = wp_insert_user( array(
			'user_login' => $username,
			'user_pass' => wp_generate_password( 32, true, true ),
			'user_email' => $email,
			'first_name' => $name[0],
			'last_name' => $name[1],
			'display_name' => '[TEST] ' . $display_name,
			'role' => 'customer',
		) );
		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}
		if ( user_can( $user_id, 'manage_options' ) ) {
			return new WP_Error( 'gb_fixture_role', 'Fixture creation stopped because a generated user unexpectedly received administrator access.' );
		}
		$locale = 'adult_es' === $profile['course_key'] ? 'es-US' : 'en-US';
		update_user_meta( $user_id, self::MARKER, 'yes' );
		update_user_meta( $user_id, self::FIXTURE_MARKER, 'yes' );
		update_user_meta( $user_id, '_gb_test_fixture_batch', $batch );
		update_user_meta( $user_id, '_gb_test_fixture_stage', $profile['slug'] );
		update_user_meta( $user_id, '_gb_test_fixture_progress_percent', absint( $profile['progress'] ) );
		update_user_meta( $user_id, '_gb_test_fixture_course_id', $course_id );
		update_user_meta( $user_id, '_gb_cert_tdlr_first_name', $name[0] );
		update_user_meta( $user_id, '_gb_cert_tdlr_last_name', $name[1] );
		update_user_meta( $user_id, 'locale', $locale );
		update_user_meta( $user_id, 'gb_preferred_locale', $locale );
		$this->grant_internal_tester_access( $user_id );

		$order = $this->create_test_order( $user_id, $course_id, $locale, $batch, $profile, $display_name, $name[2], $name[3], $email );
		if ( is_wp_error( $order ) ) {
			return $order;
		}
		update_user_meta( $user_id, '_gb_ep_active_course_' . $course_id, $order->get_id() );
		$course_item_id = $this->ensure_course_record( $user_id, $course_id, $order->get_id(), ! empty( $profile['complete'] ) );
		if ( ! $course_item_id ) {
			return new WP_Error( 'gb_fixture_lp_course', 'LearnPress did not create the fixture course record for ' . $display_name . '.' );
		}
		if ( absint( $profile['progress'] ) > 0 ) {
			$this->add_lesson_progress( $user_id, $course_id, $course_item_id, absint( $profile['progress'] ) );
		}
		if ( ! empty( $profile['final'] ) ) {
			if ( ! $this->insert_mastery_evidence_without_triggering_issuance( $user_id, $course_id, $batch, $profile['slug'] ) ) {
				return new WP_Error( 'gb_fixture_mastery', 'The simulated Adult final evidence could not be created for ' . $display_name . '.' );
			}
		}
		return array(
			'label' => $profile['label'],
			'user_id' => $user_id,
			'name' => '[TEST] ' . $display_name,
			'email' => $email,
			'order_id' => $order->get_id(),
			'course_id' => $course_id,
			'expected' => ! empty( $profile['final'] ) && ! empty( $profile['complete'] ) ? 'Certificate eligible' : 'Certificate blocked',
		);
	}

	private function grant_internal_tester_access( $user_id ) {
		$registry = get_option( 'gb_course_registry', array() );
		$registry = is_array( $registry ) ? $registry : array();
		$ids = isset( $registry['_internal_tester_user_ids'] ) && is_array( $registry['_internal_tester_user_ids'] ) ? array_map( 'absint', $registry['_internal_tester_user_ids'] ) : array();
		$ids[] = absint( $user_id );
		$registry['_internal_tester_user_ids'] = array_values( array_unique( array_filter( $ids ) ) );
		update_option( 'gb_course_registry', $registry, false );
	}

	private function create_test_order( $user_id, $course_id, $locale, $batch, $profile, $legal_name, $gender, $dob, $email ) {
		try {
			$name_parts = preg_split( '/\s+/', trim( $legal_name ), 2 );
			$order = wc_create_order( array( 'customer_id' => $user_id ) );
			if ( is_wp_error( $order ) ) {
				return $order;
			}
			if ( class_exists( 'WC_Order_Item_Fee' ) ) {
				$item = new WC_Order_Item_Fee();
				$item->set_name( '[TEST FIXTURE — NO PAYMENT] ' . get_the_title( $course_id ) );
				$item->set_amount( 0 );
				$item->set_total( 0 );
				$order->add_item( $item );
			}
			$order->set_billing_first_name( $name_parts[0] ?? '' );
			$order->set_billing_last_name( $name_parts[1] ?? '' );
			$order->set_billing_email( $email );
			$order->set_payment_method( 'gb-test-fixture' );
			$order->set_payment_method_title( 'Gulf Breeze Test Fixture — no money collected' );
			$order->set_status( 'completed' );
			$order->set_date_paid( time() );
			$order->set_total( 0 );
			$order->update_meta_data( '_gb_ep_state', 'paid_enrolled' );
			$order->update_meta_data( '_gb_ep_student_user_id', $user_id );
			$order->update_meta_data( '_gb_ep_course_id', $course_id );
			$order->update_meta_data( '_gb_ep_locale', $locale );
			$order->update_meta_data( '_gb_ep_enrollment_processed', 'yes' );
			$order->update_meta_data( '_gb_ep_access_revoked', 'no' );
			$order->update_meta_data( '_gb_ep_contract_required', 'yes' );
			$order->update_meta_data( '_gb_ep_contract_signed_at_utc', gmdate( 'c' ) );
			$order->update_meta_data( '_gb_ep_test_account', 'yes' );
			$order->update_meta_data( '_gb_test_fixture', 'yes' );
			$order->update_meta_data( '_gb_test_fixture_batch', $batch );
			$order->update_meta_data( '_gb_test_fixture_stage', $profile['slug'] );
			$order->update_meta_data( '_gb_ep_contract_snapshot_json', wp_json_encode( array(
				'test_fixture' => true,
				'test_fixture_batch' => $batch,
				'source' => 'Gulf Breeze Test Student Fixtures ' . self::VERSION,
				'student' => array( 'legal_name' => $legal_name, 'email' => $email, 'dob' => $dob, 'gender' => $gender ),
			) ) );
			$order->save();
			$order->add_order_note( 'TEST FIXTURE ONLY: Administrator created this zero-dollar synthetic completed order for certificate-gate validation. No payment or PayPal transaction exists.' );
			$order->save();
			return $order;
		} catch ( Throwable $error ) {
			return new WP_Error( 'gb_fixture_order', 'The synthetic test order could not be created: ' . $error->getMessage() );
		}
	}

	private function ensure_course_record( $user_id, $course_id, $order_id, $complete ) {
		global $wpdb;
		$table = $wpdb->prefix . 'learnpress_user_items';
		try {
			$class = '\\LearnPress\\Models\\UserItems\\UserCourseModel';
			$item = $class::find( $user_id, $course_id, true );
			if ( ! $item ) {
				$item = new $class();
				$item->user_id = $user_id;
				$item->item_id = $course_id;
				$item->item_type = LP_COURSE_CPT;
				$item->status = 'enrolled';
				$item->graduation = 'in-progress';
				$item->ref_id = $order_id;
				$item->ref_type = 'woocommerce_order';
				$item->start_time = current_time( 'mysql', true );
				$item->save();
			}
		} catch ( Throwable $error ) {
			return 0;
		}
		$row_id = absint( $wpdb->get_var( $wpdb->prepare( "SELECT user_item_id FROM {$table} WHERE user_id=%d AND item_id=%d AND item_type='lp_course' ORDER BY user_item_id DESC LIMIT 1", $user_id, $course_id ) ) );
		if ( ! $row_id ) {
			return 0;
		}
		if ( $complete ) {
			$columns = $wpdb->get_col( "SHOW COLUMNS FROM {$table}", 0 );
			$data = array( 'status' => 'finished', 'graduation' => 'passed' );
			$now = current_time( 'mysql', true );
			foreach ( array( 'end_time', 'graduation_time', 'update_time' ) as $column ) {
				if ( in_array( $column, (array) $columns, true ) ) {
					$data[ $column ] = $now;
				}
			}
			$wpdb->update( $table, $data, array( 'user_item_id' => $row_id ) );
		}
		return $row_id;
	}

	private function add_lesson_progress( $user_id, $course_id, $course_item_id, $percent ) {
		global $wpdb;
		$sections = $wpdb->prefix . 'learnpress_sections';
		$section_items = $wpdb->prefix . 'learnpress_section_items';
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $sections ) ) !== $sections || $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $section_items ) ) !== $section_items ) {
			return 0;
		}
		$lesson_ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT si.item_id FROM {$sections} s INNER JOIN {$section_items} si ON si.section_id=s.section_id WHERE s.section_course_id=%d AND si.item_type='lp_lesson' ORDER BY s.section_order ASC,si.item_order ASC,si.section_item_id ASC",
			$course_id
		) );
		$count = count( (array) $lesson_ids );
		$limit = $percent >= 100 ? $count : (int) floor( $count * min( 99, max( 0, $percent ) ) / 100 );
		$added = 0;
		foreach ( array_slice( (array) $lesson_ids, 0, $limit ) as $lesson_id ) {
			if ( $this->insert_user_item( $user_id, absint( $lesson_id ), 'lp_lesson', $course_item_id ) ) {
				$added++;
			}
		}
		return $added;
	}

	private function insert_user_item( $user_id, $item_id, $item_type, $parent_id ) {
		global $wpdb;
		$table = $wpdb->prefix . 'learnpress_user_items';
		$existing = absint( $wpdb->get_var( $wpdb->prepare( "SELECT user_item_id FROM {$table} WHERE user_id=%d AND item_id=%d AND item_type=%s LIMIT 1", $user_id, $item_id, $item_type ) ) );
		if ( $existing ) {
			return true;
		}
		$columns = $wpdb->get_results( "SHOW FULL COLUMNS FROM {$table}", ARRAY_A );
		if ( ! $columns ) {
			return false;
		}
		$now = current_time( 'mysql', true );
		$known = array(
			'user_id' => $user_id,
			'item_id' => $item_id,
			'item_type' => $item_type,
			'status' => 'completed',
			'graduation' => 'passed',
			'start_time' => $now,
			'end_time' => $now,
			'graduation_time' => $now,
			'update_time' => $now,
			'ref_id' => 0,
			'ref_type' => 'gb_test_fixture',
			'parent_id' => $parent_id,
			'access_level' => 0,
		);
		$data = array();
		foreach ( $columns as $column ) {
			$field = $column['Field'];
			if ( false !== stripos( (string) $column['Extra'], 'auto_increment' ) ) {
				continue;
			}
			if ( array_key_exists( $field, $known ) ) {
				$data[ $field ] = $known[ $field ];
			} elseif ( 'YES' !== $column['Null'] && null === $column['Default'] ) {
				if ( preg_match( '/int|decimal|float|double|bit/i', $column['Type'] ) ) {
					$data[ $field ] = 0;
				} elseif ( preg_match( '/date|time/i', $column['Type'] ) ) {
					$data[ $field ] = $now;
				} else {
					$data[ $field ] = '';
				}
			}
		}
		return false !== $wpdb->insert( $table, $data );
	}

	private function insert_mastery_evidence_without_triggering_issuance( $user_id, $course_id, $batch, $stage ) {
		global $wpdb;
		$map = $this->adult_final_map( $course_id );
		if ( ! $map ) {
			return false;
		}
		$key = '_gbcmg_state_' . $this->mapping_id( $map );
		$required = max( 70, absint( $map['pass_percent'] ?? 70 ) );
		$score = max( 88, $required );
		$now = current_time( 'mysql', true );
		$state = array(
			'passed_at' => $now,
			'failed_at' => '',
			'fail_count' => 0,
			'attempt' => 1,
			'test_fixture' => true,
			'test_fixture_batch' => $batch,
			'test_fixture_stage' => $stage,
			'last_result' => array(
				'passed' => true,
				'score_percent' => $score,
				'correct_count' => 27,
				'shown_count' => 30,
				'attempt_no' => 1,
				'completed_at' => $now,
				'test_fixture' => true,
			),
		);
		$inserted = $wpdb->insert( $wpdb->usermeta, array( 'user_id' => $user_id, 'meta_key' => $key, 'meta_value' => maybe_serialize( $state ) ), array( '%d', '%s', '%s' ) );
		wp_cache_delete( $user_id, 'user_meta' );
		clean_user_cache( $user_id );
		return false !== $inserted;
	}
}

Gulf_Breeze_Test_Student_Fixtures::instance();
