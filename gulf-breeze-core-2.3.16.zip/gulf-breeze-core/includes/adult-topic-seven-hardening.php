<?php
/**
 * Adult English Topic 4.1.7 duration-hardening content.
 * Authored for Gulf Breeze Driving School / Rodney Crawford.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

return array(
'adult_en_032'=>
<<<'HTML'
<section class="gb-duration-hardening">
<h2>Roadway-user cooperation workshop</h2>
<p>Cooperation begins by recognizing that roadway users have different protection, visibility, speed, stopping ability, communication methods, and lawful reasons for occupying the road. A defensive driver searches for each user early and preserves enough time and space for another person’s mistake, limited ability, or unexpected movement.</p>
<h3>Pedestrians</h3>
<p>Search sidewalks, crosswalks, medians, shoulders, parking areas, bus stops, driveways, and both sides before turning. Children may run, older pedestrians may need more time, and a person using a wheelchair, white cane, guide dog, or other mobility aid may follow a path or pace the driver did not predict. Yield as required and never use the horn or vehicle movement to pressure a person.</p>
<h3>Bicyclists and motorcyclists</h3>
<p>A bicyclist may lawfully move left to avoid debris, pass, turn, or use a lane too narrow to share safely. Check mirrors and blind areas before crossing a bicycle lane or opening a door. A motorcycle is entitled to a full lane. Its narrow profile makes closing speed and distance difficult to judge. Look again, accept a larger gap, and leave generous following space. Never share the lane or assume a motorcycle signal will cancel automatically.</p>
<h3>Other lawful users</h3>
<p>Light rail cannot swerve and may be quiet. Do not stop on tracks or turn across them without a verified clear path. Approach horseback riders and horse-drawn vehicles slowly, avoid sudden noise, and leave wide clearance. Reduce closing speed early for slow-moving vehicles displaying the required emblem and pass only with lawful sight distance.</p>
<h3>Occupant protection</h3>
<p>Every occupant must use the restraint required by current Texas law. Children require the correct child passenger safety seat or belt for their age, size, and the governing requirement. A pickup bed is not ordinary seating. Texas restricts transporting children in open beds, and any unrestrained rider faces ejection, crushing, roadway debris, and cargo hazards.</p>
<h3>Defensive-driver responsibilities</h3>
<ul>
<li>Search early instead of reacting after a vulnerable user enters the path.</li>
<li>Control speed for sight distance and stopping space.</li>
<li>Communicate predictably without demanding right-of-way.</li>
<li>Leave lateral clearance and avoid blind-area travel.</li>
<li>Expect another user not to see or hear the vehicle.</li>
<li>Choose collision avoidance over proving who was legally correct.</li>
</ul>
<h3>Scenario lab</h3>
<ol>
<li>
<strong>A cyclist moves around a drain grate.</strong> Slow and leave space; do not force the cyclist toward the hazard.</li>
<li>
<strong>A motorcycle appears small before a left turn.</strong> Look again and wait for a clearly safe gap.</li>
<li>
<strong>A pedestrian remains in the crosswalk after your light turns green.</strong> Continue yielding.</li>
<li>
<strong>A horse reacts to traffic noise.</strong> Reduce speed and wait for ample passing clearance.</li>
<li>
<strong>A child passenger moves the shoulder belt behind the back.</strong> Stop safely and correct the restraint.</li>
<li>
<strong>A light-rail vehicle approaches while traffic blocks the far side.</strong> Remain before the tracks until the entire path is clear.</li>
</ol>
<details>
<summary>Classify and respond</summary>
<p>For each user, state their visibility, protection, maneuvering limits, possible lawful movement, the driver’s legal duty, and one extra reduced-risk action.</p>
</details>
<h3>Observation cycle</h3>
<p>Use a repeated far-to-near search: identify the roadway user, predict the likely path, check the space that user may need, and choose a speed that preserves a stop or escape. Repeat the search before every turn, lane movement, parking maneuver, and door opening. Darkness, rain, glare, parked vehicles, landscaping, and large vehicles can hide a person until the final seconds. When uncertainty remains, reduce speed and wait safely. A horn may warn of immediate danger, but it cannot transfer the driver’s yielding or collision-avoidance duty to a vulnerable user. Before proceeding, name the vulnerable user, likely conflict point, yielding duty, and the specific speed or space adjustment that protects them.</p>
</section>
HTML,
'adult_en_033'=>
<<<'HTML'
<section class="gb-duration-hardening">
<h2>Large, oversize, transit, and emergency-vehicle workshop</h2>
<p>Large and oversize vehicles need more room to turn, stop, accelerate, and change lanes. Their drivers also have areas where smaller vehicles are difficult or impossible to see. Cooperation does not mean surrendering all movement; it means avoiding positions and decisions that depend on the large vehicle performing like a passenger car.</p>
<h3>Blind areas and following distance</h3>
<p>If the truck driver cannot be seen in the mirror, assume the driver may not see your vehicle. Avoid lingering beside the cab, trailer, or immediately behind. Increase following distance so traffic controls, stopped vehicles, work zones, debris, and lane changes become visible before the truck blocks every escape choice.</p>
<h3>Wide turns and off-tracking</h3>
<p>A long vehicle may swing left before turning right, while rear wheels follow a tighter path than the front. Never enter the space between the vehicle and curb. Stop behind the line and allow the entire combination to complete the turn. Oversize loads may use escorts, unusual lane position, reduced speed, or additional turning space. Obey authorized directions and do not pass until the path is clearly lawful and safe.</p>
<h3>Passing large vehicles</h3>
<ol>
<li>Verify legal markings and enough visible distance.</li>
<li>Check behind and ahead before leaving the lane.</li>
<li>Signal and pass without remaining beside the vehicle.</li>
<li>Do not exceed lawful speed to complete a poor decision.</li>
<li>Return only when the full vehicle is safely visible and adequate space remains.</li>
<li>Never cut closely in front; the truck requires more stopping distance.</li>
</ol>
<h3>Buses and transit</h3>
<p>Buses stop frequently, obscure pedestrians, and require turning space. Expect people to cross near a stopped bus. Apply the school-bus stopping law when the vehicle, signals, and roadway meet the statutory conditions. Light rail follows tracks, cannot steer around a vehicle, and may approach quietly. Never queue or turn across its path without complete clearance.</p>
<h3>Emergency and covered stopped vehicles</h3>
<p>For an approaching authorized emergency vehicle using required signals, yield and position as current Texas law requires without entering a new conflict. For covered vehicles stopped on or beside the roadway, apply the current Move Over or Slow Down law. Move over only when the lane change is safe; otherwise slow as required and provide maximum practical clearance. Continue searching for responders, workers, people outside vehicles, debris, and redirected traffic.</p>
<h3>Scenario lab</h3>
<ol>
<li>
<strong>A truck swings left while signaling right.</strong> Stay behind; it may be creating turning space.</li>
<li>
<strong>You cannot see around a trailer.</strong> Increase distance rather than following closer for a view.</li>
<li>
<strong>An oversize load occupies part of two lanes.</strong> Do not squeeze past. Follow escorts or authorized directions.</li>
<li>
<strong>An ambulance approaches while you are in an intersection.</strong> Clear only as necessary, then yield and stop lawfully.</li>
<li>
<strong>A covered stopped vehicle is ahead and the adjacent lane is occupied.</strong> Reduce speed as required and provide clearance; do not force a lane change.</li>
<li>
<strong>A bus blocks the view of a crosswalk.</strong> Slow and search for people emerging from either side.</li>
</ol>
<details>
<summary>Space-planning check</summary>
<p>A complete answer identifies the large vehicle’s blind area, stopping distance, turning path, lawful passing opportunity, and the smaller vehicle’s escape option.</p>
</details>
<h3>Read vehicle clues</h3>
<p>Before acting, identify the vehicle type, length, load, warning devices, turn signal, wheel position, speed, and available roadway. A trailer may track toward a curb, swing outward, or respond later than the tractor. Wind, grades, wet pavement, and load weight can further change control and stopping. Preserve a place to escape instead of driving beside the vehicle with a barrier on the other side. If the large vehicle begins a lane movement, do not accelerate into the closing space merely because your vehicle was initially alongside. At night or in rain, increase the margin again because spray, glare, and reduced contrast can conceal the trailer outline, lane edge, escorts, workers, or another vehicle. Never assume clearance from one visible lamp; confirm the complete combination and the open space beyond it.</p>
</section>
HTML,
'adult_en_034'=>
<<<'HTML'
<section class="gb-duration-hardening">
<h2>Construction and maintenance work-zone decision lab</h2>
<p>A work zone is a changing traffic environment where workers, equipment, narrowed lanes, temporary surfaces, queues, drop-offs, and unfamiliar paths may appear close to moving vehicles. The driver must interpret active temporary controls and protect people who have little physical separation from traffic.</p>
<h3>Read the transition early</h3>
<p>Orange signs, channelizing devices, arrow displays, temporary markings, portable signals, flaggers, and law-enforcement directions may replace the normal path. Reduce speed before the taper or queue, increase following distance, identify the open lane, and merge cooperatively. Do not use a closing or closed lane to pass the queue or drive around a barricade.</p>
<h3>Flaggers and temporary controls</h3>
<p>A lawful flagger direction controls the active work operation. Stop where directed and remain stopped until released. Maintain enough distance so the flagger is visible and protected. A green permanent signal does not authorize driving through a flagger’s stop command. Temporary pavement markings and signs may supersede familiar permanent markings while work is active.</p>
<h3>Work-zone hazards</h3>
<ul>
<li>Workers on foot or entering from behind equipment</li>
<li>Slow or reversing construction vehicles</li>
<li>Uneven pavement, steel plates, loose material, and abrupt edges</li>
<li>Reduced shoulder and recovery space</li>
<li>Narrow lanes and opposing traffic separated by devices</li>
<li>Unexpected stopping and end-of-queue collisions</li>
<li>Night glare, dust, rain, noise, and confusing markings</li>
</ul>
<h3>Law and consequences</h3>
<p>Drivers must obey traffic laws and active controls in construction and maintenance work zones. Violations can produce fines and other penalties and can cause bodily injury, death, property damage, secondary crashes, and danger to workers and responders. A reduced speed is not merely a financial warning; it reflects limited space and rapidly changing risk.</p>
<h3>Safe-driving routine</h3>
<ol>
<li>Remove phone and cabin distractions before entry.</li>
<li>Read every active device and look far ahead for the queue.</li>
<li>Choose lane and speed early.</li>
<li>Increase space and avoid large-vehicle blind areas.</li>
<li>Use smooth braking and signals.</li>
<li>Obey flaggers and never follow a worker into a closed area.</li>
<li>Continue reduced-risk operation until the end sign and roadway conditions confirm the zone has ended.</li>
</ol>
<h3>Scenario lab</h3>
<ol>
<li>
<strong>A lane ends ahead while traffic is heavy.</strong> Merge cooperatively at the directed point without racing or blocking.</li>
<li>
<strong>A flagger stops your lane while the signal is green.</strong> Stop for the flagger.</li>
<li>
<strong>Temporary lines conflict with faint old markings.</strong> Follow the active temporary path and channelizing devices.</li>
<li>
<strong>A queue forms beyond a hill.</strong> Slow before sight distance is lost and activate warnings when appropriate.</li>
<li>
<strong>A worker stands near the lane edge.</strong> Reduce speed, maximize clearance, and avoid abrupt inputs.</li>
<li>
<strong>A vehicle follows too closely.</strong> Increase space ahead and remain predictable; do not speed through the zone.</li>
</ol>
<details>
<summary>Work-zone explanation</summary>
<p>Identify the temporary control, the worker or equipment exposure, the available recovery space, the correct speed and following adjustment, and the consequence of ignoring the control.</p>
</details>
<h3>Four-part zone search</h3>
<p>First, locate advance warnings and begin the speed and lane decision. Second, read the transition where normal traffic shifts, merges, or crosses temporary markings. Third, maintain disciplined spacing through the activity area, where workers and equipment are most exposed. Fourth, remain cautious through the termination area because shoulders, speeds, and traffic flow may not normalize immediately. At every stage, scan beyond the vehicle ahead so a growing queue does not become a surprise. Rear-end crashes are preventable when the driver creates early visibility and smooth, controlled, predictable deceleration.</p>
</section>
HTML,
'adult_en_035'=>
<<<'HTML'
<section class="gb-duration-hardening">
<h2>Crash-scene duties and Good Samaritan decisions</h2>
<p>A driver involved in a crash must stop and perform the duties required by current Texas law. The exact duties depend on injury, death, vehicle damage, location, and whether an unattended vehicle or other property is involved. Leaving because damage appears minor can turn one event into a more serious legal and safety problem.</p>
<h3>Prevent a second crash</h3>
<p>Stop as close as safely possible without unnecessarily blocking traffic. Activate hazard warnings, evaluate fire, traffic, fuel, electrical, cargo, and roadway dangers, and call emergency services when required. Do not stand in a travel lane or send an unprotected person into traffic. Move vehicles only when lawful, possible, and safer than leaving them in place.</p>
<h3>Aid and information</h3>
<p>Check for injuries, request medical help, and provide reasonable assistance within your ability. Do not move a seriously injured person unless an immediate danger such as fire or traffic requires it or a dispatcher directs you. Exchange the information required by law and cooperate with investigating officers. Provide accurate facts; avoid threats, roadside arguments, or speculation.</p>
<h3>Good Samaritan principle</h3>
<p>Good Samaritan protections are intended to encourage emergency assistance under the conditions established by law. They do not authorize reckless conduct, medical procedures beyond ability, or abandoning the statutory duties of a driver involved in the crash. Call trained help, follow dispatcher instructions, and provide aid you can safely and reasonably perform.</p>
<h3>Evidence and reporting</h3>
<p>When safe, note the location, time, vehicles, people, witnesses, controls, weather, and visible damage. Photographs should never delay care or place someone in traffic. Notify law enforcement and other required parties as current law and circumstances require. Insurance reporting is separate from emergency and statutory crash duties.</p>
<h3>Scenario lab</h3>
<ol>
<li>
<strong>A low-speed crash blocks an active lane.</strong> Stop and fulfill legal duties while protecting everyone from a secondary collision.</li>
<li>
<strong>A person reports neck pain.</strong> Call medical help and avoid unnecessary movement.</li>
<li>
<strong>The other driver becomes aggressive.</strong> Move to safety, avoid confrontation, and contact law enforcement.</li>
<li>
<strong>You strike an unattended vehicle.</strong> Follow the specific notice and information duties rather than leaving without documentation.</li>
<li>
<strong>Cargo spills into traffic.</strong> Report the hazard; do not enter a lane on foot unless authorities make it safe.</li>
<li>
<strong>A witness wants to leave.</strong> Request contact information without detaining or arguing.</li>
</ol>
<details>
<summary>Crash-duty sequence</summary>
<p>State the stop, scene-protection, injury, emergency-contact, assistance, information, reporting, and follow-up duties in the order they should occur without creating another hazard.</p>
</details>
<h3>Pause before acting</h3>
<p>A crash creates stress, noise, traffic exposure, and incomplete information. Take one controlled breath, secure the vehicle, and look for immediate threats before opening a door. State the location first when calling 911 so help can be sent if the connection ends. Describe injuries, fire, leaking material, blocked lanes, and hazards without diagnosing conditions you cannot verify. Assign specific safe tasks when capable bystanders are present, such as calling for help or warning people from a protected location, rather than allowing an uncoordinated crowd to enter traffic.</p>
</section>
HTML,
'adult_en_036'=>
<<<'HTML'
<section class="gb-duration-hardening">
<h2>Aggression, cargo, towing, carbon monoxide, and public responsibility</h2>
<h3>Disengage from aggressive driving</h3>
<p>Aggressive driving can include unsafe speed, following too closely, repeated abrupt lane changes, improper passing, failure to yield, hostile gestures, or using the vehicle to intimidate. Do not respond with eye contact, gestures, racing, brake-checking, blocking, or following. Create distance, allow the person to pass, change route if necessary, and drive to a populated safe location. Call emergency services when conduct creates immediate danger; do not drive home while being followed.</p>
<h3>Cargo and load security</h3>
<p>Distribute weight within vehicle and axle limits, secure items against forward, rearward, lateral, and upward movement, and recheck tie-downs during the trip. Keep the driver’s view, controls, lights, plate, and required equipment unobstructed. Loose tools, luggage, animals, furniture, or debris can shift control, strike occupants, fall into traffic, or cause another user to swerve.</p>
<h3>Towing and safety chains</h3>
<p>Use a vehicle, hitch, coupler, ball, wiring, brakes, tires, and mirrors rated and configured for the load. Attach required safety chains correctly so they provide a backup without dragging or binding. Connect lighting and braking systems, verify turn signals and brake lights, secure the load, and account for greater stopping distance, wider turns, sway, reduced acceleration, and limited backing visibility.</p>
<p>Before departure, perform a walk-around. After the first portion of travel, stop safely and recheck coupling, chains, electrical connections, tires, heat, and load security. Never allow a person to ride in or on a trailer unless specifically lawful and designed for that use.</p>
<h3>Carbon monoxide</h3>
<p>Carbon monoxide is colorless and odorless and can cause headache, dizziness, weakness, confusion, nausea, loss of consciousness, and death. Exhaust leaks, a running vehicle in an enclosed space, blocked exhaust outlets, idling near openings, and certain heating practices can allow accumulation. Never run a vehicle in a closed garage. Keep exhaust systems maintained, clear outlets from snow or debris, and move to fresh air and call emergency services if exposure is suspected.</p>
<h3>Litter prevention and loose debris</h3>
<p>Keep waste inside the vehicle until it reaches a proper receptacle. Secure pickup-bed and trailer contents so paper, plastic, glass, tools, and smoking material cannot escape. Roadway debris threatens tires, visibility, motorcyclists, bicyclists, workers, and emergency responders. If material falls, stop in a safe place and report a dangerous obstruction rather than walking into traffic.</p>
<h3>Scenario lab</h3>
<ol>
<li>
<strong>A driver follows and gestures.</strong> Do not engage. Create distance and go to a safe public location.</li>
<li>
<strong>A mattress is held only by hand.</strong> Do not move the vehicle; use proper securement.</li>
<li>
<strong>Trailer lights do not work.</strong> Repair them before travel.</li>
<li>
<strong>Safety chains drag.</strong> Reconnect them correctly with adequate clearance and required crossing/configuration.</li>
<li>
<strong>A person feels dizzy in an idling vehicle inside a garage.</strong> Move to fresh air and call emergency services.</li>
<li>
<strong>Packaging begins leaving a pickup bed.</strong> Stop safely and secure the load; do not continue creating hazards.</li>
</ol>
<details>
<summary>Pretrip responsibility check</summary>
<p>Explain how you will prevent aggression escalation, secure every load direction, verify towing connections, detect carbon-monoxide risk, and keep litter or debris from reaching the roadway.</p>
</details>
</section>
HTML,
);
