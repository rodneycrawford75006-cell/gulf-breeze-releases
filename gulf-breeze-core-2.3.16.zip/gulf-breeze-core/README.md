# Gulf Breeze Core 2.3.16 Development

Authored for Gulf Breeze Driving School / Rodney Crawford.

## Core 2.3.11 Course Flow enforcement repair

Repairs the live LearnPress integration for the Adult English regulated course. The secure timer now resolves the current lesson from the queried LearnPress object and verified course-section attachment instead of depending on a brittle runtime global. Required timing metadata fails closed. The timer hides and intercepts both Complete and Next until server-confirmed active time is satisfied. Server-side sequential enforcement blocks sidebar access and direct URLs unless the immediately preceding item is validly complete; a timed lesson requires a matching completed Gulf Breeze seat-time record rather than LearnPress completion alone.

Core 2.0.0 preserves the verified Adult English curriculum at 46 instructional lessons and 330 minutes. Its automatic migration adds seven zero-seat-time participation-check shells, one after each Topic 4.1.2–4.1.8 section, so Course Mastery Gate checks can occur without skipping an instructional lesson or placing internal question banks in the visible curriculum.

The course remains a draft and Under Construction protection remains unchanged. The migration does not import question banks, create mastery mappings, enroll users, change configuration values, or publish the course.

Core 2.1.0 adds two dedicated zero-seat-time video-check shells and verifies their positions immediately after the Topic 4.1.7 CSEA video and Topic 4.1.8 recreational-water-safety video. This placement is required by Video Quiz Gate and leaves each topic participation check after the video check.

Core 2.1.1 corrects initialization of the LearnPress course and section service when upgrading an installation whose 2.0.0 migration was already complete. The recovery is idempotent and safely reuses any video-check shell created before the interrupted 2.1.0 migration.


Core 2.2.0 corrects the post-import video-check placement. It promotes the two reviewed imported four-question video banks into the Adult English course immediately after the required CSEA and recreational-water-safety videos, retires rather than deletes the empty 2.1 placeholder quizzes, preserves any existing Video Quiz Gate mapping that referenced a placeholder, and refuses to finalize unless the regulated ledger remains exactly 46 instructional lessons / 330 minutes.


## Core 2.2.1

Corrects the production-only LearnPress curriculum-cache edge case discovered during the 2.2.0 video-bank migration. The 2.2.0 migration could retire a placeholder directly in the database and then call LearnPress `add_items_section()`, whose cached curriculum could silently reinsert that retired placeholder. Core 2.2.1 places each already-reviewed imported video bank directly into its verified target section, explicitly reorders the section, verifies the placeholder is absent, and preserves the locked 46-lesson / 330-minute instructional ledger.

## Core 2.3.0 development hardening

Adds explicit Gulf Breeze instruction for three May 2026 POI course-wide subjects missing from the prior installed lesson content: anatomical gifts, litter prevention, and leaving children unattended in vehicles. The retry-safe migration updates three existing lesson records without adding a lesson or changing a timer, verifies the Adult English ledger remains exactly 46 lessons / 330 minutes, and corrects crosswalk labels that previously understated 4.1.5.1(J) and 4.1.7.1(M).

This remains a development build. It must not be published or deployed until the full Adult English objective, instructional-duration, assessment, video-enforcement, accessibility, migration, and ownership audits pass.

## Core 2.3.1 development hardening

Expands all five Topic 4.1.6 lessons with substantive instruction, Texas-law distinctions, impairment analysis, medication and combination safety, consequence mapping, decision scenarios, and guided safe-ride/intervention practice. The development duration screen now requires each Topic 4.1.6 lesson to support at least 120 readable words per assigned minute before qualitative activity credit. No timer or lesson count changes.

## Core 2.3.2 development hardening

Rebuilds the three Topic 4.1.9 instructional-review lessons as a highway-sign observation workshop, a traffic-law application workshop, and a comprehensive licensing-readiness decision lab. The migration refuses to complete unless every lesson contains at least 120 readable words per assigned minute; the sign lesson additionally requires at least ten instructional sign graphics. The 52-minute Topic 4.1.9 allocation is unchanged, and the separately controlled final assessment remains zero seat time.

## Core 2.3.3 development hardening

Topic 4.1.7 non-video duration hardening with strict installed-content word screening.

## Core 2.3.4 development hardening

Topic 4.1.8 non-video duration hardening with strict installed-content word screening.

## Core 2.3.5 development hardening

Topic 4.1.5 duration hardening for speed and stopping, lane use, turning and communication, passing, and freeway/emergency/work-zone procedures. The retry-safe migration requires exactly five expansions, verifies every installed lesson at 120 readable words per assigned minute, and refuses to finalize unless the Adult English ledger remains 46 lessons and 330 minutes.

## Core 2.3.6 development hardening

Topic 4.1.4 duration and visual-observation hardening for all six traffic-control-device lessons. Each lesson now requires substantive device comparison, prediction, and roadway-application work; the migration preserves the installed sign galleries, verifies at least 120 readable words per assigned minute, and refuses to finalize unless the Adult English ledger remains 46 lessons and 330 minutes.

## Core 2.3.7 development hardening

Topic 4.1.3 duration hardening for right-of-way, traditional and nontraditional intersections, turns and roadway entry, pedestrians and school crossings, school buses and emergency/roadside vehicles, and railroad crossings. The migration requires exactly six expansions, remeasures installed content at 120 readable words per assigned minute, and preserves the 46-lesson / 330-minute ledger.

## Core 2.3.8 development hardening

Topic 4.1.2 duration hardening for Texas driver-license application pathways, license classes and credential limits, suspension/revocation/renewal and individualized reinstatement, vehicle registration and the post-2025 inspection framework, financial responsibility, and the Texas Driving with Disability Program. The migration requires exactly five ordered expansions, resolves each lesson by its Gulf Breeze blueprint key, replaces only its own retry marker, screens installed content at 120 readable words per assigned minute, and refuses to finalize unless the Adult English ledger remains exactly 46 lessons / 330 minutes.

## Core 2.3.9 development hardening

Topic 4.1.1 qualitative and duration hardening for course purpose, active online study, identity and participation-record integrity, assessment conduct, lifelong learning, and repeatable reduced-risk decision making. The migration requires exactly four ordered expansions, replaces only its own retry marker, screens every installed lesson at 120 readable words per assigned minute, and preserves the 46-lesson / 330-minute ledger.

Expands all five non-video Topic 4.1.7 lessons with roadway-user cooperation, large-vehicle interaction, work-zone decisions, crash-scene duties, and aggression/cargo/towing/carbon-monoxide/litter instruction. The retry-safe migration refuses to finalize unless every affected lesson contains at least 120 readable words per assigned minute and the regulated ledger remains exactly 46 lessons / 330 minutes.

This checkpoint does not resolve CSEA video playback enforcement. The separate Video Quiz Gate review found that the installed gate verifies LearnPress completion state rather than actual media playback. A Gulf Breeze-only playback-evidence implementation and formal PHP/runtime testing remain release blockers.

## Core 2.3.10 controlled student-path testing

Adds an administrator-managed allowlist of WordPress user IDs for internal browser testing. An approved tester may open only regulated course objects mapped to a course whose registry status is `Internal testing`. Administrators retain their existing access, while every other visitor or authenticated user continues to receive a 404.

This checkpoint does not grant administrative capabilities, make an approval claim, alter Under Construction settings, change course publication, or change the regulated 46-lesson / 330-minute ledger.

## Core 2.3.14 LearnPress course-model synchronization repair

Repairs the verified LearnPress 4.4.4 two-store section-description failure. Core 2.3.13 wrote and reread `learnpress_sections`, but LearnPress's course editors rendered the denormalized CourseModel JSON stored in `learnpress_courses`; clearing the ordinary model cache did not rebuild that stored course structure. Core 2.3.14 updates each of the nine regulated sections through LearnPress's native `CourseSectionModel` and `CoursePostModel` save path, then proves a fresh CourseModel contains the exact student-facing descriptions before marking the migration complete.

The migration fails closed unless Course #21 retains exactly nine sections, 46 lessons, 10 quizzes, and the identical ordered 56-item curriculum signature. It is retry-safe after a partial interruption, preserves course and lesson content except for the previously approved exact private-self-check replacement, and leaves publication, enrollment, timing, access, Under Construction, and licensing status unchanged.

## Core 2.3.15 Topic 4.1.7 duration-resume correction

Corrects the verified five-word shortfall in the `adult_en_032` Topic 4.1.7 hardening source. The existing fail-closed `2.3.3` curriculum migration can now satisfy the strict 120-readable-words-per-assigned-minute screen and continue through the already-defined `2.3.4`–`2.3.9` hardening sequence.

The resumed sequence remains additive and retry-safe. It must preserve the published course, all nine sections, the exact ordered 46-lesson/10-quiz/56-item curriculum identity, the locked 330-minute ledger, public section descriptions, closed comments and pings, controlled tester access, and Under Construction status.

The LearnPress cache-refresh helper now invalidates model and post caches without rewriting the parent course status. An existing draft remains draft, while a course published for protected internal testing remains published.

## Core 2.3.16 bounded migration recovery

Permanently removes curriculum and privacy migrations from ordinary `wp-admin` request execution. Administrator requests now perform only a constant-time scheduling check; the actual work runs in background events protected by one atomic database lock.

Each background curriculum run advances at most one versioned checkpoint, records its exact target and result, and schedules the next checkpoint separately. A failed checkpoint waits before retrying, repeated failures receive a longer cooldown, and a stale-lock watchdog safely resumes work after an interrupted or fatal request. Concurrent workers cannot enter the migration body together.

This corrects the Core 2.3.15 failure mode in which multiple administrator requests could simultaneously repeat the unfinished 2.3.3–2.3.9 content-hardening chain. No threshold, lesson content, course status, timer, access rule, privacy rule, or Under Construction behavior is relaxed.
