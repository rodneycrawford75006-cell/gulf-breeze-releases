<?php
/**
 * Plugin Name: Gulf Breeze Core
 * Description: Permanent modular foundation for Gulf Breeze configuration, course compliance, enrollment, payments, records, certificates, reporting, and system health.
 * Version: 2.3.16-dev
 * Author: Gulf Breeze Driving School / Rodney Crawford
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Gulf_Breeze_Configuration {
	const OPTION = 'gb_config';
	const PAGE   = 'gulf-breeze-configuration';
	const COURSE_OPTION = 'gb_course_registry';
	const CURRICULUM_MIGRATION_TARGET = '2.3.9';
	const PRIVACY_MIGRATION_TARGET = '2.3.14';
	const MIGRATION_LOCK_OPTION = 'gb_core_migration_lock';
	const MIGRATION_RUNTIME_OPTION = 'gb_core_migration_runtime';

	private static $instance;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'define_core_constants' ), 1 );
		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_init', array( $this, 'schedule_background_migrations' ), 20 );
		add_action( 'gb_core_run_curriculum_migrations', array( $this, 'run_verified_curriculum_migrations' ) );
		add_action( 'gb_core_run_privacy_migration', array( $this, 'run_student_facing_privacy_migration' ) );
		add_action( 'gb_core_migration_watchdog', array( $this, 'migration_watchdog' ) );
		add_action( 'admin_post_gb_create_course_shells', array( $this, 'create_course_shells' ) );
		add_action( 'admin_post_gb_build_adult_english_shells', array( $this, 'build_adult_english_shells' ) );
		add_action( 'admin_post_gb_build_adult_topic_one', array( $this, 'build_adult_topic_one' ) );
		add_action( 'admin_post_gb_build_adult_topic_two', array( $this, 'build_adult_topic_two' ) );
		add_action( 'admin_post_gb_build_adult_topic_three', array( $this, 'build_adult_topic_three' ) );
		add_action( 'admin_post_gb_build_adult_topic_four', array( $this, 'build_adult_topic_four' ) );
		add_action( 'admin_post_gb_build_adult_topic_five', array( $this, 'build_adult_topic_five' ) );
		add_action( 'admin_post_gb_export_timer_audit', array( $this, 'export_timer_audit' ) );
		add_action( 'init', array( $this, 'install_seat_time_schema' ), 5 );
		add_action( 'init', array( $this, 'block_early_lesson_completion' ), 0 );
		add_action( 'init', array( $this, 'disable_lms_comment_support' ), 100 );
		add_action( 'template_redirect', array( $this, 'start_student_facing_output_filter' ), 0 );
		add_filter( 'comments_open', array( $this, 'close_lms_comments' ), 100, 2 );
		add_filter( 'pings_open', array( $this, 'close_lms_comments' ), 100, 2 );
		add_filter( 'comments_array', array( $this, 'hide_lms_comments' ), 100, 2 );
		add_filter( 'wp_insert_post_data', array( $this, 'close_future_lms_comments' ), 100, 2 );
		add_action( 'wp_footer', array( $this, 'hide_internal_frontend_notices' ), 100 );
		add_action( 'wp_ajax_gb_seat_start', array( $this, 'ajax_seat_start' ) );
		add_action( 'wp_ajax_gb_seat_heartbeat', array( $this, 'ajax_seat_heartbeat' ) );
		add_action( 'wp_ajax_gb_seat_complete', array( $this, 'ajax_seat_complete' ) );
		add_filter( 'the_content', array( $this, 'inject_seat_time_controller' ), 20 );
		add_action( 'learnpress/course/item/can-view', array( $this, 'enforce_course_item_sequence' ), 9, 2 );
		add_filter( 'learn-press/course/item/status-ico-flag', array( $this, 'filter_sequence_status_icon' ), 9, 5 );
		add_action( 'admin_notices', array( $this, 'admin_notice' ) );
		add_action( 'admin_init', array( $this, 'protect_admin_boundary' ), 0 );
		add_action( 'after_setup_theme', array( $this, 'hide_admin_toolbar' ) );
		add_filter( 'show_admin_bar', array( $this, 'filter_admin_toolbar' ), 99 );
		add_action( 'template_redirect', array( $this, 'protect_internal_course_objects' ), 0 );
		add_action( 'template_redirect', array( $this, 'redirect_locked_course_item' ), 1 );
		add_filter( 'wp_sitemaps_post_types', array( $this, 'exclude_lms_from_sitemaps' ) );
		add_filter( 'wp_robots', array( $this, 'noindex_lms_objects' ) );
		add_shortcode( 'gb_setting', array( $this, 'setting_shortcode' ) );
	}

	public function define_core_constants() {
		if ( ! defined( 'GB_CORE_VERSION' ) ) {
			define( 'GB_CORE_VERSION', '2.3.16-dev' );
		}
	}

	public static function activate() {
		if ( ! wp_next_scheduled( 'gb_core_run_curriculum_migrations' ) ) {
			wp_schedule_single_event( time() + 10, 'gb_core_run_curriculum_migrations' );
		}
		if ( ! wp_next_scheduled( 'gb_core_run_privacy_migration' ) ) {
			wp_schedule_single_event( time() + 20, 'gb_core_run_privacy_migration' );
		}
	}

	private static function curriculum_migration_versions() {
		return array(
			'1.6.0', '1.7.0', '1.8.0', '1.9.0', '2.0.0', '2.1.0', '2.2.1',
			'2.3.0', '2.3.1', '2.3.2', '2.3.3', '2.3.4', '2.3.5', '2.3.6',
			'2.3.7', '2.3.8', '2.3.9',
		);
	}

	private function next_curriculum_migration_version() {
		$current = (string) get_option( 'gb_curriculum_migration_version', '' );
		foreach ( self::curriculum_migration_versions() as $version ) {
			if ( version_compare( $current, $version, '<' ) ) {
				return $version;
			}
		}
		return '';
	}

	public function schedule_background_migrations() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$runtime = get_option( self::MIGRATION_RUNTIME_OPTION, array() );
		$blocked_until = absint( is_array( $runtime ) ? ( $runtime['blocked_until'] ?? 0 ) : 0 );
		if ( $blocked_until > time() ) {
			return;
		}
		if ( '' !== $this->next_curriculum_migration_version() ) {
			$this->schedule_single_migration_event( 'gb_core_run_curriculum_migrations', 5 );
			return;
		}
		if ( version_compare( (string) get_option( 'gb_student_privacy_migration_version', '' ), self::PRIVACY_MIGRATION_TARGET, '<' ) ) {
			$this->schedule_single_migration_event( 'gb_core_run_privacy_migration', 5 );
		}
	}

	private function schedule_single_migration_event( $hook, $delay ) {
		if ( ! wp_next_scheduled( $hook ) ) {
			wp_schedule_single_event( time() + max( 1, absint( $delay ) ), $hook );
		}
	}

	public function migration_watchdog() {
		$runtime = get_option( self::MIGRATION_RUNTIME_OPTION, array() );
		$blocked_until = absint( is_array( $runtime ) ? ( $runtime['blocked_until'] ?? 0 ) : 0 );
		if ( $blocked_until > time() ) {
			$this->schedule_single_migration_event( 'gb_core_migration_watchdog', ( $blocked_until - time() ) + 1 );
			return;
		}
		if ( '' !== $this->next_curriculum_migration_version() ) {
			$this->schedule_single_migration_event( 'gb_core_run_curriculum_migrations', 1 );
			return;
		}
		if ( version_compare( (string) get_option( 'gb_student_privacy_migration_version', '' ), self::PRIVACY_MIGRATION_TARGET, '<' ) ) {
			$this->schedule_single_migration_event( 'gb_core_run_privacy_migration', 1 );
		}
	}

	private function acquire_migration_lock() {
		$now   = time();
		$token = wp_generate_uuid4() . '|' . $now;
		if ( add_option( self::MIGRATION_LOCK_OPTION, $token, '', false ) ) {
			return $token;
		}
		$current = (string) get_option( self::MIGRATION_LOCK_OPTION, '' );
		$parts   = explode( '|', $current );
		$started = absint( end( $parts ) );
		if ( $started && ( $now - $started ) <= 900 ) {
			return '';
		}
		global $wpdb;
		$deleted = $wpdb->query( $wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s",
			self::MIGRATION_LOCK_OPTION,
			$current
		) );
		wp_cache_delete( self::MIGRATION_LOCK_OPTION, 'options' );
		return $deleted && add_option( self::MIGRATION_LOCK_OPTION, $token, '', false ) ? $token : '';
	}

	private function release_migration_lock( $token ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s",
			self::MIGRATION_LOCK_OPTION,
			(string) $token
		) );
		wp_cache_delete( self::MIGRATION_LOCK_OPTION, 'options' );
	}

	private function finish_curriculum_worker( $before_version, $target_version ) {
		$after_version = (string) get_option( 'gb_curriculum_migration_version', '' );
		if ( version_compare( $after_version, $before_version, '>' ) ) {
			update_option( self::MIGRATION_RUNTIME_OPTION, array(
				'status' => 'checkpoint_complete', 'target' => $target_version,
				'version' => $after_version, 'attempts' => 0, 'updated_at' => time(),
			), false );
			if ( '' !== $this->next_curriculum_migration_version() ) {
				$this->schedule_single_migration_event( 'gb_core_run_curriculum_migrations', 5 );
			} else {
				$this->schedule_single_migration_event( 'gb_core_run_privacy_migration', 5 );
			}
			return;
		}

		$runtime = get_option( self::MIGRATION_RUNTIME_OPTION, array() );
		$attempts = is_array( $runtime ) && ( $runtime['target'] ?? '' ) === $target_version ? absint( $runtime['attempts'] ?? 0 ) + 1 : 1;
		$delay = $attempts >= 3 ? 3600 : 300;
		update_option( self::MIGRATION_RUNTIME_OPTION, array(
			'status' => 'retry_wait', 'target' => $target_version, 'version' => $after_version,
			'attempts' => $attempts, 'blocked_until' => time() + $delay, 'updated_at' => time(),
		), false );
		$this->schedule_single_migration_event( 'gb_core_run_curriculum_migrations', $delay );
	}

	private static function student_section_descriptions() {
		return array(
			'4.1.1' => 'Learn how the course works, what completion requires, and how responsible driving begins with informed choices.',
			'4.1.2' => 'Review driver licensing, lawful vehicle use, and the responsibilities that come with operating a motor vehicle.',
			'4.1.3' => 'Practice recognizing right-of-way duties and choosing actions that reduce conflict at intersections and crossings.',
			'4.1.4' => 'Learn to recognize and respond correctly to traffic signs, signals, pavement markings, and other roadway controls.',
			'4.1.5' => 'Build safe vehicle-control, speed-management, positioning, communication, and roadway-use habits.',
			'4.1.6' => 'Examine how alcohol and other drugs affect driving ability, legal responsibility, and crash risk.',
			'4.1.7' => 'Learn how to share the roadway safely with pedestrians, cyclists, motorcyclists, large vehicles, and other road users.',
			'4.1.8' => 'Apply observation, space management, speed control, and sound judgment to identify and reduce driving risk.',
			'4.1.9' => 'Review the course concepts and demonstrate readiness for the controlled final assessment.',
		);
	}

	public function disable_lms_comment_support() {
		foreach ( array( 'lp_course', 'lp_lesson', 'lp_quiz' ) as $post_type ) {
			remove_post_type_support( $post_type, 'comments' );
			remove_post_type_support( $post_type, 'trackbacks' );
		}
	}

	public function close_lms_comments( $open, $post_id ) {
		return in_array( get_post_type( $post_id ), array( 'lp_course', 'lp_lesson', 'lp_quiz' ), true ) ? false : $open;
	}

	public function hide_lms_comments( $comments, $post_id ) {
		return in_array( get_post_type( $post_id ), array( 'lp_course', 'lp_lesson', 'lp_quiz' ), true ) ? array() : $comments;
	}

	public function close_future_lms_comments( $data, $postarr ) {
		if ( in_array( $data['post_type'] ?? '', array( 'lp_course', 'lp_lesson', 'lp_quiz' ), true ) ) {
			$data['comment_status'] = 'closed';
			$data['ping_status'] = 'closed';
		}
		return $data;
	}

	public function hide_internal_frontend_notices() {
		if ( current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<script>
		document.addEventListener('DOMContentLoaded',function(){
			var marker=document.querySelector('a[href*="action=ucp_dismiss_notice"]');
			if(!marker){return;}
			var notice=marker.parentElement;
			if(notice&&notice!==document.body&&notice.textContent.indexOf('Under Construction Mode is enabled')!==-1){notice.remove();}
		});
		</script>
		<?php
	}

	public function start_student_facing_output_filter() {
		if ( is_admin() || current_user_can( 'manage_options' ) ) {
			return;
		}
		ob_start( array( $this, 'filter_student_facing_output' ) );
	}

	public function filter_student_facing_output( $html ) {
		foreach ( self::student_section_descriptions() as $topic => $description ) {
			$html = str_replace( 'Internal Gulf Breeze POI curriculum section ' . $topic . '.', esc_html( $description ), $html );
		}
		return $html;
	}

	public function run_student_facing_privacy_migration() {
		$target_version = self::PRIVACY_MIGRATION_TARGET;
		if ( version_compare( (string) get_option( 'gb_student_privacy_migration_version', '' ), $target_version, '>=' ) ) {
			return;
		}
		if ( version_compare( (string) get_option( 'gb_curriculum_migration_version', '' ), self::CURRICULUM_MIGRATION_TARGET, '<' ) ) {
			return;
		}
		$lock_token = $this->acquire_migration_lock();
		if ( '' === $lock_token ) {
			return;
		}
		$this->schedule_single_migration_event( 'gb_core_migration_watchdog', 960 );
		try {
		$registry  = get_option( self::COURSE_OPTION, array() );
		$course_id = absint( $registry['adult_en']['learnpress_course_id'] ?? 0 );
		if ( ! $course_id || 'lp_course' !== get_post_type( $course_id ) ) {
			return;
		}
		global $wpdb;
		$sections_table = $wpdb->prefix . 'learnpress_sections';
		$items_table    = $wpdb->prefix . 'learnpress_section_items';
		$descriptions   = self::student_section_descriptions();
		$sections = $wpdb->get_results( $wpdb->prepare(
			"SELECT section_id, section_name, section_order, section_description FROM {$sections_table} WHERE section_course_id = %d ORDER BY section_order ASC, section_id ASC",
			$course_id
		) );
		if ( ! empty( $wpdb->last_error ) || 9 !== count( (array) $sections ) ) {
			update_option( 'gb_student_privacy_migration_status', array( 'status' => 'error', 'message' => 'Student-facing privacy migration could not read the regulated course sections.', 'time' => current_time( 'mysql', true ) ), false );
			return;
		}

		$curriculum_rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT s.section_id, s.section_order, si.item_id, si.item_order, si.item_type FROM {$sections_table} s INNER JOIN {$items_table} si ON si.section_id = s.section_id WHERE s.section_course_id = %d ORDER BY s.section_order ASC, s.section_id ASC, si.item_order ASC, si.item_id ASC",
			$course_id
		), ARRAY_A );
		$lesson_count = 0;
		$quiz_count   = 0;
		foreach ( (array) $curriculum_rows as $curriculum_row ) {
			$lesson_count += 'lp_lesson' === ( $curriculum_row['item_type'] ?? '' ) ? 1 : 0;
			$quiz_count   += 'lp_quiz' === ( $curriculum_row['item_type'] ?? '' ) ? 1 : 0;
		}
		if ( ! empty( $wpdb->last_error ) || 56 !== count( (array) $curriculum_rows ) || 46 !== $lesson_count || 10 !== $quiz_count ) {
			update_option( 'gb_student_privacy_migration_status', array( 'status' => 'error', 'message' => 'Student-facing privacy migration stopped because the regulated curriculum ledger was not exact.', 'time' => current_time( 'mysql', true ) ), false );
			return;
		}
		$curriculum_signature = wp_json_encode( $curriculum_rows );

		if (
			! class_exists( '\\LearnPress\\Models\\CourseModel' ) ||
			! class_exists( '\\LearnPress\\Models\\CoursePostModel' ) ||
			! class_exists( '\\LearnPress\\Models\\CourseSectionModel' )
		) {
			update_option( 'gb_student_privacy_migration_status', array( 'status' => 'error', 'message' => 'Student-facing privacy migration is waiting for the LearnPress course models.', 'time' => current_time( 'mysql', true ) ), false );
			return;
		}

		try {
			$course_model = \LearnPress\Models\CourseModel::find( $course_id, false );
			if ( ! $course_model ) {
				throw new RuntimeException( 'The regulated LearnPress course model could not be loaded.' );
			}
			$course_post_model = new \LearnPress\Models\CoursePostModel( $course_model );
			$updated_topics    = array();

			foreach ( (array) $sections as $section ) {
				$matched_topic = '';
				foreach ( $descriptions as $topic => $description ) {
					if ( 0 === strpos( (string) $section->section_name, 'Topic ' . $topic ) ) {
						$matched_topic = $topic;
						break;
					}
				}
				if ( '' === $matched_topic || isset( $updated_topics[ $matched_topic ] ) ) {
					throw new RuntimeException( 'The regulated topic-section mapping was incomplete or duplicated.' );
				}

				$section_id    = absint( $section->section_id );
				$description   = $descriptions[ $matched_topic ];
				$section_model = \LearnPress\Models\CourseSectionModel::find( $section_id, $course_id, false );
				if ( ! $section_model ) {
					throw new RuntimeException( 'A regulated LearnPress section model could not be loaded.' );
				}

				// Use LearnPress's native save path so both the section row and denormalized
				// course JSON are synchronized and the correct model caches are invalidated.
				$course_post_model->update_section( $section_model, array( 'section_description' => $description ) );
				$stored = (string) $wpdb->get_var( $wpdb->prepare( "SELECT section_description FROM {$sections_table} WHERE section_id = %d AND section_course_id = %d", $section_id, $course_id ) );
				if ( $stored !== $description ) {
					throw new RuntimeException( 'A regulated section row did not retain its exact student-facing description.' );
				}
				$updated_topics[ $matched_topic ] = $section_id;
			}

			if ( 9 !== count( $updated_topics ) || array() !== array_diff_key( $descriptions, $updated_topics ) ) {
				throw new RuntimeException( 'Not all nine regulated topic descriptions were synchronized.' );
			}

			$fresh_course_model = \LearnPress\Models\CourseModel::find( $course_id, false );
			if ( ! $fresh_course_model || ! method_exists( $fresh_course_model, 'get_section_items' ) ) {
				throw new RuntimeException( 'The refreshed LearnPress course model could not be verified.' );
			}
			$model_topics = array();
			foreach ( (array) $fresh_course_model->get_section_items() as $model_section ) {
				foreach ( $descriptions as $topic => $description ) {
					if ( 0 === strpos( (string) ( $model_section->section_name ?? '' ), 'Topic ' . $topic ) ) {
						if ( isset( $model_topics[ $topic ] ) || (string) ( $model_section->section_description ?? '' ) !== $description ) {
							throw new RuntimeException( 'The refreshed LearnPress course model did not contain the exact section descriptions.' );
						}
						$model_topics[ $topic ] = true;
						break;
					}
				}
			}
			if ( 9 !== count( $model_topics ) || array() !== array_diff_key( $descriptions, $model_topics ) ) {
				throw new RuntimeException( 'The refreshed LearnPress course model was missing a regulated topic.' );
			}
		} catch ( Throwable $e ) {
			update_option( 'gb_student_privacy_migration_status', array( 'status' => 'error', 'message' => 'Student-facing section synchronization failed: ' . sanitize_text_field( $e->getMessage() ), 'time' => current_time( 'mysql', true ) ), false );
			return;
		}

		$item_ids = array_map( 'absint', (array) $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT si.item_id FROM {$items_table} si INNER JOIN {$sections_table} s ON s.section_id = si.section_id WHERE s.section_course_id = %d",
			$course_id
		) ) );
		$legacy_prompt = '<strong>Before continuing:</strong> Explain the lesson rule in your own words and identify the action that reduces risk. If you cannot do both without looking, review the lesson and the official source again.';
		$student_prompt = '<strong>Private self-check — no submission required:</strong> Explain the lesson rule aloud or in your own private notes, then identify the action that reduces risk. If you cannot explain both without looking, review the lesson and official source before continuing.';
		foreach ( array_merge( array( $course_id ), $item_ids ) as $post_id ) {
			$post_id = absint( $post_id );
			if ( ! $post_id ) {
				continue;
			}
			$fields = array( 'comment_status' => 'closed', 'ping_status' => 'closed' );
			$formats = array( '%s', '%s' );
			if ( 'lp_lesson' === get_post_type( $post_id ) ) {
				$content = (string) get_post_field( 'post_content', $post_id );
				if ( false !== strpos( $content, $legacy_prompt ) ) {
					$fields['post_content'] = str_replace( $legacy_prompt, $student_prompt, $content );
					$formats[] = '%s';
				}
			}
			$result = $wpdb->update( $wpdb->posts, $fields, array( 'ID' => $post_id ), $formats, array( '%d' ) );
			if ( false === $result ) {
				update_option( 'gb_student_privacy_migration_status', array( 'status' => 'error', 'message' => 'Student-facing privacy migration could not update post ' . $post_id . '.', 'time' => current_time( 'mysql', true ) ), false );
				return;
			}
			clean_post_cache( $post_id );
		}
		$curriculum_rows_after = $wpdb->get_results( $wpdb->prepare(
			"SELECT s.section_id, s.section_order, si.item_id, si.item_order, si.item_type FROM {$sections_table} s INNER JOIN {$items_table} si ON si.section_id = s.section_id WHERE s.section_course_id = %d ORDER BY s.section_order ASC, s.section_id ASC, si.item_order ASC, si.item_id ASC",
			$course_id
		), ARRAY_A );
		if ( $curriculum_signature !== wp_json_encode( $curriculum_rows_after ) ) {
			update_option( 'gb_student_privacy_migration_status', array( 'status' => 'error', 'message' => 'Student-facing privacy migration stopped because curriculum identity or ordering changed.', 'time' => current_time( 'mysql', true ) ), false );
			return;
		}

		clean_post_cache( $course_id );
		update_option( 'gb_student_privacy_migration_version', $target_version, false );
		update_option( 'gb_student_privacy_migration_status', array(
			'status'  => 'success',
			'message' => 'Student-facing privacy migration synchronized all nine LearnPress section descriptions, preserved the exact curriculum ledger, closed course comments, and clarified private self-check directions.',
			'time'    => current_time( 'mysql', true ),
		), false );
		} finally {
			$this->release_migration_lock( $lock_token );
		}
	}

	private function seat_time_table() {
		global $wpdb;
		return $wpdb->prefix . 'gb_seat_time';
	}

	private function refresh_learnpress_course_cache( $course_id ) {
		$course_id = absint( $course_id );
		if ( ! $course_id ) {
			return;
		}
		clean_post_cache( $course_id );
		if ( class_exists( '\\LearnPress\\Models\\CourseModel' ) ) {
			$model = \LearnPress\Models\CourseModel::find( $course_id, false );
			if ( $model && method_exists( $model, 'clean_caches' ) ) {
				$model->clean_caches();
			}
		}
		// Cache invalidation must not change the administrator-selected course status.
		// Draft courses remain drafts, and published internal-test courses remain published.
		clean_post_cache( $course_id );
	}

	public function install_seat_time_schema() {
		if ( '1.0' === get_option( 'gb_seat_time_schema_version' ) ) {
			return;
		}
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = $this->seat_time_table();
		$charset = $wpdb->get_charset_collate();
		$sql     = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			course_id bigint(20) unsigned NOT NULL,
			lesson_id bigint(20) unsigned NOT NULL,
			required_seconds int(10) unsigned NOT NULL DEFAULT 0,
			active_seconds int(10) unsigned NOT NULL DEFAULT 0,
			started_at_utc datetime NOT NULL,
			last_seen_utc datetime NOT NULL,
			completed_at_utc datetime NULL,
			ip_address varchar(64) NOT NULL DEFAULT '',
			user_agent varchar(255) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			UNIQUE KEY user_course_lesson (user_id,course_id,lesson_id),
			KEY completed_at_utc (completed_at_utc)
		) {$charset};";
		dbDelta( $sql );
		update_option( 'gb_seat_time_schema_version', '1.0', false );
	}

	private function regulated_lesson_context( $lesson_id, $course_id ) {
		$lesson_id = absint( $lesson_id );
		$course_id = absint( $course_id );
		if ( ! $lesson_id || ! $course_id || 'lp_lesson' !== get_post_type( $lesson_id ) ) {
			return false;
		}
		$registry = get_option( self::COURSE_OPTION, array() );
		if ( $course_id !== absint( $registry['adult_en']['learnpress_course_id'] ?? 0 ) ) {
			return false;
		}
		global $wpdb;
		$section_items = $wpdb->prefix . 'learnpress_section_items';
		$sections      = $wpdb->prefix . 'learnpress_sections';
		$attached = absint( $wpdb->get_var( $wpdb->prepare(
			"SELECT si.section_id FROM {$section_items} si INNER JOIN {$sections} s ON s.section_id = si.section_id WHERE si.item_id = %d AND s.section_course_id = %d LIMIT 1",
			$lesson_id,
			$course_id
		) ) );
		if ( ! $attached ) {
			return false;
		}
		return array(
			'lesson_id'       => $lesson_id,
			'course_id'       => $course_id,
			'required_seconds'=> absint( get_post_meta( $lesson_id, '_gb_required_seconds', true ) ),
		);
	}

	private function find_course_id_for_item( $item_id ) {
		$item_id = absint( $item_id );
		if ( ! $item_id ) {
			return 0;
		}
		global $wpdb;
		return absint( $wpdb->get_var( $wpdb->prepare(
			"SELECT s.section_course_id FROM {$wpdb->learnpress_section_items} si INNER JOIN {$wpdb->learnpress_sections} s ON s.section_id = si.section_id WHERE si.item_id = %d ORDER BY s.section_order ASC, si.item_order ASC LIMIT 1",
			$item_id
		) ) );
	}

	private function current_learnpress_item_id() {
		$types = array( 'lp_lesson', 'lp_quiz' );
		$candidates = array( get_queried_object_id() );
		global $post;
		if ( $post instanceof WP_Post ) {
			$candidates[] = $post->ID;
		}
		if ( class_exists( 'LP_Global' ) && method_exists( 'LP_Global', 'course_item' ) ) {
			$item = LP_Global::course_item();
			if ( is_object( $item ) ) {
				$candidates[] = method_exists( $item, 'get_id' ) ? $item->get_id() : ( $item->id ?? 0 );
			}
		}
		foreach ( $candidates as $candidate ) {
			$candidate = absint( $candidate );
			if ( $candidate && in_array( get_post_type( $candidate ), $types, true ) ) {
				return $candidate;
			}
		}
		$path = wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH );
		$slug = $path ? sanitize_title( basename( untrailingslashit( $path ) ) ) : '';
		if ( $slug ) {
			$route_item = get_page_by_path( $slug, OBJECT, $types );
			if ( $route_item instanceof WP_Post && in_array( $route_item->post_type, $types, true ) ) {
				return absint( $route_item->ID );
			}
		}
		return 0;
	}

	private function posted_seat_context() {
		check_ajax_referer( 'gb_seat_time', 'nonce' );
		if ( ! is_user_logged_in() || current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Student session required.' ), 403 );
		}
		$context = $this->regulated_lesson_context( $_POST['lesson_id'] ?? 0, $_POST['course_id'] ?? 0 );
		if ( ! $context ) {
			wp_send_json_error( array( 'message' => 'Invalid regulated lesson.' ), 400 );
		}
		if ( empty( $context['required_seconds'] ) ) {
			wp_send_json_error( array( 'message' => 'This regulated lesson has no approved timing requirement. Access is blocked until the timing ledger is repaired.' ), 409 );
		}
		return $context;
	}

	private function get_seat_record( $user_id, $course_id, $lesson_id ) {
		global $wpdb;
		$table = $this->seat_time_table();
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE user_id = %d AND course_id = %d AND lesson_id = %d LIMIT 1", $user_id, $course_id, $lesson_id ), ARRAY_A );
	}

	public function ajax_seat_start() {
		$context = $this->posted_seat_context();
		$user_id = get_current_user_id();
		$record  = $this->get_seat_record( $user_id, $context['course_id'], $context['lesson_id'] );
		if ( ! $record ) {
			global $wpdb;
			$now = gmdate( 'Y-m-d H:i:s' );
			$wpdb->insert( $this->seat_time_table(), array(
				'user_id' => $user_id, 'course_id' => $context['course_id'], 'lesson_id' => $context['lesson_id'],
				'required_seconds' => $context['required_seconds'], 'active_seconds' => 0,
				'started_at_utc' => $now, 'last_seen_utc' => $now,
				'ip_address' => sanitize_text_field( $_SERVER['REMOTE_ADDR'] ?? '' ),
				'user_agent' => substr( sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ?? '' ), 0, 255 ),
			), array( '%d', '%d', '%d', '%d', '%d', '%s', '%s', '%s', '%s' ) );
			$record = $this->get_seat_record( $user_id, $context['course_id'], $context['lesson_id'] );
		}
		wp_send_json_success( array(
			'required' => absint( $record['required_seconds'] ),
			'active' => absint( $record['active_seconds'] ),
			'completed' => ! empty( $record['completed_at_utc'] ),
		) );
	}

	public function ajax_seat_heartbeat() {
		$context = $this->posted_seat_context();
		$user_id = get_current_user_id();
		$record  = $this->get_seat_record( $user_id, $context['course_id'], $context['lesson_id'] );
		if ( ! $record ) {
			wp_send_json_error( array( 'message' => 'Seat-time session has not started.' ), 409 );
		}
		if ( ! empty( $record['completed_at_utc'] ) ) {
			wp_send_json_success( array( 'required' => absint( $record['required_seconds'] ), 'active' => absint( $record['active_seconds'] ), 'completed' => true ) );
		}
		$now_ts  = time();
		$last_ts = strtotime( $record['last_seen_utc'] . ' UTC' );
		$delta   = max( 0, $now_ts - $last_ts );
		$active  = absint( $record['active_seconds'] );
		if ( $delta >= 20 && ! empty( $_POST['active'] ) ) {
			$active = min( absint( $record['required_seconds'] ), $active + min( 30, $delta ) );
			global $wpdb;
			$wpdb->update( $this->seat_time_table(), array( 'active_seconds' => $active, 'last_seen_utc' => gmdate( 'Y-m-d H:i:s', $now_ts ) ), array( 'id' => absint( $record['id'] ) ), array( '%d', '%s' ), array( '%d' ) );
		}
		wp_send_json_success( array( 'required' => absint( $record['required_seconds'] ), 'active' => $active, 'completed' => false ) );
	}

	public function ajax_seat_complete() {
		$context = $this->posted_seat_context();
		$user_id = get_current_user_id();
		$record  = $this->get_seat_record( $user_id, $context['course_id'], $context['lesson_id'] );
		if ( ! $record ) {
			wp_send_json_error( array( 'message' => 'Seat-time session has not started.' ), 409 );
		}
		$elapsed = max( 0, time() - strtotime( $record['started_at_utc'] . ' UTC' ) );
		$required = absint( $record['required_seconds'] );
		if ( absint( $record['active_seconds'] ) < $required || $elapsed < $required ) {
			wp_send_json_error( array( 'message' => 'Required active instructional time has not been completed.', 'remaining' => max( 0, $required - absint( $record['active_seconds'] ) ) ), 403 );
		}
		$lp_result = true;
		if ( empty( $record['completed_at_utc'] ) && function_exists( 'learn_press_get_user' ) ) {
			$lp_user = learn_press_get_user( $user_id );
			if ( $lp_user && method_exists( $lp_user, 'complete_lesson' ) ) {
				$lp_result = $lp_user->complete_lesson( $context['lesson_id'], $context['course_id'] );
			}
		}
		if ( is_wp_error( $lp_result ) ) {
			wp_send_json_error( array( 'message' => $lp_result->get_error_message() ), 409 );
		}
		global $wpdb;
		$wpdb->update( $this->seat_time_table(), array( 'completed_at_utc' => gmdate( 'Y-m-d H:i:s' ) ), array( 'id' => absint( $record['id'] ) ), array( '%s' ), array( '%d' ) );
		wp_send_json_success( array( 'required' => $required, 'active' => absint( $record['active_seconds'] ), 'completed' => true ) );
	}

	public function block_early_lesson_completion() {
		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || 'user_complete_lesson' !== ( $_POST['lp-load-ajax'] ?? '' ) ) {
			return;
		}
		$context = $this->regulated_lesson_context( $_POST['lesson_id'] ?? 0, $_POST['course_id'] ?? 0 );
		if ( ! $context || current_user_can( 'manage_options' ) ) {
			return;
		}
		$record = $this->get_seat_record( get_current_user_id(), $context['course_id'], $context['lesson_id'] );
		if ( ! $record || empty( $record['completed_at_utc'] ) ) {
			wp_die( esc_html__( 'Required active instructional time must be completed before this lesson can be marked complete.', 'gulf-breeze-core' ), esc_html__( 'Lesson time incomplete', 'gulf-breeze-core' ), array( 'response' => 403 ) );
		}
	}

	public function inject_seat_time_controller( $content ) {
		if ( is_admin() || ! is_user_logged_in() || current_user_can( 'manage_options' ) ) {
			return $content;
		}
		$lesson_id = $this->current_learnpress_item_id();
		if ( 'lp_lesson' !== get_post_type( $lesson_id ) ) {
			return $content;
		}
		$course_id = $this->find_course_id_for_item( $lesson_id );
		$context   = $this->regulated_lesson_context( $lesson_id, $course_id );
		if ( ! $context ) {
			return $content;
		}
		if ( empty( $context['required_seconds'] ) ) {
			return '<style>.button-complete-lesson,a.next,[rel=next],.course-item-nav .next,.lp-course-item-next{display:none!important}</style><section class="gb-seat-time-error" style="border:2px solid #b32d2e;padding:16px;margin:0 0 22px;background:#fff5f5"><strong>Lesson temporarily locked</strong><p>This regulated lesson has no approved timing requirement. Contact Gulf Breeze Driving School.</p></section>' . $content;
		}
		$config = array(
			'ajax' => home_url( '/wp-admin/admin-ajax.php' ), 'nonce' => wp_create_nonce( 'gb_seat_time' ),
			'lesson' => $context['lesson_id'], 'course' => $context['course_id'], 'required' => $context['required_seconds'],
		);
		$timer = '<section id="gb-seat-time" style="border:1px solid #c8d6e5;border-radius:12px;padding:16px;margin:0 0 22px;background:#f7fbff" aria-live="polite"><strong>Required active study time</strong><p id="gb-seat-status" style="margin:6px 0 0">Connecting to the secure course timer…</p><progress id="gb-seat-progress" value="0" max="' . esc_attr( $context['required_seconds'] ) . '" style="width:100%;height:14px"></progress><p style="font-size:13px;margin:8px 0 0">Time is credited only while this lesson is visible and you remain active. Your progress is saved securely.</p></section>';
		$script = '<script>(function(){const c=' . wp_json_encode( $config ) . ',box=document.getElementById("gb-seat-time"),status=document.getElementById("gb-seat-status"),bar=document.getElementById("gb-seat-progress");if(!box)return;let active=0,required=c.required,lastActivity=Date.now(),finishing=false;const gated=".button-complete-lesson,a.next,[rel=next],.course-item-nav .next,.lp-course-item-next";const fmt=s=>Math.floor(s/60)+":"+String(s%60).padStart(2,"0");const draw=done=>{bar.max=required;bar.value=Math.min(active,required);status.textContent=done?"Required study time completed.":"Server-confirmed study time: "+fmt(active)+" of "+fmt(required);document.querySelectorAll(gated).forEach(b=>{b.setAttribute("aria-disabled",done?"false":"true");b.style.display=done?"":"none";if("disabled" in b)b.disabled=!done;});};const post=(action,extra={})=>fetch(c.ajax,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({action,nonce:c.nonce,lesson_id:c.lesson,course_id:c.course,...extra})}).then(r=>r.json());const finish=()=>{if(finishing)return;finishing=true;post("gb_seat_complete").then(j=>{if(j.success){active=j.data.active;draw(true);window.location.reload();}else{finishing=false;}}).catch(()=>{finishing=false;});};document.addEventListener("click",e=>{const t=e.target.closest(gated);if(t&&t.getAttribute("aria-disabled")==="true"){e.preventDefault();e.stopImmediatePropagation();}},true);["pointerdown","keydown","scroll","touchstart"].forEach(e=>addEventListener(e,()=>{lastActivity=Date.now();},{passive:true}));draw(false);post("gb_seat_start").then(j=>{if(!j.success)throw 0;required=j.data.required;active=j.data.active;draw(j.data.completed);if(j.data.completed)return;setInterval(()=>{const engaged=!document.hidden&&(Date.now()-lastActivity)<90000;if(!engaged)return;post("gb_seat_heartbeat",{active:"1"}).then(h=>{if(!h.success)return;active=h.data.active;draw(h.data.completed);if(h.data.completed||active>=required)finish();});},30000);}).catch(()=>{status.textContent="The secure course timer could not connect. Refresh the lesson before continuing.";});})();</script>';
		return $timer . $content . $script;
	}

	private function course_item_ids( $course_id ) {
		global $wpdb;
		return array_map( 'absint', (array) $wpdb->get_col( $wpdb->prepare(
			"SELECT si.item_id FROM {$wpdb->learnpress_sections} s INNER JOIN {$wpdb->learnpress_section_items} si ON si.section_id = s.section_id WHERE s.section_course_id = %d ORDER BY s.section_order ASC, si.item_order ASC",
			absint( $course_id )
		) ) );
	}

	private function lp_item_completed( $user_id, $course_id, $item_id ) {
		if ( ! function_exists( 'learn_press_get_user' ) ) {
			return false;
		}
		$user = learn_press_get_user( absint( $user_id ) );
		if ( ! $user || ! method_exists( $user, 'get_course_data' ) ) {
			return false;
		}
		$data = $user->get_course_data( absint( $course_id ) );
		$item = $data && method_exists( $data, 'get_item' ) ? $data->get_item( absint( $item_id ) ) : false;
		return $item && method_exists( $item, 'is_completed' ) && $item->is_completed();
	}

	private function previous_item_satisfied( $user_id, $course_id, $item_id ) {
		$ids = $this->course_item_ids( $course_id );
		$pos = array_search( absint( $item_id ), $ids, true );
		if ( false === $pos || 0 === $pos ) {
			return true;
		}
		$previous = absint( $ids[ $pos - 1 ] );
		$required = absint( get_post_meta( $previous, '_gb_required_seconds', true ) );
		if ( 'lp_lesson' === get_post_type( $previous ) && $required > 0 ) {
			$record = $this->get_seat_record( $user_id, $course_id, $previous );
			return $record && ! empty( $record['completed_at_utc'] ) && absint( $record['required_seconds'] ) === $required && absint( $record['active_seconds'] ) >= $required;
		}
		return $this->lp_item_completed( $user_id, $course_id, $previous );
	}

	public function enforce_course_item_sequence( $view, $item ) {
		if ( current_user_can( 'manage_options' ) || ! is_object( $view ) || ! isset( $view->flag ) || ! $view->flag || ! is_object( $item ) || ! method_exists( $item, 'get_id' ) ) {
			return $view;
		}
		$item_id   = absint( $item->get_id() );
		$course_id = $this->find_course_id_for_item( $item_id );
		$registry  = get_option( self::COURSE_OPTION, array() );
		if ( $course_id !== absint( $registry['adult_en']['learnpress_course_id'] ?? 0 ) ) {
			return $view;
		}
		if ( ! $this->previous_item_satisfied( get_current_user_id(), $course_id, $item_id ) ) {
			$view->flag = false;
			$view->message = esc_html__( 'Complete the previous course item and its verified requirements before continuing.', 'gulf-breeze-core' );
		}
		return $view;
	}

	public function filter_sequence_status_icon( $flag, $course_model, $user_model, $item, $section_item ) {
		if ( current_user_can( 'manage_options' ) || ! is_object( $item ) || empty( $item->id ) ) {
			return $flag;
		}
		$course_id = $this->find_course_id_for_item( $item->id );
		$registry  = get_option( self::COURSE_OPTION, array() );
		return $course_id === absint( $registry['adult_en']['learnpress_course_id'] ?? 0 ) && ! $this->previous_item_satisfied( get_current_user_id(), $course_id, $item->id ) ? 'locked' : $flag;
	}

	public function redirect_locked_course_item() {
		if ( is_admin() || current_user_can( 'manage_options' ) || ! is_user_logged_in() ) {
			return;
		}
		$item_id = $this->current_learnpress_item_id();
		if ( ! in_array( get_post_type( $item_id ), array( 'lp_lesson', 'lp_quiz' ), true ) ) {
			return;
		}
		$course_id = $this->find_course_id_for_item( $item_id );
		$registry  = get_option( self::COURSE_OPTION, array() );
		if ( ! $course_id || $course_id !== absint( $registry['adult_en']['learnpress_course_id'] ?? 0 ) || $this->previous_item_satisfied( get_current_user_id(), $course_id, $item_id ) ) {
			return;
		}
		$ids = $this->course_item_ids( $course_id );
		$course = function_exists( 'learn_press_get_course' ) ? learn_press_get_course( $course_id ) : null;
		$target = get_permalink( $course_id );
		foreach ( $ids as $candidate ) {
			if ( absint( $candidate ) === absint( $item_id ) ) {
				break;
			}
			if ( $this->previous_item_satisfied( get_current_user_id(), $course_id, $candidate ) ) {
				$target = is_object( $course ) && method_exists( $course, 'get_item_link' )
					? $course->get_item_link( absint( $candidate ) )
					: get_permalink( $candidate );
			} else {
				break;
			}
		}
		wp_safe_redirect( add_query_arg( 'gb_sequence_locked', '1', $target ) );
		exit;
	}

	public function filter_admin_toolbar( $show ) {
		return current_user_can( 'manage_options' ) ? $show : false;
	}

	public function hide_admin_toolbar() {
		if ( is_user_logged_in() && ! current_user_can( 'manage_options' ) ) {
			show_admin_bar( false );
		}
	}

	public function protect_admin_boundary() {
		if ( current_user_can( 'manage_options' ) || wp_doing_ajax() ) {
			return;
		}
		global $pagenow;
		if ( in_array( $pagenow, array( 'admin-post.php', 'async-upload.php' ), true ) ) {
			return;
		}
		wp_safe_redirect( home_url( '/' ) );
		exit;
	}

	public function protect_internal_course_objects() {
		if ( current_user_can( 'manage_options' ) ) {
			return;
		}
		$object_id  = get_queried_object_id();
		if ( ! is_singular( array( 'lp_course', 'lp_lesson', 'lp_quiz' ) ) ) {
			$object_id = $this->current_learnpress_item_id();
			if ( ! $object_id ) {
				return;
			}
		}
		$course_key = get_post_meta( $object_id, '_gb_course_key', true );
		if ( $course_key && array_key_exists( $course_key, self::course_definitions() ) ) {
			$registry = get_option( self::COURSE_OPTION, array() );
			$course   = isset( $registry[ $course_key ] ) && is_array( $registry[ $course_key ] ) ? $registry[ $course_key ] : array();
			$testers  = isset( $registry['_internal_tester_user_ids'] ) && is_array( $registry['_internal_tester_user_ids'] )
				? array_map( 'absint', $registry['_internal_tester_user_ids'] )
				: array();

			if (
				is_user_logged_in()
				&& 'internal_testing' === ( $course['status'] ?? '' )
				&& in_array( get_current_user_id(), $testers, true )
			) {
				return;
			}

			global $wp_query;
			$wp_query->set_404();
			status_header( 404 );
			nocache_headers();
		}
	}

	public function exclude_lms_from_sitemaps( $post_types ) {
		unset( $post_types['lp_course'], $post_types['lp_lesson'], $post_types['lp_quiz'], $post_types['lp_question'] );
		return $post_types;
	}

	public function noindex_lms_objects( $robots ) {
		if ( is_singular( array( 'lp_course', 'lp_lesson', 'lp_quiz', 'lp_question' ) ) ) {
			$robots['noindex']  = true;
			$robots['nofollow'] = true;
		}
		return $robots;
	}

	public static function schema() {
		return array(
			'business' => array(
				'label'  => 'Business Identity',
				'fields' => array(
					'legal_name'       => array( 'label' => 'Exact legal business name', 'required' => true ),
					'public_name'      => array( 'label' => 'Public/approved provider name', 'required' => true ),
					'owner_name'       => array( 'label' => 'Owner name', 'required' => true ),
					'entity_type'      => array( 'label' => 'Entity type' ),
					'assumed_name'     => array( 'label' => 'Assumed name / DBA' ),
					'federal_ein_last4'=> array( 'label' => 'EIN last four digits only', 'maxlength' => 4 ),
				),
			),
			'licensing' => array(
				'label'  => 'TDLR Approval and Course Identity',
				'fields' => array(
					'provider_number'          => array( 'label' => 'TDLR provider/license number' ),
					'ptde_en_approval'         => array( 'label' => 'Parent-Taught English approval/course identifier' ),
					'ptde_es_approval'         => array( 'label' => 'Parent-Taught Spanish approval/course identifier' ),
					'adult_en_approval'        => array( 'label' => 'Adult Six-Hour English approval/course identifier' ),
					'adult_es_approval'        => array( 'label' => 'Adult Six-Hour Spanish approval/course identifier' ),
					'license_effective_date'   => array( 'label' => 'License effective date', 'type' => 'date' ),
					'license_expiration_date'  => array( 'label' => 'License expiration date', 'type' => 'date' ),
				),
			),
			'contact' => array(
				'label'  => 'Business and Student Support',
				'fields' => array(
					'business_address_1' => array( 'label' => 'Business address line 1' ),
					'business_address_2' => array( 'label' => 'Business address line 2' ),
					'business_city'      => array( 'label' => 'City' ),
					'business_state'     => array( 'label' => 'State', 'default' => 'Texas' ),
					'business_zip'       => array( 'label' => 'ZIP code' ),
					'mailing_same'       => array( 'label' => 'Mailing address is the same', 'type' => 'checkbox' ),
					'mailing_address'    => array( 'label' => 'Mailing address, if different', 'type' => 'textarea' ),
					'phone'              => array( 'label' => 'Public phone number' ),
					'support_email'      => array( 'label' => 'Student support email', 'type' => 'email' ),
					'legal_email'        => array( 'label' => 'Legal/compliance email', 'type' => 'email' ),
					'support_hours_en'   => array( 'label' => 'Support hours — English', 'type' => 'textarea' ),
					'support_hours_es'   => array( 'label' => 'Support hours — Spanish', 'type' => 'textarea' ),
				),
			),
			'policies' => array(
				'label'  => 'Policy and Complaint Details',
				'fields' => array(
					'contract_version'       => array( 'label' => 'Current enrollment-contract version' ),
					'privacy_version'        => array( 'label' => 'Current privacy-policy version' ),
					'refund_version'         => array( 'label' => 'Current cancellation/refund-policy version' ),
					'grievance_version'      => array( 'label' => 'Current grievance-procedure version' ),
					'tdlr_complaint_text_en' => array( 'label' => 'Required TDLR complaint notice — English', 'type' => 'textarea' ),
					'tdlr_complaint_text_es' => array( 'label' => 'Required TDLR complaint notice — Spanish', 'type' => 'textarea' ),
				),
			),
			'operations' => array(
				'label'  => 'Operational Defaults',
				'fields' => array(
					'timezone'                => array( 'label' => 'Compliance timezone', 'default' => 'America/Chicago', 'readonly' => true ),
					'certificate_signer_name' => array( 'label' => 'Authorized certificate signer name' ),
					'certificate_signer_title'=> array( 'label' => 'Authorized certificate signer title' ),
					'record_retention_note'   => array( 'label' => 'Internal record-retention note', 'type' => 'textarea', 'private' => true ),
				),
			),
		);
	}

	public static function course_definitions() {
		return array(
			'ptde_en' => array(
				'label'               => 'Parent-Taught Driver Education — English',
				'program'             => 'parent_taught',
				'language'            => 'English',
				'total_minutes'       => 1440,
				'instruction_minutes' => 1320,
				'other_minutes'       => 120,
				'modules'             => 12,
				'approval_key'        => 'ptde_en_approval',
			),
			'ptde_es' => array(
				'label'               => 'Parent-Taught Driver Education — Spanish',
				'program'             => 'parent_taught',
				'language'            => 'Spanish',
				'total_minutes'       => 1440,
				'instruction_minutes' => 1320,
				'other_minutes'       => 120,
				'modules'             => 12,
				'approval_key'        => 'ptde_es_approval',
			),
			'adult_en' => array(
				'label'               => 'Online Adult Six-Hour — English',
				'program'             => 'adult_six_hour',
				'language'            => 'English',
				'total_minutes'       => 360,
				'instruction_minutes' => 330,
				'other_minutes'       => 30,
				'modules'             => null,
				'approval_key'        => 'adult_en_approval',
			),
			'adult_es' => array(
				'label'               => 'Online Adult Six-Hour — Spanish',
				'program'             => 'adult_six_hour',
				'language'            => 'Spanish',
				'total_minutes'       => 360,
				'instruction_minutes' => 330,
				'other_minutes'       => 30,
				'modules'             => null,
				'approval_key'        => 'adult_es_approval',
			),
		);
	}

	public static function curriculum_blueprints() {
		return array(
			'parent_taught' => array(
				'source'         => 'POI-DE — May 2026 adopted edition',
				'source_url'     => 'https://www.sos.state.tx.us/texreg/archive/April242026/In%20Addition/202601592-1.pdf',
				'total_minutes'  => 1440,
				'minimum_content'=> 1320,
				'flex_minutes'   => 120,
				'units'          => array(
					'1'  => 'Traffic Laws',
					'2'  => 'Driver Preparation',
					'3'  => 'Vehicle Movements',
					'4'  => 'Driver Readiness',
					'5'  => 'Risk Reduction (Management)',
					'6'  => 'Environmental Factors',
					'7'  => 'Distractions',
					'8'  => 'Alcohol and Other Drugs',
					'9'  => 'Adverse Conditions',
					'10' => 'Vehicle Requirements',
					'11' => 'Consumer Responsibilities',
					'12' => 'Personal Responsibilities',
				),
				'work_zone_units' => array( '3', '6' ),
			),
			'adult_six_hour' => array(
				'source'         => 'POI-Adult Six-Hour — May 2026 adopted edition',
				'source_url'     => 'https://www.sos.state.tx.us/texreg/archive/April242026/In%20Addition/202601590-1.pdf',
				'total_minutes'  => 360,
				'minimum_content'=> 330,
				'flex_minutes'   => 30,
				'units'          => array(
					'4.1.1' => 'Course Introduction',
					'4.1.2' => 'Your License to Drive',
					'4.1.3' => 'Right-of-Way',
					'4.1.4' => 'Traffic Control Devices',
					'4.1.5' => 'Controlling Traffic Flow',
					'4.1.6' => 'Alcohol and Other Drugs',
					'4.1.7' => 'Cooperating with Other Roadway Users',
					'4.1.8' => 'Managing Risk',
					'4.1.9' => 'Classroom Progress Assessment',
				),
				'work_zone_units' => array( '4.1.7' ),
			),
		);
	}

	public static function adult_english_crosswalk() {
		return array(
			array( 'topic' => '4.1.1', 'lesson' => 'Welcome and Course Purpose', 'minutes' => 2, 'coverage' => '4.1.1.1(A)' ),
			array( 'topic' => '4.1.1', 'lesson' => 'How the Online Course Works', 'minutes' => 3, 'coverage' => 'Orientation and logical navigation' ),
			array( 'topic' => '4.1.1', 'lesson' => 'Course Rules, Identity, Seat Time, and Completion', 'minutes' => 3, 'coverage' => 'Online participation and security requirements' ),
			array( 'topic' => '4.1.1', 'lesson' => 'Driving as a Privilege and Lifelong Responsibility', 'minutes' => 2, 'coverage' => '4.1.1.1(B)–(C)' ),
			array( 'topic' => '4.1.2', 'lesson' => 'Applying for a Texas Driver License', 'minutes' => 4, 'coverage' => '4.1.2.1(A); Chapter 3 anatomical-gift objective' ),
			array( 'topic' => '4.1.2', 'lesson' => 'License Classes, Restrictions, and Endorsements', 'minutes' => 5, 'coverage' => '4.1.2.1(B)' ),
			array( 'topic' => '4.1.2', 'lesson' => 'Suspensions, Revocations, and Renewal', 'minutes' => 5, 'coverage' => '4.1.2.1(A)–(C)' ),
			array( 'topic' => '4.1.2', 'lesson' => 'Vehicle Registration and Financial Responsibility', 'minutes' => 5, 'coverage' => '4.1.2.1(D)–(F)' ),
			array( 'topic' => '4.1.2', 'lesson' => 'Texas Driving with Disabilities Program', 'minutes' => 5, 'coverage' => '4.1.2.1(G)' ),
			array( 'topic' => '4.1.3', 'lesson' => 'What Right-of-Way Means', 'minutes' => 5, 'coverage' => '4.1.3.1(A)' ),
			array( 'topic' => '4.1.3', 'lesson' => 'Controlled and Uncontrolled Intersections', 'minutes' => 8, 'coverage' => '4.1.3.1(B)–(C)' ),
			array( 'topic' => '4.1.3', 'lesson' => 'Turns, T-Intersections, Circles, and Entering Traffic', 'minutes' => 7, 'coverage' => '4.1.3.1(C)' ),
			array( 'topic' => '4.1.3', 'lesson' => 'Pedestrians, Crosswalks, and School Crossings', 'minutes' => 7, 'coverage' => '4.1.3.1(D)' ),
			array( 'topic' => '4.1.3', 'lesson' => 'School Buses, Emergency Vehicles, and Move Over or Slow Down', 'minutes' => 8, 'coverage' => '4.1.3.1(D)–(E)' ),
			array( 'topic' => '4.1.3', 'lesson' => 'Railroad Crossings and Right-of-Way Decisions', 'minutes' => 7, 'coverage' => '4.1.3.1(C), (F)–(G)' ),
			array( 'topic' => '4.1.4', 'lesson' => 'Why Traffic Control Devices Matter', 'minutes' => 4, 'coverage' => '4.1.4.1(C)–(D)' ),
			array( 'topic' => '4.1.4', 'lesson' => 'Regulatory Signs', 'minutes' => 6, 'coverage' => '4.1.4.1(A)–(B)' ),
			array( 'topic' => '4.1.4', 'lesson' => 'Warning Signs', 'minutes' => 6, 'coverage' => '4.1.4.1(A)–(B)' ),
			array( 'topic' => '4.1.4', 'lesson' => 'Guide, School-Zone, and Work-Zone Signs', 'minutes' => 6, 'coverage' => '4.1.4.1(A)–(B)' ),
			array( 'topic' => '4.1.4', 'lesson' => 'Traffic Signals and Flashing Signals', 'minutes' => 8, 'coverage' => '4.1.4.1(B)–(D)' ),
			array( 'topic' => '4.1.4', 'lesson' => 'Pavement and Lane-Control Markings', 'minutes' => 7, 'coverage' => '4.1.4.1(B)–(D)' ),
			array( 'topic' => '4.1.5', 'lesson' => 'Speed Control, Following Distance, and Stopping', 'minutes' => 7, 'coverage' => '4.1.5.1(A), (F)–(J), (P)' ),
			array( 'topic' => '4.1.5', 'lesson' => 'Lane Position, Lane Changes, and Blind Spots', 'minutes' => 6, 'coverage' => '4.1.5.1(A)–(F)' ),
			array( 'topic' => '4.1.5', 'lesson' => 'Turning, Signaling, and Communication', 'minutes' => 6, 'coverage' => '4.1.5.1(B)–(D)' ),
			array( 'topic' => '4.1.5', 'lesson' => 'Passing and Being Passed', 'minutes' => 6, 'coverage' => '4.1.5.1(D)' ),
			array( 'topic' => '4.1.5', 'lesson' => 'Parking, Backing, Freeway Travel, Emergencies, and Work Zones', 'minutes' => 7, 'coverage' => '4.1.5.1(D), (K)–(Q)' ),
			array( 'topic' => '4.1.6', 'lesson' => 'Zero-Tolerance Driving Decisions', 'minutes' => 6, 'coverage' => '4.1.6.1(G)' ),
			array( 'topic' => '4.1.6', 'lesson' => 'Alcohol, BAC, and Impairment', 'minutes' => 8, 'coverage' => '4.1.6.1(A)–(B)' ),
			array( 'topic' => '4.1.6', 'lesson' => 'Drugs, Prescriptions, Cannabis, and Mixed Substances', 'minutes' => 7, 'coverage' => '4.1.6.1(B)' ),
			array( 'topic' => '4.1.6', 'lesson' => 'Texas DWI Laws, Penalties, and Consequences', 'minutes' => 10, 'coverage' => '4.1.6.1(C)–(F)' ),
			array( 'topic' => '4.1.6', 'lesson' => 'Planning a Safe Ride', 'minutes' => 6, 'coverage' => '4.1.6.1(G)' ),
			array( 'topic' => '4.1.7', 'lesson' => 'Pedestrians, Bicyclists, Motorcyclists, and Other Roadway Users', 'minutes' => 8, 'coverage' => '4.1.7.1(A), (C)–(E), (K)' ),
			array( 'topic' => '4.1.7', 'lesson' => 'Large and Oversize Vehicles, Buses, and Emergency Vehicles', 'minutes' => 8, 'coverage' => '4.1.7.1(C), (L)' ),
			array( 'topic' => '4.1.7', 'lesson' => 'Construction and Maintenance Work-Zone Safety', 'minutes' => 7, 'coverage' => '4.1.7.1(C); SB 1366 safe driving, flaggers/signs, penalties and dangers' ),
			array( 'topic' => '4.1.7', 'lesson' => 'Crash Responsibilities and the Good Samaritan Law', 'minutes' => 6, 'coverage' => '4.1.7.1(B)' ),
			array( 'topic' => '4.1.7', 'lesson' => 'Road Rage, Courtesy, Cargo, Towing, and Carbon Monoxide', 'minutes' => 8, 'coverage' => '4.1.7.1(H)–(J); Chapter 3 litter-prevention objective' ),
			array( 'topic' => '4.1.7', 'lesson' => 'Traffic Stops and the Community Safety Education Act Video', 'minutes' => 16, 'coverage' => '4.1.7.1(F)–(G), (M)' ),
			array( 'topic' => '4.1.8', 'lesson' => 'The Risk Formula: Driver, Vehicle, Roadway, and Environment', 'minutes' => 5, 'coverage' => '4.1.8.1(A)–(C), (I); Chapter 3 unattended-child objective' ),
			array( 'topic' => '4.1.8', 'lesson' => 'Distractions, Cell Phones, Fatigue, and Inattention', 'minutes' => 7, 'coverage' => '4.1.8.1(C)–(D), (H)–(I)' ),
			array( 'topic' => '4.1.8', 'lesson' => 'Night Driving, Weather, Skids, and Emergencies', 'minutes' => 7, 'coverage' => '4.1.8.1(C), (G), (I)' ),
			array( 'topic' => '4.1.8', 'lesson' => 'Aggressive Driving, Street Racing, and High-Risk Choices', 'minutes' => 6, 'coverage' => '4.1.8.1(A)–(B), (E)–(I)' ),
			array( 'topic' => '4.1.8', 'lesson' => 'Recognizing and Reporting Human Trafficking', 'minutes' => 6, 'coverage' => '4.1.8.1(J)' ),
			array( 'topic' => '4.1.8', 'lesson' => 'Recreational Water Safety Video', 'minutes' => 12, 'coverage' => '§84.500 educational objective' ),
			array( 'topic' => '4.1.9', 'lesson' => 'Highway Sign Review', 'minutes' => 10, 'coverage' => 'Pre-exam instructional review' ),
			array( 'topic' => '4.1.9', 'lesson' => 'Traffic Law Review', 'minutes' => 20, 'coverage' => 'Pre-exam instructional review' ),
			array( 'topic' => '4.1.9', 'lesson' => 'Comprehensive Licensing Readiness Review', 'minutes' => 22, 'coverage' => 'Pre-exam summation and review' ),
		);
	}

	private static function timed_practice( $key ) {
		$sets = array(
			'adult_en_001' => array(
				'heading' => 'Build Your Safe-Driver Foundation',
				'intro' => 'Use these situations to connect course knowledge with the decisions a responsible driver must make. Read each situation, decide what you would do, and then open the explanation.',
				'cases' => array(
					array( 'A friend says that passing the written and road tests means a new driver has finished learning. What is missing from that statement?', 'Licensing tests measure minimum knowledge and skill at a point in time. Safe driving still requires supervised practice, continued observation, honest self-evaluation, and experience in gradually more complex conditions.' ),
					array( 'Name one personal reason for becoming a safe driver and one person besides yourself who may be affected by your choices.', 'The particular answer is personal. A complete response recognizes that driving choices affect passengers, pedestrians, other drivers, family members, employers, emergency responders, and the community—not only the driver.' ),
				),
			),
			'adult_en_002' => array(
				'heading' => 'Practice the Course Process',
				'intro' => 'The online format divides the required instruction into short lessons, but every lesson remains part of one regulated course ledger.',
				'cases' => array(
					array( 'You finish reading before the assigned lesson time has elapsed. What should you do?', 'Review the examples, revisit the official-source links, complete the guided practice, and identify any rule you could not explain without looking. Opening another tab or leaving the page does not turn waiting time into instruction.' ),
					array( 'You remember a rule differently from an older handbook saved on your phone. Which source controls?', 'Use the current official Texas source supplied with the course. Laws and agency procedures change. Report an apparent conflict to the school rather than guessing or relying on an older copy.' ),
					array( 'A scheduled break begins after a topic. Can it be counted toward that topic’s instructional minutes?', 'No. The course ledger separates required instructional time, scheduled breaks, and the comprehensive final examination.' ),
				),
			),
			'adult_en_003' => array(
				'heading' => 'Protect the Integrity of Your Record',
				'intro' => 'A compliant record must show that the enrolled student personally participated for the required time and demonstrated knowledge.',
				'cases' => array(
					array( 'A family member offers to answer several questions while you make a phone call. Why is that unacceptable?', 'The enrolled student must personally complete the instruction and assessments. Shared answers make the participation record inaccurate and can invalidate completion.' ),
					array( 'The lesson is visible, but there has been no keyboard, pointer, scrolling, or touch activity for an extended period. Should time continue?', 'No. The Gulf Breeze timer requires both page visibility and recent activity. The server—not the device clock—records credited active seconds.' ),
					array( 'You miss a required question linked to a multimedia segment. What may the course require?', 'The segment may have to be replayed before a different question is presented. This supports actual review instead of memorizing one answer.' ),
				),
			),
			'adult_en_004' => array(
				'heading' => 'Apply the Reduced-Risk Decision Process',
				'intro' => 'For each situation, identify the law, the developing hazard, who may be harmed, and the safest legal response.',
				'cases' => array(
					array( 'Your light turns green while a pedestrian is finishing the crossing. A driver behind you honks. What controls your decision?', 'The pedestrian’s safety and the duty to yield control—not pressure from the driver behind. Wait until the path is clear.' ),
					array( 'You have the legal right-of-way, but another vehicle is entering your lane. Does being legally correct remove your responsibility to react?', 'No. Brake, create space, or take another reasonable evasive action. Right-of-way rules organize traffic; they do not authorize a preventable collision.' ),
				),
			),
			'adult_en_005' => array(
				'heading' => 'Licensing Decision Workshop',
				'intro' => 'Licensing requirements depend on the applicant and transaction. Work through the distinctions instead of memorizing one applicant’s checklist.',
				'cases' => array(
					array( 'A 20-year-old first-time applicant asks whether the adult six-hour course is optional. What should the applicant verify?', 'Texas generally requires the six-hour adult course for a first-time applicant age 18 through 24 unless an exception applies. The applicant should confirm current DPS eligibility and document requirements for the specific transaction.' ),
					array( 'A 27-year-old first-time applicant wants supervised practice before the road test. Does age alone authorize practice on public roads?', 'No. The applicant must obtain and obey the credential and restriction DPS requires for supervised practice. Course completion alone is not driving authority.' ),
					array( 'An applicant arrives with identity documents but owns an uninsured, unregistered vehicle. Why can that still affect the transaction or driving test?', 'Driver eligibility and vehicle legality are separate. DPS may require registration and insurance evidence, and any vehicle used for testing must meet the testing authority’s current requirements.' ),
					array( 'A new resident has a valid, unexpired license from another state. Should the person assume the first-time Texas checklist applies unchanged?', 'No. New-resident procedures can differ. Use the current DPS instructions for transferring an out-of-state credential.' ),
				),
			),
			'adult_en_006' => array(
				'heading' => 'Class, Restriction, and Endorsement Practice',
				'intro' => 'Authorization depends on the actual vehicle, its use, and the exact credential—not what the vehicle looks like.',
				'cases' => array(
					array( 'A driver with a Class C license is asked to operate a large passenger van for pay. What must be checked before accepting?', 'Check passenger capacity, weight ratings, commercial use, and applicable state and federal requirements. A familiar steering wheel does not mean the existing class is sufficient.' ),
					array( 'A restriction requires corrective lenses, but the driver can read nearby text without them. May the driver ignore it for a short trip?', 'No. The restriction remains part of the legal privilege until DPS officially changes it.' ),
					array( 'A person has years of motorcycle riding experience on private property but no motorcycle authorization. Is experience an endorsement?', 'No. Experience does not replace the required application, testing, and licensing process.' ),
					array( 'Before towing an unfamiliar trailer, what should be examined?', 'Review vehicle and combination weight ratings, trailer type, use, license class, endorsements or exemptions, vehicle equipment, registration, and insurance.' ),
				),
			),
			'adult_en_007' => array(
				'heading' => 'License-Status Practice',
				'intro' => 'The physical card and the legal status of the privilege are not always the same.',
				'cases' => array(
					array( 'The card’s expiration date is next year, but the driver received a suspension notice. Which status controls?', 'The suspension controls. Possessing an unexpired-looking card does not authorize driving while the privilege is suspended.' ),
					array( 'A friend says paying one fee automatically reinstates every case. Why is that unsafe advice?', 'Reinstatement requirements are individualized and may involve a period of ineligibility, fees, court compliance, education, an SR-22 filing, or other documents. Verify the official DPS eligibility record.' ),
					array( 'An SR-22 is required. Can the driver carry an ordinary insurance card instead?', 'No. An SR-22 is a certificate filed by an authorized insurer when specifically required. Ordinary proof of insurance does not replace that filing.' ),
					array( 'A driver renews the plastic card while an enforcement action is unresolved. Did renewal erase the action?', 'No. Renewal and eligibility are separate. The driver must resolve the enforcement requirements shown by DPS.' ),
				),
			),
			'adult_en_008' => array(
				'heading' => 'Vehicle-Legality Checklist',
				'intro' => 'Before driving, verify the driver and the vehicle as separate legal systems.',
				'cases' => array(
					array( 'A noncommercial passenger vehicle is registered in a county without emissions testing. Must the owner obtain the former annual safety inspection?', 'Texas eliminated the annual safety inspection for most noncommercial vehicles beginning in 2025. Commercial safety inspections and emissions inspections for applicable vehicles in designated counties continue.' ),
					array( 'A liability policy lapsed yesterday, but the registration sticker is current. Is the vehicle ready to drive?', 'No. Registration does not replace financial responsibility. Confirm active coverage before driving.' ),
					array( 'What does 30/60/25 describe, and what does it not guarantee?', 'It describes Texas minimum liability limits commonly stated as $30,000 injury to one person, $60,000 total injury per crash, and $25,000 property damage. It does not guarantee payment for every loss to the insured driver or vehicle.' ),
					array( 'A driver submits an insurance application and payment. When is it safe to assume coverage began?', 'Only after the insurer confirms an effective policy and effective date. An application or attempted payment by itself may not establish coverage.' ),
				),
			),
			'adult_en_009' => array(
				'heading' => 'Communication-Support Practice',
				'intro' => 'The Driving with Disability Program offers voluntary communication tools. It does not change the duty to obey traffic law.',
				'cases' => array(
					array( 'A qualifying person wants an indicator on the front of a driver license. Which agency process applies?', 'Use the current DPS process, including the required in-person transaction documents and DL-101 completed by the appropriate healthcare provider.' ),
					array( 'A person wants information connected to a vehicle record so an officer may receive an alert through TLETS. Is that the same request?', 'No. That is the separate voluntary TxDMV vehicle-registration disclosure process.' ),
					array( 'Does an indicator permit a driver to disregard an officer’s lawful instruction during a stop?', 'No. It alerts the officer to a potential communication need. The driver should keep hands visible, avoid sudden movements, and follow lawful instructions using the safest available communication method.' ),
					array( 'May another person diagnose a communication disability from unusual behavior during a traffic encounter?', 'No. Avoid assumptions. The program relies on voluntary disclosure and required documentation, and individual communication needs differ.' ),
				),
			),
			'adult_en_010' => array(
				'heading' => 'Right-of-Way Decision Lab',
				'intro' => 'Right-of-way decisions must combine the legal rule with a fresh search for actual danger.',
				'cases' => array(
					array( 'You are first at a stop, but a bicyclist enters the conflict area unexpectedly. What should you do?', 'Wait or stop again. Being first does not authorize movement into an occupied path.' ),
					array( 'An approaching motorcycle looks far away. Why should you delay a quick left-turn judgment?', 'A motorcycle’s smaller profile can make speed and distance harder to judge. Look twice and turn only with a clearly safe gap.' ),
					array( 'Another driver waves you across two traffic lanes. What must you verify?', 'The gesture covers only that driver’s intention. Search every lane, the sidewalk, and all other conflict paths yourself.' ),
				),
			),
			'adult_en_011' => array(
				'heading' => 'Intersection Search and Decision Practice',
				'intro' => 'For every intersection, identify the control, stop position, users with priority, blocked views, and escape space before proceeding.',
				'cases' => array(
					array( 'A STOP sign has a marked stop line several feet before the crosswalk. Where is the required first stop?', 'At the stop line. After stopping, creep forward only as needed for visibility while yielding and keeping the crosswalk protected.' ),
					array( 'Two vehicles arrive at an uncontrolled intersection at approximately the same time. One is on the left. Who normally yields?', 'The driver on the left yields to the driver on the right. Both drivers still verify that the other is actually responding.' ),
					array( 'You are on an unpaved road entering a paved road with no sign. What is the duty?', 'Yield to traffic on the paved road and enter only with a safe gap.' ),
					array( 'Your signal is green, but stopped traffic leaves no room beyond the intersection. May you enter and wait in the intersection?', 'No. Remain behind the entry point until there is space to clear the intersection.' ),
					array( 'A four-way signal is dark. What is the safe process?', 'Reduce speed, identify all approaches, follow current Texas law and any officer or temporary control, communicate, and proceed only after yielding and confirming a clear path.' ),
				),
			),
			'adult_en_012' => array(
				'heading' => 'Turning and Entering-Traffic Workshop',
				'intro' => 'Turning errors often begin before the wheel moves: late signals, wrong lane choice, incomplete searches, or accepting a gap that forces others to react.',
				'cases' => array(
					array( 'You plan a left turn across approaching traffic. What makes an approaching vehicle an immediate hazard?', 'Its distance and speed are close enough that your turn would interfere with its safe movement. When uncertain, wait for a larger gap.' ),
					array( 'At a T-intersection, your road ends and the crossroad continues. No assumption gives you priority. What should you do?', 'Obey the posted control, search both directions and for pedestrians, yield to through traffic, and enter only with adequate space.' ),
					array( 'You approach a two-lane roundabout in the wrong lane for your exit. Should you cut across inside the circle?', 'No. Follow lane markings, continue safely, and use another route or circle again as permitted rather than making an abrupt cross-lane movement.' ),
					array( 'You are exiting a parking lot across a sidewalk. Who must be protected first?', 'Pedestrians and other sidewalk users. Stop or yield as required before crossing the sidewalk, then yield to roadway traffic.' ),
					array( 'The freeway acceleration lane is ending and no safe gap exists. Does signaling force highway traffic to let you enter?', 'No. Entering traffic must yield. Adjust speed and locate a safe gap without forcing another driver to brake or swerve.' ),
				),
			),
			'adult_en_013' => array(
				'heading' => 'Pedestrian-Hazard Workshop',
				'intro' => 'Pedestrian risk is highest when visibility is blocked or the driver’s attention is directed toward vehicle traffic instead of the crosswalk.',
				'cases' => array(
					array( 'A vehicle stops before an unmarked crosswalk. You do not see a pedestrian. Should you pass?', 'Slow and determine why it stopped. The vehicle may be hiding a pedestrian. Do not pass until the crossing is clear and the maneuver is lawful.' ),
					array( 'You are turning right while watching traffic approaching from the left. What must happen before the vehicle moves?', 'Turn your head and rescan the crosswalk and sidewalk in the direction of travel. A pedestrian may have entered while you were looking left.' ),
					array( 'A person using a white cane is preparing to cross. What is the correct attitude?', 'Stop and provide the protection required by law. Do not honk, crowd the crosswalk, or assume the person can see your gesture.' ),
					array( 'A crossing guard directs traffic differently from the normal signal pattern. Which direction controls?', 'Follow the crossing guard’s lawful direction and remain stopped until children and the conflict area are clear.' ),
					array( 'A pedestrian crosses improperly. Does that allow the driver to continue at an unchanged speed toward the person?', 'No. Use reasonable braking, steering, warning, and space to prevent injury even when the pedestrian made an error.' ),
				),
			),
			'adult_en_014' => array(
				'heading' => 'Protected-Vehicle Response Workshop',
				'intro' => 'Identify the vehicle, its signals, the roadway division, adjacent workers or children, and the safest legal space before acting.',
				'cases' => array(
					array( 'A school bus ahead activates alternating flashing red lights. What ends the stop duty?', 'Proceed only when the bus resumes motion, the bus driver signals, or the visual signal is no longer activated, and only after checking for children.' ),
					array( 'A school bus is stopped on the opposite side of a roadway separated only by a painted center turn lane. Should you assume you are exempt?', 'No. A painted lane is not necessarily the physical division required for the opposite-roadway exception. Stop as the law requires.' ),
					array( 'An emergency vehicle approaches from behind with required audible and visual signals while you are in an intersection. What should you avoid?', 'Do not stop in the intersection. Clear it safely, move toward the right edge or curb, and stop as directed by law.' ),
					array( 'The limit is 70 mph and a covered stopped vehicle has activated overhead lights. Moving over is unsafe. What speed threshold applies?', 'Slow to at least 20 mph below the posted limit—50 mph or less—while also choosing a speed safe for actual conditions.' ),
					array( 'The limit is 25 mph. Moving over is not possible. What does the Texas rule require?', 'Slow to 5 mph and maintain control while passing the protected area.' ),
					array( 'You can move over only by cutting sharply in front of another vehicle. Is that required?', 'No. Do not create another emergency. Slow as required, maintain control, and move over only when the lane change can be made safely.' ),
				),
			),
			'adult_en_015' => array(
				'heading' => 'Railroad-Crossing Decision Workshop',
				'intro' => 'At a railroad crossing, the controlling question is whether the entire vehicle can clear every track before a train arrives or traffic stops.',
				'cases' => array(
					array( 'A warning signal activates. Where must the vehicle stop?', 'Between 15 and 50 feet from the nearest rail, as required by Texas law.' ),
					array( 'The gate rises immediately after one train passes. What must you check before moving?', 'Look and listen again for a second train on any track, confirm signals and gates permit movement, and cross only when every track and the far side are clear.' ),
					array( 'Traffic beyond the tracks is stopped but may move soon. Can you enter and wait?', 'No. Wait before the tracks until enough space exists for the entire vehicle to clear all rails.' ),
					array( 'Your vehicle stalls on a crossing and a train is approaching. Where should occupants move?', 'Exit immediately and move away from the tracks toward the direction from which the train is approaching, then call 911 and use the crossing’s Emergency Notification System information once clear.' ),
					array( 'No train is visible, but a flagger directs you to stop. Does the absence of a visible train cancel the instruction?', 'No. Stop as directed. A flagger or warning device may identify danger before the train is visible to you.' ),
				),
			),
		);
		if ( empty( $sets[ $key ] ) ) {
			return '';
		}
		$set  = $sets[ $key ];
		$html = '<section class="gb-guided-practice"><h2>' . esc_html( $set['heading'] ) . '</h2><p>' . esc_html( $set['intro'] ) . '</p><ol>';
		foreach ( $set['cases'] as $case ) {
			$html .= '<li><p><strong>' . esc_html( $case[0] ) . '</strong></p><details><summary>Compare your decision</summary><p>' . esc_html( $case[1] ) . '</p></details></li>';
		}
		$html .= '</ol><div style="border-left:4px solid #1769aa;padding:12px 16px;background:#f3f8fc;margin:18px 0"><strong>Private self-check — no submission required:</strong> Explain the lesson rule aloud or in your own private notes, then identify the action that reduces risk. If you cannot explain both without looking, review the lesson and official source before continuing.</div></section>';
		return $html;
	}

	private static function complete_timed_content( $key, $content ) {
		$practice = self::timed_practice( $key ) . self::topic_four_visuals( $key );
		$position = strpos( $content, '<hr>' );
		if ( false === $position ) {
			return $content . $practice;
		}
		return substr( $content, 0, $position ) . $practice . substr( $content, $position );
	}

	public static function adult_topic_one_content() {
		$poi_url      = 'https://www.sos.state.tx.us/texreg/archive/April242026/In%20Addition/202601590-1.pdf';
		$handbook_url = 'https://www.dps.texas.gov/internetforms/forms/dl-7.pdf';
		$source_note  = '<hr><p><small><strong>Official course sources:</strong> <a href="' . esc_url( $poi_url ) . '" target="_blank" rel="noopener noreferrer">TDLR Adult Six-Hour POI, May 2026</a> and <a href="' . esc_url( $handbook_url ) . '" target="_blank" rel="noopener noreferrer">Texas Driver Handbook, January 2026</a>.</small></p>';

		return array(
			'adult_en_001' => array(
				'title'    => 'Welcome and Course Purpose',
				'objective'=> '4.1.1.1(A)',
				'minutes'  => 2,
				'content'  => '<div class="gb-lesson"><p><strong>Welcome to Gulf Breeze Driving School Texas.</strong> This course is designed to give a new adult driver a reliable starting point for learning to drive legally, responsibly, and with less risk.</p><h2>What driver education provides</h2><p>A driver education course cannot create an experienced driver in six hours. It provides the foundation for the learning that continues through study, supervised practice, observation, and every responsible decision made behind the wheel.</p><p>That foundation includes four connected parts:</p><ul><li><strong>Knowledge:</strong> understanding traffic laws, signs, signals, roadway markings, and safe-driving principles.</li><li><strong>Understanding:</strong> knowing why a rule or procedure matters and what risk it is meant to reduce.</li><li><strong>Skills:</strong> learning how to control a vehicle, observe traffic, communicate, and respond safely.</li><li><strong>Experience:</strong> applying knowledge and skills repeatedly in real traffic conditions.</li></ul><div style="border-left:4px solid #1769aa;padding:12px 16px;background:#f3f8fc;margin:18px 0"><strong>Key idea:</strong> Completing the course is one step in a lifelong learning process. Safe drivers continue to learn, evaluate their choices, and improve.</div><h2>Before moving forward</h2><p>Think about one reason you want to become a safe driver. Your reason may involve independence, work, family, education, or protecting other people. Keep that purpose in mind throughout the course.</p><h3>Lesson check</h3><p><strong>Which statement best describes the purpose of adult driver education?</strong></p><ol type="A"><li>To replace supervised driving practice</li><li>To provide a foundation for continued reduced-risk learning</li><li>To guarantee that every student will pass a road test</li></ol><details><summary>Check your answer</summary><p><strong>B.</strong> The course provides a foundation of knowledge, understanding, skills, and experiences for continued lifelong learning. It does not replace practice or guarantee a test result.</p></details>' . $source_note,
			),
			'adult_en_002' => array(
				'title'    => 'How the Online Course Works',
				'objective'=> 'Online course orientation supporting 4.1.1.1(A)',
				'minutes'  => 3,
				'content'  => '<div class="gb-lesson"><p>This is an online adult six-hour driver education course. It is organized into short lessons so you can focus on one subject at a time while still completing every required Texas topic.</p><h2>Your course path</h2><ol><li><strong>Read or watch the assigned material.</strong> Give the lesson your full attention.</li><li><strong>Complete the required instructional time.</strong> Instructional time is measured separately from scheduled breaks and the comprehensive final examination.</li><li><strong>Answer lesson and topic questions.</strong> These checks confirm participation and help you identify material that needs another review.</li><li><strong>Continue in order.</strong> Later topics build on the legal and safety principles introduced earlier.</li><li><strong>Complete the comprehensive final examination.</strong> The final measures your understanding of Texas highway signs and traffic laws.</li></ol><h2>Short lessons, complete coverage</h2><p>A short lesson is not permission to rush. Each lesson has an assigned instructional-time requirement based on the course timing ledger. The complete Adult English course contains 330 minutes of instruction and three separate 10-minute breaks, for a total course time of 360 minutes. The comprehensive final examination is not counted as instructional time.</p><div style="border-left:4px solid #1769aa;padding:12px 16px;background:#f3f8fc;margin:18px 0"><strong>Stay active:</strong> Course time is intended for active study. Leaving the lesson, switching away for an extended period, or allowing another person to complete work does not satisfy the learning requirement.</div><h2>Use the official handbook</h2><p>The current Texas Driver Handbook is a primary course resource. Keep it available throughout the course. Laws, procedures, and official guidance may change, so the current official edition controls over an older saved copy.</p><h3>Lesson check</h3><p><strong>Does the final examination count toward the 330 minutes of required instruction?</strong></p><details><summary>Check your answer</summary><p><strong>No.</strong> The instructional ledger is completed separately. The comprehensive final examination follows the required instruction and breaks.</p></details>' . $source_note,
			),
			'adult_en_003' => array(
				'title'    => 'Course Rules, Identity, Seat Time, and Completion',
				'objective'=> 'Online participation and security requirements supporting 4.1.1.1(A)',
				'minutes'  => 3,
				'content'  => '<div class="gb-lesson"><p>Your course record must accurately show who completed the work, how instructional time was earned, and how knowledge was demonstrated.</p><h2>Complete your own work</h2><p>The enrolled student must personally complete the lessons, participation questions, multimedia checks, and final examination. Do not share course access or allow another person to answer for you. Identity and participation controls protect the validity of the course record.</p><h2>How instructional time is earned</h2><ul><li>Remain present and actively engaged with the assigned lesson.</li><li>Follow lessons in the required sequence.</li><li>Do not count a scheduled break as instructional time.</li><li>Do not count time spent taking the comprehensive final examination as instruction.</li><li>Return to material when a response shows that more review is needed.</li></ul><p>The course may use activity checks, timed lessons, identity validation, and question history to document participation. A page being open by itself is not the same as active study.</p><h2>Participation questions and multimedia</h2><p>Required topics include participation-question banks. Multimedia longer than three minutes may also have clip-specific questions. If a required multimedia question is missed, the course may require the material to be replayed before a different question is presented.</p><h2>Final examination standard</h2><p>The comprehensive final contains at least 30 questions drawn from separate highway-sign and traffic-law banks. A score of 70 percent or higher demonstrates mastery. Retests use different questions. Three failed comprehensive-final attempts result in failure of the course.</p><div style="border-left:4px solid #9a6700;padding:12px 16px;background:#fff8e5;margin:18px 0"><strong>Protect your account:</strong> Keep your sign-in information private and sign out when using a shared device.</div><h3>Lesson check</h3><p><strong>True or false:</strong> Leaving a lesson open while you do something unrelated automatically earns instructional time.</p><details><summary>Check your answer</summary><p><strong>False.</strong> The course record must reflect active participation and the student must personally complete the work.</p></details>' . $source_note,
			),
			'adult_en_004' => array(
				'title'    => 'Driving as a Privilege and Lifelong Responsibility',
				'objective'=> '4.1.1.1(B)–(C)',
				'minutes'  => 2,
				'content'  => '<div class="gb-lesson"><p>Driving gives a person mobility and independence, but it also places that person in control of a machine capable of causing injury, death, and property damage. Texas therefore treats driving as a privilege that carries continuing responsibilities and obligations.</p><h2>Knowledge supports responsible decisions</h2><p>Traffic laws create a shared system for people who use public roadways. Knowing the law helps a driver predict what others should do and choose a legal response. Knowledge alone is not enough: the driver must understand the situation and apply the rule correctly.</p><p>A reduced-risk driver asks:</p><ul><li>What does the law require?</li><li>What hazards are present or developing?</li><li>Who could be affected by my decision?</li><li>What legal action gives me the safest available margin?</li></ul><h2>Responsibilities and consequences</h2><p>Driver responsibilities include maintaining attention, yielding when required, controlling speed, communicating intentions, protecting passengers, and cooperating with other roadway users. Failing to meet those responsibilities can lead to a collision, injury, financial loss, a citation, license action, criminal consequences, or loss of life.</p><div style="border-left:4px solid #1769aa;padding:12px 16px;background:#f3f8fc;margin:18px 0"><strong>Reduced-risk driving:</strong> You cannot remove every risk from driving. You can recognize risk early and make informed, legal, and responsible choices that reduce it.</div><h3>Apply the principle</h3><p>A traffic signal turns green, but a pedestrian is still in the crosswalk. The green signal permits movement only when it is legal and safe. A responsible driver waits, protects the pedestrian, and proceeds only after the path is clear.</p><h3>Lesson check</h3><p><strong>What is the best foundation for a reduced-risk driving decision?</strong></p><details><summary>Check your answer</summary><p>Use knowledge of the law, identify the actual risk, consider your responsibilities to others, and choose the safest legal action available.</p></details><p><strong>Topic One takeaway:</strong> Driving is a privilege. Legal knowledge, responsible judgment, and continued learning are obligations that come with that privilege.</p>' . $source_note,
			),
		);
	}

	public static function adult_topic_two_content() {
		$poi       = 'https://www.sos.state.tx.us/texreg/archive/April242026/In%20Addition/202601590-1.pdf';
		$handbook  = 'https://www.dps.texas.gov/internetforms/forms/dl-7.pdf';
		$apply     = 'https://www.dps.texas.gov/section/driver-license/apply-texas-driver-license';
		$register  = 'https://www.txdmv.gov/motorists/register-your-vehicle';
		$sr22      = 'https://www.dps.texas.gov/section/driver-license/financial-responsibility-insurance-certificate-sr-22';
		$disability= 'https://www.dps.texas.gov/news/dps-announces-driver-license-card-updates-under-texas-driving-disability-program';
		$base_note = '<hr><p><small><strong>Official sources:</strong> <a href="' . esc_url( $poi ) . '" target="_blank" rel="noopener noreferrer">TDLR Adult Six-Hour POI, May 2026</a> and <a href="' . esc_url( $handbook ) . '" target="_blank" rel="noopener noreferrer">Texas Driver Handbook, January 2026</a>.</small></p>';

		return array(
			'adult_en_005' => array(
				'title' => 'Applying for a Texas Driver License', 'objective' => '4.1.2.1(A)', 'minutes' => 4,
				'content' => '<div class="gb-lesson"><p>A Texas driver license is evidence that the state has authorized a person to operate the class of vehicle shown on the license, subject to any restrictions. Obtaining it is a legal process, not simply a driving test.</p><h2>Start with the correct requirements</h2><p>Requirements depend on age, prior licensing history, lawful presence, the type of vehicle, and the transaction being requested. Always check the current DPS instructions before an appointment. A first-time applicant generally must establish identity, lawful presence or U.S. citizenship, Texas residency, and a Social Security number, and must meet applicable education, testing, vision, and fee requirements.</p><p>Applicants who own vehicles may also be asked for evidence of current Texas registration and insurance. A person who does not own a vehicle may make the statement DPS requires for that situation.</p><h2>Adult driver education</h2><p>Texas requires a six-hour adult driver education course for a first-time applicant who is 18 through 24 years old, unless an applicable exception applies. Adults 25 or older are not subject to that age-based education requirement, although they may take the course to prepare for licensing. A new Texas resident surrendering a valid, unexpired out-of-state license may have different requirements.</p><h2>The instruction permit and practice</h2><p>An adult who needs to practice before the road test must hold the credential DPS requires for supervised driving. The license may carry a restriction requiring a properly licensed adult to be in the front seat. The student must follow the exact restrictions printed on the credential.</p><h2>Knowledge, vision, and driving skills</h2><p>DPS may require vision, knowledge, and driving examinations. Driver education supports preparation, but the student remains responsible for meeting DPS requirements. If a driving test is required, the applicant must bring the documents and vehicle required by the testing authority and must satisfy the current Impact Texas Drivers requirement when applicable.</p><div style="border-left:4px solid #1769aa;padding:12px 16px;background:#f3f8fc;margin:18px 0"><strong>Best practice:</strong> Use the DPS application checklist shortly before the appointment. Do not rely on an old social-media post or another applicant’s document list.</div><h3>Lesson check</h3><p><strong>Why should an applicant review current DPS instructions before applying?</strong></p><details><summary>Check your answer</summary><p>Requirements vary by applicant and transaction and can change. The applicant must bring the current documents and satisfy the current education, testing, and licensing requirements.</p></details><p><small><a href="' . esc_url( $apply ) . '" target="_blank" rel="noopener noreferrer">Current DPS application guidance</a></small></p>' . $base_note,
			),
			'adult_en_006' => array(
				'title' => 'License Classes, Restrictions, and Endorsements', 'objective' => '4.1.2.1(B)', 'minutes' => 5,
				'content' => '<div class="gb-lesson"><p>A driver is authorized to operate only the vehicles permitted by the license class and must obey every restriction shown on the credential. An endorsement adds a specific authorization; a restriction limits how or what the person may drive.</p><h2>Noncommercial and commercial classes</h2><p>Most passenger-car drivers use a noncommercial Class C license. Other classes apply when vehicle weight, configuration, passenger capacity, cargo, or use places the vehicle in another category. Commercial motor vehicles are governed by additional licensing, knowledge, skills, medical, and federal requirements.</p><p>Do not choose a class by the vehicle’s appearance. A large pickup, van, trailer combination, bus, or recreational vehicle may require closer review of weight ratings, passenger capacity, use, and statutory exemptions.</p><h2>Restrictions</h2><p>A restriction appears on the license when driving privileges are limited. Common examples may address corrective lenses, vehicle equipment, daytime operation, supervised driving, or another condition DPS has placed on the credential. The exact code and wording on the license control.</p><p>Ignoring a restriction means operating outside the privilege granted by the state. Before driving, read the front and back of the credential and understand every restriction. If circumstances change, follow the DPS procedure to request removal or modification; do not simply stop obeying it.</p><h2>Endorsements</h2><p>An endorsement represents additional qualification for a particular vehicle or operation, such as motorcycle operation or certain commercial activities. An endorsement is not automatic merely because the driver has experience. The person must meet the applicable application, testing, and eligibility requirements.</p><h2>Special information</h2><p>A Texas license or identification card may also contain information that assists with identification, emergency response, or communication. Some indicators are voluntary and require supporting documentation.</p><div style="border-left:4px solid #9a6700;padding:12px 16px;background:#fff8e5;margin:18px 0"><strong>Before using an unfamiliar vehicle:</strong> Confirm that your license class, endorsements, and restrictions authorize that operation. Also verify that the vehicle itself is legally equipped, registered, and insured.</div><h3>Decision practice</h3><p>A driver has a restriction requiring corrective lenses. The trip is short and the driver believes vision is “good enough.” May the driver ignore the restriction?</p><details><summary>Check your answer</summary><p>No. The restriction is part of the legal driving privilege. The driver must use the required corrective lenses until DPS officially changes the restriction.</p></details><h3>Lesson check</h3><p><strong>Match the term:</strong> A limitation placed on driving privileges is a <em>restriction</em>. An added authorization based on additional qualification is an <em>endorsement</em>.</p>' . $base_note,
			),
			'adult_en_007' => array(
				'title' => 'Suspensions, Revocations, and Renewal', 'objective' => '4.1.2.1(A)–(C)', 'minutes' => 5,
				'content' => '<div class="gb-lesson"><p>A driver must maintain legal eligibility after the license is issued. A card that appears unexpired does not guarantee that the driving privilege is currently valid.</p><h2>Suspension, revocation, cancellation, and denial</h2><ul><li><strong>Suspension:</strong> driving privilege is temporarily withdrawn for a stated period or until requirements are satisfied.</li><li><strong>Revocation:</strong> the license or privilege is terminated under law; restoration generally requires satisfying the applicable eligibility and application requirements.</li><li><strong>Cancellation:</strong> DPS withdraws a license that should not remain in effect, such as when eligibility or required information is not established.</li><li><strong>Denial:</strong> issuance of a license or privilege is refused for the applicable period or reason.</li></ul><p>Enforcement actions can result from driving-related convictions, impaired-driving proceedings, failure to maintain required financial responsibility, certain crashes or judgments, medical determinations, administrative actions, or other grounds established by law.</p><h2>Do not drive while ineligible</h2><p>If DPS has suspended, revoked, cancelled, or denied the privilege, the person must not drive merely because the physical card is still in possession. Driving while the license is invalid can create additional criminal and administrative consequences.</p><h2>Reinstatement is individualized</h2><p>There is no single reinstatement checklist for every case. DPS directs a person to the License Eligibility system to identify the period, fees, education, insurance filing, court documentation, or other compliance items that apply. In some cases an SR-22 certificate of financial responsibility must be maintained for the required period. An ordinary insurance card is not a substitute when an SR-22 filing is specifically required.</p><h2>Renewal responsibilities</h2><p>Drivers are responsible for monitoring expiration and eligibility, maintaining a current address with DPS, and completing renewal requirements on time. Eligibility for online renewal varies. Renewal does not erase unresolved enforcement actions.</p><div style="border-left:4px solid #1769aa;padding:12px 16px;background:#f3f8fc;margin:18px 0"><strong>Verify before driving:</strong> If you received a notice, missed a court obligation, had an insurance-related action, or are uncertain about status, use the official DPS License Eligibility service.</div><h3>Lesson check</h3><p>A license card expires next year, but DPS suspended the person’s driving privilege. Is the person legally permitted to drive?</p><details><summary>Check your answer</summary><p>No. The status of the driving privilege controls. Possession of an apparently unexpired card does not override a suspension.</p></details><p><small><a href="https://www.dps.texas.gov/section/driver-license/reinstating-your-driver-license-or-driving-privilege" target="_blank" rel="noopener noreferrer">DPS reinstatement guidance</a> · <a href="' . esc_url( $sr22 ) . '" target="_blank" rel="noopener noreferrer">DPS SR-22 guidance</a></small></p>' . $base_note,
			),
			'adult_en_008' => array(
				'title' => 'Vehicle Registration and Financial Responsibility', 'objective' => '4.1.2.1(D)–(F)', 'minutes' => 5,
				'content' => '<div class="gb-lesson"><p>Legal driving requires more than a valid driver license. The vehicle must also meet current registration, equipment, inspection when applicable, and financial-responsibility requirements.</p><h2>Registration</h2><p>Texas vehicle registration connects the vehicle to its owner and authorizes operation under the registration laws. Owners are responsible for completing title and registration transactions, keeping registration current, displaying the required plates, and reporting required ownership or address changes.</p><p>Registration procedures depend on whether the vehicle is new, used, newly brought into Texas, commercial, exempt, or subject to an emissions requirement. Current TxDMV instructions and the county tax assessor-collector provide the controlling transaction guidance.</p><h2>Current inspection framework</h2><p>Beginning in 2025, Texas eliminated the annual safety inspection requirement for most noncommercial vehicles. Commercial vehicles remain subject to safety-inspection requirements. Emissions inspections continue in designated counties for applicable vehicles. A driver must check the current rule for the vehicle and county rather than assuming every Texas vehicle follows the same inspection procedure.</p><h2>Financial responsibility</h2><p>The Texas Motor Vehicle Safety Responsibility Act requires drivers and owners to maintain proof of financial responsibility. Most people satisfy this through motor-vehicle liability insurance. Texas minimum liability limits are commonly described as 30/60/25: up to $30,000 for bodily injury to one person, $60,000 total bodily injury per crash, and $25,000 for property damage, subject to the policy and law.</p><p>Minimum liability coverage pays covered losses owed to other people; it does not automatically pay for every loss to the insured driver or vehicle. Drivers should understand what their policy covers, who is listed, which vehicles are covered, deductibles, exclusions, and effective dates.</p><h2>Proof and verification</h2><p>Carry acceptable proof of financial responsibility and provide it when legally required. Texas also uses electronic insurance verification. Never drive after a policy has lapsed, and do not assume a payment or application created coverage until the insurer confirms the effective policy.</p><div style="border-left:4px solid #9a6700;padding:12px 16px;background:#fff8e5;margin:18px 0"><strong>Before every trip:</strong> The driver, vehicle, registration, and insurance must all be legally ready. Fixing one does not cure a problem with another.</div><h3>Lesson check</h3><p>True or false: Every noncommercial vehicle in every Texas county must receive the former annual safety inspection.</p><details><summary>Check your answer</summary><p>False. Texas eliminated that safety inspection for most noncommercial vehicles beginning in 2025, while commercial safety inspections and designated-county emissions requirements continue.</p></details><p><small><a href="' . esc_url( $register ) . '" target="_blank" rel="noopener noreferrer">Current TxDMV registration guidance</a></small></p>' . $base_note,
			),
			'adult_en_009' => array(
				'title' => 'Texas Driving with Disabilities Program', 'objective' => '4.1.2.1(G)', 'minutes' => 5,
				'content' => '<div class="gb-lesson"><p>The Texas Driving with Disability Program provides voluntary ways for a person with a disability or health condition affecting communication to alert law enforcement before or during an interaction. Its purpose is safer, clearer communication—not reduced legal responsibility.</p><h2>Driver license and identification-card indicators</h2><p>Qualifying Texans may request a <strong>Communication Impediment</strong> indicator or a <strong>Deaf/Hard of Hearing</strong> indicator on the front of a Texas driver license or identification card. Participation is voluntary.</p><p>The applicant must use the current DPS process. DPS guidance requires Physician/Psychiatrist’s Statement Form DL-101 signed by the appropriate healthcare provider, along with the documents required for the driver license or identification-card transaction, at an in-person DPS appointment.</p><h2>Conditions and communication needs</h2><p>A communication impediment may arise from a disability or health condition that affects how a person understands, processes, or responds during an encounter. Eligibility is supported by the healthcare professional’s statement. A driver should not attempt to diagnose another person based on appearance or behavior.</p><h2>Vehicle-registration disclosure and TLETS</h2><p>Texas also provides a voluntary vehicle-registration disclosure process through TxDMV. Information associated with a vehicle can be made available to law enforcement through the Texas Law Enforcement Telecommunications System (TLETS). This is separate from placing an indicator on the front of a driver license or ID card, and the required forms and agency procedures differ.</p><h2>During a traffic stop</h2><p>An indicator or disclosure can alert the officer that communication may require additional time or a different approach. The driver should still follow lawful instructions, keep hands visible, avoid sudden movements, and communicate in the safest available way. A program indicator is not a waiver of traffic laws, licensing rules, or officer safety procedures.</p><div style="border-left:4px solid #1769aa;padding:12px 16px;background:#f3f8fc;margin:18px 0"><strong>Remember:</strong> The program is voluntary and intended to reduce misunderstanding. The individual chooses whether to participate.</div><h3>Lesson check</h3><p>Which form does current DPS guidance identify for requesting a qualifying communication indicator on a driver license or ID card?</p><details><summary>Check your answer</summary><p>Physician/Psychiatrist’s Statement Form DL-101, completed and signed by the appropriate healthcare provider.</p></details><h3>Apply the distinction</h3><p>An indicator on the front of a driver license or ID card is requested through DPS. A vehicle-related disclosure is handled through the TxDMV process and may be available to officers through TLETS.</p><p><small><a href="' . esc_url( $disability ) . '" target="_blank" rel="noopener noreferrer">May 2026 DPS program update</a> · <a href="https://gov.texas.gov/organization/disabilities/texas-driving-with-disability" target="_blank" rel="noopener noreferrer">Texas Driving with Disability Program</a></small></p>' . $base_note,
			),
		);
	}

	public static function adult_topic_three_content() {
		$poi      = 'https://www.sos.state.tx.us/texreg/archive/April242026/In%20Addition/202601590-1.pdf';
		$handbook = 'https://www.dps.texas.gov/internetforms/forms/dl-7.pdf';
		$law      = 'https://statutes.capitol.texas.gov/Docs/TN/htm/TN.545.htm';
		$moveover = 'https://www.txdot.gov/safety/traffic-safety-campaigns/move-over-or-slow-down.html';
		$note     = '<hr><p><small><strong>Official sources:</strong> <a href="' . esc_url( $poi ) . '" target="_blank" rel="noopener noreferrer">TDLR Adult Six-Hour POI, May 2026</a>, <a href="' . esc_url( $handbook ) . '" target="_blank" rel="noopener noreferrer">Texas Driver Handbook, January 2026</a>, and <a href="' . esc_url( $law ) . '" target="_blank" rel="noopener noreferrer">Texas Transportation Code, Chapter 545</a>.</small></p>';

		return array(
			'adult_en_010' => array(
				'title' => 'What Right-of-Way Means', 'objective' => '4.1.3.1(A), (F)–(G)', 'minutes' => 5,
				'content' => '<div class="gb-lesson"><p><strong>Right-of-way</strong> describes who may lawfully proceed first when roadway paths conflict. It is never a guarantee that another person will yield, and it does not excuse a driver from avoiding a crash.</p><h2>Yielding and accepting</h2><p>To yield is to give another road user the time and space needed to proceed. Before accepting right-of-way, search left, front, right, mirrors, and blind areas; confirm that others are actually yielding; and enter only when the available gap is safe.</p><p>Drivers must share the road with pedestrians, bicyclists, motorcyclists, and vehicles of every size. A motorcycle is entitled to a full lane. Its smaller size can make its speed and distance difficult to judge, so look twice and never turn across its path based on a quick glance.</p><h2>Responsibility remains</h2><p>A driver who fails to yield may receive a citation and may cause injury, death, or property loss. A driver who technically has priority must still brake or wait when proceeding would create a collision.</p><div style="border-left:4px solid #1769aa;padding:12px 16px;background:#f3f8fc;margin:18px 0"><strong>Reduced-risk rule:</strong> Know when the law requires you to yield, then verify that the path is clear before moving.</div><h3>Lesson check</h3><p>A driver has a green light, but a vehicle is still blocking the intersection. Should the driver enter?</p><details><summary>Check your answer</summary><p>No. A signal does not authorize a collision or entry into a blocked path. Wait until movement is legal and safe.</p></details>' . $note,
			),
			'adult_en_011' => array(
				'title' => 'Controlled and Uncontrolled Intersections', 'objective' => '4.1.3.1(B)–(C)', 'minutes' => 8,
				'content' => '<div class="gb-lesson"><p>An intersection is a conflict area where roads or roadway movements meet. Approach every intersection at a speed that permits observation, decision, and stopping.</p><h2>Controlled intersections</h2><p>Traffic signals, STOP signs, YIELD signs, pavement markings, or an officer may control movement. Stop at the marked stop line; if none, stop before the crosswalk; if neither exists, stop where the intersecting roadway can be seen without entering it. A green light permits movement only after yielding as required and confirming a clear path. A driver turning left yields to approaching traffic close enough to be hazardous.</p><h2>Uncontrolled intersections</h2><p>When no sign or signal controls the intersection, reduce speed and prepare to yield. When vehicles arrive at approximately the same time, the driver on the left yields to the driver on the right. A driver entering from an unpaved road yields to traffic on a paved road. Never assume another driver understands or will follow the rule.</p><h2>Four-way stops</h2><p>Each driver makes a complete stop. The vehicle that stopped first normally proceeds first. If vehicles stop at approximately the same time, apply the right-side rule. Communicate with signals and vehicle position, but do not wave another road user into danger.</p><h2>Blocked or failed controls</h2><p>Do not enter an intersection unless there is room to clear it. If a traffic signal is dark or malfunctioning, slow, identify the condition, follow current law and any officer or temporary control, and proceed only when safe.</p><h3>Lesson check</h3><p>Two vehicles reach an uncontrolled intersection at approximately the same time. Which driver normally yields?</p><details><summary>Check your answer</summary><p>The driver on the left yields to the driver on the right, while both remain responsible for avoiding a crash.</p></details>' . $note,
			),
			'adult_en_012' => array(
				'title' => 'Turns, T-Intersections, Circles, and Entering Traffic', 'objective' => '4.1.3.1(B)–(C), (F)–(G)', 'minutes' => 7,
				'content' => '<div class="gb-lesson"><p>Turning and entering traffic require a driver to cross or join another road user’s path. Plan early, signal, position correctly, control speed, and yield before the paths conflict.</p><h2>Turns and T-intersections</h2><p>A left-turning driver yields to approaching traffic that is in the intersection or close enough to be an immediate hazard. At a T-intersection, traffic on the road that ends must stop or yield as directed and enter the through road only when safe. Make turns into the lawful lane without cutting corners or swinging wide.</p><h2>Traffic circles and roundabouts</h2><p>Slow before entry, read signs and lane arrows, and yield to traffic already circulating. Choose the correct lane before entering, follow the circular roadway, and signal the exit when practical. Never stop inside merely to allow an entering vehicle to go unless traffic conditions require stopping.</p><h2>Private roads, driveways, alleys, and parking lots</h2><p>A driver entering a roadway from a private road, driveway, alley, building, or parking area must stop or yield as the law requires and protect pedestrians using the sidewalk or shoulder. Enter only with a gap large enough to accelerate without forcing roadway traffic to brake sharply.</p><h2>Controlled-access roads</h2><p>Use the acceleration lane to build an appropriate speed, signal, find a safe gap, and yield to traffic already on the highway. Drivers on the highway should maintain a predictable path and may change lanes when lawful and safe, but entering traffic remains responsible for yielding.</p><h3>Lesson check</h3><p>Who yields at a roundabout entrance?</p><details><summary>Check your answer</summary><p>The entering driver yields to traffic already circulating and enters only when the selected lane and gap are safe.</p></details>' . $note,
			),
			'adult_en_013' => array(
				'title' => 'Pedestrians, Crosswalks, and School Crossings', 'objective' => '4.1.3.1(C)–(D), (G)', 'minutes' => 7,
				'content' => '<div class="gb-lesson"><p>Pedestrians are vulnerable road users. Drivers must search for them before turning, backing, entering a roadway, passing stopped traffic, or moving through a crosswalk.</p><h2>Crosswalk awareness</h2><p>A crosswalk may be marked or unmarked. Yield as required to pedestrians in a crosswalk, and never pass a vehicle stopped at a crosswalk without first determining why it stopped. A pedestrian can be hidden by the stopped vehicle.</p><p>Before turning, scan the sidewalk and both ends of the crosswalk. Check again immediately before movement. Keep the entire crosswalk clear while stopped. When backing from a driveway or parking space, move slowly and yield to people on the sidewalk or behind the vehicle.</p><h2>Signals and special risk</h2><p>Obey pedestrian-control signals and traffic signals, but remain ready for error. Children may move unpredictably; older adults and people with disabilities may need more time. A white cane or guide dog can identify a person who is blind or has impaired vision. Stop and protect the person as the law requires.</p><h2>School areas</h2><p>Reduce speed, obey the posted school-zone control when active, follow crossing-guard directions, and expect children between parked vehicles. Do not use a phone or other distraction in a way prohibited by law or that prevents full attention.</p><div style="border-left:4px solid #9a6700;padding:12px 16px;background:#fff8e5;margin:18px 0"><strong>Do not surrender judgment:</strong> Even when a pedestrian acts unlawfully, use every reasonable action to avoid injury.</div><h3>Lesson check</h3><p>A vehicle is stopped before a crosswalk with no visible traffic signal problem. What should an approaching driver do?</p><details><summary>Check your answer</summary><p>Slow and determine whether a pedestrian is hidden from view. Do not pass until the crosswalk and path are confirmed clear and passing is lawful.</p></details>' . $note,
			),
			'adult_en_014' => array(
				'title' => 'School Buses, Emergency Vehicles, and Move Over or Slow Down', 'objective' => '4.1.3.1(D)–(E)', 'minutes' => 8,
				'content' => '<div class="gb-lesson"><p>Some stopped or approaching vehicles create special legal duties because people may be working, responding to emergencies, or entering the roadway.</p><h2>School buses</h2><p>When a school bus displays alternating flashing red signals, approaching drivers must stop as Texas law requires and may not proceed until the bus resumes motion, the driver signals, or the visual signal is no longer activated. A divided highway can change the duty for traffic on the opposite roadway; a painted center line or turn lane alone is not necessarily the physical separation required by law. Slow early and watch for children.</p><h2>Approaching emergency vehicles</h2><p>When an authorized emergency vehicle approaches using required audible and visual signals, yield the right-of-way, move toward the right edge or curb clear of the intersection, and stop until it passes, unless an officer directs otherwise. Do not follow closely or enter a scene.</p><h2>Move Over or Slow Down</h2><p>When approaching a stopped vehicle covered by the Texas law with activated overhead lights, move out of the lane closest to it when the roadway and traffic permit. If you cannot safely move over, slow to at least 20 mph below the posted speed limit. When the posted limit is 25 mph or less, slow to 5 mph. Maintain control and be prepared for workers or people near the lane.</p><p>Effective September 1, 2025, Texas expanded the covered group to include animal-control officers and parking-enforcement employees. Current law also covers the other vehicle and worker categories identified in the statute and official TxDOT guidance. Learn the current list rather than relying on an older memory of the rule.</p><div style="border-left:4px solid #1769aa;padding:12px 16px;background:#f3f8fc;margin:18px 0"><strong>Make space early:</strong> Check mirrors, signal, and change lanes smoothly. Never create a second emergency by forcing an unsafe lane change.</div><h3>Lesson check</h3><p>The speed limit is 65 mph and moving over is unsafe. What does the rule require?</p><details><summary>Check your answer</summary><p>Slow to at least 20 mph below the posted limit—45 mph or less—while maintaining safe control for conditions.</p></details><p><small><a href="' . esc_url( $moveover ) . '" target="_blank" rel="noopener noreferrer">Current TxDOT Move Over or Slow Down guidance</a></small></p>' . $note,
			),
			'adult_en_015' => array(
				'title' => 'Railroad Crossings and Right-of-Way Decisions', 'objective' => '4.1.3.1(C), (F)–(G)', 'minutes' => 7,
				'content' => '<div class="gb-lesson"><p>A train cannot swerve and may require a long distance to stop. The safe decision is made before the vehicle enters the crossing.</p><h2>When Texas law requires a stop</h2><p>Stop between <strong>15 and 50 feet</strong> from the nearest rail when a signal warns of a train, a crossing gate is lowered, a flagger signals, a train is plainly visible and dangerously close, or an approaching train emits an audible signal as specified by law. Never drive around, under, or through a lowered or moving gate.</p><h2>Before crossing</h2><p>Slow, look both directions, listen, and confirm enough space exists on the far side for the entire vehicle. Never begin crossing unless you can clear every track without stopping. Expect a second train from either direction after the first passes. Cross only at a designated roadway crossing and obey signs, pavement markings, signals, and flaggers.</p><h2>Special vehicles and conditions</h2><p>Some vehicles must stop at railroad crossings even when an ordinary passenger vehicle might not. Follow the rules for the vehicle being operated. Use extra caution when visibility is limited, traffic is backed up, the surface is uneven, or multiple tracks are present.</p><h2>If the vehicle becomes trapped</h2><p>Leave the vehicle and move away from the tracks immediately, toward the direction from which the train is approaching so debris is carried away from you. Once clear, use the Emergency Notification System information posted at the crossing and call 911. Do not remain in or return to a vehicle in the train’s path.</p><h3>Decision practice</h3><p>Traffic beyond the tracks leaves no room for your vehicle. The signal is inactive. May you cross?</p><details><summary>Check your answer</summary><p>No. Do not enter until there is enough room to clear all tracks completely.</p></details><h3>Topic takeaway</h3><p>Right-of-way law organizes traffic, but reduced-risk driving requires observation, communication, space, and a willingness to yield whenever proceeding would be unsafe.</p>' . $note,
			),
		);
	}

	public static function adult_topic_four_content() {
		$poi = 'https://www.sos.state.tx.us/texreg/archive/April242026/In%20Addition/202601590-1.pdf';
		$handbook = 'https://www.dps.texas.gov/internetforms/forms/dl-7.pdf';
		$note = '<hr><p><small><strong>Official sources:</strong> <a href="' . esc_url( $poi ) . '" target="_blank" rel="noopener noreferrer">TDLR Adult Six-Hour POI, May 2026, Topic 4.1.4</a> and <a href="' . esc_url( $handbook ) . '" target="_blank" rel="noopener noreferrer">Texas Driver Handbook, January 2026, Chapter 5</a>.</small></p>';
		return array(
			'adult_en_016' => array( 'title'=>'Why Traffic Control Devices Matter','objective'=>'4.1.4.1(C)–(D)','minutes'=>4,'content'=>'<div class="gb-lesson"><p>Traffic control devices create a shared visual language for drivers, pedestrians, bicyclists, and workers. Signs, signals, and pavement markings assign movement, warn of hazards, guide routes, and organize roadway space.</p><h2>Use a decision sequence</h2><ol><li><strong>Detect:</strong> search far enough ahead to notice the device early.</li><li><strong>Identify:</strong> use color, shape, symbol, words, location, and illumination.</li><li><strong>Interpret:</strong> decide what the device requires or warns about in the present conditions.</li><li><strong>Respond:</strong> check surrounding traffic, communicate, and adjust speed or position smoothly.</li></ol><p>A device states a rule or warning; it does not guarantee the path is safe. A green signal does not remove the duty to yield to a pedestrian, and a posted speed is not a promise that the speed is safe in rain or congestion.</p><h2>Conflicting directions</h2><p>Follow lawful directions from a police officer or authorized traffic controller even when they differ from a routine signal. Temporary work-zone controls may replace normal lane markings. When a device is damaged, dark, blocked, or unclear, reduce speed, increase space, and follow current law rather than guessing.</p><h3>Guided decisions</h3><ol><li><p><strong>A signal is green but the intersection is blocked. Enter?</strong></p><details><summary>Compare your decision</summary><p>No. Wait until there is room to clear the intersection.</p></details></li><li><p><strong>A flagger directs traffic through a red signal in a work area. Which direction controls?</strong></p><details><summary>Compare your decision</summary><p>Follow the authorized flagger while continuing to watch for workers and conflicting movement.</p></details></li><li><p><strong>A sign is partly hidden by a truck. What reduces risk?</strong></p><details><summary>Compare your decision</summary><p>Slow, create space, search for repeated markings or signals, and do not make an abrupt maneuver based on a partial view.</p></details></li></ol></div>'.$note ),
			'adult_en_017' => array( 'title'=>'Regulatory Signs','objective'=>'4.1.4.1(A)–(B)','minutes'=>6,'content'=>'<div class="gb-lesson"><p>Regulatory signs communicate laws and legally enforceable movement rules. Most use white backgrounds with black or red symbols or words, but shape can identify a critical rule before the message is readable.</p><h2>Shapes and meanings</h2><ul><li><strong>Octagon:</strong> STOP. Make a complete stop at the correct location and yield before proceeding.</li><li><strong>Downward-pointing triangle:</strong> YIELD. Slow and give right-of-way; stop when necessary.</li><li><strong>Vertical rectangle:</strong> common regulatory form for speed, lane use, parking, turning, and other rules.</li><li><strong>Circle with a slash:</strong> the pictured action is prohibited.</li></ul><h2>Common regulatory decisions</h2><p>A speed-limit sign establishes the legal maximum under favorable conditions; drivers must choose a lower safe speed when conditions require. ONE WAY and DO NOT ENTER prevent opposing movement. Lane-use arrows and turn restrictions control which movements may be made from a lane. Parking signs can limit location, direction, duration, vehicle class, or time.</p><p>STOP means wheels cease movement. Stop at the line, before the crosswalk, or at the point required by law. YIELD never means force another road user to brake. It means select a gap that allows the other movement to continue safely.</p><h2>Red, white, and black</h2><p>Red emphasizes stop, prohibition, or a critical restriction. White and black commonly state enforceable rules. Always interpret the complete sign; color alone is not enough.</p><h3>Guided decisions</h3><ol><li><p><strong>The limit is 70 mph during heavy rain. Is 70 automatically safe?</strong></p><details><summary>Compare your decision</summary><p>No. It is the maximum under favorable conditions, not a required speed.</p></details></li><li><p><strong>You slow to 2 mph at STOP with no traffic visible. Is that a stop?</strong></p><details><summary>Compare your decision</summary><p>No. The vehicle must come to a complete stop.</p></details></li><li><p><strong>A YIELD-controlled merge has no immediate traffic. Must you always stop?</strong></p><details><summary>Compare your decision</summary><p>No, but slow, search, and yield; stop whenever needed to avoid interference.</p></details></li><li><p><strong>A turn arrow has a red slash. What does it mean?</strong></p><details><summary>Compare your decision</summary><p>The depicted turn is prohibited under the sign’s stated conditions.</p></details></li></ol></div>'.$note ),
			'adult_en_018' => array( 'title'=>'Warning Signs','objective'=>'4.1.4.1(A)–(B)','minutes'=>6,'content'=>'<div class="gb-lesson"><p>Warning signs provide advance notice of a roadway condition or hazard. Most are yellow diamonds with black symbols or words. Their purpose is to create time to search, slow, position, and prepare—not to replace observation.</p><h2>Recognizable shapes</h2><ul><li><strong>Diamond:</strong> general warning.</li><li><strong>Pennant:</strong> no-passing zone, placed on the left side of the road.</li><li><strong>Round:</strong> railroad crossing advance warning.</li><li><strong>Crossbuck:</strong> railroad grade crossing at the tracks.</li><li><strong>Pentagon:</strong> school area or school crossing.</li></ul><h2>Read the symbol, then the road</h2><p>Curve, intersection, merge, lane-ending, divided-highway, slippery-road, low-clearance, animal, bicycle, and pedestrian symbols identify the type of risk. Advisory-speed plaques describe a recommended speed for the condition; they do not cancel the duty to choose an even lower speed when weather, visibility, traffic, or vehicle condition requires it.</p><p>After seeing a warning sign, check mirrors before slowing, cover the brake when appropriate, select a safe lane position, and search for the actual hazard. The hazard may begin before or after the sign’s apparent location.</p><h3>Guided decisions</h3><ol><li><p><strong>A yellow curve sign includes a 35 mph plaque while the road limit is 55. What should change?</strong></p><details><summary>Compare your decision</summary><p>Reduce speed before the curve toward a safe speed no greater than conditions allow; the plaque warns of the curve’s recommended handling speed.</p></details></li><li><p><strong>You see a lane-ending symbol. Should you wait until the taper to force a merge?</strong></p><details><summary>Compare your decision</summary><p>No. Check traffic early, communicate, and merge according to signs and conditions without forcing another driver to react.</p></details></li><li><p><strong>A round yellow sign appears ahead. What risk should you anticipate?</strong></p><details><summary>Compare your decision</summary><p>A railroad crossing. Slow, look, listen, and be prepared to stop.</p></details></li><li><p><strong>Why look beyond a deer-crossing sign?</strong></p><details><summary>Compare your decision</summary><p>The sign identifies an area of increased risk; the animal can appear anywhere nearby and may be followed by others.</p></details></li></ol></div>'.$note ),
			'adult_en_019' => array( 'title'=>'Guide, School-Zone, and Work-Zone Signs','objective'=>'4.1.4.1(A)–(B)','minutes'=>6,'content'=>'<div class="gb-lesson"><p>Guide signs help drivers select routes and services. School and work-zone devices add warnings and controls where vulnerable people or changing roadway conditions require extra attention.</p><h2>Guide colors</h2><ul><li><strong>Green:</strong> destinations, directions, distances, and permitted movements.</li><li><strong>Blue:</strong> motorist services such as fuel, food, lodging, or medical help.</li><li><strong>Brown:</strong> recreation, parks, and cultural-interest destinations.</li></ul><p>Read guide signs early. Confirm route number, direction, exit, and lane before making a gradual lane change. Missing an exit is safer than crossing a gore area or making a sudden turn.</p><h2>School devices</h2><p>Fluorescent yellow-green signs and pentagon shapes draw attention to school areas, crossings, pedestrians, and bicyclists. Obey the posted school-zone speed when the sign, schedule, beacon, or other control makes it active. Search between parked vehicles and follow crossing-guard directions.</p><h2>Work zones</h2><p>Orange signs, channelizing devices, arrow boards, temporary markings, and flaggers warn that the normal roadway pattern may be changed. Slow before the activity area, increase following space, keep out of closed lanes, and expect workers and equipment near traffic. Temporary controls govern while in effect.</p><h3>Guided decisions</h3><ol><li><p><strong>You realize your exit is across a solid gore area. Cross it?</strong></p><details><summary>Compare your decision</summary><p>No. Continue and reroute safely.</p></details></li><li><p><strong>Normal white markings conflict with clear temporary orange controls. Which path applies?</strong></p><details><summary>Compare your decision</summary><p>Follow the temporary work-zone traffic control while it is in effect.</p></details></li><li><p><strong>A school-zone beacon is active but no children are visible. Obey the zone?</strong></p><details><summary>Compare your decision</summary><p>Yes. Follow the activated posted control and continue searching for children.</p></details></li><li><p><strong>A flagger holds a STOP paddle. May you proceed when the lane looks clear?</strong></p><details><summary>Compare your decision</summary><p>No. Remain stopped until the flagger directs movement.</p></details></li></ol></div>'.$note ),
			'adult_en_020' => array( 'title'=>'Traffic Signals and Flashing Signals','objective'=>'4.1.4.1(B)–(D)','minutes'=>8,'content'=>'<div class="gb-lesson"><p>Signals assign movement by color, arrow, position, and flashing pattern. Approach with a plan to stop; then proceed only when the indication and the roadway both permit it.</p><h2>Steady indications</h2><ul><li><strong>Red:</strong> stop at the required location. Remain stopped until a permitted movement is lawful and safe.</li><li><strong>Yellow:</strong> the green movement is ending. Stop if this can be done safely; never accelerate merely to beat red.</li><li><strong>Green:</strong> proceed only after yielding as required and checking that the intersection can be cleared.</li></ul><p>An arrow controls the movement it points toward. A green arrow gives a protected movement subject to yielding to people already lawfully in the intersection. A red arrow prohibits that movement until a signal permits it, subject to current law and posted controls.</p><h2>Flashing indications</h2><p>A flashing red signal is treated as a stop: stop completely, yield, and proceed when safe. A flashing yellow signal means slow and proceed with caution. A flashing yellow arrow permits the indicated turn after yielding to conflicting traffic and pedestrians.</p><h2>Signal failures and officers</h2><p>When a signal is dark or malfunctioning, reduce speed, identify every approach, follow current Texas law, and obey any officer or temporary control. Never assume cross traffic has the same display.</p><h2>Timing the decision</h2><p>Scan the signal while still checking the intersection. A stale green may change; cover the brake when circumstances suggest the phase may end. Rear-view awareness matters before braking, but a close follower never requires entering against a signal.</p><h3>Guided decisions</h3><ol><li><p><strong>Your light turns green while a pedestrian remains in the crosswalk.</strong></p><details><summary>Compare your decision</summary><p>Wait and yield until the path is clear.</p></details></li><li><p><strong>The signal turns yellow and a safe controlled stop is available.</strong></p><details><summary>Compare your decision</summary><p>Stop; do not accelerate to enter before red.</p></details></li><li><p><strong>A flashing red signal has no visible cross traffic.</strong></p><details><summary>Compare your decision</summary><p>Make a complete stop, search, yield, and then proceed when safe.</p></details></li><li><p><strong>A flashing yellow arrow permits a left turn. Is oncoming traffic required to stop?</strong></p><details><summary>Compare your decision</summary><p>No. Turn only after yielding to conflicting traffic and pedestrians.</p></details></li><li><p><strong>An officer signals you to remain stopped during green.</strong></p><details><summary>Compare your decision</summary><p>Obey the officer.</p></details></li><li><p><strong>Traffic beyond green is backed into the intersection.</strong></p><details><summary>Compare your decision</summary><p>Wait before entering until there is room to clear.</p></details></li></ol></div>'.$note ),
			'adult_en_021' => array( 'title'=>'Pavement and Lane-Control Markings','objective'=>'4.1.4.1(B)–(D)','minutes'=>7,'content'=>'<div class="gb-lesson"><p>Pavement markings organize opposing traffic, lanes traveling in the same direction, passing, turning, stopping, crossings, and roadway edges. Interpret color, line pattern, arrows, and surrounding signs together.</p><h2>Color and line pattern</h2><p><strong>Yellow</strong> generally separates traffic moving in opposite directions or marks the left edge of a divided roadway. <strong>White</strong> generally separates lanes moving in the same direction or marks the right edge. Broken lines permit crossing when lawful and safe; solid lines restrict or discourage crossing according to their location and the applicable rule.</p><p>A double solid yellow center line prohibits crossing for ordinary passing. When one side is broken and the other solid, passing permission differs by side. Never pass merely because the line is broken; sight distance, signs, intersections, hills, curves, traffic, and law must also permit it.</p><h2>Arrows, stop lines, and crosswalks</h2><p>Lane arrows assign or guide movements. Select the correct lane early and follow its arrow. Stop behind a stop line. Keep crosswalks clear and search for pedestrians before turning. Diagonal gore markings separate traffic streams and are not travel lanes.</p><h2>Special markings</h2><p>Center turn lanes are for lawful turning movements, not passing or extended travel. Bicycle-lane and shared-lane markings alert drivers to bicycle movements but do not replace a full search before crossing or turning. Raised markers and reflectors reinforce lane boundaries, especially at night.</p><h3>Guided decisions</h3><ol><li><p><strong>A broken yellow line is on your side. Is passing automatic?</strong></p><details><summary>Compare your decision</summary><p>No. Pass only when every legal and visibility condition is satisfied and the maneuver can be completed safely.</p></details></li><li><p><strong>Your lane arrow indicates left turn only, but you want to continue straight.</strong></p><details><summary>Compare your decision</summary><p>Follow the lane assignment; change lanes only before the control and only when lawful and safe, otherwise turn and reroute.</p></details></li><li><p><strong>May a center turn lane be used to pass stopped traffic?</strong></p><details><summary>Compare your decision</summary><p>No. It is reserved for lawful turning use, not passing or ordinary travel.</p></details></li><li><p><strong>A white stop line is before the crosswalk. Where do you stop?</strong></p><details><summary>Compare your decision</summary><p>Behind the stop line, leaving the crosswalk clear.</p></details></li><li><p><strong>A bicycle lane crosses your right-turn path.</strong></p><details><summary>Compare your decision</summary><p>Signal, search mirrors and blind areas, yield to the bicyclist, and cross only when safe.</p></details></li></ol></div>'.$note ),
		);
	}

	public static function adult_topic_five_content() {
		$poi='https://www.sos.state.tx.us/texreg/archive/April242026/In%20Addition/202601590-1.pdf'; $hb='https://www.dps.texas.gov/internetforms/forms/dl-7.pdf';
		$note='<hr><p><small><strong>Official sources:</strong> <a href="'.esc_url($poi).'" target="_blank" rel="noopener noreferrer">TDLR Adult Six-Hour POI, May 2026, Topic 4.1.5</a> and <a href="'.esc_url($hb).'" target="_blank" rel="noopener noreferrer">Texas Driver Handbook, January 2026, Chapters 6–9</a>.</small></p>';
		return array(
		'adult_en_022'=>array('title'=>'Speed Control, Following Distance, and Stopping','objective'=>'4.1.5.1(A), (F)–(J), (P)','minutes'=>7,'content'=>'<div class="gb-lesson"><p><strong>Traffic flow</strong> is the organized movement of roadway users through a transportation system. Safe flow depends on predictable speed, adequate space, communication, and cooperation with traffic controls and lawful directions.</p><h2>Choose speed for the whole situation</h2><p>A posted maximum applies under favorable conditions. The safe speed may be lower because of traffic, rain, darkness, glare, hills, curves, work zones, vehicle condition, cargo, fatigue, or limited sight distance. Never drive faster than the distance you can see and manage. Route planning or postponing the trip may be the only responsible choice in severe conditions.</p><h2>Following interval</h2><p>Use a fixed roadside object to measure the time between the vehicle ahead passing it and your vehicle reaching it. Maintain at least the interval recommended by the current Texas Driver Handbook, and add substantial space for poor traction, darkness, heavy vehicles, motorcycles, blocked views, work zones, or a following driver who crowds you. Space is time to perceive, decide, and brake.</p><h2>Total stopping distance</h2><p>Stopping includes perception distance, reaction distance, and braking distance. Speed increases every part of the problem: the vehicle travels farther before braking begins, and braking distance rises sharply. Wet or loose pavement, worn tires, downhill grade, heavy load, and brake condition increase it further.</p><h2>Lights and visibility</h2><p>Use vehicle lights when required by law and whenever visibility demands them. Headlights help you see and help others detect you. High beams can improve distance vision but must be dimmed as required and whenever glare would endanger another road user.</p><h3>Guided decisions</h3><ol><li><p><strong>The limit is 65, but heavy rain limits sight distance. What controls?</strong></p><details><summary>Compare your decision</summary><p>Slow to a speed that allows control and stopping within the visible path; the posted maximum is not a safe-speed guarantee.</p></details></li><li><p><strong>A truck blocks your view ahead. Keep the normal interval?</strong></p><details><summary>Compare your decision</summary><p>Add space so you can see farther and respond without relying only on the truck driver.</p></details></li><li><p><strong>A driver tailgates you.</strong></p><details><summary>Compare your decision</summary><p>Increase space ahead, remain predictable, and allow the driver to pass when lawful and safe; do not brake-check.</p></details></li><li><p><strong>You feel highway hypnosis or repeated yawning.</strong></p><details><summary>Compare your decision</summary><p>Leave the roadway safely and rest. Music, open windows, or caffeine do not make a fatigued driver reliably safe.</p></details></li></ol></div>'.$note),
		'adult_en_023'=>array('title'=>'Lane Position, Lane Changes, and Blind Spots','objective'=>'4.1.5.1(A)–(F), (P)','minutes'=>6,'content'=>'<div class="gb-lesson"><p>Lane position controls visibility, space, and communication. Stay centered in the lawful lane unless a hazard or maneuver requires a deliberate adjustment.</p><h2>Blind spots</h2><p>Mirrors do not show every area beside and behind a vehicle. Adjust mirrors properly, scan them regularly, and make a brief shoulder check before moving laterally. Do not remain beside another vehicle where its driver may not see you—especially beside large trucks, buses, and motorcycles.</p><h2>Safe lane-change sequence</h2><ol><li>Search well ahead and identify why the change is needed.</li><li>Check inside and outside mirrors.</li><li>Signal early enough to communicate—not to demand space.</li><li>Check the blind area with a quick shoulder glance.</li><li>Confirm a safe gap ahead and behind.</li><li>Move smoothly one lane at a time and cancel the signal.</li></ol><p>Avoid changing lanes in intersections, across prohibited markings, through gore areas, or where visibility is inadequate. Temporary work-zone lanes may be narrower or shifted; follow the active controls and avoid drifting toward workers or barriers.</p><h2>Lane choice</h2><p>Use lane-control signs and arrows early. Keep right except when passing or when another lawful movement requires a different lane. Never use a center turn lane as a passing or travel lane. If you miss a turn or exit, continue and reroute instead of cutting across traffic.</p><h3>Guided decisions</h3><ol><li><p><strong>Your mirror looks clear. Is the lane change ready?</strong></p><details><summary>Compare your decision</summary><p>No. Signal, check the blind area, confirm the gap, and move only when safe.</p></details></li><li><p><strong>You are beside a truck near its rear wheels.</strong></p><details><summary>Compare your decision</summary><p>Avoid lingering. Fall back or pass efficiently when lawful, while staying out of the truck’s blind area.</p></details></li><li><p><strong>Your exit is separated by gore markings.</strong></p><details><summary>Compare your decision</summary><p>Do not cross the gore. Continue to the next lawful route.</p></details></li><li><p><strong>A work-zone taper ends your lane.</strong></p><details><summary>Compare your decision</summary><p>Obey signs and flaggers, communicate, manage speed and spacing, and merge without forcing another driver to brake or swerve.</p></details></li></ol></div>'.$note),
		'adult_en_024'=>array('title'=>'Turning, Signaling, and Communication','objective'=>'4.1.5.1(B)–(D), (P)','minutes'=>6,'content'=>'<div class="gb-lesson"><p>Drivers communicate with signals, brake lights, headlights, horn, lane position, speed, and eye contact. Communication must be timely and clear, but it never transfers responsibility to another road user.</p><h2>Before turning</h2><p>Plan early, choose the lawful lane, signal for the distance required by Texas law, reduce speed before steering, search the intersection and crosswalk, and yield as required. Keep wheels straight while waiting for a gap in a left turn so a rear impact is less likely to push the vehicle into opposing traffic.</p><p>Turn into the lawful lane without cutting the corner or swinging wide. Search again immediately before movement because pedestrians, bicyclists, and motorcycles can enter after the first check.</p><h2>Stopping, parking, backing, and leaving a space</h2><p>Signal or communicate before slowing substantially when practical. Stop where required without blocking a crosswalk. Before leaving a parking space, check around the vehicle, signal, yield, and enter traffic only with adequate space. Avoid backing whenever a forward option exists. When backing is necessary, look through the rear window and around the vehicle, move at walking speed, and stop if the view is lost. Cameras assist but do not replace direct observation.</p><h2>Horn and headlights</h2><p>Use the horn to warn of immediate danger, not to punish or express anger. Flashing headlights is not a legal command and may be misunderstood. Never rely on a wave from another driver without checking every conflict path yourself.</p><h3>Guided decisions</h3><ol><li><p><strong>A driver waves you across two lanes.</strong></p><details><summary>Compare your decision</summary><p>Verify every lane, sidewalk, and blind area yourself; the gesture covers only that driver.</p></details></li><li><p><strong>You begin turning right while looking left for traffic.</strong></p><details><summary>Compare your decision</summary><p>Stop and rescan the crosswalk and right-side path before moving.</p></details></li><li><p><strong>Your backup camera is clear.</strong></p><details><summary>Compare your decision</summary><p>Still check around and behind the vehicle directly and move slowly.</p></details></li><li><p><strong>Another driver makes an error.</strong></p><details><summary>Compare your decision</summary><p>Use the horn only if needed as a danger warning; create space rather than retaliating.</p></details></li></ol></div>'.$note),
		'adult_en_025'=>array('title'=>'Passing and Being Passed','objective'=>'4.1.5.1(D), (E), (P)','minutes'=>6,'content'=>'<div class="gb-lesson"><p>Passing creates closing-speed, visibility, and lane-conflict risks. Pass only when law, markings, sight distance, speed, and traffic all allow the maneuver.</p><h2>Before passing</h2><p>Ask whether passing is necessary. Check signs and markings, the road far ahead, mirrors, blind spots, vehicles entering from side roads, and the vehicle behind. Do not pass on hills, curves, intersections, railroad crossings, or other locations where law or limited view prohibits it. Never exceed the lawful safe speed to complete a pass.</p><h2>Passing sequence</h2><p>Signal, confirm the lane remains clear, move smoothly, maintain safe lateral space, and continue until the passed vehicle is visible in the mirror before returning. Signal the return and avoid cutting in. Motorcycles and bicycles require full recognition as roadway users; do not crowd them.</p><h2>When being passed</h2><p>Maintain a predictable lane and do not increase speed. Create space if needed. Competitive acceleration traps the passing driver beside you and increases danger for everyone.</p><h2>Passing on the right</h2><p>Passing on the right is permitted only under specific legal conditions and must never be done by driving off the pavement or using a non-travel lane. A shoulder, bicycle lane, parking lane, or center turn lane is not an ordinary passing lane.</p><h3>Guided decisions</h3><ol><li><p><strong>The center line is broken, but a hill blocks the view.</strong></p><details><summary>Compare your decision</summary><p>Do not pass. A permissive marking does not overcome inadequate sight distance.</p></details></li><li><p><strong>A vehicle begins passing you.</strong></p><details><summary>Compare your decision</summary><p>Hold a steady lane and do not accelerate; allow safe completion.</p></details></li><li><p><strong>Traffic stops for a pedestrian and the right shoulder is open.</strong></p><details><summary>Compare your decision</summary><p>Do not pass on the shoulder; the stopped traffic may conceal a pedestrian.</p></details></li><li><p><strong>You cannot return without cutting closely in front.</strong></p><details><summary>Compare your decision</summary><p>The pass was not safe to begin. Before passing, ensure enough clear distance to complete the entire maneuver legally.</p></details></li></ol></div>'.$note),
		'adult_en_026'=>array('title'=>'Parking, Backing, Freeway Travel, Emergencies, and Work Zones','objective'=>'4.1.5.1(D), (K)–(Q)','minutes'=>7,'content'=>'<div class="gb-lesson"><p>This lesson combines procedures used when ordinary traffic flow becomes more complex: freeway entry and exit, breakdowns, loss of vehicle control, poor weather, parking, and work zones.</p><h2>Freeway entry, travel, and exit</h2><p>Use the acceleration lane to approach traffic speed, signal, locate a gap, and yield to freeway traffic. Do not stop in the acceleration lane unless traffic leaves no safe alternative. On the freeway, maintain space, scan far ahead, avoid blind spots, and choose lanes early. For an exit, signal and enter the deceleration lane before reducing speed substantially.</p><h2>Breakdown</h2><p>Move out of travel lanes when possible, activate hazard warning lights, stop in the safest available location, and call for help. Stay away from moving traffic. Whether occupants should remain in or leave the vehicle depends on location and immediate hazards; choose the option that places people behind a barrier or farthest from traffic without crossing active lanes.</p><h2>Vehicle emergencies</h2><ul><li><strong>Skid:</strong> ease off the accelerator, look and steer toward the intended path, and avoid abrupt inputs.</li><li><strong>Blowout:</strong> hold the wheel firmly, ease off the accelerator, maintain direction, and slow gradually before leaving the roadway.</li><li><strong>Brake failure:</strong> try controlled braking methods appropriate to the system, shift to a lower gear when safe, use the parking brake gradually, and search for an escape path.</li><li><strong>Run off pavement:</strong> ease off the accelerator, stabilize, slow, and return gradually only when the edge and traffic permit.</li><li><strong>Steep downgrade:</strong> select a lower gear before the descent and avoid riding the brakes.</li></ul><h2>Winter and work zones</h2><p>Winter countermeasures include postponing travel, reducing speed, increasing space, making smooth inputs, clearing all glass and lights, and avoiding cruise control on slick surfaces. In construction or maintenance zones, obey temporary signs, markings, flaggers, and reduced speeds; expect abrupt stops, narrow lanes, equipment, and workers near traffic. Violations can cause bodily injury, death, property damage, and enhanced legal consequences.</p><h3>Guided decisions</h3><ol><li><p><strong>No freeway gap exists near the end of the acceleration lane.</strong></p><details><summary>Compare your decision</summary><p>Continue yielding and adjust speed; entering traffic does not gain priority by signaling.</p></details></li><li><p><strong>A tire blows at highway speed.</strong></p><details><summary>Compare your decision</summary><p>Grip firmly, maintain direction, ease off power, and slow gradually before moving off the road.</p></details></li><li><p><strong>Your wheels drop off pavement.</strong></p><details><summary>Compare your decision</summary><p>Do not jerk the wheel back. Stabilize, slow, and return gradually when safe.</p></details></li><li><p><strong>Ice is forecast along the route.</strong></p><details><summary>Compare your decision</summary><p>Consider delaying the trip; if travel is necessary, prepare the vehicle, reduce speed, add space, and use smooth controls.</p></details></li><li><p><strong>A flagger’s direction conflicts with normal markings.</strong></p><details><summary>Compare your decision</summary><p>Follow the authorized temporary control while continuing to protect workers and traffic.</p></details></li></ol></div>'.$note),
		);
	}

	public static function adult_topic_six_content() {
		$poi='https://www.sos.state.tx.us/texreg/archive/April242026/In%20Addition/202601590-1.pdf';
		$handbook='https://www.dps.texas.gov/internetforms/forms/dl-7.pdf';
		$note='<hr><p><small><strong>Controlling sources:</strong> <a href="'.esc_url($poi).'" target="_blank" rel="noopener noreferrer">TDLR Adult Six-Hour POI, May 2026, Topic 4.1.6</a>; <a href="'.esc_url($handbook).'" target="_blank" rel="noopener noreferrer">Texas Driver Handbook, January 2026, Chapter 10</a>; and the cited current Texas statutes. Statutes control if a summary becomes outdated.</small></p>';
		return array(
		'adult_en_027'=>array('title'=>'Zero-Tolerance Driving Decisions','objective'=>'4.1.6.1(G)','minutes'=>6,'content'=>'<div class="gb-lesson"><p><strong>Zero tolerance for driving</strong> means the driving decision is made before alcohol, cannabis, an impairing medicine, or another drug is used: do not drive after use and do not ride with an impaired driver.</p><h2>A complete transportation plan</h2><ol><li>Choose a sober driver who uses no impairing substance.</li><li>Arrange a rideshare, taxi, transit, overnight stay, or sober pickup before use begins.</li><li>Keep control of your own safe transportation and do not depend on an impaired person.</li><li>Prevent an impaired person from driving when this can be done safely; call emergency services when danger is immediate.</li></ol><p>Coffee, food, cold air, exercise, or a shower does not rapidly remove alcohol. Time is required. A person who feels “fine” may still have impaired judgment, divided attention, vision, coordination, or reaction time.</p><h3>Decision practice</h3><ol><li><strong>The designated driver has one drink.</strong> The plan has failed; use another sober option.</li><li><strong>A friend insists they drive because the trip is short.</strong> Distance does not remove impairment; stop the trip and arrange safe transportation.</li><li><strong>You took a new prescription and the label warns against driving.</strong> Do not drive until a qualified prescriber or pharmacist confirms how it affects you.</li></ol></div>'.$note),
		'adult_en_028'=>array('title'=>'Intoxication, BAC, and Driving Impairment','objective'=>'4.1.6.1(A)–(B)','minutes'=>8,'content'=>'<div class="gb-lesson"><p>Texas Penal Code §49.01 defines <strong>intoxicated</strong> in two independent ways: not having the normal use of mental or physical faculties because of alcohol, a controlled substance, a drug, a dangerous drug, a combination of substances, or another substance; <strong>or</strong> having an alcohol concentration of 0.08 or more.</p><p>A driver can therefore be legally intoxicated below 0.08 when normal faculties are lost. A number is not permission to drive, and the 0.08 definition does not apply as a safe threshold for a person under 21.</p><h2>What impairment changes</h2><ul><li><strong>Vision and attention:</strong> narrower search, missed hazards, poor tracking, and difficulty dividing attention.</li><li><strong>Judgment:</strong> increased risk-taking and reduced ability to recognize impairment.</li><li><strong>Reaction and coordination:</strong> slower responses, poor steering, braking, balance, and speed control.</li><li><strong>Memory and emotion:</strong> incomplete recall, aggression, drowsiness, or confusion.</li></ul><p>BAC depends on the amount and rate of consumption and individual factors. Counting drinks, body size, or elapsed time cannot guarantee a lawful or unimpaired condition. Only avoiding driving eliminates the calculation risk.</p><h3>Check understanding</h3><p><strong>True or false:</strong> A BAC below 0.08 prevents a Texas DWI charge.</p><details><summary>Answer</summary><p>False. Loss of normal mental or physical faculties is an independent definition of intoxication.</p></details></div>'.$note),
		'adult_en_029'=>array('title'=>'Drugs, Prescriptions, Cannabis, and Mixed Substances','objective'=>'4.1.6.1(B), (G)','minutes'=>7,'content'=>'<div class="gb-lesson"><p>Illegal drugs, cannabis products, prescriptions, over-the-counter medicines, inhalants, and combinations can impair driving. A lawful prescription does not make impaired driving lawful.</p><h2>Common driving effects</h2><ul><li>Sedatives, sleep aids, some antihistamines, pain medicines, and anxiety medicines may cause drowsiness, blurred vision, or slow reaction.</li><li>Stimulants may encourage aggression, overconfidence, distraction, or a later crash in alertness.</li><li>Cannabis can alter attention, time-distance judgment, coordination, lane control, and reaction.</li><li>Alcohol combined with another depressant can produce greater impairment than either substance alone.</li></ul><h2>Medication safety routine</h2><ol><li>Read every label and medication guide.</li><li>Ask the prescriber or pharmacist specifically about driving and combinations.</li><li>Do not drive while learning how a medicine affects you.</li><li>Never share medication or change dosage contrary to medical directions.</li><li>Arrange alternate transportation whenever impairment is possible.</li></ol><h3>Decision practice</h3><p>A medicine is sold without a prescription, so is driving automatically safe?</p><details><summary>Answer</summary><p>No. Over-the-counter products can impair alertness, vision, coordination, or reaction. Follow the warning and obtain professional guidance.</p></details></div>'.$note),
		'adult_en_030'=>array('title'=>'Texas Alcohol and Drug Driving Laws and Consequences','objective'=>'4.1.6.1(C)–(F)','minutes'=>10,'content'=>'<div class="gb-lesson"><p>Texas separates criminal cases, alcohol-law violations, and administrative driver-license actions. More than one process may arise from the same event.</p><h2>Adults and offenses applying at any age</h2><ul><li><strong>DWI:</strong> operating a motor vehicle in a public place while intoxicated. A first basic offense is generally a Class B misdemeanor with a minimum confinement term; aggravating facts, prior convictions, a passenger younger than 15, or alcohol concentration of 0.15 or more can increase the grade and penalties.</li><li><strong>Public intoxication:</strong> appearing in a public place while intoxicated to the degree the person may endanger self or another; generally a Class C misdemeanor.</li><li><strong>Intoxication assault:</strong> intoxication-related serious bodily injury; generally a third-degree felony, with enhancements in specified circumstances.</li><li><strong>Intoxication manslaughter:</strong> intoxication-related death; generally a second-degree felony, with enhancements in specified circumstances.</li><li><strong>Improper driver-license use:</strong> lending, possessing, displaying, or representing a license unlawfully can create a criminal offense and licensing consequences.</li></ul><h2>Under 21</h2><p>Texas Alcoholic Beverage Code Chapter 106 establishes zero-tolerance offenses and consequences for minors, including driving under the influence of alcohol by a minor and minor in possession. Consequences can include a fine, alcohol-awareness education, community service, and escalating driver-license suspension. A person under 21 can also be prosecuted for DWI and the intoxication offenses when their elements are met.</p><h2>Open containers</h2><p>Penal Code §49.031 generally prohibits knowingly possessing an open container in the passenger area of a motor vehicle on a public highway, subject to statutory exceptions. It is a Class C misdemeanor. When open-container possession is shown at trial for DWI, §49.04 establishes a minimum six-day confinement term.</p><h2>Implied consent and ALR</h2><p>Transportation Code Chapters 524 and 724 govern administrative suspension and implied consent. Arrest for a qualifying intoxication offense triggers a request for an authorized specimen. Refusal or a qualifying alcohol-concentration result can produce a separate DPS suspension even before the criminal case is resolved. Deadlines to request an administrative hearing are short; the official notice controls.</p><h3>Penalty framework</h3><p>Misdemeanor and felony ranges, license sanctions, surcharges or state fines, interlock requirements, education, probation conditions, and enhancements depend on the exact statute, age, history, concentration, injuries, passengers, and current law. Never rely on a remembered “first-offense price” as a complete consequence.</p></div>'.$note),
		'adult_en_031'=>array('title'=>'Safe-Ride Planning and Responsible Intervention','objective'=>'4.1.6.1(G)','minutes'=>6,'content'=>'<div class="gb-lesson"><p>The safest impaired-driving response is practical, immediate, and nonjudgmental: separate the person from the vehicle and provide a workable alternative.</p><h2>Before an event</h2><ul><li>Choose the sober transportation method and backup.</li><li>Charge the phone and save pickup contacts.</li><li>Budget for transportation or lodging.</li><li>Agree that no one pressures the sober driver to use a substance.</li></ul><h2>When a risk develops</h2><ol><li>State the concern clearly: “You are not driving.”</li><li>Offer the arranged ride, sober pickup, or safe overnight option.</li><li>Recruit help from a responsible sober person.</li><li>Do not physically confront someone when that increases danger.</li><li>Call 911 when an impaired person drives or immediate danger cannot otherwise be stopped.</li></ol><p>Never ride with an impaired driver to “keep an eye on them.” A passenger cannot restore the driver’s perception, judgment, coordination, or reaction.</p><h3>Personal commitment</h3><p>Complete this decision before leaving the lesson: identify your primary safe-ride method, a backup method, and the person you would call. The commitment is simple—no alcohol or impairing drug before driving, no exceptions based on distance, confidence, or convenience.</p></div>'.$note),
		);
	}

	public static function adult_topic_seven_content() {
		$poi='https://www.sos.state.tx.us/texreg/archive/April242026/In%20Addition/202601590-1.pdf'; $handbook='https://www.dps.texas.gov/internetforms/forms/dl-7.pdf'; $statutes='https://statutes.capitol.texas.gov/';
		$note='<hr><p><small><strong>Controlling sources:</strong> <a href="'.esc_url($poi).'" target="_blank" rel="noopener noreferrer">TDLR Adult Six-Hour POI, May 2026, Topic 4.1.7</a>; <a href="'.esc_url($handbook).'" target="_blank" rel="noopener noreferrer">Texas Driver Handbook, January 2026, Chapters 11–14</a>; and <a href="'.esc_url($statutes).'" target="_blank" rel="noopener noreferrer">current Texas statutes</a>. Current law controls if a summary becomes outdated.</small></p>';
		return array(
		'adult_en_032'=>array('title'=>'Pedestrians, Bicyclists, Motorcyclists, and Other Roadway Users','objective'=>'4.1.7.1(A), (C)–(E), (K)','minutes'=>8,'content'=>'<div class="gb-lesson"><p>Roadways are shared by people with very different visibility, speed, protection, and maneuvering ability. A defensive driver identifies each user early, predicts possible movement, and preserves enough time and space to keep one mistake from becoming a tragedy.</p><h2>Vulnerable roadway users</h2><ul><li><strong>Pedestrians:</strong> search crosswalks, sidewalks, shoulders, medians, parking areas, and both sides before turning. Yield as required and never pass a vehicle stopped for a pedestrian.</li><li><strong>Bicyclists:</strong> bicycles are vehicles with roadway rights and duties. A bicyclist may lawfully leave the right edge to pass, turn left, avoid hazards, or use a lane too narrow to share safely. Check mirrors and blind areas before crossing a bicycle lane.</li><li><strong>Motorcyclists:</strong> their narrow profile makes speed and distance harder to judge. Give a full lane and generous following interval; never share a lane or assume a turn signal will cancel automatically.</li><li><strong>People with disabilities:</strong> a white cane, guide dog, wheelchair, slower movement, or communication difference calls for patience—not pressure.</li></ul><h2>Other users</h2><p>Light-rail vehicles cannot swerve and may be quiet. Never turn across tracks until signals, traffic, and the full path permit it. Approach horseback riders and horse-drawn vehicles slowly, leave wide clearance, and avoid sudden noise. Slow-moving vehicles may display an orange-and-red emblem; reduce closing speed early and pass only when legal and fully visible.</p><h2>Restraints and open beds</h2><p>Every occupant must use the restraint required by Texas law. Children require the correct child safety seat or belt. Never treat a pickup bed as ordinary seating; Texas restricts transporting children in open beds, and any unrestrained rider faces ejection and crushing risk.</p><h2>Cooperation</h2><p>Yield, communicate, reduce speed, and create space. Do not use size, speed, or the horn to claim priority. TxDOT recorded 772 pedestrian deaths in 2024, showing why every driver must search deliberately.</p><h3>Decision practice</h3><ol><li><strong>A cyclist moves left around a drain grate.</strong> Slow and leave room.</li><li><strong>A motorcycle looks far away.</strong> Look again and wait; its narrow profile can distort your estimate.</li><li><strong>A horse becomes unsettled.</strong> Reduce speed and pass only with ample clearance.</li><li><strong>A child is crossing when your signal turns green.</strong> Remain stopped until the path is clear.</li></ol></div>'.$note),
		'adult_en_033'=>array('title'=>'Large and Oversize Vehicles, Buses, and Emergency Vehicles','objective'=>'4.1.7.1(C), (K), (L)','minutes'=>8,'content'=>'<div class="gb-lesson"><p>Large vehicles need more room to stop, turn, merge, and recover. The smaller driver protects everyone by staying visible, avoiding sudden conflicts, and refusing to compete for space.</p><h2>Blind areas and turns</h2><p>Large blind areas extend in front, behind, and along both sides; the right side is especially dangerous. If you cannot see the driver in a side mirror, assume the driver may not see you. Do not linger beside a truck or follow so closely that the road ahead disappears.</p><p>A long vehicle may swing left before a right turn and track its rear wheels inside the front-wheel path. Never squeeze between it and the curb. Trucks and buses require greater stopping distance, especially downhill or on wet pavement. Never cut in and brake after passing.</p><h2>Oversize and overweight vehicles</h2><p>Oversize loads may be wider than a lane, travel slowly, use escort vehicles, or need unusual positioning. Read escort signs and directions, increase following distance, and do not pass until the entire route is visible and wide enough. Account for wind, spray, turbulence, overhang, and the time needed to clear the vehicle. If uncertain, wait.</p><h2>Buses and emergency vehicles</h2><p>Obey special stopping rules for school buses displaying required signals. Expect pedestrians near transit buses. When an authorized emergency vehicle approaches with audible or visual signals, yield as Texas law requires and remain stopped until it passes. At a roadside emergency, tow, utility, TxDOT, or other covered vehicle, change lanes away when safe or slow as the Move Over or Slow Down law requires.</p><h3>Decision practice</h3><ol><li><strong>A truck begins a wide right turn.</strong> Stay back; never enter the space beside the curb.</li><li><strong>Passing an oversize load seems barely possible.</strong> Wait for a fully visible, legal, wide-enough path.</li><li><strong>An ambulance approaches from behind.</strong> Signal, move without entering an intersection, stop, and check for another responder.</li></ol></div>'.$note),
		'adult_en_034'=>array('title'=>'Construction and Maintenance Work-Zone Safety','objective'=>'4.1.7.1(C); SB 1366 work-zone safety','minutes'=>7,'content'=>'<div class="gb-lesson"><p>A work zone is a temporary traffic system, not an ordinary road with cones added. Lanes may shift, shoulders may disappear, pavement may be uneven, and workers or equipment may enter with little separation from traffic.</p><h2>Read the temporary system</h2><ol><li>Recognize orange signs and warning devices early.</li><li>Reduce speed before the queue or lane shift.</li><li>Increase following distance and avoid distraction.</li><li>Obey temporary markings, signals, barriers, and authorized flaggers even when they differ from the usual pattern.</li><li>Expect abrupt stops, construction entrances, narrow lanes, and slow equipment.</li></ol><p>A flagger gives regulatory direction. Stop where directed and proceed only when released. Never follow another vehicle through after the signal changes.</p><h2>SB 1366 safety emphasis</h2><p>Texas instruction emphasizes safety around construction and maintenance workers, flaggers, signs, vehicles, and equipment. Speeding or inattention can cause injury or death. Violations can carry enhanced consequences; the current statute and posted control govern.</p><p>TxDOT reported more than 26,000 Texas work-zone crashes in 2023, with 193 fatalities and 806 serious injuries. Drivers and passengers made up most deaths. Speed and inattention were leading preventable causes.</p><h2>When traffic becomes confusing</h2><p>Do not make an abrupt change or follow navigation against the controls. Slow smoothly and follow the official temporary route. If you miss a turn, continue to a safe lawful correction.</p><h3>Decision practice</h3><ol><li><strong>A flagger signals stop although the lane looks open.</strong> Stop; hidden equipment or opposing traffic may be moving.</li><li><strong>Normal and temporary markings conflict.</strong> Follow the active temporary control.</li><li><strong>Your map directs you through a closed lane.</strong> Obey the closure and reroute.</li></ol></div>'.$note),
		'adult_en_035'=>array('title'=>'Crash Responsibilities and the Good Samaritan Law','objective'=>'4.1.7.1(B)','minutes'=>6,'content'=>'<div class="gb-lesson"><p>After a crash, stop, prevent additional harm, obtain aid, and meet the duties required by law. Leaving can turn an emergency into a serious offense.</p><h2>Immediate duties</h2><ol><li><strong>Stop immediately</strong> at or as close as possible to the scene without obstructing traffic more than necessary.</li><li><strong>Protect life.</strong> Call 911 when anyone may be injured or danger remains. Warn traffic without standing in moving lanes.</li><li><strong>Render reasonable assistance,</strong> including arranging transportation for an injured person when treatment appears necessary or is requested.</li><li><strong>Exchange required information</strong> and show a driver license when required.</li><li><strong>Notify law enforcement promptly</strong> when injury, death, or damage preventing normal and safe vehicle operation triggers the duty.</li></ol><p>Move vehicles after a minor crash when law and safety direct clearing travel lanes. Do not move an injured person unless immediate danger requires it.</p><h2>Good Samaritan protection</h2><p>Texas Civil Practice and Remedies Code §74.151 generally limits civil liability for a person who in good faith administers emergency care at the scene, but it contains exceptions and does not protect willfully or wantonly negligent conduct. Protection is not permission to exceed your training.</p><h2>Practical response</h2><p>Give dispatch the location, direction, hazards, number of vehicles, and visible injuries. Follow instructions. Preserve photos and notes only after safety and medical needs. Do not argue, admit fault, or post details online.</p><h3>Decision practice</h3><ol><li><strong>A vehicle cannot be driven safely.</strong> Notify law enforcement by the quickest means.</li><li><strong>Fuel is leaking near an injured person.</strong> Call 911 and follow directions; move the person only if immediate danger requires it.</li></ol></div>'.$note),
		'adult_en_036'=>array('title'=>'Road Rage, Courtesy, Cargo, Towing, and Carbon Monoxide','objective'=>'4.1.7.1(H)–(J)','minutes'=>8,'content'=>'<div class="gb-lesson"><h2>Aggressive driving and road rage</h2><p>Aggressive driving includes unsafe speeding, tailgating, weaving, failing to yield, and hostile use of the horn or vehicle. Road rage can escalate into intentional violence. Do not answer with eye contact, gestures, pursuit, blocking, or brake-checking.</p><p>Create space and drive to a populated safe location. If threatened or followed, call 911 hands-free, describe the vehicle and location, and do not drive home. Courtesy is a safety strategy: signal, allow safe merges, acknowledge mistakes without confrontation, and leave time so delay does not become anger.</p><h2>Cargo and towing</h2><p>Load cargo low, balanced, and secured against movement. Confirm doors, tailgates, racks, and trailer couplers are latched. Recheck straps and connections. Never exceed vehicle, tire, axle, hitch, trailer, or manufacturer ratings.</p><p>Texas law requires the primary towing connection and applicable safety chains or another approved safety device. Crossed chains may support the trailer tongue if the coupler separates. Connect breakaway equipment and lights as required, test signals and brakes, allow more stopping and turning room, and avoid sudden steering. Passengers should not ride in a towed trailer.</p><h2>Carbon monoxide</h2><p>Carbon monoxide is colorless and odorless. It can cause headache, dizziness, weakness, nausea, confusion, unconsciousness, and death. Exhaust can enter through leaks, an open rear hatch, damage, or a blocked tailpipe. Never run a vehicle in a closed garage, even with the door open. If symptoms occur, reach fresh air, call emergency services, and do not drive until the vehicle is inspected.</p><h3>Decision practice</h3><ol><li><strong>An angry driver follows you.</strong> Do not go home; call 911 and proceed to a safe public or law-enforcement location.</li><li><strong>The trailer chains are not attached.</strong> Do not move until every required connection and light is correct.</li><li><strong>Occupants develop headache and dizziness.</strong> Stop safely, reach fresh air, and obtain emergency help.</li></ol></div>'.$note),
		'adult_en_037'=>array('title'=>'Traffic Stops and the Community Safety Education Act Video','objective'=>'4.1.7.1(F)–(G), (M)','minutes'=>16,'content'=>'<div class="gb-lesson"><p>This lesson uses official Community Safety Education Act material to explain the roles, rights, duties, and safe behaviors involved in traffic-stop interactions.</p><h2>When stopped</h2><ol><li>Signal, reduce speed, and pull to a safe location as soon as reasonably possible. If unsafe, slow, activate hazards, and proceed only far enough to a safer place.</li><li>Stop, park, remain inside unless directed otherwise, lower the window, and keep hands visible. At night, turn on the interior light.</li><li>Follow lawful instructions. Tell the officer before reaching for a license, insurance document, or other item.</li><li>Passengers should remain calm and avoid sudden movement. Do not physically resist or argue the case roadside.</li></ol><p>A driver may ask why they were stopped. Rights continue to apply, but use the court process to contest a citation. Direct complaints or compliments to the employing agency with time, location, identifying information, and facts.</p><h2>Required official video</h2><p><strong>Watch the complete 16-minute “Flashing Lights: Creating Safe Interactions between Citizens and Law Enforcement” video from the Texas Commission on Law Enforcement.</strong></p><div style="position:relative;padding-bottom:56.25%;height:0;overflow:hidden;max-width:900px;background:#000;margin:18px 0"><iframe src="https://www.youtube-nocookie.com/embed/FaWO1xNVZlw" title="Flashing Lights: Creating Safe Interactions between Citizens and Law Enforcement" loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen style="position:absolute;top:0;left:0;width:100%;height:100%;border:0"></iframe></div><p><a href="https://www.youtube.com/watch?v=FaWO1xNVZlw" target="_blank" rel="noopener noreferrer">Open the official video in a new tab if the player does not load.</a></p><h2>Texas Driving with Disabilities Program</h2><p>Participation is voluntary. Diagnoses that may impede communication can be identified so an officer receiving a TLETS return may be alerted. For a driver-license or identification-card indicator, a physician or psychiatrist completes DPS Form DL-101 and the applicant presents it through the DPS process. The indicator appears on the front of the card. A separate TxDMV process uses current prescribed forms to associate disclosure information with a vehicle record for TLETS. The indicator does not excuse a violation, change a duty, or guarantee receipt of the information.</p><p><a href="https://www.dps.texas.gov/news/dps-announces-driver-license-card-updates-under-texas-driving-disability-program" target="_blank" rel="noopener noreferrer">DPS program information</a></p><h3>After-video check</h3><ol><li><strong>Why keep hands visible?</strong> It reduces uncertainty for both officer and occupants.</li><li><strong>May you reach without warning?</strong> Tell the officer where the item is and follow directions.</li><li><strong>How is a citation challenged?</strong> Through the court process, not roadside confrontation.</li><li><strong>Does an indicator replace communication?</strong> No; it is one voluntary aid.</li></ol></div>'.$note),
		);
	}

	public static function adult_topic_eight_content() {
		$poi='https://www.sos.state.tx.us/texreg/archive/April242026/In%20Addition/202601590-1.pdf'; $handbook='https://www.dps.texas.gov/internetforms/forms/dl-7.pdf'; $txdot='https://www.txdot.gov/data-maps/crash-reports-records/motor-vehicle-crash-statistics.html';
		$note='<hr><p><small><strong>Official sources:</strong> <a href="'.esc_url($poi).'" target="_blank" rel="noopener noreferrer">TDLR Adult Six-Hour POI, May 2026, Topic 4.1.8</a>; <a href="'.esc_url($handbook).'" target="_blank" rel="noopener noreferrer">Texas Driver Handbook, January 2026</a>; and <a href="'.esc_url($txdot).'" target="_blank" rel="noopener noreferrer">TxDOT crash statistics</a>.</small></p>';
		return array(
		'adult_en_038'=>array('title'=>'The Risk Formula: Driver, Vehicle, Roadway, and Environment','objective'=>'4.1.8.1(A)–(C), (I)','minutes'=>5,'content'=>'<div class="gb-lesson"><p>Driving risk is the possibility that a hazard, exposure, and an unsafe response will combine to cause a collision. Risk changes continuously. A responsible driver does not wait for danger to become obvious; the driver searches, evaluates, and adjusts early.</p><h2>Four interacting parts</h2><ul><li><strong>Driver:</strong> attention, judgment, attitude, fatigue, illness, emotion, impairment, knowledge, and skill.</li><li><strong>Vehicle:</strong> tires, brakes, lights, visibility, load, restraints, maintenance, and handling limits.</li><li><strong>Roadway:</strong> curves, intersections, lanes, surface, shoulders, work zones, traffic controls, and sight distance.</li><li><strong>Environment:</strong> traffic, darkness, glare, rain, fog, wind, ice, animals, and unexpected events.</li></ul><p>Weakness in one part can multiply weakness in another. A tired driver in a poorly maintained vehicle on a wet, dark curve faces far more than four separate risks.</p><h2>Reduced-risk process</h2><ol><li><strong>Identify</strong> hazards far ahead and around the vehicle.</li><li><strong>Predict</strong> what can change and who may enter the path.</li><li><strong>Choose</strong> a legal response with the greatest margin.</li><li><strong>Act</strong> smoothly, communicate, and reassess.</li></ol><h3>Decision practice</h3><p>You are ill, rain is intensifying, and the tires are near their wear limit. The responsible choice may be to delay the trip, change route, or use other transportation—not merely drive slower.</p></div>'.$note),
		'adult_en_039'=>array('title'=>'Distractions, Cell Phones, Fatigue, and Inattention','objective'=>'4.1.8.1(C)–(D), (H)–(I)','minutes'=>7,'content'=>'<div class="gb-lesson"><p>Distraction removes visual, manual, or mental resources from driving. Texting can involve all three. Other distractions include navigation entry, music and vehicle controls, passengers, pets, eating, drinking, grooming, reading, working, reaching, and events outside the vehicle.</p><h2>Texas wireless-device law</h2><p>Texas generally prohibits using a portable wireless communication device to read, write, or send an electronic message while operating a motor vehicle unless a statutory exception applies. Additional restrictions apply to novice drivers, school zones, and local rules. The safest routine is to set navigation and communication before moving, enable do-not-disturb, and pull completely off the road before handling a device.</p><h2>Fatigue, illness, and emotion</h2><p>Sleep loss slows reaction, narrows attention, damages judgment, and can produce microsleeps. Highway hypnosis is reduced awareness caused by monotony and fatigue. Illness, medication, pain, grief, anger, and anxiety can also make a physically sober driver unsafe.</p><p>Warning signs include repeated yawning, heavy eyelids, missing signs, drifting, inconsistent speed, rubbing the eyes, and not remembering recent miles. Open windows, loud music, or caffeine cannot make a seriously fatigued driver safe. Stop in a safe place and obtain real rest or alternate transportation.</p><h2>Passenger and pet plan</h2><p>Set expectations before departure. Secure pets properly; never allow an animal in the driver’s lap. Ask a passenger to handle navigation or climate controls. If a child, passenger, or pet needs attention, park safely first.</p><h3>Decision practice</h3><ol><li><strong>A message feels urgent.</strong> Do not read it while driving; stop safely.</li><li><strong>You miss an exit because of fatigue.</strong> Continue safely, then leave the road and rest.</li><li><strong>Navigation changes route.</strong> Listen to voice guidance or let a passenger adjust it; never type while moving.</li></ol></div>'.$note),
		'adult_en_040'=>array('title'=>'Night Driving, Weather, Skids, and Emergencies','objective'=>'4.1.8.1(C), (G), (I)','minutes'=>7,'content'=>'<div class="gb-lesson"><p>At night, the driver sees less distance, color, and detail while glare and fatigue increase. Drive at a speed that permits stopping within the illuminated, visible path. Keep glass and lights clean, dim high beams as required, look toward the right edge when facing glare, and add following space.</p><h2>Weather and traction</h2><p>Rain mixes with roadway residue, reduces tire grip, hides markings, and increases stopping distance. Slow before curves and standing water. Avoid cruise control on slick surfaces. Fog, smoke, dust, snow, and ice may require a major speed reduction, a different route, or postponement.</p><h2>Loss of control</h2><ul><li><strong>Skid:</strong> ease off the accelerator, look and steer toward the intended path, and avoid abrupt braking or steering.</li><li><strong>Hydroplaning:</strong> ease off power, hold direction, and avoid sudden inputs until traction returns.</li><li><strong>Blowout:</strong> grip the wheel, maintain direction, ease off power, and slow gradually before leaving the road.</li><li><strong>Run off pavement:</strong> stabilize and slow before returning gradually when safe.</li><li><strong>Brake failure:</strong> use controlled braking methods suitable for the system, downshift when safe, apply the parking brake gradually, and find an escape path.</li></ul><p>Preparation reduces emergency risk: inspect tires, lights, wipers, brakes, fuel or charge, and weather before departure.</p><h3>Decision practice</h3><p>Heavy rain exceeds your wipers and you cannot see a safe stopping path. Reduce speed smoothly and leave the roadway at a safe location; continuing at the limit is not responsible.</p></div>'.$note),
		'adult_en_041'=>array('title'=>'Aggressive Driving, Street Racing, and High-Risk Choices','objective'=>'4.1.8.1(A)–(B), (E)–(I)','minutes'=>6,'content'=>'<div class="gb-lesson"><p>Speed reduces available response time and increases stopping distance and crash energy. A posted limit is a maximum under favorable conditions, not a promise that the speed is safe now.</p><h2>Street racing</h2><p>Transportation Code §545.420 prohibits racing, speed competitions, drag races or acceleration contests, testing physical endurance, and related exhibitions of speed or acceleration on a highway as defined by current law. Consequences can include arrest, license suspension, vehicle impoundment, fines, confinement, and enhanced charges when injury, death, prior offenses, or other facts apply.</p><h2>High-risk chain</h2><p>A collision often follows a chain: hurry leads to speed, speed closes the gap, frustration leads to a risky lane change, and distraction prevents detection. Break the chain early by leaving time, accepting a missed turn, increasing space, and refusing competition.</p><h2>Safety belts</h2><p>A belt restrains the occupant through rapid deceleration, reduces contact with the interior, and helps prevent ejection. Wear it correctly—lap belt low across the hips, shoulder belt across the chest, and seat upright. Air bags supplement belts; they do not replace them. TxDOT reported 965 unbuckled people died in Texas traffic crashes in 2025.</p><h3>Decision practice</h3><ol><li><strong>Another driver revs at a signal.</strong> Do not engage; create distance.</li><li><strong>You are late.</strong> Notify the destination when safely parked; do not convert schedule pressure into roadway risk.</li><li><strong>A passenger puts the shoulder belt behind them.</strong> Stop and correct the restraint before continuing.</li></ol></div>'.$note),
		'adult_en_042'=>array('title'=>'Recognizing and Reporting Human Trafficking','objective'=>'4.1.8.1(J)','minutes'=>6,'content'=>'<div class="gb-lesson"><p>Human trafficking exploits a person for compelled labor or commercial sex through force, fraud, or coercion; when commercial sex involves a minor, proof of force, fraud, or coercion is not required. Victims may be encountered at transportation hubs, hotels, businesses, homes, worksites, or vehicles.</p><h2>Possible indicators</h2><ul><li>Another person controls identification, money, transportation, communication, or answers.</li><li>The person appears fearful, coached, monitored, unable to leave, or unsure of location.</li><li>Work conditions, debt, housing, threats, or promised employment differ from reality.</li><li>There are signs of abuse, exhaustion, malnutrition, branding, frequent moves, or restricted contact.</li><li>A minor is involved in commercial sex, or an adult appears compelled into it.</li></ul><p>No single sign proves trafficking. Do not confront a suspected trafficker, attempt a rescue, follow a vehicle dangerously, or photograph a victim. Observe safely and record useful facts such as location, time, vehicle, direction, people, and exact behavior.</p><h2>Report safely</h2><p>Call <strong>911</strong> for immediate danger. Otherwise contact the <strong>National Human Trafficking Hotline at 1-888-373-7888</strong> or text <strong>233733</strong>. Texas DPS also accepts appropriate suspicious-activity reports through iWatchTexas. For a missing or exploited child, the National Center for Missing & Exploited Children is available at <strong>1-800-THE-LOST</strong>.</p><p>Use respectful, trauma-informed language. A person may not identify as a victim and may fear law enforcement, retaliation, homelessness, or harm to family. Trained responders determine next steps.</p><h3>Decision practice</h3><p>You notice a young person at a rest stop whose companion holds all documents and prevents them from speaking. Do not confront them. Move to safety, note objective details, and report through the appropriate channel.</p></div>'.$note),
		'adult_en_043'=>array('title'=>'Recreational Water Safety Video','objective'=>'Course educational objective: recreational water safety','minutes'=>12,'content'=>'<div class="gb-lesson"><p>Texas law requires driver education to include the recreational-water-safety video produced for this purpose by the Texas Parks and Wildlife Department.</p><h2>Required TPWD video</h2><p><strong>Watch the complete “True Stories About Water Safety / Never Happens” video.</strong> TPWD identifies this full video as the Legislature-mandated driver-education water-safety presentation.</p><div style="position:relative;padding-bottom:56.25%;height:0;overflow:hidden;max-width:900px;background:#000;margin:18px 0"><iframe src="https://www.youtube-nocookie.com/embed/-qZJXEPh6PA" title="True Stories About Water Safety — Texas Parks and Wildlife" loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen style="position:absolute;top:0;left:0;width:100%;height:100%;border:0"></iframe></div><p><a href="https://www.youtube.com/watch?v=-qZJXEPh6PA" target="_blank" rel="noopener noreferrer">Open the official TPWD video in a new tab if the player does not load.</a></p><h2>Four actions that prevent tragedy</h2><ul><li>Wear a properly fitted life jacket.</li><li>Use the engine-cutoff or ignition-safety switch when required and whenever available.</li><li>Learn to swim and respect open-water conditions.</li><li>Complete TPWD boater education and follow current Texas boating law.</li></ul><p>Assign a sober operator and a dedicated adult water watcher. Never mix alcohol or impairing drugs with boat operation or supervision. Check weather, capacity, equipment, navigation hazards, and communications before departure.</p><h3>After-video check</h3><ol><li><strong>Why wear the jacket before an emergency?</strong> A sudden ejection or injury may make it impossible to put on later.</li><li><strong>What does the cutoff switch do?</strong> It can stop propulsion if the operator is displaced.</li><li><strong>Can a strong swimmer ignore a life jacket?</strong> No. Injury, cold, current, distance, and unconsciousness can defeat swimming ability.</li></ol></div>'.$note),
		);
	}

	public static function adult_topic_nine_content() {
		$poi='https://www.sos.state.tx.us/texreg/archive/April242026/In%20Addition/202601590-1.pdf'; $handbook='https://www.dps.texas.gov/internetforms/forms/dl-7.pdf';
		$note='<hr><p><small><strong>Official sources:</strong> <a href="'.esc_url($poi).'" target="_blank" rel="noopener noreferrer">TDLR Adult Six-Hour POI, May 2026, Topic 4.1.9</a> and <a href="'.esc_url($handbook).'" target="_blank" rel="noopener noreferrer">Texas Driver Handbook, January 2026</a>. These lessons are instructional review. The separately controlled final assessment does not add instructional seat time.</small></p>';
		return array(
			'adult_en_044'=>array('title'=>'Highway Sign Review','objective'=>'4.1.9.1(A) — highway-sign readiness review','minutes'=>10,'content'=>'<div class="gb-lesson"><p>This review organizes the sign knowledge used throughout the course. Do not memorize a picture without connecting it to the lawful driving decision it requires.</p><h2>Recognize the message early</h2><ul><li><strong>Shape:</strong> octagon means STOP; downward triangle means YIELD; round warns of a railroad crossing; pennant identifies a no-passing zone; pentagon identifies a school area; diamond gives a warning.</li><li><strong>Color:</strong> red emphasizes stop or prohibition; white and black commonly state regulations; yellow warns; orange marks temporary work-zone conditions; green guides; blue identifies services; brown identifies recreation or cultural interest.</li><li><strong>Symbol and wording:</strong> confirm the exact movement, hazard, restriction, or destination.</li><li><strong>Location:</strong> determine where the message begins and which lane or approach it controls.</li></ul><h2>Apply the sign</h2><p>STOP requires a complete stop at the lawful location and yielding before entry. YIELD requires slowing and giving right-of-way, with a stop whenever necessary. Warning signs require an early speed, lane, search, or space adjustment. Regulatory signs establish rules; they do not guarantee the movement is safe.</p><h2>Signals and markings</h2><p>Steady and flashing signals, lane arrows, center lines, edge lines, crosswalks, stop lines, railroad markings, and temporary work-zone devices operate together. Follow an authorized officer or flagger when their lawful direction differs from a routine control.</p><h3>Readiness check</h3><ol><li><strong>A yellow pennant appears on the left.</strong> Do not begin a pass.</li><li><strong>A green signal faces a blocked intersection.</strong> Wait until the vehicle can clear it.</li><li><strong>Orange markings conflict with the usual lane path.</strong> Follow the active temporary control.</li><li><strong>A round yellow sign appears.</strong> A railroad crossing is ahead; slow, look, listen, and prepare to stop.</li></ol></div>'.$note),
			'adult_en_045'=>array('title'=>'Traffic Law Review','objective'=>'4.1.9.1(A) — traffic-law readiness review','minutes'=>20,'content'=>'<div class="gb-lesson"><p>Traffic law provides the minimum legal framework. Safe driving also requires observation, judgment, communication, and enough time and space to avoid a collision when another person makes a mistake.</p><h2>Right-of-way and intersections</h2><ul><li>Stop at the line, before the crosswalk, or at the required point of visibility.</li><li>At an uncontrolled intersection reached at approximately the same time, the driver on the left generally yields to the driver on the right.</li><li>A left-turning driver yields to approaching traffic close enough to be hazardous.</li><li>Yield to pedestrians as required and search every crosswalk before turning.</li><li>Do not enter an intersection unless there is room to clear it.</li></ul><h2>Speed, space, and lane use</h2><p>Choose a reasonable speed for traffic, weather, visibility, roadway, vehicle, and driver condition. Maintain following space, use the correct lane, signal before movement, check mirrors and blind areas, and pass only where legal with sufficient clear distance. Never use a shoulder or prohibited zone to force a pass.</p><h2>Special duties</h2><ul><li>Stop for a school bus when Texas law requires it.</li><li>Yield and move as required for an approaching authorized emergency vehicle.</li><li>Move over or slow down for covered stopped vehicles.</li><li>Obey railroad signals and never enter unless the entire vehicle can clear every track.</li><li>Protect workers and obey temporary traffic controls and flaggers.</li><li>Stop after a crash, obtain aid, exchange required information, and notify law enforcement when required.</li></ul><h2>Fitness and responsibility</h2><p>Use safety belts and proper child restraints. Do not drive impaired, fatigued, distracted, angry, or medically unsafe. Maintain required financial responsibility and lawful vehicle equipment. For alcohol or another drug, the safe driving decision is made before use: arrange sober transportation.</p><h3>Scenario review</h3><ol><li><strong>The limit is 70 mph in heavy rain.</strong> Reduce speed; the posted maximum does not override actual conditions.</li><li><strong>A motorcycle appears small and distant.</strong> Look again and wait for a clearly safe gap.</li><li><strong>A message arrives while moving.</strong> Do not read it; park safely first.</li><li><strong>A tire fails.</strong> Hold direction, ease off power, slow gradually, and leave the roadway when safe.</li></ol></div>'.$note),
			'adult_en_046'=>array('title'=>'Comprehensive Licensing Readiness Review','objective'=>'4.1.9.1(A) — comprehensive progress-assessment preparation','minutes'=>22,'content'=>'<div class="gb-lesson"><p>This final instructional review connects highway signs, traffic law, and reduced-risk decisions. It is preparation—not the scored final assessment.</p><h2>Use one decision process</h2><ol><li><strong>Search:</strong> look well ahead, to both sides, behind, and into blind areas.</li><li><strong>Identify:</strong> recognize signs, signals, markings, users, hazards, restrictions, and changing conditions.</li><li><strong>Predict:</strong> determine what could enter the path or reduce traction, visibility, time, or space.</li><li><strong>Decide:</strong> choose the lawful response with the greatest safety margin.</li><li><strong>Act:</strong> communicate and adjust speed or position smoothly, then search again.</li></ol><h2>Final-review priorities</h2><ul><li>Licensing responsibility, restrictions, vehicle equipment, restraints, and financial responsibility.</li><li>Signs by shape, color, symbol, wording, and location; signals and pavement markings.</li><li>Intersections, yielding, turns, passing, parking, railroad crossings, and freeway entry or exit.</li><li>Speed selection, following distance, night driving, adverse weather, skids, tire failure, and emergencies.</li><li>Pedestrians, bicyclists, motorcyclists, trucks, buses, work zones, emergency vehicles, and other roadway users.</li><li>Alcohol, drugs, fatigue, distraction, aggressive driving, crashes, and responsible transportation planning.</li></ul><h2>How to approach the assessment</h2><p>Read the complete question and every answer. Identify whether it asks for a legal requirement, a sign meaning, or the safest response. Eliminate answers that create a new violation or reduce control. Do not rush based on one familiar word. If two answers appear possible, choose the one that fully satisfies the law and preserves the greater safety margin.</p><div style="border-left:4px solid #1769aa;padding:12px 16px;background:#f3f8fc;margin:18px 0"><strong>Assessment standard:</strong> The controlled final uses separate traffic-law and highway-sign banks, requires at least 70 percent mastery, rotates questions on retest, and records the attempt for administrative review. The final does not count toward the locked 330 instructional minutes.</div><h3>Self-check before continuing</h3><ol><li>Can you identify critical sign families without relying only on words?</li><li>Can you explain who yields at common intersection conflicts?</li><li>Can you choose a safer speed and following distance for changing conditions?</li><li>Can you describe the correct response to impairment, distraction, fatigue, a crash, or a vehicle emergency?</li><li>Can you protect vulnerable roadway users and cooperate with large or emergency vehicles?</li></ol><p>Review any uncertain lesson before beginning the scored assessment. Mastery means understanding the decision, not merely recognizing an answer.</p></div>'.$note),
		);
	}

	private static function sign_visual_card( $file, $alt, $caption, $designation ) {
		$url = plugin_dir_url( __FILE__ ) . 'assets/signs/' . sanitize_file_name( $file );
		return '<figure style="margin:0;padding:16px;border:1px solid #cbd8e5;border-radius:12px;background:#fff;text-align:center"><img src="' . esc_url( $url ) . '?gb_signs=2026.07" alt="' . esc_attr( $alt ) . '" loading="lazy" style="display:block;width:100%;height:190px;object-fit:contain;margin:0 auto 12px"><figcaption><strong>' . esc_html( $caption ) . '</strong><br><small>FHWA Standard Highway Sign ' . esc_html( $designation ) . '</small></figcaption></figure>';
	}

	private static function topic_four_visuals( $key ) {
		$sets = array(
			'adult_en_010' => array(
				array('official-2026-r1-2-yield.svg','Red and white downward-pointing YIELD sign','Yield means give the required time and space','R1-2'),
			),
			'adult_en_011' => array(
				array('official-2026-r1-1-r1-3p-all-way-stop.png','STOP sign with ALL WAY plaque','Every approach must stop; then apply right-of-way rules','R1-1 + R1-3P'),
				array('official-2026-w2-1-crossroad.svg','Yellow diamond crossroad warning sign','Intersecting roadway ahead','W2-1'),
				array('official-2026-w2-2-side-road.svg','Yellow diamond side-road warning sign','Traffic may enter from the side road','W2-2'),
			),
			'adult_en_012' => array(
				array('official-2026-w4-1-merge.svg','Yellow diamond merging-traffic sign','Merging traffic — adjust speed and space','W4-1'),
				array('official-2026-r6-1-one-way.svg','Black and white ONE WAY arrow sign','Enter only in the arrow’s direction','R6-1'),
				array('official-2026-w6-1-divided-highway.svg','Yellow diamond divided-highway-begins sign','Keep right of the median','W6-1'),
			),
			'adult_en_013' => array(
				array('official-2026-w11-2-pedestrian.svg','Yellow diamond pedestrian warning sign','Pedestrians may be in or near the roadway','W11-2'),
			),
			'adult_en_014' => array(
				array('official-2026-w20-1-road-work.svg','Orange diamond ROAD WORK AHEAD sign','Workers and temporary traffic controls may be ahead','W20-1'),
			),
			'adult_en_015' => array(
				array('official-2026-w10-1-railroad-ahead.svg','Round yellow railroad advance-warning sign','Railroad crossing ahead — look, listen, prepare to stop','W10-1'),
				array('official-2026-r15-1-crossbuck.svg','White railroad crossbuck sign','Railroad grade crossing at the tracks','R15-1'),
			),
			'adult_en_016' => array(
				array('official-2026-r1-1-stop.svg','Red octagonal STOP regulatory sign','Regulatory: a required legal action','R1-1'),
				array('official-2026-w3-3-signal-ahead.svg','Yellow diamond warning sign showing a traffic signal','Warning: a condition requires preparation','W3-3'),
				array('official-2026-r6-1-one-way.svg','Black and white ONE WAY sign with arrow','Direction and roadway organization','R6-1'),
			),
			'adult_en_017' => array(
				array('official-2026-r1-1-stop.svg','Red octagonal STOP sign','STOP — complete stop required','R1-1'),
				array('official-2026-r1-2-yield.svg','Red and white downward-pointing YIELD sign','YIELD — give right-of-way','R1-2'),
				array('official-2026-r2-1-speed-limit.svg','White rectangular SPEED LIMIT sign','SPEED LIMIT — regulatory maximum','R2-1'),
				array('official-2026-r5-1-do-not-enter.svg','Red and white DO NOT ENTER sign','DO NOT ENTER — entry prohibited','R5-1'),
				array('official-2026-r5-1a-wrong-way.svg','Red rectangular WRONG WAY sign','WRONG WAY — opposing direction danger','R5-1a'),
				array('official-2026-r3-4-no-u-turn.svg','White NO U-TURN regulatory sign','NO U-TURN — movement prohibited','R3-4'),
				array('official-2026-r6-1-one-way.svg','Black and white ONE WAY sign','ONE WAY — permitted direction','R6-1'),
				array('official-2026-r1-1-r1-3p-all-way-stop.png','STOP sign with ALL WAY plaque','ALL WAY — every approach stops','R1-1 + R1-3P'),
			),
			'adult_en_018' => array(
				array('official-2026-w1-2-curve.svg','Yellow diamond sign showing a right curve','Curve ahead — choose speed before entry','W1-2'),
				array('official-2026-w1-1-turn.svg','Yellow diamond sign showing a sharp right turn','Sharp turn ahead — greater speed reduction','W1-1'),
				array('official-2026-w2-1-crossroad.svg','Yellow diamond crossroad warning sign','Crossroad ahead — search both sides','W2-1'),
				array('official-2026-w4-1-merge.svg','Yellow diamond merging traffic sign','Merging traffic — manage speed and space','W4-1'),
				array('official-2026-w8-5-slippery-when-wet.svg','Yellow diamond slippery when wet sign','Slippery when wet — smooth inputs','W8-5'),
				array('official-2026-w10-1-railroad-ahead.svg','Round yellow railroad advance warning sign','Railroad crossing ahead — look, listen, prepare','W10-1'),
				array('official-2026-w14-3-no-passing-zone.svg','Yellow pennant no-passing-zone sign','No-passing zone — remain in lane','W14-3'),
				array('official-2026-w12-2-low-clearance.svg','Yellow diamond low-clearance warning sign','Low clearance — verify vehicle height','W12-2'),
			),
			'adult_en_019' => array(
				array('official-2026-w20-1-road-work.svg','Orange diamond ROAD WORK AHEAD sign','Work zone — temporary conditions ahead','W20-1'),
				array('official-2026-w11-2-pedestrian.svg','Yellow diamond pedestrian warning sign','Pedestrians — reduce speed and search','W11-2'),
				array('official-2026-w3-3-signal-ahead.svg','Yellow diamond signal-ahead warning sign','Signal ahead — stopped traffic may be hidden','W3-3'),
			),
			'adult_en_020' => array(
				array('official-2026-w3-3-signal-ahead.svg','Yellow diamond sign displaying red yellow and green traffic lights','Signal ahead — prepare to stop','W3-3'),
				array('official-2026-r5-1-do-not-enter.svg','Red and white DO NOT ENTER sign','Red communicates prohibition or stop-related control','R5-1'),
			),
			'adult_en_021' => array(
				array('official-2026-w6-1-divided-highway.svg','Yellow diamond divided-highway-begins sign','Divider begins — keep right of median','W6-1'),
				array('official-2026-w6-3-two-way-traffic.svg','Yellow diamond two-way-traffic sign','Opposing traffic begins — keep right','W6-3'),
				array('official-2026-w14-3-no-passing-zone.svg','Yellow pennant no-passing-zone sign','Markings and signs work together','W14-3'),
			),
			'adult_en_022' => array(
				array('official-2026-r2-1-speed-limit.svg','White rectangular SPEED LIMIT sign','The posted maximum does not replace a safe speed for conditions','R2-1'),
				array('official-2026-w8-5-slippery-when-wet.svg','Yellow diamond slippery-when-wet sign','Reduce speed and increase following space','W8-5'),
			),
			'adult_en_023' => array(
				array('official-2026-w4-1-merge.svg','Yellow diamond merging-traffic sign','Search blind areas and manage a safe gap','W4-1'),
				array('official-2026-w6-1-divided-highway.svg','Yellow diamond divided-highway sign','Use the correct lane and keep right of the median','W6-1'),
			),
			'adult_en_024' => array(
				array('official-2026-r3-4-no-u-turn.svg','White regulatory NO U-TURN sign','Signals cannot authorize a prohibited movement','R3-4'),
				array('official-2026-r6-1-one-way.svg','Black and white ONE WAY sign','Communicate and enter in the permitted direction','R6-1'),
			),
			'adult_en_025' => array(
				array('official-2026-w14-3-no-passing-zone.svg','Yellow pennant no-passing-zone sign','Do not begin a passing maneuver','W14-3'),
				array('official-2026-w1-2-curve.svg','Yellow diamond curve warning sign','Limited sight distance can prohibit a safe pass','W1-2'),
			),
			'adult_en_026' => array(
				array('official-2026-w20-1-road-work.svg','Orange diamond ROAD WORK AHEAD sign','Expect temporary controls, workers, equipment, and abrupt stops','W20-1'),
				array('official-2026-w8-5-slippery-when-wet.svg','Yellow diamond slippery-when-wet sign','Smooth steering, braking, and acceleration reduce loss-of-control risk','W8-5'),
				array('official-2026-w3-3-signal-ahead.svg','Yellow diamond signal-ahead sign','Stopped freeway or work-zone traffic may be beyond sight distance','W3-3'),
			),
		);
		if ( empty( $sets[$key] ) ) return '';
		$html = '<section class="gb-sign-gallery" aria-labelledby="gb-signs-' . esc_attr( $key ) . '"><h2 id="gb-signs-' . esc_attr( $key ) . '">Learn the Device by Sight</h2><p>Study each official sign face. Identify its color and shape first, then explain the legal or risk-reducing response before reading the caption.</p><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin:18px 0">';
		foreach ( $sets[$key] as $sign ) $html .= self::sign_visual_card( $sign[0], $sign[1], $sign[2], $sign[3] );
		$html .= '</div><p><small>Artwork: Federal Highway Administration 2024 Standard Highway Signs releases; traffic-control device designs are public domain under 23 CFR 655.603.</small></p></section>';
		return $html;
	}

	private static function complete_topic_four_content( $key, $content ) {
		$visuals = self::topic_four_visuals( $key );
		$position = strpos( $content, '<hr>' );
		return false === $position ? $content . $visuals : substr($content,0,$position) . $visuals . substr($content,$position);
	}

	public function admin_menu() {
		add_menu_page(
			'Gulf Breeze Core',
			'Gulf Breeze Core',
			'manage_options',
			self::PAGE,
			array( $this, 'render_page' ),
			'dashicons-admin-settings',
			3
		);
		add_submenu_page(
			self::PAGE,
			'Core Status',
			'Core Status',
			'manage_options',
			'gulf-breeze-core-status',
			array( $this, 'render_status_page' )
		);
		add_submenu_page(
			self::PAGE,
			'Configuration',
			'Configuration',
			'manage_options',
			self::PAGE,
			array( $this, 'render_page' )
		);
		add_submenu_page(
			self::PAGE,
			'Course Registry',
			'Course Registry',
			'manage_options',
			'gulf-breeze-course-registry',
			array( $this, 'render_course_registry' )
		);
		add_submenu_page(
			self::PAGE,
			'Curriculum Blueprint',
			'Curriculum Blueprint',
			'manage_options',
			'gulf-breeze-curriculum-blueprint',
			array( $this, 'render_curriculum_blueprint' )
		);
		add_submenu_page(
			self::PAGE,
			'Adult English Timer Audit',
			'Timer Audit',
			'manage_options',
			'gulf-breeze-timer-audit',
			array( $this, 'render_timer_audit' )
		);
	}

	private function adult_timer_audit_rows() {
		$registry  = get_option( self::COURSE_OPTION, array() );
		$course_id = absint( $registry['adult_en']['learnpress_course_id'] ?? 0 );
		$rows      = array();
		global $wpdb;

		foreach ( self::adult_english_crosswalk() as $index => $lesson ) {
			$key   = 'adult_en_' . str_pad( (string) ( $index + 1 ), 3, '0', STR_PAD_LEFT );
			$posts = get_posts(
				array(
					'post_type'      => 'lp_lesson',
					'post_status'    => array( 'publish', 'draft', 'private', 'pending' ),
					'meta_key'       => '_gb_blueprint_key',
					'meta_value'     => $key,
					'posts_per_page' => -1,
					'orderby'        => 'ID',
					'order'          => 'ASC',
				)
			);
			$post = 1 === count( $posts ) ? $posts[0] : null;
			$lesson_id = $post ? absint( $post->ID ) : 0;
			$section_id = 0;
			$attached_course_id = 0;
			if ( $lesson_id ) {
				$section_id = absint( $wpdb->get_var( $wpdb->prepare( "SELECT section_id FROM {$wpdb->learnpress_section_items} WHERE item_id = %d LIMIT 1", $lesson_id ) ) );
				if ( $section_id ) {
					$attached_course_id = absint( $wpdb->get_var( $wpdb->prepare( "SELECT section_course_id FROM {$wpdb->learnpress_sections} WHERE section_id = %d LIMIT 1", $section_id ) ) );
				}
			}

			$expected_minutes  = absint( $lesson['minutes'] );
			$expected_seconds  = $expected_minutes * 60;
			$installed_minutes = $lesson_id ? absint( get_post_meta( $lesson_id, '_gb_required_minutes', true ) ) : 0;
			$installed_seconds = $lesson_id ? absint( get_post_meta( $lesson_id, '_gb_required_seconds', true ) ) : 0;
			$course_key        = $lesson_id ? (string) get_post_meta( $lesson_id, '_gb_course_key', true ) : '';
			$content_status    = $lesson_id ? (string) get_post_meta( $lesson_id, '_gb_content_status', true ) : '';
			$content_present   = $post && '' !== trim( wp_strip_all_tags( $post->post_content ) );
			$timer_exact       = $lesson_id && $expected_minutes === $installed_minutes && $expected_seconds === $installed_seconds;
			$attached          = $course_id && $attached_course_id === $course_id;
			$identity_exact    = 1 === count( $posts ) && 'adult_en' === $course_key;

			$rows[] = array(
				'number'            => $index + 1,
				'key'               => $key,
				'topic'             => $lesson['topic'],
				'expected_title'    => $lesson['lesson'],
				'installed_title'   => $post ? $post->post_title : '',
				'lesson_id'         => $lesson_id,
				'duplicate_count'   => count( $posts ),
				'expected_minutes'  => $expected_minutes,
				'expected_seconds'  => $expected_seconds,
				'installed_minutes' => $installed_minutes,
				'installed_seconds' => $installed_seconds,
				'content_status'    => $content_status,
				'content_present'   => $content_present,
				'attached'          => $attached,
				'timer_exact'       => $timer_exact,
				'identity_exact'    => $identity_exact,
				'result'            => $timer_exact && $attached && $identity_exact ? 'EXACT' : 'REPAIR REQUIRED',
			);
		}

		return $rows;
	}

	public function render_timer_audit() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$rows = $this->adult_timer_audit_rows();
		$expected_total = 0;
		$installed_total = 0;
		$exact_count = 0;
		$topic_totals = array();
		foreach ( $rows as $row ) {
			$expected_total += $row['expected_seconds'];
			$installed_total += $row['installed_seconds'];
			$exact_count += 'EXACT' === $row['result'] ? 1 : 0;
			if ( ! isset( $topic_totals[ $row['topic'] ] ) ) {
				$topic_totals[ $row['topic'] ] = array( 'expected' => 0, 'installed' => 0, 'exact' => 0, 'count' => 0 );
			}
			$topic_totals[ $row['topic'] ]['expected'] += $row['expected_seconds'];
			$topic_totals[ $row['topic'] ]['installed'] += $row['installed_seconds'];
			$topic_totals[ $row['topic'] ]['exact'] += 'EXACT' === $row['result'] ? 1 : 0;
			$topic_totals[ $row['topic'] ]['count']++;
		}
		$migration_version = (string) get_option( 'gb_curriculum_migration_version', '' );
		$migration_status = get_option( 'gb_curriculum_migration_status', array() );
		$export_url = wp_nonce_url( admin_url( 'admin-post.php?action=gb_export_timer_audit' ), 'gb_export_timer_audit' );
		?>
		<div class="wrap">
			<h1>Adult English Timer Audit</h1>
			<p>This page is read-only. It compares the 46 installed LearnPress lessons with the locked 330-minute Gulf Breeze POI ledger and does not modify course records.</p>
			<table class="widefat striped" style="max-width:1000px"><tbody>
				<tr><th>Core version</th><td><?php echo esc_html( defined( 'GB_CORE_VERSION' ) ? GB_CORE_VERSION : '' ); ?></td></tr>
				<tr><th>Curriculum migration version</th><td><?php echo esc_html( $migration_version ?: 'Not recorded' ); ?></td></tr>
				<tr><th>Last migration status</th><td><?php echo esc_html( is_array( $migration_status ) ? ( $migration_status['message'] ?? 'Not recorded' ) : 'Not recorded' ); ?></td></tr>
				<tr><th>Exact lesson records</th><td><strong style="color:<?php echo 46 === $exact_count ? '#16752a' : '#b32d2e'; ?>"><?php echo esc_html( $exact_count ); ?>/46</strong></td></tr>
				<tr><th>Timer total</th><td><strong style="color:<?php echo $expected_total === $installed_total ? '#16752a' : '#b32d2e'; ?>"><?php echo esc_html( round( $installed_total / 60 ) ); ?> installed / <?php echo esc_html( round( $expected_total / 60 ) ); ?> required minutes</strong></td></tr>
			</tbody></table>
			<p><a class="button" href="<?php echo esc_url( $export_url ); ?>">Download Timer Audit CSV</a></p>

			<h2>Topic Totals</h2>
			<table class="widefat striped" style="max-width:800px"><thead><tr><th>Topic</th><th>Required</th><th>Installed</th><th>Exact lessons</th><th>Result</th></tr></thead><tbody>
			<?php foreach ( $topic_totals as $topic => $total ) : $topic_exact = $total['expected'] === $total['installed'] && $total['exact'] === $total['count']; ?>
				<tr><td><code><?php echo esc_html( $topic ); ?></code></td><td><?php echo esc_html( round( $total['expected'] / 60 ) ); ?> min</td><td><?php echo esc_html( round( $total['installed'] / 60 ) ); ?> min</td><td><?php echo esc_html( $total['exact'] . '/' . $total['count'] ); ?></td><td><?php echo $topic_exact ? '<strong style="color:#16752a">EXACT</strong>' : '<strong style="color:#b32d2e">REVIEW</strong>'; ?></td></tr>
			<?php endforeach; ?>
			</tbody></table>

			<h2>Lesson Detail</h2>
			<table class="widefat striped"><thead><tr><th>#</th><th>Topic</th><th>Lesson</th><th>ID</th><th>Required</th><th>Installed</th><th>Attached</th><th>Content</th><th>Status</th><th>Result</th></tr></thead><tbody>
			<?php foreach ( $rows as $row ) : ?>
				<tr>
					<td><?php echo esc_html( $row['number'] ); ?></td>
					<td><code><?php echo esc_html( $row['topic'] ); ?></code></td>
					<td><?php echo esc_html( $row['installed_title'] ?: $row['expected_title'] ); ?><?php echo $row['duplicate_count'] > 1 ? '<br><strong style="color:#b32d2e">DUPLICATES: ' . esc_html( $row['duplicate_count'] ) . '</strong>' : ''; ?></td>
					<td><?php echo $row['lesson_id'] ? esc_html( $row['lesson_id'] ) : '<strong style="color:#b32d2e">MISSING</strong>'; ?></td>
					<td><?php echo esc_html( $row['expected_minutes'] ); ?> min<br><small><?php echo esc_html( $row['expected_seconds'] ); ?> sec</small></td>
					<td><?php echo esc_html( $row['installed_minutes'] ); ?> min<br><small><?php echo esc_html( $row['installed_seconds'] ); ?> sec</small></td>
					<td><?php echo $row['attached'] ? '<strong style="color:#16752a">YES</strong>' : '<strong style="color:#b32d2e">NO</strong>'; ?></td>
					<td><?php echo $row['content_present'] ? '<strong style="color:#16752a">PRESENT</strong>' : 'Shell only'; ?></td>
					<td><code><?php echo esc_html( $row['content_status'] ?: 'not recorded' ); ?></code></td>
					<td><?php echo 'EXACT' === $row['result'] ? '<strong style="color:#16752a">EXACT</strong>' : '<strong style="color:#b32d2e">REPAIR REQUIRED</strong>'; ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody></table>
		</div>
		<?php
	}

	public function export_timer_audit() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to export this audit.', 'gulf-breeze-core' ) );
		}
		check_admin_referer( 'gb_export_timer_audit' );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=gulf-breeze-adult-english-timer-audit-' . gmdate( 'Y-m-d-His' ) . '.csv' );
		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, array( 'number', 'blueprint_key', 'topic', 'expected_title', 'installed_title', 'lesson_id', 'matching_records', 'required_minutes', 'required_seconds', 'installed_minutes', 'installed_seconds', 'attached_to_adult_english', 'content_present', 'content_status', 'result' ) );
		foreach ( $this->adult_timer_audit_rows() as $row ) {
			fputcsv( $out, array( $row['number'], $row['key'], $row['topic'], $row['expected_title'], $row['installed_title'], $row['lesson_id'], $row['duplicate_count'], $row['expected_minutes'], $row['expected_seconds'], $row['installed_minutes'], $row['installed_seconds'], $row['attached'] ? 'yes' : 'no', $row['content_present'] ? 'yes' : 'no', $row['content_status'], $row['result'] ) );
		}
		fclose( $out );
		exit;
	}

	public function render_status_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$active_plugins = (array) get_option( 'active_plugins', array() );
		$learnpress     = in_array( 'learnpress/learnpress.php', $active_plugins, true );
		$under_plugin  = false;
		foreach ( $active_plugins as $plugin_file ) {
			if ( false !== stripos( $plugin_file, 'under-construction' ) ) {
				$under_plugin = true;
				break;
			}
		}
		$ucp_options = get_option( 'ucp_options', array() );
		$ucp_enabled = $under_plugin && is_array( $ucp_options ) && ! empty( $ucp_options['status'] );
		$ucp_no_end  = $ucp_enabled && empty( $ucp_options['end_date_toggle'] );
		$ucp_admin   = $ucp_enabled && in_array( 'administrator', (array) ( $ucp_options['whitelisted_roles'] ?? array() ), true );
		$mastery_gate = class_exists( 'GulfBreeze_Course_Mastery_Gate' );
		$video_gate   = class_exists( 'GulfBreeze_Video_Quiz_Gate' );
		?>
		<div class="wrap">
			<h1>Gulf Breeze Core Status</h1>
			<p>Permanent modular foundation for the Gulf Breeze course and compliance system.</p>
			<table class="widefat striped" style="max-width:900px"><tbody>
				<tr><th>Core version</th><td><?php echo esc_html( defined( 'GB_CORE_VERSION' ) ? GB_CORE_VERSION : '1.0.0' ); ?></td></tr>
				<tr><th>Configuration module</th><td><strong style="color:#16752a">ACTIVE</strong></td></tr>
				<tr><th>LearnPress plugin</th><td><?php echo $learnpress ? '<strong style="color:#16752a">ACTIVE</strong>' : '<strong style="color:#b32d2e">NOT ACTIVE</strong>'; ?></td></tr>
				<tr><th>Under Construction plugin</th><td><?php echo $under_plugin ? '<strong style="color:#16752a">ACTIVE</strong>' : '<strong style="color:#b32d2e">NOT ACTIVE</strong>'; ?></td></tr>
				<tr><th>Public-site protection mode</th><td><?php echo $ucp_enabled ? '<strong style="color:#16752a">ENABLED</strong>' : '<strong style="color:#b32d2e">DISABLED — ACTION REQUIRED</strong>'; ?></td></tr>
				<tr><th>Automatic protection end date</th><td><?php echo $ucp_no_end ? 'None configured' : 'Configured or protection unavailable'; ?></td></tr>
				<tr><th>Administrator preview access</th><td><?php echo $ucp_admin ? 'Allowed' : 'Not verified'; ?></td></tr>
				<tr><th>Course Registry module</th><td><strong style="color:#16752a">ACTIVE</strong></td></tr>
				<tr><th>Admin/student privacy boundary</th><td><strong style="color:#16752a">ACTIVE</strong> — internal controls hidden from non-administrators</td></tr>
				<tr><th>May 2026 POI blueprint</th><td><strong style="color:#16752a">ACTIVE</strong> — adopted teen and adult source editions locked</td></tr>
				<tr><th>Adult English objective crosswalk</th><td><strong style="color:#16752a">ACTIVE</strong> — 46 short lessons / 330 instructional minutes</td></tr>
				<tr><th>Seat-time enforcement</th><td><strong style="color:#16752a">ACTIVE</strong> — server-recorded active time, visibility/activity checks, early-completion block, LearnPress completion bridge</td></tr>
				<tr><th>Assessment enforcement</th><td><?php echo $mastery_gate ? '<strong style="color:#16752a">ACTIVE</strong> — Course Mastery Gate controls question selection, scoring, retakes, lockouts, audit records, and LearnPress progression' : '<strong style="color:#b32d2e">NOT ACTIVE</strong> — Course Mastery Gate required before production'; ?></td></tr>
				<tr><th>Video assessment enforcement</th><td><?php echo $video_gate ? '<strong style="color:#16752a">ACTIVE</strong> — Video Quiz Gate available for mapped required-video checks' : 'Not active — only required when a lesson is mapped to a controlled video check'; ?></td></tr>
				<tr><th>Payment modules</th><td>Not installed yet</td></tr>
			</tbody></table>
			<p><strong>Safety rule:</strong> missing legal configuration values render blank. The plugin does not fabricate provider numbers, approvals, addresses, or policy text.</p>
		</div>
		<?php
	}

	public function register_settings() {
		register_setting(
			'gb_config_group',
			self::OPTION,
			array( 'sanitize_callback' => array( $this, 'sanitize' ), 'default' => array() )
		);
		register_setting(
			'gb_course_registry_group',
			self::COURSE_OPTION,
			array( 'sanitize_callback' => array( $this, 'sanitize_course_registry' ), 'default' => array() )
		);
	}

	public function render_curriculum_blueprint() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<div class="wrap">
			<h1>Gulf Breeze Curriculum Blueprint</h1>
			<?php if ( isset( $_GET['gb_adult_built'] ) ) : ?>
				<div class="notice notice-success inline"><p><?php echo esc_html( absint( $_GET['gb_adult_built'] ) ); ?> Adult English lesson shell(s) created; <?php echo esc_html( absint( $_GET['gb_adult_reused'] ?? 0 ) ); ?> existing shell(s) verified and retained.</p></div>
			<?php elseif ( isset( $_GET['gb_topic_one_built'] ) ) : ?>
				<div class="notice notice-success inline"><p>Adult English Topic 4.1.1 content loaded into <?php echo esc_html( absint( $_GET['gb_topic_one_built'] ) ); ?> internal lesson item(s). The parent course remains Draft. Required time: 10 instructional minutes.</p></div>
			<?php elseif ( isset( $_GET['gb_topic_two_built'] ) ) : ?>
				<div class="notice notice-success inline"><p>Adult English Topic 4.1.2 content loaded into <?php echo esc_html( absint( $_GET['gb_topic_two_built'] ) ); ?> internal lesson item(s). Required time: 24 instructional minutes.</p></div>
			<?php elseif ( isset( $_GET['gb_topic_three_built'] ) ) : ?>
				<div class="notice notice-success inline"><p>Adult English Topic 4.1.3 content loaded into <?php echo esc_html( absint( $_GET['gb_topic_three_built'] ) ); ?> internal lesson item(s). Required time: 42 instructional minutes.</p></div>
			<?php elseif ( isset( $_GET['gb_topic_four_built'] ) ) : ?>
				<div class="notice notice-success inline"><p>Adult English Topic 4.1.4 content loaded into <?php echo esc_html( absint( $_GET['gb_topic_four_built'] ) ); ?> internal lesson item(s). Required time: 37 instructional minutes.</p></div>
			<?php elseif ( isset( $_GET['gb_topic_five_built'] ) ) : ?>
				<div class="notice notice-success inline"><p>Adult English Topic 4.1.5 content loaded into <?php echo esc_html( absint( $_GET['gb_topic_five_built'] ) ); ?> internal lesson item(s). Required time: 32 instructional minutes.</p></div>
			<?php elseif ( isset( $_GET['gb_adult_error'] ) ) : ?>
				<div class="notice notice-error inline"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['gb_adult_error'] ) ) ); ?></p></div>
			<?php endif; ?>
			<div class="notice notice-warning inline"><p><strong>Internal only.</strong> This is a compliance construction ledger, not student-facing course content and not a public approval claim.</p></div>
			<p><strong>Lesson architecture:</strong> divide each required POI objective into multiple focused lessons, normally 10–20 minutes each. No hour-long lesson blocks. English and Spanish must use equivalent objectives and timing.</p>
			<p><strong>Source rule:</strong> lesson content may be written only after it is cross-referenced to the controlling POI objective, current Texas law, current Texas Driver Handbook, and current safety data. Unknown facts remain unbuilt until verified.</p>
			<?php foreach ( self::curriculum_blueprints() as $program_key => $blueprint ) : ?>
				<h2><?php echo esc_html( 'parent_taught' === $program_key ? 'Parent-Taught — English and Spanish' : 'Adult Six-Hour — English and Spanish' ); ?></h2>
				<p><strong>Controlling source:</strong> <a href="<?php echo esc_url( $blueprint['source_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $blueprint['source'] ); ?></a></p>
				<table class="widefat striped" style="max-width:1000px">
					<thead><tr><th>POI unit</th><th>Required subject</th><th>Timing ledger</th><th>2026 work-zone overlay</th></tr></thead>
					<tbody>
					<?php foreach ( $blueprint['units'] as $unit_key => $unit_label ) : ?>
						<tr>
							<td><code><?php echo esc_html( $unit_key ); ?></code></td>
							<td><?php echo esc_html( $unit_label ); ?></td>
							<td>Short-lesson allocation pending objective-level crosswalk</td>
							<td><?php echo in_array( (string) $unit_key, $blueprint['work_zone_units'], true ) ? '<strong>REQUIRED</strong>' : 'Covered where required by POI'; ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
					<tfoot><tr><th colspan="2">Program totals</th><td colspan="2"><?php echo esc_html( number_format_i18n( $blueprint['total_minutes'] ) ); ?> total = <?php echo esc_html( number_format_i18n( $blueprint['minimum_content'] ) ); ?> required content + <?php echo esc_html( number_format_i18n( $blueprint['flex_minutes'] ) ); ?> additional instruction/break</td></tr></tfoot>
				</table>
			<?php endforeach; ?>
			<h2>Adult English — Objective-Level Lesson Crosswalk</h2>
			<p><strong>Instruction ledger:</strong> 46 focused lessons ranging from 2–22 minutes = exactly 330 instructional minutes. Add three separate 10-minute breaks after Topics 3, 6, and 8 and before the comprehensive final examination. Total course ledger: 360 minutes. The final examination does not count toward instructional minutes.</p>
			<table class="widefat striped" style="max-width:1100px">
				<thead><tr><th>#</th><th>POI topic</th><th>English lesson shell</th><th>Minutes</th><th>Required objective coverage</th><th>Validation</th></tr></thead>
				<tbody>
				<?php $adult_total = 0; foreach ( self::adult_english_crosswalk() as $index => $lesson ) : $adult_total += $lesson['minutes']; ?>
					<tr>
						<td><?php echo esc_html( $index + 1 ); ?></td>
						<td><code><?php echo esc_html( $lesson['topic'] ); ?></code></td>
						<td><?php echo esc_html( $lesson['lesson'] ); ?></td>
						<td><?php echo esc_html( $lesson['minutes'] ); ?></td>
						<td><?php echo esc_html( $lesson['coverage'] ); ?></td>
						<td><?php echo '4.1.1' === $lesson['topic'] ? 'Lesson check' : 'Lesson check + Topic participation bank'; ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
				<tfoot><tr><th colspan="3">Instructional total</th><th><?php echo esc_html( $adult_total ); ?></th><th colspan="2"><?php echo 330 === $adult_total ? '<strong>EXACT</strong>' : '<strong>ERROR — MUST EQUAL 330</strong>'; ?></th></tr></tfoot>
			</table>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:18px 0 26px">
				<input type="hidden" name="action" value="gb_build_adult_english_shells">
				<?php wp_nonce_field( 'gb_build_adult_english_shells' ); ?>
				<?php submit_button( 'Create or Repair Adult English LearnPress Shells', 'primary', 'submit', false ); ?>
				<p class="description">Creates nine POI topic sections and 46 internal LearnPress lesson items while keeping the parent course Draft and inaccessible. LearnPress requires attached lesson items to use its published item status before it will count them. Direct access and sitemap exposure remain blocked by Gulf Breeze Core.</p>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:18px 0 26px">
				<input type="hidden" name="action" value="gb_build_adult_topic_one">
				<?php wp_nonce_field( 'gb_build_adult_topic_one' ); ?>
				<?php submit_button( 'Load or Refresh Adult English Topic 4.1.1 Content', 'secondary', 'submit', false ); ?>
				<p class="description">Loads the four sourced Course Introduction lessons into their internal LearnPress items. It does not publish the parent course or claim approval.</p>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:18px 0 26px">
				<input type="hidden" name="action" value="gb_build_adult_topic_two">
				<?php wp_nonce_field( 'gb_build_adult_topic_two' ); ?>
				<?php submit_button( 'Load or Refresh Adult English Topic 4.1.2 Content', 'secondary', 'submit', false ); ?>
				<p class="description">Loads five sourced Your License to Drive lessons totaling 24 instructional minutes. The public construction barrier remains unchanged.</p>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:18px 0 26px">
				<input type="hidden" name="action" value="gb_build_adult_topic_three">
				<?php wp_nonce_field( 'gb_build_adult_topic_three' ); ?>
				<?php submit_button( 'Load or Refresh Adult English Topic 4.1.3 Content', 'secondary', 'submit', false ); ?>
				<p class="description">Loads six sourced Right-of-Way lessons totaling 42 instructional minutes. The public construction barrier remains unchanged.</p>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:18px 0 26px">
				<input type="hidden" name="action" value="gb_build_adult_topic_four">
				<?php wp_nonce_field( 'gb_build_adult_topic_four' ); ?>
				<?php submit_button( 'Load or Refresh Adult English Topic 4.1.4 Content', 'secondary', 'submit', false ); ?>
				<p class="description">Loads six sourced Traffic Control Devices lessons totaling 37 instructional minutes.</p>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:18px 0 26px">
				<input type="hidden" name="action" value="gb_build_adult_topic_five">
				<?php wp_nonce_field( 'gb_build_adult_topic_five' ); ?>
				<?php submit_button( 'Load or Refresh Adult English Topic 4.1.5 Content', 'secondary', 'submit', false ); ?>
				<p class="description">Loads five sourced Controlling Traffic Flow lessons totaling 32 instructional minutes with locally hosted instructional visuals.</p>
			</form>
			<h3>Adult English — Live Timing Audit (Topics 4.1.1–4.1.3)</h3>
			<p>This audit reads the installed LearnPress lesson records. A lesson passes only when its server-enforced timer exactly matches the adopted POI ledger and its guided-practice block is present.</p>
			<table class="widefat striped" style="max-width:1100px">
				<thead><tr><th>#</th><th>POI topic</th><th>Lesson</th><th>Required</th><th>Installed timer</th><th>Guided practice</th><th>Result</th></tr></thead>
				<tbody>
				<?php
				$timing_expected = 0;
				$timing_installed = 0;
				$timing_passed = 0;
				foreach ( array_slice( self::adult_english_crosswalk(), 0, 15 ) as $audit_index => $audit_lesson ) :
					$audit_key = 'adult_en_' . str_pad( (string) ( $audit_index + 1 ), 3, '0', STR_PAD_LEFT );
					$audit_posts = get_posts( array( 'post_type' => 'lp_lesson', 'post_status' => array( 'publish', 'draft', 'private', 'pending' ), 'meta_key' => '_gb_blueprint_key', 'meta_value' => $audit_key, 'posts_per_page' => 1 ) );
					$audit_post = $audit_posts ? $audit_posts[0] : null;
					$expected_seconds = absint( $audit_lesson['minutes'] ) * 60;
					$installed_seconds = $audit_post ? absint( get_post_meta( $audit_post->ID, '_gb_required_seconds', true ) ) : 0;
					$has_practice = $audit_post && false !== strpos( $audit_post->post_content, 'gb-guided-practice' );
					$is_exact = $audit_post && $expected_seconds === $installed_seconds && $has_practice;
					$timing_expected += $expected_seconds;
					$timing_installed += $installed_seconds;
					$timing_passed += $is_exact ? 1 : 0;
				?>
				<tr>
					<td><?php echo esc_html( $audit_index + 1 ); ?></td>
					<td><code><?php echo esc_html( $audit_lesson['topic'] ); ?></code></td>
					<td><?php echo esc_html( $audit_lesson['lesson'] ); ?></td>
					<td><?php echo esc_html( gmdate( 'i:s', $expected_seconds ) ); ?></td>
					<td><?php echo $audit_post ? esc_html( gmdate( 'i:s', $installed_seconds ) ) : '<strong style="color:#b32d2e">MISSING</strong>'; ?></td>
					<td><?php echo $has_practice ? '<strong style="color:#16752a">PRESENT</strong>' : '<strong style="color:#b32d2e">MISSING</strong>'; ?></td>
					<td><?php echo $is_exact ? '<strong style="color:#16752a">EXACT</strong>' : '<strong style="color:#b32d2e">REPAIR REQUIRED</strong>'; ?></td>
				</tr>
				<?php endforeach; ?>
				</tbody>
				<tfoot><tr><th colspan="3">Topics 4.1.1–4.1.3 total</th><th><?php echo esc_html( round( $timing_expected / 60 ) ); ?> minutes</th><th><?php echo esc_html( round( $timing_installed / 60 ) ); ?> minutes</th><th colspan="2"><?php echo 15 === $timing_passed && $timing_expected === $timing_installed ? '<strong style="color:#16752a">15/15 EXACT</strong>' : '<strong style="color:#b32d2e">AUDIT FAILED</strong>'; ?></th></tr></tfoot>
			</table>
			<h3>Adult Online Assessment and Security Controls</h3>
			<ul>
				<li>Topics 2–8: at least 10 participation questions in each topic bank; administer at least 2 at the end of each topic.</li>
				<li>Any multimedia clip longer than 180 seconds: at least 4 clip-specific questions; ask at least 1 after the clip; an incorrect answer requires replay and a different question.</li>
				<li>Comprehensive final: at least 30 questions, drawn equally from separate highway-sign and traffic-law banks; mastery is 70% or above.</li>
				<li>Each retest uses different questions. Three failed comprehensive-final attempts fail the course.</li>
				<li>Identity validation, question/response history, staff changes, time per unit, and total instructional time must be retained in the protected student record.</li>
			</ul>
			<p><strong>Build lock:</strong> course shells remain drafts. No course can advance to internal testing until every objective has a source reference, assigned minutes, English content, equivalent Spanish content, and an assessment mapping.</p>
		</div>
		<?php
	}

	public function build_adult_english_shells() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to build course curriculum.', 'gulf-breeze-core' ) );
		}
		check_admin_referer( 'gb_build_adult_english_shells' );

		$registry  = get_option( self::COURSE_OPTION, array() );
		$course_id = absint( $registry['adult_en']['learnpress_course_id'] ?? 0 );
		$base_url  = admin_url( 'admin.php?page=gulf-breeze-curriculum-blueprint' );

		if ( ! $course_id || 'lp_course' !== get_post_type( $course_id ) ) {
			wp_safe_redirect( add_query_arg( 'gb_adult_error', rawurlencode( 'Adult English must be mapped to a valid LearnPress course in Course Registry first.' ), $base_url ) );
			exit;
		}
		if ( ! class_exists( 'LP_Section_CURD' ) || ! defined( 'LP_LESSON_CPT' ) ) {
			wp_safe_redirect( add_query_arg( 'gb_adult_error', rawurlencode( 'LearnPress curriculum services are not available.' ), $base_url ) );
			exit;
		}

		global $wpdb;
		$section_curd = new LP_Section_CURD( $course_id );
		$topic_names  = self::curriculum_blueprints()['adult_six_hour']['units'];
		$sections     = array();

		foreach ( $topic_names as $topic => $name ) {
			$section_name = 'Topic ' . $topic . ' — ' . $name;
			$section_id   = absint( $wpdb->get_var( $wpdb->prepare( "SELECT section_id FROM {$wpdb->learnpress_sections} WHERE section_course_id = %d AND section_name = %s LIMIT 1", $course_id, $section_name ) ) );
			if ( ! $section_id ) {
				$descriptions = self::student_section_descriptions();
				$args    = array( 'section_course_id' => $course_id, 'section_name' => $section_name, 'section_description' => $descriptions[ $topic ] ?? '' );
				$section = $section_curd->create( $args );
				$section_id = absint( $section['section_id'] ?? 0 );
			}
			if ( ! $section_id ) {
				wp_safe_redirect( add_query_arg( 'gb_adult_error', rawurlencode( 'A LearnPress topic section could not be created. No course was published.' ), $base_url ) );
				exit;
			}
			$sections[ $topic ] = $section_id;
		}

		$created = 0;
		$reused  = 0;
		foreach ( self::adult_english_crosswalk() as $index => $lesson ) {
			$key      = 'adult_en_' . str_pad( (string) ( $index + 1 ), 3, '0', STR_PAD_LEFT );
			$existing = get_posts( array( 'post_type' => LP_LESSON_CPT, 'post_status' => array( 'draft', 'pending', 'private', 'publish' ), 'meta_key' => '_gb_blueprint_key', 'meta_value' => $key, 'posts_per_page' => 1, 'fields' => 'ids' ) );
			$item_id  = $existing ? absint( $existing[0] ) : 0;

			if ( $item_id ) {
				if ( 'publish' !== get_post_status( $item_id ) ) {
					wp_update_post( array( 'ID' => $item_id, 'post_status' => 'publish' ) );
				}
				$assigned_section = absint( $wpdb->get_var( $wpdb->prepare( "SELECT section_id FROM {$wpdb->learnpress_section_items} WHERE item_id = %d LIMIT 1", $item_id ) ) );
				if ( ! $assigned_section ) {
					$section_curd->add_items_section( $sections[ $lesson['topic'] ], array( array( 'id' => $item_id, 'type' => LP_LESSON_CPT ) ) );
				}
				$reused++;
			} else {
				$result = $section_curd->new_item( $sections[ $lesson['topic'] ], array( 'title' => $lesson['lesson'], 'type' => LP_LESSON_CPT, 'content' => '', 'status' => 'publish' ) );
				$item_id = is_array( $result ) && ! empty( $result[0]['id'] ) ? absint( $result[0]['id'] ) : 0;
				if ( ! $item_id ) {
					wp_safe_redirect( add_query_arg( 'gb_adult_error', rawurlencode( 'A LearnPress lesson shell could not be created. Existing drafts were left intact.' ), $base_url ) );
					exit;
				}
				$created++;
			}

			update_post_meta( $item_id, '_gb_blueprint_key', $key );
			update_post_meta( $item_id, '_gb_course_key', 'adult_en' );
			update_post_meta( $item_id, '_gb_poi_topic', $lesson['topic'] );
			update_post_meta( $item_id, '_gb_poi_coverage', $lesson['coverage'] );
			update_post_meta( $item_id, '_gb_required_minutes', absint( $lesson['minutes'] ) );
			update_post_meta( $item_id, '_gb_required_seconds', absint( $lesson['minutes'] ) * 60 );
			update_post_meta( $item_id, '_gb_content_status', 'internal_item_empty' );
		}

		$this->refresh_learnpress_course_cache( $course_id );
		wp_safe_redirect( add_query_arg( array( 'gb_adult_built' => $created, 'gb_adult_reused' => $reused ), $base_url ) );
		exit;
	}

	public function build_adult_topic_one() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to build course content.', 'gulf-breeze-core' ) );
		}
		check_admin_referer( 'gb_build_adult_topic_one' );

		$base_url  = admin_url( 'admin.php?page=gulf-breeze-curriculum-blueprint' );
		$registry  = get_option( self::COURSE_OPTION, array() );
		$course_id = absint( $registry['adult_en']['learnpress_course_id'] ?? 0 );
		$built     = 0;
		global $wpdb;
		$section_name = 'Topic 4.1.1 — Course Introduction';
		$section_id   = $course_id ? absint( $wpdb->get_var( $wpdb->prepare( "SELECT section_id FROM {$wpdb->learnpress_sections} WHERE section_course_id = %d AND section_name = %s LIMIT 1", $course_id, $section_name ) ) ) : 0;
		$section_curd = $course_id && class_exists( 'LP_Section_CURD' ) ? new LP_Section_CURD( $course_id ) : null;
		if ( ! $section_id || ! $section_curd ) {
			wp_safe_redirect( add_query_arg( 'gb_adult_error', rawurlencode( 'The Adult English Topic 4.1.1 LearnPress section is missing. Run the shell builder first.' ), $base_url ) );
			exit;
		}
		foreach ( self::adult_topic_one_content() as $key => $lesson ) {
			$posts = get_posts( array( 'post_type' => 'lp_lesson', 'post_status' => array( 'draft', 'pending', 'private', 'publish' ), 'meta_key' => '_gb_blueprint_key', 'meta_value' => $key, 'posts_per_page' => 1 ) );
			if ( ! $posts ) {
				wp_safe_redirect( add_query_arg( 'gb_adult_error', rawurlencode( 'A required Topic 4.1.1 lesson shell is missing. Run the Adult English shell builder first.' ), $base_url ) );
				exit;
			}
			$lesson_id = absint( $posts[0]->ID );
			$result    = wp_update_post( array( 'ID' => $lesson_id, 'post_title' => $lesson['title'], 'post_content' => self::complete_timed_content( $key, $lesson['content'] ), 'post_status' => 'publish' ), true );
			if ( is_wp_error( $result ) ) {
				wp_safe_redirect( add_query_arg( 'gb_adult_error', rawurlencode( 'A Topic 4.1.1 lesson could not be updated. No lesson was published.' ), $base_url ) );
				exit;
			}
			update_post_meta( $lesson_id, '_gb_poi_topic', '4.1.1' );
			update_post_meta( $lesson_id, '_gb_poi_coverage', $lesson['objective'] );
			update_post_meta( $lesson_id, '_gb_required_minutes', absint( $lesson['minutes'] ) );
			update_post_meta( $lesson_id, '_gb_required_seconds', absint( $lesson['minutes'] ) * 60 );
			update_post_meta( $lesson_id, '_gb_content_status', 'internal_item_sourced_topic_one' );
			update_post_meta( $lesson_id, '_gb_source_poi', 'TDLR POI-Adult Six-Hour, May 2026, 4.1.1' );
			update_post_meta( $lesson_id, '_gb_source_handbook', 'Texas Driver Handbook DL-7, January 2026' );
			$assigned_section = absint( $wpdb->get_var( $wpdb->prepare( "SELECT section_id FROM {$wpdb->learnpress_section_items} WHERE item_id = %d LIMIT 1", $lesson_id ) ) );
			if ( ! $assigned_section ) {
				$section_curd->add_items_section( $section_id, array( array( 'id' => $lesson_id, 'type' => LP_LESSON_CPT ) ) );
			}
			$built++;
		}

		$this->refresh_learnpress_course_cache( $course_id );
		wp_safe_redirect( add_query_arg( 'gb_topic_one_built', $built, $base_url ) );
		exit;
	}

	public function build_adult_topic_two() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to build course content.', 'gulf-breeze-core' ) );
		}
		check_admin_referer( 'gb_build_adult_topic_two' );
		$base_url  = admin_url( 'admin.php?page=gulf-breeze-curriculum-blueprint' );
		$registry  = get_option( self::COURSE_OPTION, array() );
		$course_id = absint( $registry['adult_en']['learnpress_course_id'] ?? 0 );
		global $wpdb;
		$section_name = 'Topic 4.1.2 — Your License to Drive';
		$section_id   = $course_id ? absint( $wpdb->get_var( $wpdb->prepare( "SELECT section_id FROM {$wpdb->learnpress_sections} WHERE section_course_id = %d AND section_name = %s LIMIT 1", $course_id, $section_name ) ) ) : 0;
		$section_curd = $course_id && class_exists( 'LP_Section_CURD' ) ? new LP_Section_CURD( $course_id ) : null;
		if ( ! $section_id || ! $section_curd ) {
			wp_safe_redirect( add_query_arg( 'gb_adult_error', rawurlencode( 'The Adult English Topic 4.1.2 LearnPress section is missing. Run the shell builder first.' ), $base_url ) );
			exit;
		}
		$built = 0;
		foreach ( self::adult_topic_two_content() as $key => $lesson ) {
			$posts = get_posts( array( 'post_type' => 'lp_lesson', 'post_status' => array( 'draft', 'pending', 'private', 'publish' ), 'meta_key' => '_gb_blueprint_key', 'meta_value' => $key, 'posts_per_page' => 1 ) );
			if ( ! $posts ) {
				wp_safe_redirect( add_query_arg( 'gb_adult_error', rawurlencode( 'A required Topic 4.1.2 lesson shell is missing.' ), $base_url ) );
				exit;
			}
			$lesson_id = absint( $posts[0]->ID );
			$result = wp_update_post( array( 'ID' => $lesson_id, 'post_title' => $lesson['title'], 'post_content' => self::complete_timed_content( $key, $lesson['content'] ), 'post_status' => 'publish' ), true );
			if ( is_wp_error( $result ) ) {
				wp_safe_redirect( add_query_arg( 'gb_adult_error', rawurlencode( 'A Topic 4.1.2 lesson could not be updated.' ), $base_url ) );
				exit;
			}
			update_post_meta( $lesson_id, '_gb_poi_topic', '4.1.2' );
			update_post_meta( $lesson_id, '_gb_poi_coverage', $lesson['objective'] );
			update_post_meta( $lesson_id, '_gb_required_minutes', absint( $lesson['minutes'] ) );
			update_post_meta( $lesson_id, '_gb_required_seconds', absint( $lesson['minutes'] ) * 60 );
			update_post_meta( $lesson_id, '_gb_content_status', 'internal_item_sourced_topic_two' );
			update_post_meta( $lesson_id, '_gb_source_poi', 'TDLR POI-Adult Six-Hour, May 2026, 4.1.2' );
			update_post_meta( $lesson_id, '_gb_source_handbook', 'Texas Driver Handbook DL-7, January 2026, Chapters 1-3' );
			$assigned = absint( $wpdb->get_var( $wpdb->prepare( "SELECT section_id FROM {$wpdb->learnpress_section_items} WHERE item_id = %d LIMIT 1", $lesson_id ) ) );
			if ( ! $assigned ) {
				$section_curd->add_items_section( $section_id, array( array( 'id' => $lesson_id, 'type' => LP_LESSON_CPT ) ) );
			}
			$built++;
		}
		$this->refresh_learnpress_course_cache( $course_id );
		wp_safe_redirect( add_query_arg( 'gb_topic_two_built', $built, $base_url ) );
		exit;
	}

	public function build_adult_topic_three() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to build course content.', 'gulf-breeze-core' ) );
		}
		check_admin_referer( 'gb_build_adult_topic_three' );
		$base_url  = admin_url( 'admin.php?page=gulf-breeze-curriculum-blueprint' );
		$registry  = get_option( self::COURSE_OPTION, array() );
		$course_id = absint( $registry['adult_en']['learnpress_course_id'] ?? 0 );
		global $wpdb;
		$section_name = 'Topic 4.1.3 — Right-of-Way';
		$section_id   = $course_id ? absint( $wpdb->get_var( $wpdb->prepare( "SELECT section_id FROM {$wpdb->learnpress_sections} WHERE section_course_id = %d AND section_name = %s LIMIT 1", $course_id, $section_name ) ) ) : 0;
		$section_curd = $course_id && class_exists( 'LP_Section_CURD' ) ? new LP_Section_CURD( $course_id ) : null;
		if ( ! $section_id || ! $section_curd ) {
			wp_safe_redirect( add_query_arg( 'gb_adult_error', rawurlencode( 'The Adult English Topic 4.1.3 LearnPress section is missing. Run the shell builder first.' ), $base_url ) );
			exit;
		}
		$built = 0;
		foreach ( self::adult_topic_three_content() as $key => $lesson ) {
			$posts = get_posts( array( 'post_type' => 'lp_lesson', 'post_status' => array( 'draft', 'pending', 'private', 'publish' ), 'meta_key' => '_gb_blueprint_key', 'meta_value' => $key, 'posts_per_page' => 1 ) );
			if ( ! $posts ) {
				wp_safe_redirect( add_query_arg( 'gb_adult_error', rawurlencode( 'A required Topic 4.1.3 lesson shell is missing.' ), $base_url ) );
				exit;
			}
			$lesson_id = absint( $posts[0]->ID );
			$result = wp_update_post( array( 'ID' => $lesson_id, 'post_title' => $lesson['title'], 'post_content' => self::complete_timed_content( $key, $lesson['content'] ), 'post_status' => 'publish' ), true );
			if ( is_wp_error( $result ) ) {
				wp_safe_redirect( add_query_arg( 'gb_adult_error', rawurlencode( 'A Topic 4.1.3 lesson could not be updated.' ), $base_url ) );
				exit;
			}
			update_post_meta( $lesson_id, '_gb_poi_topic', '4.1.3' );
			update_post_meta( $lesson_id, '_gb_poi_coverage', $lesson['objective'] );
			update_post_meta( $lesson_id, '_gb_required_minutes', absint( $lesson['minutes'] ) );
			update_post_meta( $lesson_id, '_gb_required_seconds', absint( $lesson['minutes'] ) * 60 );
			update_post_meta( $lesson_id, '_gb_content_status', 'internal_item_sourced_topic_three' );
			update_post_meta( $lesson_id, '_gb_source_poi', 'TDLR POI-Adult Six-Hour, May 2026, 4.1.3' );
			update_post_meta( $lesson_id, '_gb_source_handbook', 'Texas Driver Handbook DL-7, January 2026' );
			$assigned = absint( $wpdb->get_var( $wpdb->prepare( "SELECT section_id FROM {$wpdb->learnpress_section_items} WHERE item_id = %d LIMIT 1", $lesson_id ) ) );
			if ( ! $assigned ) {
				$section_curd->add_items_section( $section_id, array( array( 'id' => $lesson_id, 'type' => LP_LESSON_CPT ) ) );
			}
			$built++;
		}
		$this->refresh_learnpress_course_cache( $course_id );
		wp_safe_redirect( add_query_arg( 'gb_topic_three_built', $built, $base_url ) );
		exit;
	}

	public function build_adult_topic_four() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to build course content.', 'gulf-breeze-core' ) );
		}
		check_admin_referer( 'gb_build_adult_topic_four' );
		$base_url = admin_url( 'admin.php?page=gulf-breeze-curriculum-blueprint' );
		$registry = get_option( self::COURSE_OPTION, array() );
		$course_id = absint( $registry['adult_en']['learnpress_course_id'] ?? 0 );
		global $wpdb;
		$section_name = 'Topic 4.1.4 — Traffic Control Devices';
		$section_id = $course_id ? absint( $wpdb->get_var( $wpdb->prepare( "SELECT section_id FROM {$wpdb->learnpress_sections} WHERE section_course_id = %d AND section_name = %s LIMIT 1", $course_id, $section_name ) ) ) : 0;
		$section_curd = $course_id && class_exists( 'LP_Section_CURD' ) ? new LP_Section_CURD( $course_id ) : null;
		if ( ! $section_id || ! $section_curd ) {
			wp_safe_redirect( add_query_arg( 'gb_adult_error', rawurlencode( 'The Adult English Topic 4.1.4 LearnPress section is missing.' ), $base_url ) ); exit;
		}
		$built = 0;
		foreach ( self::adult_topic_four_content() as $key => $lesson ) {
			$posts = get_posts( array( 'post_type'=>'lp_lesson', 'post_status'=>array('draft','pending','private','publish'), 'meta_key'=>'_gb_blueprint_key', 'meta_value'=>$key, 'posts_per_page'=>1 ) );
			if ( ! $posts ) { wp_safe_redirect( add_query_arg( 'gb_adult_error', rawurlencode( 'A required Topic 4.1.4 lesson shell is missing.' ), $base_url ) ); exit; }
			$lesson_id = absint( $posts[0]->ID );
			$result = wp_update_post( array( 'ID'=>$lesson_id, 'post_title'=>$lesson['title'], 'post_content'=>self::complete_topic_four_content( $key, $lesson['content'] ), 'post_status'=>'publish' ), true );
			if ( is_wp_error( $result ) ) { wp_safe_redirect( add_query_arg( 'gb_adult_error', rawurlencode( 'A Topic 4.1.4 lesson could not be updated.' ), $base_url ) ); exit; }
			update_post_meta( $lesson_id, '_gb_poi_topic', '4.1.4' );
			update_post_meta( $lesson_id, '_gb_poi_coverage', $lesson['objective'] );
			update_post_meta( $lesson_id, '_gb_required_minutes', absint( $lesson['minutes'] ) );
			update_post_meta( $lesson_id, '_gb_required_seconds', absint( $lesson['minutes'] ) * 60 );
			update_post_meta( $lesson_id, '_gb_content_status', 'internal_item_sourced_topic_four' );
			update_post_meta( $lesson_id, '_gb_source_poi', 'TDLR POI-Adult Six-Hour, May 2026, 4.1.4' );
			update_post_meta( $lesson_id, '_gb_source_handbook', 'Texas Driver Handbook DL-7, January 2026, Chapter 5' );
			$assigned = absint( $wpdb->get_var( $wpdb->prepare( "SELECT section_id FROM {$wpdb->learnpress_section_items} WHERE item_id = %d LIMIT 1", $lesson_id ) ) );
			if ( ! $assigned ) { $section_curd->add_items_section( $section_id, array( array( 'id'=>$lesson_id, 'type'=>LP_LESSON_CPT ) ) ); }
			$built++;
		}
		$this->refresh_learnpress_course_cache( $course_id );
		wp_safe_redirect( add_query_arg( 'gb_topic_four_built', $built, $base_url ) ); exit;
	}

	public function build_adult_topic_five() {
		if(!current_user_can('manage_options'))wp_die(esc_html__('You are not allowed to build course content.','gulf-breeze-core'));
		check_admin_referer('gb_build_adult_topic_five');
		$base_url=admin_url('admin.php?page=gulf-breeze-curriculum-blueprint'); $registry=get_option(self::COURSE_OPTION,array()); $course_id=absint($registry['adult_en']['learnpress_course_id']??0); global $wpdb;
		$section_name='Topic 4.1.5 — Controlling Traffic Flow'; $section_id=$course_id?absint($wpdb->get_var($wpdb->prepare("SELECT section_id FROM {$wpdb->learnpress_sections} WHERE section_course_id=%d AND section_name=%s LIMIT 1",$course_id,$section_name))):0; $section_curd=$course_id&&class_exists('LP_Section_CURD')?new LP_Section_CURD($course_id):null;
		if(!$section_id||!$section_curd){wp_safe_redirect(add_query_arg('gb_adult_error',rawurlencode('The Adult English Topic 4.1.5 LearnPress section is missing.'),$base_url));exit;}
		$built=0; foreach(self::adult_topic_five_content() as $key=>$lesson){
			$posts=get_posts(array('post_type'=>'lp_lesson','post_status'=>array('draft','pending','private','publish'),'meta_key'=>'_gb_blueprint_key','meta_value'=>$key,'posts_per_page'=>1)); if(!$posts){wp_safe_redirect(add_query_arg('gb_adult_error',rawurlencode('A required Topic 4.1.5 lesson shell is missing.'),$base_url));exit;}
			$lesson_id=absint($posts[0]->ID); $result=wp_update_post(array('ID'=>$lesson_id,'post_title'=>$lesson['title'],'post_content'=>self::complete_topic_four_content($key,$lesson['content']),'post_status'=>'publish'),true); if(is_wp_error($result)){wp_safe_redirect(add_query_arg('gb_adult_error',rawurlencode('A Topic 4.1.5 lesson could not be updated.'),$base_url));exit;}
			update_post_meta($lesson_id,'_gb_poi_topic','4.1.5'); update_post_meta($lesson_id,'_gb_poi_coverage',$lesson['objective']); update_post_meta($lesson_id,'_gb_required_minutes',absint($lesson['minutes'])); update_post_meta($lesson_id,'_gb_required_seconds',absint($lesson['minutes'])*60); update_post_meta($lesson_id,'_gb_content_status','internal_item_sourced_topic_five'); update_post_meta($lesson_id,'_gb_source_poi','TDLR POI-Adult Six-Hour, May 2026, 4.1.5'); update_post_meta($lesson_id,'_gb_source_handbook','Texas Driver Handbook DL-7, January 2026, Chapters 6-9');
			$assigned=absint($wpdb->get_var($wpdb->prepare("SELECT section_id FROM {$wpdb->learnpress_section_items} WHERE item_id=%d LIMIT 1",$lesson_id))); if(!$assigned)$section_curd->add_items_section($section_id,array(array('id'=>$lesson_id,'type'=>LP_LESSON_CPT))); $built++;
		}
		$this->refresh_learnpress_course_cache($course_id); wp_safe_redirect(add_query_arg('gb_topic_five_built',$built,$base_url));exit;
	}

	public function run_verified_curriculum_migrations() {
		$target_version = $this->next_curriculum_migration_version();
		if ( '' === $target_version ) {
			return;
		}
		$lock_token = $this->acquire_migration_lock();
		if ( '' === $lock_token ) {
			return;
		}
		$this->schedule_single_migration_event( 'gb_core_migration_watchdog', 960 );
		$before_version = (string) get_option( 'gb_curriculum_migration_version', '' );
		$previous_runtime = get_option( self::MIGRATION_RUNTIME_OPTION, array() );
		$previous_attempts = is_array( $previous_runtime ) && ( $previous_runtime['target'] ?? '' ) === $target_version
			? absint( $previous_runtime['attempts'] ?? 0 )
			: 0;
		update_option( self::MIGRATION_RUNTIME_OPTION, array(
			'status' => 'running', 'target' => $target_version, 'version' => $before_version,
			'attempts' => $previous_attempts,
			'started_at' => time(),
		), false );
		try {
		if($target_version==='1.6.0'&&version_compare((string)get_option('gb_curriculum_migration_version',''),'1.6.0','<')){
		$registry=get_option(self::COURSE_OPTION,array()); $course_id=absint($registry['adult_en']['learnpress_course_id']??0); global $wpdb;
		$section_name='Topic 4.1.6 — Alcohol and Other Drugs';
		$section_id=$course_id?absint($wpdb->get_var($wpdb->prepare("SELECT section_id FROM {$wpdb->learnpress_sections} WHERE section_course_id=%d AND section_name=%s LIMIT 1",$course_id,$section_name))):0;
		$section_curd=$course_id&&class_exists('LP_Section_CURD')?new LP_Section_CURD($course_id):null;
		if(!$section_id||!$section_curd){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.6 section is missing.','time'=>current_time('mysql',true)),false);return;}
		$built=0; $minutes=0;
		foreach(self::adult_topic_six_content() as $key=>$lesson){
			$posts=get_posts(array('post_type'=>'lp_lesson','post_status'=>array('draft','pending','private','publish'),'meta_key'=>'_gb_blueprint_key','meta_value'=>$key,'posts_per_page'=>1));
			if(!$posts){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Required lesson shell missing: '.$key,'time'=>current_time('mysql',true)),false);return;}
			$lesson_id=absint($posts[0]->ID); $result=wp_update_post(array('ID'=>$lesson_id,'post_title'=>$lesson['title'],'post_content'=>$lesson['content'],'post_status'=>'publish'),true);
			if(is_wp_error($result)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>$result->get_error_message(),'time'=>current_time('mysql',true)),false);return;}
			update_post_meta($lesson_id,'_gb_poi_topic','4.1.6'); update_post_meta($lesson_id,'_gb_poi_coverage',$lesson['objective']); update_post_meta($lesson_id,'_gb_required_minutes',absint($lesson['minutes'])); update_post_meta($lesson_id,'_gb_required_seconds',absint($lesson['minutes'])*60); update_post_meta($lesson_id,'_gb_content_status','verified_automatic_migration_1_6_0'); update_post_meta($lesson_id,'_gb_source_poi','TDLR POI-Adult Six-Hour, May 2026, 4.1.6'); update_post_meta($lesson_id,'_gb_source_handbook','Texas Driver Handbook DL-7, January 2026, Chapter 10');
			$assigned=absint($wpdb->get_var($wpdb->prepare("SELECT section_id FROM {$wpdb->learnpress_section_items} WHERE item_id=%d LIMIT 1",$lesson_id))); if(!$assigned)$section_curd->add_items_section($section_id,array(array('id'=>$lesson_id,'type'=>LP_LESSON_CPT)));
			$built++; $minutes+=absint($lesson['minutes']);
		}
		$this->refresh_learnpress_course_cache($course_id);
		update_option('gb_curriculum_migration_version','1.6.0',false);
		update_option('gb_curriculum_migration_status',array('status'=>'success','message'=>'Adult English Topic 4.1.6 automatically loaded into '.$built.' lesson items; '.$minutes.' instructional minutes.','time'=>current_time('mysql',true)),false);
		}
		if($target_version==='1.7.0'&&version_compare((string)get_option('gb_curriculum_migration_version',''),'1.7.0','<')){
		$registry=get_option(self::COURSE_OPTION,array()); $course_id=absint($registry['adult_en']['learnpress_course_id']??0); global $wpdb;
		$section_name='Topic 4.1.7 — Cooperating with Other Roadway Users'; $section_id=$course_id?absint($wpdb->get_var($wpdb->prepare("SELECT section_id FROM {$wpdb->learnpress_sections} WHERE section_course_id=%d AND section_name=%s LIMIT 1",$course_id,$section_name))):0; $section_curd=$course_id&&class_exists('LP_Section_CURD')?new LP_Section_CURD($course_id):null;
		if(!$section_id||!$section_curd){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.7 section is missing.','time'=>current_time('mysql',true)),false);return;}
		$built=0; $minutes=0;
		foreach(self::adult_topic_seven_content() as $key=>$lesson){
			$posts=get_posts(array('post_type'=>'lp_lesson','post_status'=>array('draft','pending','private','publish'),'meta_key'=>'_gb_blueprint_key','meta_value'=>$key,'posts_per_page'=>1)); if(!$posts){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Required lesson shell missing: '.$key,'time'=>current_time('mysql',true)),false);return;}
			$lesson_id=absint($posts[0]->ID); $result=wp_update_post(array('ID'=>$lesson_id,'post_title'=>$lesson['title'],'post_content'=>$lesson['content'],'post_status'=>'publish'),true); if(is_wp_error($result)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>$result->get_error_message(),'time'=>current_time('mysql',true)),false);return;}
			update_post_meta($lesson_id,'_gb_poi_topic','4.1.7'); update_post_meta($lesson_id,'_gb_poi_coverage',$lesson['objective']); update_post_meta($lesson_id,'_gb_required_minutes',absint($lesson['minutes'])); update_post_meta($lesson_id,'_gb_required_seconds',absint($lesson['minutes'])*60); update_post_meta($lesson_id,'_gb_content_status','verified_automatic_migration_1_7_0'); update_post_meta($lesson_id,'_gb_source_poi','TDLR POI-Adult Six-Hour, May 2026, 4.1.7'); update_post_meta($lesson_id,'_gb_source_handbook','Texas Driver Handbook DL-7, January 2026, Chapters 11-14');
			$assigned=absint($wpdb->get_var($wpdb->prepare("SELECT section_id FROM {$wpdb->learnpress_section_items} WHERE item_id=%d LIMIT 1",$lesson_id))); if(!$assigned)$section_curd->add_items_section($section_id,array(array('id'=>$lesson_id,'type'=>LP_LESSON_CPT))); $built++; $minutes+=absint($lesson['minutes']);
		}
		$this->refresh_learnpress_course_cache($course_id); update_option('gb_curriculum_migration_version','1.7.0',false); update_option('gb_curriculum_migration_status',array('status'=>'success','message'=>'Adult English Topic 4.1.7 automatically loaded into '.$built.' lesson items; '.$minutes.' instructional minutes.','time'=>current_time('mysql',true)),false);
		}
		if($target_version==='1.8.0'&&version_compare((string)get_option('gb_curriculum_migration_version',''),'1.8.0','<')){
		$registry=get_option(self::COURSE_OPTION,array()); $course_id=absint($registry['adult_en']['learnpress_course_id']??0); global $wpdb;
		$section_name='Topic 4.1.8 — Managing Risk'; $section_id=$course_id?absint($wpdb->get_var($wpdb->prepare("SELECT section_id FROM {$wpdb->learnpress_sections} WHERE section_course_id=%d AND section_name=%s LIMIT 1",$course_id,$section_name))):0; $section_curd=$course_id&&class_exists('LP_Section_CURD')?new LP_Section_CURD($course_id):null;
		if(!$section_id||!$section_curd){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.8 section is missing.','time'=>current_time('mysql',true)),false);return;}
		$built=0; $minutes=0;
		foreach(self::adult_topic_eight_content() as $key=>$lesson){
			$posts=get_posts(array('post_type'=>'lp_lesson','post_status'=>array('draft','pending','private','publish'),'meta_key'=>'_gb_blueprint_key','meta_value'=>$key,'posts_per_page'=>1)); if(!$posts){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Required lesson shell missing: '.$key,'time'=>current_time('mysql',true)),false);return;}
			$lesson_id=absint($posts[0]->ID); $result=wp_update_post(array('ID'=>$lesson_id,'post_title'=>$lesson['title'],'post_content'=>$lesson['content'],'post_status'=>'publish'),true); if(is_wp_error($result)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>$result->get_error_message(),'time'=>current_time('mysql',true)),false);return;}
			update_post_meta($lesson_id,'_gb_poi_topic','4.1.8'); update_post_meta($lesson_id,'_gb_poi_coverage',$lesson['objective']); update_post_meta($lesson_id,'_gb_required_minutes',absint($lesson['minutes'])); update_post_meta($lesson_id,'_gb_required_seconds',absint($lesson['minutes'])*60); update_post_meta($lesson_id,'_gb_content_status','verified_automatic_migration_1_8_0'); update_post_meta($lesson_id,'_gb_source_poi','TDLR POI-Adult Six-Hour, May 2026, 4.1.8'); update_post_meta($lesson_id,'_gb_source_handbook','Texas Driver Handbook DL-7, January 2026, risk-management topics');
			$assigned=absint($wpdb->get_var($wpdb->prepare("SELECT section_id FROM {$wpdb->learnpress_section_items} WHERE item_id=%d LIMIT 1",$lesson_id))); if(!$assigned)$section_curd->add_items_section($section_id,array(array('id'=>$lesson_id,'type'=>LP_LESSON_CPT))); $built++; $minutes+=absint($lesson['minutes']);
		}
		$this->refresh_learnpress_course_cache($course_id); update_option('gb_curriculum_migration_version','1.8.0',false); update_option('gb_curriculum_migration_status',array('status'=>'success','message'=>'Adult English Topic 4.1.8 automatically loaded into '.$built.' lesson items; '.$minutes.' instructional minutes.','time'=>current_time('mysql',true)),false);
		}
		if($target_version==='1.9.0'&&version_compare((string)get_option('gb_curriculum_migration_version',''),'1.9.0','<')){
		$registry=get_option(self::COURSE_OPTION,array()); $course_id=absint($registry['adult_en']['learnpress_course_id']??0); global $wpdb;
		$section_name='Topic 4.1.9 — Classroom Progress Assessment'; $section_id=$course_id?absint($wpdb->get_var($wpdb->prepare("SELECT section_id FROM {$wpdb->learnpress_sections} WHERE section_course_id=%d AND section_name=%s LIMIT 1",$course_id,$section_name))):0; $section_curd=$course_id&&class_exists('LP_Section_CURD')?new LP_Section_CURD($course_id):null;
		if(!$section_id||!$section_curd){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.9 section is missing.','time'=>current_time('mysql',true)),false);return;}
		$built=0; $minutes=0;
		foreach(self::adult_topic_nine_content() as $key=>$lesson){
			$posts=get_posts(array('post_type'=>'lp_lesson','post_status'=>array('draft','pending','private','publish'),'meta_key'=>'_gb_blueprint_key','meta_value'=>$key,'posts_per_page'=>1)); if(!$posts){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Required lesson shell missing: '.$key,'time'=>current_time('mysql',true)),false);return;}
			$lesson_id=absint($posts[0]->ID); $result=wp_update_post(array('ID'=>$lesson_id,'post_title'=>$lesson['title'],'post_content'=>$lesson['content'],'post_status'=>'publish'),true); if(is_wp_error($result)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>$result->get_error_message(),'time'=>current_time('mysql',true)),false);return;}
			update_post_meta($lesson_id,'_gb_poi_topic','4.1.9'); update_post_meta($lesson_id,'_gb_poi_coverage',$lesson['objective']); update_post_meta($lesson_id,'_gb_required_minutes',absint($lesson['minutes'])); update_post_meta($lesson_id,'_gb_required_seconds',absint($lesson['minutes'])*60); update_post_meta($lesson_id,'_gb_content_status','verified_automatic_migration_1_9_0'); update_post_meta($lesson_id,'_gb_source_poi','TDLR POI-Adult Six-Hour, May 2026, 4.1.9'); update_post_meta($lesson_id,'_gb_source_handbook','Texas Driver Handbook DL-7, January 2026, comprehensive readiness review');
			$assigned=absint($wpdb->get_var($wpdb->prepare("SELECT section_id FROM {$wpdb->learnpress_section_items} WHERE item_id=%d LIMIT 1",$lesson_id))); if(!$assigned)$section_curd->add_items_section($section_id,array(array('id'=>$lesson_id,'type'=>LP_LESSON_CPT))); $built++; $minutes+=absint($lesson['minutes']);
		}
		$final_posts=get_posts(array('post_type'=>'lp_quiz','post_status'=>array('draft','pending','private','publish'),'meta_key'=>'_gb_assessment_key','meta_value'=>'adult_en_final','posts_per_page'=>1));
		if($final_posts){$final_id=absint($final_posts[0]->ID); $final_result=wp_update_post(array('ID'=>$final_id,'post_title'=>'Adult English Comprehensive Final Assessment','post_content'=>'This controlled final assessment draws 15 highway-sign questions and 15 traffic-law questions from separate reviewed banks. A score of 70 percent or higher is required. The assessment does not add instructional seat time.','post_status'=>'publish'),true);}else{$final_result=wp_insert_post(array('post_type'=>'lp_quiz','post_title'=>'Adult English Comprehensive Final Assessment','post_content'=>'This controlled final assessment draws 15 highway-sign questions and 15 traffic-law questions from separate reviewed banks. A score of 70 percent or higher is required. The assessment does not add instructional seat time.','post_status'=>'publish'),true); $final_id=is_wp_error($final_result)?0:absint($final_result);}
		if(is_wp_error($final_result)||!$final_id){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'The Adult English final-assessment shell could not be created.','time'=>current_time('mysql',true)),false);return;}
		update_post_meta($final_id,'_gb_assessment_key','adult_en_final'); update_post_meta($final_id,'_gb_poi_topic','4.1.9'); update_post_meta($final_id,'_gb_required_minutes',0); update_post_meta($final_id,'_gb_required_seconds',0); update_post_meta($final_id,'_lp_passing_grade','70'); update_post_meta($final_id,'_lp_review','no'); update_post_meta($final_id,'_lp_show_correct_review','no'); update_post_meta($final_id,'_lp_retake_count','-1');
		$final_assigned=absint($wpdb->get_var($wpdb->prepare("SELECT section_id FROM {$wpdb->learnpress_section_items} WHERE item_id=%d LIMIT 1",$final_id))); if(!$final_assigned)$section_curd->add_items_section($section_id,array(array('id'=>$final_id,'type'=>LP_QUIZ_CPT)));
		$this->refresh_learnpress_course_cache($course_id); update_option('gb_curriculum_migration_version','1.9.0',false); update_option('gb_curriculum_migration_status',array('status'=>'success','message'=>'Adult English Topic 4.1.9 automatically loaded into '.$built.' instructional-review lesson items; '.$minutes.' instructional minutes. A separate controlled final-assessment shell was added with zero seat time.','time'=>current_time('mysql',true)),false);
		}
		if($target_version==='2.0.0'&&version_compare((string)get_option('gb_curriculum_migration_version',''),'2.0.0','<')){
		$registry=get_option(self::COURSE_OPTION,array()); $course_id=absint($registry['adult_en']['learnpress_course_id']??0); global $wpdb;
		$section_curd=$course_id&&class_exists('LP_Section_CURD')?new LP_Section_CURD($course_id):null;
		if(!$course_id||!$section_curd){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Adult English course or LearnPress section service is unavailable.','time'=>current_time('mysql',true)),false);return;}
		$topic_names=self::curriculum_blueprints()['adult_six_hour']['units']; $created=0; $verified=0;
		foreach(range(2,8) as $topic_number){
			$topic='4.1.'.$topic_number; $section_name='Topic '.$topic.' — '.$topic_names[$topic];
			$section_id=absint($wpdb->get_var($wpdb->prepare("SELECT section_id FROM {$wpdb->learnpress_sections} WHERE section_course_id=%d AND section_name=%s LIMIT 1",$course_id,$section_name)));
			if(!$section_id){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Required curriculum section is missing: '.$section_name,'time'=>current_time('mysql',true)),false);return;}
			$key='adult_en_topic_'.$topic_number.'_participation';
			$posts=get_posts(array('post_type'=>'lp_quiz','post_status'=>array('draft','pending','private','publish'),'meta_key'=>'_gb_assessment_key','meta_value'=>$key,'posts_per_page'=>1));
			$title='Adult English Topic '.$topic.' Participation Check';
			$content='This controlled participation check administers two questions from the reviewed 10-question Topic '.$topic.' bank. A score of 70 percent or higher is required. The check carries zero instructional seat time and does not change the locked 330-minute course total.';
			if($posts){$quiz_id=absint($posts[0]->ID); $result=wp_update_post(array('ID'=>$quiz_id,'post_title'=>$title,'post_content'=>$content,'post_status'=>'publish'),true);}else{$result=wp_insert_post(array('post_type'=>'lp_quiz','post_title'=>$title,'post_content'=>$content,'post_status'=>'publish'),true); $quiz_id=is_wp_error($result)?0:absint($result); $created++;}
			if(is_wp_error($result)||!$quiz_id){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Participation-check shell could not be created for Topic '.$topic.'.','time'=>current_time('mysql',true)),false);return;}
			update_post_meta($quiz_id,'_gb_assessment_key',$key); update_post_meta($quiz_id,'_gb_poi_topic',$topic); update_post_meta($quiz_id,'_gb_required_minutes',0); update_post_meta($quiz_id,'_gb_required_seconds',0); update_post_meta($quiz_id,'_lp_passing_grade','70'); update_post_meta($quiz_id,'_lp_review','no'); update_post_meta($quiz_id,'_lp_show_correct_review','no'); update_post_meta($quiz_id,'_lp_retake_count','-1');
			$assigned=absint($wpdb->get_var($wpdb->prepare("SELECT section_id FROM {$wpdb->learnpress_section_items} WHERE item_id=%d LIMIT 1",$quiz_id))); if(!$assigned)$section_curd->add_items_section($section_id,array(array('id'=>$quiz_id,'type'=>LP_QUIZ_CPT)));
			$verified++;
		}
		$this->refresh_learnpress_course_cache($course_id); update_option('gb_curriculum_migration_version','2.0.0',false); update_option('gb_curriculum_migration_status',array('status'=>'success','message'=>'Adult English Topics 4.1.2–4.1.8 now contain '.$verified.' controlled participation-check shells ('.$created.' newly created), all with zero seat time. The instructional ledger remains 46 lessons / 330 minutes.','time'=>current_time('mysql',true)),false);
		}
		if($target_version==='2.1.0'&&version_compare((string)get_option('gb_curriculum_migration_version',''),'2.1.0','<')){
		// The 2.1 migration must initialize its own dependencies. On an already
		// migrated 2.0 installation, the preceding 2.0 block is skipped and its
		// local variables do not exist.
		$registry=get_option(self::COURSE_OPTION,array());
		$course_id=absint($registry['adult_en']['learnpress_course_id']??0);
		global $wpdb;
		$section_curd=$course_id&&class_exists('LP_Section_CURD')?new LP_Section_CURD($course_id):null;
		if(!$course_id||!$section_curd){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Adult English course or LearnPress section service is unavailable for the video-check migration.','time'=>current_time('mysql',true)),false);return;}
		$video_checks=array(
			array('topic'=>'4.1.7','section'=>'Topic 4.1.7 — Cooperating with Other Roadway Users','lesson_key'=>'adult_en_037','assessment_key'=>'adult_en_csea_video_check','title'=>'Adult English CSEA Video Check'),
			array('topic'=>'4.1.8','section'=>'Topic 4.1.8 — Managing Risk','lesson_key'=>'adult_en_043','assessment_key'=>'adult_en_water_safety_video_check','title'=>'Adult English Recreational Water Safety Video Check'),
		);
		$created=0; $positioned=0;
		foreach($video_checks as $check){
			$section_id=absint($wpdb->get_var($wpdb->prepare("SELECT section_id FROM {$wpdb->learnpress_sections} WHERE section_course_id=%d AND section_name=%s LIMIT 1",$course_id,$check['section'])));
			$lesson_id=absint($wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_gb_blueprint_key' AND meta_value=%s LIMIT 1",$check['lesson_key'])));
			if(!$section_id||!$lesson_id){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Required video lesson or section is missing for Topic '.$check['topic'].'.','time'=>current_time('mysql',true)),false);return;}
			$posts=get_posts(array('post_type'=>'lp_quiz','post_status'=>array('draft','pending','private','publish'),'meta_key'=>'_gb_assessment_key','meta_value'=>$check['assessment_key'],'posts_per_page'=>1));
			$content='This controlled check administers one question from the reviewed four-question video bank. An incorrect response requires the student to return to the required video before receiving a different question. This check carries zero instructional seat time.';
			if($posts){$quiz_id=absint($posts[0]->ID); $result=wp_update_post(array('ID'=>$quiz_id,'post_title'=>$check['title'],'post_content'=>$content,'post_status'=>'publish'),true);}else{$result=wp_insert_post(array('post_type'=>'lp_quiz','post_title'=>$check['title'],'post_content'=>$content,'post_status'=>'publish'),true); $quiz_id=is_wp_error($result)?0:absint($result); $created++;}
			if(is_wp_error($result)||!$quiz_id){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Video-check shell could not be created for Topic '.$check['topic'].'.','time'=>current_time('mysql',true)),false);return;}
			update_post_meta($quiz_id,'_gb_assessment_key',$check['assessment_key']); update_post_meta($quiz_id,'_gb_poi_topic',$check['topic']); update_post_meta($quiz_id,'_gb_required_minutes',0); update_post_meta($quiz_id,'_gb_required_seconds',0); update_post_meta($quiz_id,'_lp_passing_grade','70'); update_post_meta($quiz_id,'_lp_review','no'); update_post_meta($quiz_id,'_lp_show_correct_review','no'); update_post_meta($quiz_id,'_lp_retake_count','-1');
			$assigned=absint($wpdb->get_var($wpdb->prepare("SELECT section_id FROM {$wpdb->learnpress_section_items} WHERE item_id=%d LIMIT 1",$quiz_id))); if(!$assigned)$section_curd->add_items_section($section_id,array(array('id'=>$quiz_id,'type'=>LP_QUIZ_CPT)));
			$rows=$wpdb->get_results($wpdb->prepare("SELECT section_item_id,item_id FROM {$wpdb->learnpress_section_items} WHERE section_id=%d ORDER BY item_order ASC,section_item_id ASC",$section_id),ARRAY_A); $ordered=array();
			foreach($rows as $row){$iid=absint($row['item_id']); if($iid!==$quiz_id)$ordered[]=$iid; if($iid===$lesson_id)$ordered[]=$quiz_id;}
			if(!in_array($quiz_id,$ordered,true))$ordered[]=$quiz_id;
			foreach($ordered as $index=>$iid)$wpdb->update($wpdb->learnpress_section_items,array('item_order'=>(($index+1)*10)),array('section_id'=>$section_id,'item_id'=>$iid),array('%d'),array('%d','%d'));
			$after=absint($wpdb->get_var($wpdb->prepare("SELECT item_id FROM {$wpdb->learnpress_section_items} WHERE section_id=%d AND item_order>(SELECT item_order FROM {$wpdb->learnpress_section_items} WHERE section_id=%d AND item_id=%d LIMIT 1) ORDER BY item_order ASC,section_item_id ASC LIMIT 1",$section_id,$section_id,$lesson_id)));
			if($after!==$quiz_id){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Video-check placement verification failed for Topic '.$check['topic'].'.','time'=>current_time('mysql',true)),false);return;} $positioned++;
		}
		$this->refresh_learnpress_course_cache($course_id); update_option('gb_curriculum_migration_version','2.1.0',false); update_option('gb_curriculum_migration_status',array('status'=>'success','message'=>'Two zero-seat-time video-check shells were verified immediately after the CSEA and recreational-water-safety video lessons ('.$created.' newly created). The instructional ledger remains 46 lessons / 330 minutes.','time'=>current_time('mysql',true)),false);
		}

		if($target_version==='2.2.1'&&version_compare((string)get_option('gb_curriculum_migration_version',''),'2.2.1','<')){
			// Core 2.1 created position placeholders before the reviewed four-question
			// video banks were imported. Core 2.2 promotes the imported banks into the
			// course at those exact positions and retires (never deletes) the empty
			// placeholders. The operation is deliberately retry-safe after a partial run.
			$registry=get_option(self::COURSE_OPTION,array());
			$course_id=absint($registry['adult_en']['learnpress_course_id']??0);
			global $wpdb;
			$section_curd=$course_id&&class_exists('LP_Section_CURD')?new LP_Section_CURD($course_id):null;
			if(!$course_id||!$section_curd){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Adult English course or LearnPress section service is unavailable for the 2.2 video-bank correction.','time'=>current_time('mysql',true)),false);return;}

			$video_banks=array(
				array('topic'=>'4.1.7','section'=>'Topic 4.1.7 — Cooperating with Other Roadway Users','lesson_key'=>'adult_en_037','assessment_key'=>'adult_en_csea_video_check','bank_title'=>'Gulf Breeze Adult English — CSEA Video Check Bank'),
				array('topic'=>'4.1.8','section'=>'Topic 4.1.8 — Managing Risk','lesson_key'=>'adult_en_043','assessment_key'=>'adult_en_water_safety_video_check','bank_title'=>'Gulf Breeze Adult English — Water Safety Video Check Bank'),
			);
			$retired=0; $positioned=0; $mapping_updates=0;

			foreach($video_banks as $bank){
				$section_id=absint($wpdb->get_var($wpdb->prepare("SELECT section_id FROM {$wpdb->learnpress_sections} WHERE section_course_id=%d AND section_name=%s LIMIT 1",$course_id,$bank['section'])));
				$lesson_id=absint($wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_gb_blueprint_key' AND meta_value=%s LIMIT 1",$bank['lesson_key'])));
				$bank_id=absint($wpdb->get_var($wpdb->prepare("SELECT p.ID FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm ON pm.post_id=p.ID AND pm.meta_key='_gb_lpq_imported_bank' AND pm.meta_value='yes' WHERE p.post_type='lp_quiz' AND p.post_title=%s AND p.post_status IN ('draft','pending','private','publish') ORDER BY p.ID ASC LIMIT 1",$bank['bank_title'])));
				if(!$section_id||!$lesson_id||!$bank_id){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'The reviewed imported video bank, required video lesson, or target section is missing for Topic '.$bank['topic'].'.','time'=>current_time('mysql',true)),false);return;}

				$question_count=absint($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->learnpress_quiz_questions} WHERE quiz_id=%d",$bank_id)));
				if(4!==$question_count){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'The imported video bank for Topic '.$bank['topic'].' must contain exactly four reviewed questions before it can replace the placeholder.','time'=>current_time('mysql',true)),false);return;}

				$placeholder_ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT pm.post_id FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID=pm.post_id WHERE pm.meta_key IN ('_gb_assessment_key','_gb_retired_assessment_key') AND pm.meta_value=%s AND p.post_type='lp_quiz' AND pm.post_id<>%d ORDER BY pm.post_id ASC",$bank['assessment_key'],$bank_id));
				$placeholder_id=0;
				foreach((array)$placeholder_ids as $candidate_id){
					$candidate_id=absint($candidate_id);
					$candidate_questions=absint($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->learnpress_quiz_questions} WHERE quiz_id=%d",$candidate_id)));
					if(0===$candidate_questions){$placeholder_id=$candidate_id;break;}
				}

				// Promote the imported reviewed bank to the canonical assessment identity.
				update_post_meta($bank_id,'_gb_assessment_key',$bank['assessment_key']);
				update_post_meta($bank_id,'_gb_poi_topic',$bank['topic']);
				update_post_meta($bank_id,'_gb_required_minutes',0);
				update_post_meta($bank_id,'_gb_required_seconds',0);
				update_post_meta($bank_id,'_gb_video_check_bank','yes');
				update_post_meta($bank_id,'_gb_video_check_migration','2.2.1');
				update_post_meta($bank_id,'_lp_passing_grade','70');
				update_post_meta($bank_id,'_lp_review','no');
				update_post_meta($bank_id,'_lp_show_correct_review','no');
				update_post_meta($bank_id,'_lp_retake_count','-1');

				// If a gate was mapped to the temporary shell, preserve that mapping by
				// substituting the real reviewed bank. No new gate is invented here.
				if($placeholder_id){
					$placeholder_section_ids=$wpdb->get_col($wpdb->prepare("SELECT si.section_id FROM {$wpdb->learnpress_section_items} si WHERE si.item_id=%d ORDER BY si.section_id ASC",$placeholder_id));
					foreach((array)$placeholder_section_ids as $placement_section_id){
						if(absint($placement_section_id)!==$section_id){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'The empty video-check placeholder for Topic '.$bank['topic'].' has an unexpected LearnPress placement. Core 2.2 refused to detach it from another section.','time'=>current_time('mysql',true)),false);return;}
					}

					$gates=get_option('gbvqg_gates',array());
					if(is_array($gates)){
						$changed=false;
						foreach($gates as &$gate){
							if(is_array($gate)&&absint($gate['quiz_id']??0)===$placeholder_id){$gate['quiz_id']=$bank_id;$changed=true;$mapping_updates++;}
						}
						unset($gate);
						if($changed)update_option('gbvqg_gates',$gates,false);
					}

					// Retire the empty shell without deleting the post or its audit history.
					$wpdb->delete($wpdb->learnpress_section_items,array('section_id'=>$section_id,'item_id'=>$placeholder_id),array('%d','%d'));
					update_post_meta($placeholder_id,'_gb_retired_assessment_key',$bank['assessment_key']);
					delete_post_meta($placeholder_id,'_gb_assessment_key');
					update_post_meta($placeholder_id,'_gb_retired_by_core_version','2.2.1');
					update_post_meta($placeholder_id,'_gb_retired_replacement_quiz_id',$bank_id);
					$current_title=get_the_title($placeholder_id);
					if(0!==strpos((string)$current_title,'Retired Placeholder — '))$current_title='Retired Placeholder — '.$current_title;
					$result=wp_update_post(array('ID'=>$placeholder_id,'post_title'=>$current_title,'post_status'=>'draft'),true);
					if(is_wp_error($result)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'The empty video-check placeholder for Topic '.$bank['topic'].' could not be retired safely.','time'=>current_time('mysql',true)),false);return;}
					$retired++;
				}

				// Refuse to move a reviewed bank out of an unexpected section. Within the
				// intended section, remove/re-add it so a retry cannot create duplicates.
				$bank_section_ids=$wpdb->get_col($wpdb->prepare("SELECT si.section_id FROM {$wpdb->learnpress_section_items} si WHERE si.item_id=%d ORDER BY si.section_id ASC",$bank_id));
				foreach((array)$bank_section_ids as $placement_section_id){
					if(absint($placement_section_id)!==$section_id){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'The reviewed imported video bank for Topic '.$bank['topic'].' has an unexpected LearnPress placement. Core 2.2 refused to move it from another section.','time'=>current_time('mysql',true)),false);return;}
				}
				$wpdb->delete($wpdb->learnpress_section_items,array('section_id'=>$section_id,'item_id'=>$bank_id),array('%d','%d'));

				// Do not use LP_Section_CURD::add_items_section() here. That method reads
				// the section through LearnPress's cached course curriculum; after a direct
				// placeholder retirement the cache can still contain the retired shell and
				// silently reinsert it. Core 2.2.1 writes the one known-safe quiz placement
				// directly, then explicitly reorders and verifies the whole target section.
				$inserted=$wpdb->insert(
					$wpdb->learnpress_section_items,
					array('section_id'=>$section_id,'item_id'=>$bank_id,'item_order'=>9999,'item_type'=>LP_QUIZ_CPT),
					array('%d','%d','%d','%s')
				);
				if(false===$inserted){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'The reviewed imported video bank for Topic '.$bank['topic'].' could not be inserted into the verified target section.','time'=>current_time('mysql',true)),false);return;}

				$rows=$wpdb->get_results($wpdb->prepare("SELECT section_item_id,item_id FROM {$wpdb->learnpress_section_items} WHERE section_id=%d ORDER BY item_order ASC,section_item_id ASC",$section_id),ARRAY_A);
				$ordered=array();
				foreach($rows as $row){
					$iid=absint($row['item_id']);
					if($iid===$bank_id||($placeholder_id&&$iid===$placeholder_id))continue;
					$ordered[]=$iid;
					if($iid===$lesson_id)$ordered[]=$bank_id;
				}
				if(!in_array($bank_id,$ordered,true))$ordered[]=$bank_id;
				foreach($ordered as $index=>$iid)$wpdb->update($wpdb->learnpress_section_items,array('item_order'=>(($index+1)*10)),array('section_id'=>$section_id,'item_id'=>$iid),array('%d'),array('%d','%d'));

				$after=absint($wpdb->get_var($wpdb->prepare("SELECT item_id FROM {$wpdb->learnpress_section_items} WHERE section_id=%d AND item_order>(SELECT item_order FROM {$wpdb->learnpress_section_items} WHERE section_id=%d AND item_id=%d LIMIT 1) ORDER BY item_order ASC,section_item_id ASC LIMIT 1",$section_id,$section_id,$lesson_id)));
				$bank_rows=absint($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->learnpress_section_items} WHERE item_id=%d",$bank_id)));
				$placeholder_rows=$placeholder_id?absint($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->learnpress_section_items} WHERE item_id=%d",$placeholder_id))):0;
				if($after!==$bank_id||1!==$bank_rows||0!==$placeholder_rows){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Video-bank placement verification failed for Topic '.$bank['topic'].'.','time'=>current_time('mysql',true)),false);return;}
				$positioned++;
			}

			// The corrective release is not allowed to alter the regulated ledger.
			$lesson_ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT si.item_id FROM {$wpdb->learnpress_section_items} si INNER JOIN {$wpdb->learnpress_sections} s ON s.section_id=si.section_id WHERE s.section_course_id=%d AND si.item_type='lp_lesson' ORDER BY si.item_id ASC",$course_id));
			$lesson_count=count((array)$lesson_ids); $minute_total=0;
			foreach((array)$lesson_ids as $regulated_lesson_id)$minute_total+=absint(get_post_meta(absint($regulated_lesson_id),'_gb_required_minutes',true));
			if(46!==$lesson_count||330!==$minute_total){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Core 2.2 refused to finalize because the Adult English instructional ledger is '.$lesson_count.'/46 lessons and '.$minute_total.'/330 minutes.','time'=>current_time('mysql',true)),false);return;}

			$this->refresh_learnpress_course_cache($course_id);
			update_option('gb_curriculum_migration_version','2.2.1',false);
			update_option('gb_curriculum_migration_status',array('status'=>'success','message'=>'Core 2.2.1 verified two imported four-question video banks positioned immediately after the required CSEA and recreational-water-safety videos. '.$retired.' empty Core 2.1 placeholder(s) were retired without deletion and '.$mapping_updates.' existing Video Quiz Gate mapping(s) were preserved. Adult English remains 46/46 instructional lessons and 330/330 minutes.','time'=>current_time('mysql',true)),false);
		}

		// Core 2.3.0 development hardening: add three Chapter Three subjects that
		// the May 2026 Adult Six-Hour POI requires course-wide. This migration is
		// deterministic and retry-safe: it removes only its own marked block before
		// appending the canonical replacement. It does not alter lesson count or time.
		if($target_version==='2.3.0'&&version_compare((string)get_option('gb_curriculum_migration_version',''),'2.3.0','<')){
			$registry=get_option(self::COURSE_OPTION,array());
			$course_id=absint($registry['adult_en']['learnpress_course_id']??0);
			global $wpdb;
			if(!$course_id){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Adult English course is unavailable for the 2.3 compliance-hardening migration.','time'=>current_time('mysql',true)),false);return;}
			$additions=array(
				'adult_en_005'=>array(
					'coverage'=>'4.1.2.1(A); Chapter 3 anatomical-gift objective',
					'html'=>'<section class="gb-compliance-hardening"><h2>Anatomical gifts and the driver-license decision</h2><p>Texas includes an anatomical-gift decision in the driver-license and identification-card process. An anatomical gift is a voluntary donation of organs, eyes, or tissue for transplantation, therapy, research, or education as authorized by law. A licensing employee may provide the opportunity to join the state donor registry, but the decision belongs to the applicant. Driver education must explain the opportunity without pressuring a student toward either choice.</p><p>Before answering, read the current official registry information and make an informed personal decision. Registration records a person’s authorization through the official process; a symbol or registry record is not permission for another driver to make medical decisions at a crash scene. Emergency personnel first provide lifesaving care. Donation questions are handled later by qualified medical and donation professionals under applicable law.</p><h3>Apply the distinction</h3><ul><li><strong>Voluntary:</strong> The applicant decides whether to register.</li><li><strong>Informed:</strong> Use current official information rather than a rumor about medical treatment or eligibility.</li><li><strong>Separate from safe driving:</strong> Donor status does not change traffic duties, insurance obligations, or emergency treatment.</li></ul><details><summary>Decision check</summary><p>A friend claims doctors will not try to save a registered donor. That claim is false. Emergency treatment and donation coordination are separate responsibilities. The safe response is to consult the official Texas donor-registry information before making a voluntary decision.</p></details></section>',
				),
				'adult_en_036'=>array(
					'coverage'=>'4.1.7.1(H)–(J); Chapter 3 litter-prevention objective',
					'html'=>'<section class="gb-compliance-hardening"><h2>Litter prevention is a roadway-safety responsibility</h2><p>Trash thrown or allowed to escape from a vehicle can become a traffic hazard. Paper and plastic can block a driver’s view; glass, metal, and sharp objects can damage tires or injure people; smoking material can start a fire; and unsecured debris can cause a driver, bicyclist, or motorcyclist to swerve. Roadside litter also exposes maintenance workers and volunteers to moving traffic while it is removed.</p><p>Prevent litter before the trip. Keep a closed waste container in the vehicle, empty it at an appropriate receptacle, secure every load, close pickup-bed containers, and inspect trailers or cargo areas for loose material. Never ask a passenger to throw anything from a window. If an item falls from the vehicle, do not stop suddenly or enter a travel lane on foot. Continue to a safe location and report a dangerous roadway obstruction through the appropriate non-emergency or emergency channel.</p><h3>Roadway decisions</h3><ol><li><strong>A cup blows out of an open truck bed.</strong> Do not reverse or walk into traffic. Stop safely and report or retrieve it only when lawful and genuinely safe.</li><li><strong>A load contains light packaging.</strong> A heavy object on top is not reliable securement. Use a cover, closed container, straps, or another proper method that prevents escape.</li><li><strong>A passenger wants to discard a cigarette.</strong> Require it to remain in a proper vehicle receptacle; it can injure another user or start a fire.</li></ol></section>',
				),
				'adult_en_038'=>array(
					'coverage'=>'4.1.8.1(A)–(C), (I); Chapter 3 unattended-child objective',
					'html'=>'<section class="gb-compliance-hardening"><h2>Never leave a child unattended in a vehicle</h2><p>A parked vehicle can become dangerous within minutes. Interior temperature can rise rapidly even when the outside temperature feels moderate, windows are partly open, or the vehicle is in shade. A child may also release a brake, operate a control, become trapped by a window or belt, leave the vehicle into traffic, access a hazardous object, or be taken. Sleep, silence, or a short errand does not make the situation safe.</p><p>Build a prevention routine: check the entire passenger area every time the vehicle is parked; place a necessary item near the child seat as a reminder without creating a hazard; require the responsible adult to confirm the handoff; and lock an empty vehicle so children cannot enter it to play. Never leave keys or remote-start controls accessible to a child. Caregivers should communicate schedule changes so no one assumes another adult removed the child.</p><h3>Recognize and respond</h3><p>If a child appears distressed or is in immediate danger in a vehicle, call 911 and follow the dispatcher’s instructions. Give the exact location, vehicle description, observed condition, and whether the vehicle is running. Do not delay emergency help while searching for an owner. Texas law can impose criminal consequences for leaving a young child in a vehicle without the supervision required by law; the reduced-risk rule is stricter and simpler: take the child with you or leave a responsible adult in direct supervision.</p><details><summary>Risk check</summary><p>“I will only be inside for two minutes” is not a safety plan. Lines, distraction, locked doors, a medical event, or a vehicle problem can extend the absence while the child has no way to protect themselves.</p></details></section>',
				),
			);
			$updated=0;
			foreach($additions as $key=>$addition){
				$lesson_id=absint($wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_gb_blueprint_key' AND meta_value=%s LIMIT 1",$key)));
				if(!$lesson_id||'lp_lesson'!==get_post_type($lesson_id)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Required lesson is unavailable for compliance hardening: '.$key,'time'=>current_time('mysql',true)),false);return;}
				$content=(string)get_post_field('post_content',$lesson_id);
				$pattern='/<!-- gb-compliance-hardening-2\\.3\\.0:'.preg_quote($key,'/').' -->.*?<!-- \/gb-compliance-hardening-2\\.3\\.0 -->/s';
				$content=preg_replace($pattern,'',$content);
				$block='<!-- gb-compliance-hardening-2.3.0:'.$key.' -->'.$addition['html'].'<!-- /gb-compliance-hardening-2.3.0 -->';
				$result=wp_update_post(array('ID'=>$lesson_id,'post_content'=>trim($content).$block),true);
				if(is_wp_error($result)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Compliance-hardening content update failed for '.$key.': '.$result->get_error_message(),'time'=>current_time('mysql',true)),false);return;}
				update_post_meta($lesson_id,'_gb_poi_coverage',$addition['coverage']);
				update_post_meta($lesson_id,'_gb_content_status','compliance_hardening_2_3_0_dev');
				$updated++;
			}
			$lesson_ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT si.item_id FROM {$wpdb->learnpress_section_items} si INNER JOIN {$wpdb->learnpress_sections} s ON s.section_id=si.section_id WHERE s.section_course_id=%d AND si.item_type='lp_lesson' ORDER BY si.item_id ASC",$course_id));
			$lesson_count=count((array)$lesson_ids); $minute_total=0;
			foreach((array)$lesson_ids as $regulated_lesson_id)$minute_total+=absint(get_post_meta(absint($regulated_lesson_id),'_gb_required_minutes',true));
			if(46!==$lesson_count||330!==$minute_total){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Core 2.3 refused to finalize because the Adult English instructional ledger is '.$lesson_count.'/46 lessons and '.$minute_total.'/330 minutes.','time'=>current_time('mysql',true)),false);return;}
			$this->refresh_learnpress_course_cache($course_id);
			update_option('gb_curriculum_migration_version','2.3.0',false);
			update_option('gb_curriculum_migration_status',array('status'=>'success','message'=>'Core 2.3 added the required anatomical-gift, litter-prevention, and unattended-child instruction to three existing Adult English lessons. No lesson or timer was added; Adult English remains 46/46 lessons and 330/330 minutes.','time'=>current_time('mysql',true)),false);
		}

		// Topic 4.1.6 strict duration hardening. These canonical additions deepen
		// instruction and guided practice without changing the five lesson timers.
		if($target_version==='2.3.1'&&version_compare((string)get_option('gb_curriculum_migration_version',''),'2.3.1','<')){
			$registry=get_option(self::COURSE_OPTION,array()); $course_id=absint($registry['adult_en']['learnpress_course_id']??0); global $wpdb;
			if(!$course_id){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Adult English course is unavailable for Topic 4.1.6 duration hardening.','time'=>current_time('mysql',true)),false);return;}
			$expansions=array(
			'adult_en_027'=>'<section class="gb-duration-hardening"><h2>Make the decision before impairment begins</h2><p>Zero tolerance is a planning standard, not a claim that every substance affects every person identically. The driver removes uncertainty by separating vehicle operation from alcohol or any potentially impairing drug. Once judgment is affected, the person may underestimate impairment, overestimate skill, forget the plan, or accept a risk they would normally reject. That is why the safest decision must be made while sober.</p><h3>Build a transportation ladder</h3><p>A strong plan has several levels. The first choice may be a sober driver, transit, taxi, rideshare, or remaining overnight. A backup may be a family member, trusted friend, hotel, or another sober ride. The final level is emergency intervention when an impaired person is attempting to drive and immediate danger cannot otherwise be stopped. Record addresses, pickup procedures, operating hours, payment access, and a charged-phone plan before the event.</p><p>A designated driver must remain completely sober. Rotating turns after drinking, choosing the person who appears “least impaired,” or waiting for someone to say they feel better does not create a sober driver. The same principle applies to cannabis, sedatives, sleep medicines, opioids, certain antihistamines, and combinations.</p><h3>Recognize plan failures</h3><ul><li>The sober driver consumes an impairing substance.</li><li>The ride depends on a person who may leave early or lose phone access.</li><li>The vehicle owner refuses to release the keys.</li><li>Passengers pressure the driver to take “just one.”</li><li>The only backup requires riding with another impaired person.</li></ul><p>When a plan fails, do not bargain with distance, traffic, weather, experience, or confidence. Replace the transportation method. A short trip still includes intersections, pedestrians, turns, unexpected braking, and enforcement.</p><h3>Guided decisions</h3><ol><li><strong>The designated driver drinks half a beverage.</strong> The role ends immediately. Activate a sober backup.</li><li><strong>A friend says cannabis makes them more careful.</strong> Self-confidence is not evidence of unimpaired attention, judgment, timing, or coordination. Do not ride with them.</li><li><strong>A prescription has a new warning.</strong> Do not “test” its effect in traffic. Consult the prescriber or pharmacist and use alternate transportation.</li><li><strong>An impaired person becomes angry when keys are withheld.</strong> Avoid a physical struggle that increases danger. Get sober help, move to safety, and call emergency services if driving is imminent.</li></ol><details><summary>Personal planning exercise</summary><p>Identify a primary ride, a backup ride, a safe place to remain, one sober person to call, and the condition that would cause you to call 911. A complete answer does not depend on an impaired person making the final decision.</p></details></section>',
			'adult_en_028'=>'<section class="gb-duration-hardening"><h2>Understand both Texas definitions of intoxication</h2><p>Texas law does not require an alcohol concentration of 0.08 or more in every intoxication case. Loss of the normal use of mental faculties or physical faculties because of alcohol, a controlled substance, a drug, a dangerous drug, a combination, or another substance is an independent definition. A person can therefore be unsafe and legally intoxicated even when a numerical test is below 0.08 or no reliable number is known.</p><p>Mental faculties include judgment, attention, perception, memory, risk recognition, and the ability to divide attention. Physical faculties include balance, coordination, reaction, tracking, steering precision, and controlled braking. Driving requires these functions at the same time. A person does not need to appear unconscious, fall down, or drive at an extreme speed before impairment matters.</p><h3>Alcohol concentration is not a personal calculator</h3><p>Alcohol concentration is influenced by the amount consumed, pace of consumption, time, body composition, food, and other individual conditions. Students should not use a chart, drink count, phone application, or another person’s experience as permission to drive. Serving sizes vary, mixed drinks may contain more than one standard serving, and alcohol may continue to enter the bloodstream after the last drink.</p><p>Only time reduces alcohol concentration. Coffee may make a person feel more awake without restoring judgment or coordination. Food can affect absorption but does not remove alcohol already absorbed. Cold air, exercise, vomiting, and a shower do not rapidly sober a driver.</p><h3>How impairment changes the driving task</h3><ul><li><strong>Search:</strong> hazards are detected later or not at all.</li><li><strong>Prediction:</strong> speed, distance, closing time, and another user’s movement are judged poorly.</li><li><strong>Decision:</strong> risk appears acceptable and consequences seem less likely.</li><li><strong>Control:</strong> steering, braking, lane position, and speed become inconsistent.</li><li><strong>Communication:</strong> signals may be late, forgotten, or misunderstood.</li></ul><h3>Progressive scenario</h3><p>A driver has consumed alcohol, speaks normally, and believes they are below 0.08. They miss a turn, brake late, and drift while adjusting navigation. The lawful and safe question is not whether the driver can defend a guessed number. The observed loss of attention and control requires the trip to stop.</p><ol><li><strong>Below 0.08 means safe.</strong> False. Loss of normal faculties is independently relevant.</li><li><strong>Experience creates immunity.</strong> False. Practice with drinking does not restore divided attention or eliminate legal risk.</li><li><strong>A sober passenger can compensate.</strong> False. A passenger cannot control the driver’s perception, reaction, or vehicle inputs.</li><li><strong>Waiting without measuring is enough.</strong> Not necessarily. When impairment is possible, use sober transportation instead of guessing.</li></ol><details><summary>Explain the rule in your own words</summary><p>A complete explanation states that Texas recognizes both loss of normal faculties and an alcohol concentration of 0.08 or more, and that neither definition should be treated as a target for driving.</p></details></section>',
			'adult_en_029'=>'<section class="gb-duration-hardening"><h2>Impairment is broader than alcohol</h2><p>A drug may be legal to possess and still make driving unsafe. Prescription status, over-the-counter availability, a dispensary label, or prior use does not guarantee that attention, vision, coordination, or reaction will remain normal. The responsible question is whether the substance or combination can impair the person now.</p><h3>Read warnings as driving information</h3><p>Labels may warn about drowsiness, dizziness, blurred vision, slowed reaction, confusion, fainting, or avoiding machinery. “Use care” does not mean experiment on a public road. Ask the prescriber or pharmacist how long effects may last, whether the dose should be taken before driving, and whether alcohol, cannabis, sleep products, pain medicine, or another prescription creates an interaction.</p><p>Effects can change after a new medicine, dose change, missed sleep, illness, dehydration, or addition of another substance. A medicine that seemed manageable previously may affect the next trip differently. Do not stop or change prescribed treatment without professional direction; change the transportation plan instead.</p><h3>Common risk patterns</h3><ul><li><strong>Sedating products:</strong> sleep aids, some allergy medicines, anxiety medicines, muscle relaxers, and some pain medicines can slow reaction or produce microsleep.</li><li><strong>Stimulants:</strong> increased alertness can be accompanied by agitation, overconfidence, distraction, aggressive decisions, or a later crash in alertness.</li><li><strong>Cannabis:</strong> attention, time-and-distance judgment, coordination, lane position, memory, and reaction may be affected.</li><li><strong>Inhalants or unknown products:</strong> effects may be rapid, unpredictable, and medically dangerous.</li><li><strong>Combinations:</strong> alcohol with a depressant can produce greater impairment than either alone; several medicines may also interact.</li></ul><h3>Four-step medication routine</h3><ol><li>Read the complete label and medication guide.</li><li>Ask specifically about driving, timing, and combinations.</li><li>Observe the warning by arranging transportation before the dose.</li><li>Recheck after any medication, dosage, health, or sleep change.</li></ol><h3>Decision laboratory</h3><ol><li><strong>A nighttime antihistamine causes morning grogginess.</strong> Do not drive until alertness and safe function are reliably restored; obtain professional advice if uncertain.</li><li><strong>A friend offers a prescription that “works better.”</strong> Do not take medication prescribed to someone else. It is medically unsafe and may be unlawful.</li><li><strong>A cannabis user waits until the strongest feeling passes.</strong> Subjective feeling is not a dependable measure of restored driving functions. Use sober transportation.</li><li><strong>Two labels separately allow caution.</strong> That does not prove the combination is safe. Ask a pharmacist or prescriber.</li></ol><details><summary>What must a lawful prescription never become?</summary><p>It must never become permission to drive while normal mental or physical faculties are impaired. The driver remains responsible for recognizing warnings and choosing another transportation method.</p></details></section>',
			'adult_en_030'=>'<section class="gb-duration-hardening"><h2>One event can create several separate cases</h2><p>An impaired-driving event may produce a criminal case, an administrative driver-license action, alcohol-law consequences, civil liability, insurance consequences, employment effects, and personal harm. Dismissal or delay in one process does not automatically end the others. Students must distinguish the elements of each offense instead of treating every event as a generic “DWI.”</p><h3>Required adult and any-age offenses</h3><p><strong>Driving while intoxicated</strong> involves operating a motor vehicle in a public place while intoxicated. <strong>Public intoxication</strong> focuses on appearing in a public place while intoxicated to the degree the person may endanger themselves or another. <strong>Intoxication assault</strong> and <strong>intoxication manslaughter</strong> address serious bodily injury or death caused by specified intoxication conduct. Improper use of a driver license can include unlawful lending, possession, display, or representation. Each offense has its own elements, grade, and possible enhancements.</p><p>Penalty exposure changes with facts such as prior convictions, alcohol concentration, a passenger younger than the statutory age, injury, death, emergency personnel or other protected victims, and current law. A course should not teach one memorized dollar amount as the complete consequence. Courts and DPS apply the controlling statutes to the individual case.</p><h3>Under 21 and minor-related laws</h3><p>Texas uses zero-tolerance alcohol rules for people under 21. Driving under the influence of alcohol by a minor is distinct from DWI and does not require proof of adult-level intoxication. Minor in possession and other Alcoholic Beverage Code violations can add education, community-service, fine, and driver-license consequences. A person under 21 may also face DWI, intoxication assault, intoxication manslaughter, public intoxication, or driver-license misuse when the elements of those offenses are met.</p><h3>Open container</h3><p>Texas law generally prohibits knowingly possessing an open container in the passenger area of a motor vehicle located on a public highway, subject to statutory definitions and exceptions. The passenger area and open-container definitions matter; moving a container or claiming another occupant owns it may not remove the issue. When an open container is proven with DWI, the DWI statute provides an enhanced minimum confinement consequence. The safest practice is no open alcoholic container in the passenger area.</p><h3>Implied consent and administrative license revocation</h3><p>Texas implied-consent law applies to an arrested person under the circumstances defined by statute. A request for an authorized specimen, refusal, or a qualifying analysis can begin an administrative process affecting driving privileges. That process is separate from the criminal prosecution. The notice provides the applicable hearing deadline and temporary-driving information; ignoring it can forfeit an opportunity to challenge the administrative action.</p><p>Do not confuse consent law with a license to physically resist a test or officer. Follow lawful instructions, avoid confrontation, and obtain legal advice through the proper process. Certain circumstances allow or require a specimen under statutory authority or a warrant.</p><h3>Consequence map</h3><ul><li>Loss or restriction of driving privileges</li><li>Arrest, court, supervision, confinement, fines, and statutory costs</li><li>Ignition-interlock or alcohol-monitoring conditions when applicable</li><li>Education, treatment evaluation, or community service</li><li>Vehicle, insurance, employment, immigration, or professional-license consequences</li><li>Injury, death, family loss, and civil claims that cannot be repaired by completing a sentence</li></ul><h3>Classify the situation</h3><ol><li><strong>A 19-year-old has consumed alcohol and drives.</strong> Analyze the under-21 zero-tolerance offense and also whether facts establish DWI or another offense.</li><li><strong>An intoxicated adult seriously injures another person.</strong> DWI is not the only possible charge; intoxication-assault elements must be considered.</li><li><strong>A driver refuses an authorized specimen request.</strong> A separate administrative license process may begin even while the criminal case remains unresolved.</li><li><strong>An open can is in the passenger area.</strong> Open-container law may apply independently and may affect a DWI consequence.</li></ol><details><summary>Why avoid memorizing a single “first-offense cost”?</summary><p>The full consequence depends on the current statute and facts. A remembered figure can omit license action, enhancements, court conditions, insurance, employment, injury, and other lasting effects.</p></details></section>',
			'adult_en_031'=>'<section class="gb-duration-hardening"><h2>Intervention must be safe and workable</h2><p>Telling an impaired person not to drive is only the beginning. A successful intervention removes immediate access to driving when this can be done safely, supplies a realistic alternative, and escalates to trained help when danger remains. Shame, argument, or vague advice can make the person defensive without solving transportation.</p><h3>Use clear language</h3><p>Describe the behavior and action: “You have been drinking, and I will not ride with you. Your ride is on the way.” Offer two safe choices rather than debating whether the person looks impaired. Involve a sober host, family member, security employee, or other responsible adult. Do not place yourself between an aggressive person and a moving vehicle.</p><h3>Protect passengers and the public</h3><p>Never enter the vehicle to supervise the impaired driver. A passenger cannot restore perception, judgment, reaction, or coordination. Do not follow dangerously to collect evidence. If the person drives and poses an immediate hazard, call 911 from a safe location. Provide the vehicle description, license plate if known, location, direction, and observed behavior. Do not exaggerate or attempt enforcement yourself.</p><h3>Plan for common barriers</h3><ul><li><strong>No money:</strong> identify a sober pickup, prepaid ride, host assistance, or safe overnight option before substance use.</li><li><strong>Vehicle security:</strong> leave it lawfully parked or arrange authorized retrieval later; protecting a vehicle never justifies impaired driving.</li><li><strong>Fear of embarrassment:</strong> a private safe ride is less harmful than a crash, arrest, injury, or death.</li><li><strong>Rural distance:</strong> plan lodging or a sober driver in advance because on-demand service may be unavailable.</li><li><strong>Medication impairment:</strong> treat it with the same transportation seriousness as alcohol impairment.</li></ul><h3>Personal safe-ride contract</h3><ol><li>Name the substances or warnings that mean you will not drive.</li><li>Name the primary and backup transportation methods.</li><li>Name one sober person authorized to challenge your decision.</li><li>Choose where the vehicle can remain legally and how it will be retrieved.</li><li>Commit never to ride with an impaired driver.</li></ol><h3>Practice responses</h3><ol><li><strong>“I live only two blocks away.”</strong> The trip still exposes other people; use the arranged sober option.</li><li><strong>“I need my vehicle tomorrow.”</strong> Retrieve it tomorrow with a sober driver. Convenience does not control tonight’s safety decision.</li><li><strong>“The medicine was prescribed.”</strong> Prescription status does not cancel an impairment warning.</li><li><strong>“Give me coffee and an hour.”</strong> Do not guess when safe function returns. Keep the person from driving and use alternate transportation.</li></ol><details><summary>Final decision check</summary><p>Your plan is complete only when it works without relying on the impaired person’s later judgment. Identify the ride, backup, safe location, sober contact, and emergency threshold now.</p></details></section>',
			);
			$expansions['adult_en_027'].='<section class="gb-duration-reinforcement"><h3>Separate possession, consumption, and driving decisions</h3><p>A person may face different rules because of age, location, substance, licensing status, or conduct. The course’s zero-tolerance driving standard does not wait for a student to calculate which offense might be charged. It asks one practical question: could this substance or combination reduce the mental or physical functions needed to drive? If yes or uncertain, the vehicle does not move under that person’s control.</p><p>Write the plan as an action rather than a hope. “I probably will not drive” is weak. “My keys remain with the sober host, my prepaid ride is scheduled, and my backup is an overnight stay” identifies actual barriers between impairment and vehicle operation.</p></section>';
			$expansions['adult_en_028'].='<section class="gb-duration-reinforcement"><h3>Trace impairment through a complete driving event</h3><p>At first, the driver must notice a pedestrian near the curb while monitoring a changing signal. Next, the driver must estimate whether the pedestrian may enter, control speed, stay in lane, cover the brake, and communicate with following traffic. Alcohol or another drug does not need to eliminate every ability to create danger. A small delay in detection can remove the time needed for every later step.</p><p>Consider a freeway lane change. The driver searches mirrors, checks the blind area, judges closing speed, signals, maintains lane and speed, predicts another driver’s action, moves smoothly, and reestablishes space. Impaired divided attention can cause the driver to omit one step while believing the maneuver was complete.</p><p>Impairment can also change emotional control. Frustration may become aggression, caution may become impulsiveness, and ordinary feedback from a passenger may be rejected. These changes matter because safe driving depends on accepting new information and correcting a decision before the vehicle enters a conflict. Repetition does not make the impaired sequence safe; it can instead make the driver less likely to notice accumulating errors or accept help every time.</p><h3>Observation exercise</h3><ol><li>List the mental tasks required to turn left across approaching traffic.</li><li>List the physical tasks required to brake and steer around an unexpected obstruction.</li><li>Explain how confidence can increase while actual performance decreases.</li><li>Explain why an officer, court, or crash investigator does not have to accept the driver’s personal feeling of sobriety.</li></ol><details><summary>Compare your explanation</summary><p>A complete response connects perception, judgment, timing, coordination, and control. It recognizes that loss of any normal faculty can affect several steps of the driving process before the driver recognizes the loss.</p></details></section>';
			$expansions['adult_en_029'].='<section class="gb-duration-reinforcement"><h3>Create a no-drive decision record</h3><p>Before taking a new medicine, record the product, dose time, warning language, prescriber or pharmacist guidance, and planned transportation. This is not a medical diagnosis; it is a driving-safety checklist. If the guidance is unclear, the safe decision is not to drive until it is clarified.</p><p>Watch for delayed effects. A product taken at night may affect morning alertness. A long trip can reveal drowsiness that was not obvious while sitting. Heat, dehydration, illness, missed meals, and sleep loss may worsen dizziness or fatigue. If warning signs appear after a trip begins, leave the travel lane safely, stop in an appropriate place, and arrange another driver or transportation.</p><p>Never use another drug to cancel an unwanted effect. A stimulant does not make a sedated driver reliably safe, and a sedative does not safely correct stimulant agitation. Adding substances makes effects and interactions harder to predict. The safe response is to stop driving and obtain appropriate professional help.</p><h3>Combination analysis</h3><ol><li><strong>Prescription plus alcohol:</strong> the label and professional guidance control; never assume a small amount is harmless.</li><li><strong>Two over-the-counter products:</strong> check for duplicate or interacting ingredients and driving warnings.</li><li><strong>Cannabis plus alcohol:</strong> combined effects can make self-assessment even less reliable.</li><li><strong>Stimulant plus severe fatigue:</strong> feeling temporarily awake does not restore sleep or guarantee stable attention.</li></ol><details><summary>Apply the rule</summary><p>If a student cannot confidently explain why the substance, dose, timing, and combination permit safe vehicle operation, the student must use another transportation method and consult a qualified professional.</p></details></section>';
			$expansions['adult_en_030'].='<section class="gb-duration-reinforcement"><h3>Criminal and administrative processes are not interchangeable</h3><p>A criminal court determines criminal allegations under the applicable burden and procedures. DPS administers licensing actions under separate transportation statutes. A student must not conclude that keeping a temporary driving document means the criminal allegation disappeared, or that a criminal disposition automatically cancelled an administrative suspension. Read every notice, observe every deadline, and use qualified legal counsel for an individual case.</p><h3>Consequences extend beyond the judgment</h3><p>A conviction or suspension can affect transportation to work or school, insurance availability and price, rental eligibility, professional credentials, family responsibilities, and future offense enhancement. A crash can add restitution, civil claims, permanent injury, grief, and lost income. These are not scare tactics; they explain why the POI requires legal knowledge to be applied before substance use and driving intersect. Prevention avoids every branch of this consequence chain.</p><details><summary>Process check</summary><p>After an arrest, the driver receives paperwork describing a license action. The correct response is to read it immediately and follow the stated process. Waiting for the criminal court date may cause a separate administrative deadline to pass.</p></details></section>';
			$expansions['adult_en_031'].='<section class="gb-duration-reinforcement"><h3>After the immediate danger</h3><p>Follow-up can prevent the next event. Arrange lawful vehicle retrieval, check that every passenger reached safety, and discuss the failed plan when everyone is sober. Replace weak steps: add another contact, budget for transportation, choose lodging earlier, or require keys to remain with a sober host. If substance use repeatedly defeats safety plans, encourage qualified medical, counseling, or recovery support rather than relying on repeated promises.</p><p>Do not post photographs, accusations, or personal medical information. The intervention goal is safety. Preserve factual information only when it is needed for emergency responders, law enforcement, insurance, or another legitimate process.</p></section>';
			$updated=0;
			foreach($expansions as $key=>$html){
				$lesson_id=absint($wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_gb_blueprint_key' AND meta_value=%s LIMIT 1",$key)));
				if(!$lesson_id||'lp_lesson'!==get_post_type($lesson_id)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Required Topic 4.1.6 lesson is unavailable: '.$key,'time'=>current_time('mysql',true)),false);return;}
				$content=(string)get_post_field('post_content',$lesson_id); $pattern='/<!-- gb-duration-hardening-2\\.3\\.1:'.preg_quote($key,'/').' -->.*?<!-- \/gb-duration-hardening-2\\.3\\.1 -->/s'; $content=preg_replace($pattern,'',$content);
				$result=wp_update_post(array('ID'=>$lesson_id,'post_content'=>trim($content).'<!-- gb-duration-hardening-2.3.1:'.$key.' -->'.$html.'<!-- /gb-duration-hardening-2.3.1 -->'),true);
				if(is_wp_error($result)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.6 duration hardening failed for '.$key.': '.$result->get_error_message(),'time'=>current_time('mysql',true)),false);return;}
				update_post_meta($lesson_id,'_gb_content_status','duration_hardening_2_3_1_dev'); $updated++;
			}
			$lesson_ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT si.item_id FROM {$wpdb->learnpress_section_items} si INNER JOIN {$wpdb->learnpress_sections} s ON s.section_id=si.section_id WHERE s.section_course_id=%d AND si.item_type='lp_lesson' ORDER BY si.item_id ASC",$course_id)); $lesson_count=count((array)$lesson_ids); $minute_total=0;
			foreach((array)$lesson_ids as $regulated_lesson_id)$minute_total+=absint(get_post_meta(absint($regulated_lesson_id),'_gb_required_minutes',true));
			if(46!==$lesson_count||330!==$minute_total){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Core 2.3.1 refused to finalize because the Adult English instructional ledger is '.$lesson_count.'/46 lessons and '.$minute_total.'/330 minutes.','time'=>current_time('mysql',true)),false);return;}
			$this->refresh_learnpress_course_cache($course_id); update_option('gb_curriculum_migration_version','2.3.1',false); update_option('gb_curriculum_migration_status',array('status'=>'success','message'=>'Core 2.3.1 expanded all five Topic 4.1.6 lessons for strict instructional-duration review without changing any timer. Adult English remains 46/46 lessons and 330/330 minutes.','time'=>current_time('mysql',true)),false);
		}

		// Topic 4.1.9 strict duration hardening. The include is Gulf Breeze-owned
		// curriculum source and is never executed outside WordPress.
		if($target_version==='2.3.2'&&version_compare((string)get_option('gb_curriculum_migration_version',''),'2.3.2','<')){
			$registry=get_option(self::COURSE_OPTION,array()); $course_id=absint($registry['adult_en']['learnpress_course_id']??0); global $wpdb;
			$source=plugin_dir_path(__FILE__).'includes/adult-topic-nine-hardening.php';
			if(!$course_id||!is_readable($source)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Adult English course or Gulf Breeze Topic 4.1.9 hardening source is unavailable.','time'=>current_time('mysql',true)),false);return;}
			$expansions=require $source;
			if(!is_array($expansions)||3!==count($expansions)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.9 hardening source must contain exactly three lesson expansions.','time'=>current_time('mysql',true)),false);return;}
			$asset_url=plugin_dir_url(__FILE__).'assets/signs/'; $updated=0;
			foreach($expansions as $key=>$html){
				$lesson_id=absint($wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_gb_blueprint_key' AND meta_value=%s LIMIT 1",$key)));
				if(!$lesson_id||'lp_lesson'!==get_post_type($lesson_id)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Required Topic 4.1.9 lesson is unavailable: '.$key,'time'=>current_time('mysql',true)),false);return;}
				$html=str_replace('{{asset_url}}',esc_url($asset_url),$html); $content=(string)get_post_field('post_content',$lesson_id); $pattern='/<!-- gb-duration-hardening-2\\.3\\.2:'.preg_quote($key,'/').' -->.*?<!-- \/gb-duration-hardening-2\\.3\\.2 -->/s'; $content=preg_replace($pattern,'',$content);
				$content=trim($content).'<!-- gb-duration-hardening-2.3.2:'.$key.' -->'.$html.'<!-- /gb-duration-hardening-2.3.2 -->';
				$plain=wp_strip_all_tags($content); preg_match_all("/\\b[\\p{L}\\p{N}][\\p{L}\\p{N}’'-]*\\b/u",$plain,$word_matches); $word_count=count($word_matches[0]); $minutes=absint(get_post_meta($lesson_id,'_gb_required_minutes',true));
				if(!$minutes||$word_count<($minutes*120)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.9 strict duration screen failed for '.$key.': '.$word_count.' readable words for '.$minutes.' assigned minutes.','time'=>current_time('mysql',true)),false);return;}
				if('adult_en_044'===$key&&substr_count($content,'<img ')<10){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Highway Sign Review must contain at least ten instructional sign graphics.','time'=>current_time('mysql',true)),false);return;}
				$result=wp_update_post(array('ID'=>$lesson_id,'post_content'=>$content),true); if(is_wp_error($result)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.9 duration hardening failed for '.$key.': '.$result->get_error_message(),'time'=>current_time('mysql',true)),false);return;}
				update_post_meta($lesson_id,'_gb_content_status','duration_hardening_2_3_2_dev'); update_post_meta($lesson_id,'_gb_duration_audit_words',$word_count); $updated++;
			}
			$lesson_ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT si.item_id FROM {$wpdb->learnpress_section_items} si INNER JOIN {$wpdb->learnpress_sections} s ON s.section_id=si.section_id WHERE s.section_course_id=%d AND si.item_type='lp_lesson' ORDER BY si.item_id ASC",$course_id)); $lesson_count=count((array)$lesson_ids); $minute_total=0;
			foreach((array)$lesson_ids as $regulated_lesson_id)$minute_total+=absint(get_post_meta(absint($regulated_lesson_id),'_gb_required_minutes',true));
			if(46!==$lesson_count||330!==$minute_total){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Core 2.3.2 refused to finalize because the Adult English instructional ledger is '.$lesson_count.'/46 lessons and '.$minute_total.'/330 minutes.','time'=>current_time('mysql',true)),false);return;}
			$this->refresh_learnpress_course_cache($course_id); update_option('gb_curriculum_migration_version','2.3.2',false); update_option('gb_curriculum_migration_status',array('status'=>'success','message'=>'Core 2.3.2 rebuilt all three Topic 4.1.9 instructional-review lessons and verified each at 120 or more readable words per assigned minute. Adult English remains 46/46 lessons and 330/330 minutes; the separately controlled final assessment remains zero seat time.','time'=>current_time('mysql',true)),false);
		}

		// Topic 4.1.7 non-video duration hardening. The CSEA video remains subject
		// to the separate playback-enforcement release blocker.
		if($target_version==='2.3.3'&&version_compare((string)get_option('gb_curriculum_migration_version',''),'2.3.3','<')){
			$registry=get_option(self::COURSE_OPTION,array()); $course_id=absint($registry['adult_en']['learnpress_course_id']??0); global $wpdb;
			$source=plugin_dir_path(__FILE__).'includes/adult-topic-seven-hardening.php';
			if(!$course_id||!is_readable($source)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Adult English course or Gulf Breeze Topic 4.1.7 hardening source is unavailable.','time'=>current_time('mysql',true)),false);return;}
			$expansions=require $source;
			if(!is_array($expansions)||5!==count($expansions)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.7 hardening source must contain exactly five lesson expansions.','time'=>current_time('mysql',true)),false);return;}
			foreach($expansions as $key=>$html){
				$lesson_id=absint($wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_gb_blueprint_key' AND meta_value=%s LIMIT 1",$key)));
				if(!$lesson_id||'lp_lesson'!==get_post_type($lesson_id)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Required Topic 4.1.7 lesson is unavailable: '.$key,'time'=>current_time('mysql',true)),false);return;}
				$content=(string)get_post_field('post_content',$lesson_id); $pattern='/<!-- gb-duration-hardening-2\\.3\\.3:'.preg_quote($key,'/').' -->.*?<!-- \/gb-duration-hardening-2\\.3\\.3 -->/s'; $content=preg_replace($pattern,'',$content);
				$content=trim($content).'<!-- gb-duration-hardening-2.3.3:'.$key.' -->'.$html.'<!-- /gb-duration-hardening-2.3.3 -->';
				$plain=wp_strip_all_tags($content); preg_match_all("/\\b[\\p{L}\\p{N}][\\p{L}\\p{N}’'-]*\\b/u",$plain,$word_matches); $word_count=count($word_matches[0]); $minutes=absint(get_post_meta($lesson_id,'_gb_required_minutes',true));
				if(!$minutes||$word_count<($minutes*120)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.7 strict duration screen failed for '.$key.': '.$word_count.' readable words for '.$minutes.' assigned minutes.','time'=>current_time('mysql',true)),false);return;}
				$result=wp_update_post(array('ID'=>$lesson_id,'post_content'=>$content),true); if(is_wp_error($result)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.7 duration hardening failed for '.$key.': '.$result->get_error_message(),'time'=>current_time('mysql',true)),false);return;}
				update_post_meta($lesson_id,'_gb_content_status','duration_hardening_2_3_3_dev'); update_post_meta($lesson_id,'_gb_duration_audit_words',$word_count);
			}
			$lesson_ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT si.item_id FROM {$wpdb->learnpress_section_items} si INNER JOIN {$wpdb->learnpress_sections} s ON s.section_id=si.section_id WHERE s.section_course_id=%d AND si.item_type='lp_lesson' ORDER BY si.item_id ASC",$course_id)); $lesson_count=count((array)$lesson_ids); $minute_total=0;
			foreach((array)$lesson_ids as $regulated_lesson_id)$minute_total+=absint(get_post_meta(absint($regulated_lesson_id),'_gb_required_minutes',true));
			if(46!==$lesson_count||330!==$minute_total){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Core 2.3.3 refused to finalize because the Adult English instructional ledger is '.$lesson_count.'/46 lessons and '.$minute_total.'/330 minutes.','time'=>current_time('mysql',true)),false);return;}
			$this->refresh_learnpress_course_cache($course_id); update_option('gb_curriculum_migration_version','2.3.3',false); update_option('gb_curriculum_migration_status',array('status'=>'success','message'=>'Core 2.3.3 expanded all five non-video Topic 4.1.7 lessons and verified each at 120 or more readable words per assigned minute. Adult English remains 46/46 lessons and 330/330 minutes. CSEA playback enforcement remains a separate release requirement.','time'=>current_time('mysql',true)),false);
		}

		// Topic 4.1.8 non-video duration hardening. Water Safety playback remains
		// governed by the separately tested playback-evidence gate.
		if($target_version==='2.3.4'&&version_compare((string)get_option('gb_curriculum_migration_version',''),'2.3.4','<')){
			$registry=get_option(self::COURSE_OPTION,array()); $course_id=absint($registry['adult_en']['learnpress_course_id']??0); global $wpdb;
			$source=plugin_dir_path(__FILE__).'includes/adult-topic-eight-hardening.php';
			if(!$course_id||!is_readable($source)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Adult English course or Gulf Breeze Topic 4.1.8 hardening source is unavailable.','time'=>current_time('mysql',true)),false);return;}
			$expansions=require $source;
			$expansions['adult_en_038'].='<section class="gb-duration-reinforcement"><h3>Margin worksheet</h3><p>Write one preventive action for each category before departure and one adjustment if conditions worsen. A plan is credible only when it names the trigger that causes change. “Be careful” is not measurable; “leave the freeway when visibility no longer supports a safe stopping path” is.</p><p>Continue the inventory during the trip. A warning light, building rain, new fatigue, unexpected congestion, or rising anger changes the calculation. Reduce exposure early instead of waiting until every escape option disappears.</p></section>';
			$expansions['adult_en_039'].='<section class="gb-duration-reinforcement"><h3>Attention self-audit</h3><p>At regular points ask: Where are my eyes? What are my hands doing? What am I thinking about? What changed ahead, beside, or behind? If the answer reveals a cabin task or wandering thought, restore the search immediately and increase space while attention recovers.</p><p>Plan breaks before fatigue appears. Monotony, overnight schedules, illness, medication warnings, and inadequate prior sleep justify shorter driving intervals. A passenger who notices drifting, missed exits, or delayed responses should speak clearly, and the driver should accept the warning without treating it as a challenge.</p><p>Separate a true emergency from ordinary urgency. An emergency may require a lawful safe stop and a 911 call. A message, schedule change, missed turn, food request, or argument does not justify taking attention from vehicle control. Build a routine that makes the safe response automatic before pressure begins. Before restarting, finish the task, secure the device or item, restore mirrors and seating, review traffic, signal, and reenter only with a safe gap.</p></section>';
			$expansions['adult_en_040'].='<section class="gb-duration-reinforcement"><h3>Preparation and recovery space</h3><p>Review weather along the entire route, not just at departure. Carry equipment appropriate to the season and location, maintain communication, and preserve extra fuel or charge when detours, idling, cold, or heat may increase consumption.</p><p>When conditions deteriorate, avoid driving beside large vehicles in wind or spray, beside barriers on slick pavement, or inside another driver’s blind area. Increase the interval early so braking remains smooth. If every path is occupied, reduce exposure instead of continuing at a speed that assumes perfect behavior from others.</p><p>After an emergency maneuver, do not immediately accelerate away. Stabilize the vehicle, check mirrors and warning indicators, assess damage or tire condition, and stop at a protected location when inspection is needed. A successful first recovery can still become a second crash if the driver ignores a damaged tire, overheated brake, debris, traffic behind, or emotional shock.</p><p>When stopping because visibility is poor, choose a location completely outside the travel path when possible. Keep warning devices appropriate to the situation, remain belted when exposure makes exiting dangerous, and avoid creating a new obstruction that approaching drivers cannot see.</p></section>';
			$expansions['adult_en_041'].='<section class="gb-duration-reinforcement"><h3>Emotional-control reset</h3><p>Notice a tight grip, rapid breathing, fixation on one driver, hostile self-talk, or an urge to “teach a lesson.” Ease off, increase space, end eye contact, and return attention to the whole scene. If control does not return, leave the roadway safely and pause. Calling someone while still driving is not the reset.</p><p>Passengers should not encourage racing, record a confrontation, or pressure retaliation. A responsible passenger supports distance, navigation to safety, and an emergency call when needed. The goal is to end exposure without a crash, crime, or escalation.</p><p>Review the consequence chain from the viewpoint of an uninvolved road user. A racing or aggressive driver does not control who enters the next intersection, who is concealed beyond a curve, or who is injured by a loss of control. Refusing the challenge protects people who never agreed to share the risk.</p></section>';
			if(!is_array($expansions)||5!==count($expansions)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.8 hardening source must contain exactly five lesson expansions.','time'=>current_time('mysql',true)),false);return;}
			foreach($expansions as $key=>$html){
				$lesson_id=absint($wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_gb_blueprint_key' AND meta_value=%s LIMIT 1",$key)));
				if(!$lesson_id||'lp_lesson'!==get_post_type($lesson_id)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Required Topic 4.1.8 lesson is unavailable: '.$key,'time'=>current_time('mysql',true)),false);return;}
				$content=(string)get_post_field('post_content',$lesson_id); $pattern='/<!-- gb-duration-hardening-2\\.3\\.4:'.preg_quote($key,'/').' -->.*?<!-- \/gb-duration-hardening-2\\.3\\.4 -->/s'; $content=preg_replace($pattern,'',$content);
				$content=trim($content).'<!-- gb-duration-hardening-2.3.4:'.$key.' -->'.$html.'<!-- /gb-duration-hardening-2.3.4 -->';
				$plain=wp_strip_all_tags($content); preg_match_all("/\\b[\\p{L}\\p{N}][\\p{L}\\p{N}’'-]*\\b/u",$plain,$word_matches); $word_count=count($word_matches[0]); $minutes=absint(get_post_meta($lesson_id,'_gb_required_minutes',true));
				if(!$minutes||$word_count<($minutes*120)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.8 strict duration screen failed for '.$key.': '.$word_count.' readable words for '.$minutes.' assigned minutes.','time'=>current_time('mysql',true)),false);return;}
				$result=wp_update_post(array('ID'=>$lesson_id,'post_content'=>$content),true); if(is_wp_error($result)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.8 duration hardening failed for '.$key.': '.$result->get_error_message(),'time'=>current_time('mysql',true)),false);return;}
				update_post_meta($lesson_id,'_gb_content_status','duration_hardening_2_3_4_dev'); update_post_meta($lesson_id,'_gb_duration_audit_words',$word_count);
			}
			$lesson_ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT si.item_id FROM {$wpdb->learnpress_section_items} si INNER JOIN {$wpdb->learnpress_sections} s ON s.section_id=si.section_id WHERE s.section_course_id=%d AND si.item_type='lp_lesson' ORDER BY si.item_id ASC",$course_id)); $lesson_count=count((array)$lesson_ids); $minute_total=0;
			foreach((array)$lesson_ids as $regulated_lesson_id)$minute_total+=absint(get_post_meta(absint($regulated_lesson_id),'_gb_required_minutes',true));
			if(46!==$lesson_count||330!==$minute_total){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Core 2.3.4 refused to finalize because the Adult English instructional ledger is '.$lesson_count.'/46 lessons and '.$minute_total.'/330 minutes.','time'=>current_time('mysql',true)),false);return;}
			$this->refresh_learnpress_course_cache($course_id); update_option('gb_curriculum_migration_version','2.3.4',false); update_option('gb_curriculum_migration_status',array('status'=>'success','message'=>'Core 2.3.4 expanded all five non-video Topic 4.1.8 lessons and verified each at 120 or more readable words per assigned minute. Adult English remains 46/46 lessons and 330/330 minutes.','time'=>current_time('mysql',true)),false);
		}

		// Topic 4.1.5 duration hardening: core vehicle-control and roadway-use lessons.
		if($target_version==='2.3.5'&&version_compare((string)get_option('gb_curriculum_migration_version',''),'2.3.5','<')){
			$registry=get_option(self::COURSE_OPTION,array()); $course_id=absint($registry['adult_en']['learnpress_course_id']??0); global $wpdb;
			$source=plugin_dir_path(__FILE__).'includes/adult-topic-five-hardening.php';
			if(!$course_id||!is_readable($source)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Adult English course or Gulf Breeze Topic 4.1.5 hardening source is unavailable.','time'=>current_time('mysql',true)),false);return;}
			$expansions=require $source;
			if(!is_array($expansions)||5!==count($expansions)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.5 hardening source must contain exactly five lesson expansions.','time'=>current_time('mysql',true)),false);return;}
			foreach($expansions as $key=>$html){
				$lesson_id=absint($wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_gb_blueprint_key' AND meta_value=%s LIMIT 1",$key)));
				if(!$lesson_id||'lp_lesson'!==get_post_type($lesson_id)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Required Topic 4.1.5 lesson is unavailable: '.$key,'time'=>current_time('mysql',true)),false);return;}
				$content=(string)get_post_field('post_content',$lesson_id); $pattern='/<!-- gb-duration-hardening-2\\.3\\.5:'.preg_quote($key,'/').' -->.*?<!-- \/gb-duration-hardening-2\\.3\\.5 -->/s'; $content=preg_replace($pattern,'',$content);
				$content=trim($content).'<!-- gb-duration-hardening-2.3.5:'.$key.' -->'.$html.'<!-- /gb-duration-hardening-2.3.5 -->';
				$plain=wp_strip_all_tags($content); preg_match_all("/\\b[\\p{L}\\p{N}][\\p{L}\\p{N}’'-]*\\b/u",$plain,$word_matches); $word_count=count($word_matches[0]); $minutes=absint(get_post_meta($lesson_id,'_gb_required_minutes',true));
				if(!$minutes||$word_count<($minutes*120)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.5 strict duration screen failed for '.$key.': '.$word_count.' readable words for '.$minutes.' assigned minutes.','time'=>current_time('mysql',true)),false);return;}
				$result=wp_update_post(array('ID'=>$lesson_id,'post_content'=>$content),true); if(is_wp_error($result)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.5 duration hardening failed for '.$key.': '.$result->get_error_message(),'time'=>current_time('mysql',true)),false);return;}
				update_post_meta($lesson_id,'_gb_content_status','duration_hardening_2_3_5_dev'); update_post_meta($lesson_id,'_gb_duration_audit_words',$word_count);
			}
			$lesson_ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT si.item_id FROM {$wpdb->learnpress_section_items} si INNER JOIN {$wpdb->learnpress_sections} s ON s.section_id=si.section_id WHERE s.section_course_id=%d AND si.item_type='lp_lesson' ORDER BY si.item_id ASC",$course_id)); $lesson_count=count((array)$lesson_ids); $minute_total=0;
			foreach((array)$lesson_ids as $regulated_lesson_id)$minute_total+=absint(get_post_meta(absint($regulated_lesson_id),'_gb_required_minutes',true));
			if(46!==$lesson_count||330!==$minute_total){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Core 2.3.5 refused to finalize because the Adult English instructional ledger is '.$lesson_count.'/46 lessons and '.$minute_total.'/330 minutes.','time'=>current_time('mysql',true)),false);return;}
			$this->refresh_learnpress_course_cache($course_id); update_option('gb_curriculum_migration_version','2.3.5',false); update_option('gb_curriculum_migration_status',array('status'=>'success','message'=>'Core 2.3.5 expanded all five Topic 4.1.5 lessons and verified each at 120 or more readable words per assigned minute. Adult English remains 46/46 lessons and 330/330 minutes.','time'=>current_time('mysql',true)),false);
		}

		// Topic 4.1.4 traffic-control-device duration and visual-observation hardening.
		if($target_version==='2.3.6'&&version_compare((string)get_option('gb_curriculum_migration_version',''),'2.3.6','<')){
			$registry=get_option(self::COURSE_OPTION,array()); $course_id=absint($registry['adult_en']['learnpress_course_id']??0); global $wpdb;
			$source=plugin_dir_path(__FILE__).'includes/adult-topic-four-hardening.php';
			if(!$course_id||!is_readable($source)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Adult English course or Gulf Breeze Topic 4.1.4 hardening source is unavailable.','time'=>current_time('mysql',true)),false);return;}
			$expansions=require $source;
			if(!is_array($expansions)||6!==count($expansions)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.4 hardening source must contain exactly six lesson expansions.','time'=>current_time('mysql',true)),false);return;}
			foreach($expansions as $key=>$html){
				$lesson_id=absint($wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_gb_blueprint_key' AND meta_value=%s LIMIT 1",$key)));
				if(!$lesson_id||'lp_lesson'!==get_post_type($lesson_id)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Required Topic 4.1.4 lesson is unavailable: '.$key,'time'=>current_time('mysql',true)),false);return;}
				$content=(string)get_post_field('post_content',$lesson_id); $pattern='/<!-- gb-duration-hardening-2\\.3\\.6:'.preg_quote($key,'/').' -->.*?<!-- \/gb-duration-hardening-2\\.3\\.6 -->/s'; $content=preg_replace($pattern,'',$content);
				$content=trim($content).'<!-- gb-duration-hardening-2.3.6:'.$key.' -->'.$html.'<!-- /gb-duration-hardening-2.3.6 -->';
				$plain=wp_strip_all_tags($content); preg_match_all("/\\b[\\p{L}\\p{N}][\\p{L}\\p{N}’'-]*\\b/u",$plain,$word_matches); $word_count=count($word_matches[0]); $minutes=absint(get_post_meta($lesson_id,'_gb_required_minutes',true));
				if(!$minutes||$word_count<($minutes*120)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.4 strict duration screen failed for '.$key.': '.$word_count.' readable words for '.$minutes.' assigned minutes.','time'=>current_time('mysql',true)),false);return;}
				if('adult_en_016'!==$key&&false===strpos($content,'gb-sign-gallery')){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.4 visual-observation screen failed because the installed sign gallery is missing from '.$key.'.','time'=>current_time('mysql',true)),false);return;}
				$result=wp_update_post(array('ID'=>$lesson_id,'post_content'=>$content),true); if(is_wp_error($result)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.4 duration hardening failed for '.$key.': '.$result->get_error_message(),'time'=>current_time('mysql',true)),false);return;}
				update_post_meta($lesson_id,'_gb_content_status','duration_hardening_2_3_6_dev'); update_post_meta($lesson_id,'_gb_duration_audit_words',$word_count);
			}
			$lesson_ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT si.item_id FROM {$wpdb->learnpress_section_items} si INNER JOIN {$wpdb->learnpress_sections} s ON s.section_id=si.section_id WHERE s.section_course_id=%d AND si.item_type='lp_lesson' ORDER BY si.item_id ASC",$course_id)); $lesson_count=count((array)$lesson_ids); $minute_total=0;
			foreach((array)$lesson_ids as $regulated_lesson_id)$minute_total+=absint(get_post_meta(absint($regulated_lesson_id),'_gb_required_minutes',true));
			if(46!==$lesson_count||330!==$minute_total){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Core 2.3.6 refused to finalize because the Adult English instructional ledger is '.$lesson_count.'/46 lessons and '.$minute_total.'/330 minutes.','time'=>current_time('mysql',true)),false);return;}
			$this->refresh_learnpress_course_cache($course_id); update_option('gb_curriculum_migration_version','2.3.6',false); update_option('gb_curriculum_migration_status',array('status'=>'success','message'=>'Core 2.3.6 expanded all six Topic 4.1.4 lessons, preserved required sign galleries, and verified each at 120 or more readable words per assigned minute. Adult English remains 46/46 lessons and 330/330 minutes.','time'=>current_time('mysql',true)),false);
		}

		// Topic 4.1.3 right-of-way duration hardening.
		if($target_version==='2.3.7'&&version_compare((string)get_option('gb_curriculum_migration_version',''),'2.3.7','<')){
			$registry=get_option(self::COURSE_OPTION,array()); $course_id=absint($registry['adult_en']['learnpress_course_id']??0); global $wpdb; $source=plugin_dir_path(__FILE__).'includes/adult-topic-three-hardening.php';
			if(!$course_id||!is_readable($source)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Adult English course or Gulf Breeze Topic 4.1.3 hardening source is unavailable.','time'=>current_time('mysql',true)),false);return;}
			$expansions=require $source; if(!is_array($expansions)||6!==count($expansions)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.3 hardening source must contain exactly six lesson expansions.','time'=>current_time('mysql',true)),false);return;}
			foreach($expansions as $key=>$html){
				$lesson_id=absint($wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_gb_blueprint_key' AND meta_value=%s LIMIT 1",$key))); if(!$lesson_id||'lp_lesson'!==get_post_type($lesson_id)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Required Topic 4.1.3 lesson is unavailable: '.$key,'time'=>current_time('mysql',true)),false);return;}
				$content=(string)get_post_field('post_content',$lesson_id); $pattern='/<!-- gb-duration-hardening-2\\.3\\.7:'.preg_quote($key,'/').' -->.*?<!-- \/gb-duration-hardening-2\\.3\\.7 -->/s'; $content=preg_replace($pattern,'',$content); $content=trim($content).'<!-- gb-duration-hardening-2.3.7:'.$key.' -->'.$html.'<!-- /gb-duration-hardening-2.3.7 -->';
				$plain=wp_strip_all_tags($content); preg_match_all("/\\b[\\p{L}\\p{N}][\\p{L}\\p{N}’'-]*\\b/u",$plain,$word_matches); $word_count=count($word_matches[0]); $minutes=absint(get_post_meta($lesson_id,'_gb_required_minutes',true)); if(!$minutes||$word_count<($minutes*120)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.3 strict duration screen failed for '.$key.': '.$word_count.' readable words for '.$minutes.' assigned minutes.','time'=>current_time('mysql',true)),false);return;}
				$result=wp_update_post(array('ID'=>$lesson_id,'post_content'=>$content),true); if(is_wp_error($result)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.3 duration hardening failed for '.$key.': '.$result->get_error_message(),'time'=>current_time('mysql',true)),false);return;} update_post_meta($lesson_id,'_gb_content_status','duration_hardening_2_3_7_dev'); update_post_meta($lesson_id,'_gb_duration_audit_words',$word_count);
			}
			$lesson_ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT si.item_id FROM {$wpdb->learnpress_section_items} si INNER JOIN {$wpdb->learnpress_sections} s ON s.section_id=si.section_id WHERE s.section_course_id=%d AND si.item_type='lp_lesson' ORDER BY si.item_id ASC",$course_id)); $lesson_count=count((array)$lesson_ids); $minute_total=0; foreach((array)$lesson_ids as $regulated_lesson_id)$minute_total+=absint(get_post_meta(absint($regulated_lesson_id),'_gb_required_minutes',true));
			if(46!==$lesson_count||330!==$minute_total){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Core 2.3.7 refused to finalize because the Adult English instructional ledger is '.$lesson_count.'/46 lessons and '.$minute_total.'/330 minutes.','time'=>current_time('mysql',true)),false);return;}
			$this->refresh_learnpress_course_cache($course_id); update_option('gb_curriculum_migration_version','2.3.7',false); update_option('gb_curriculum_migration_status',array('status'=>'success','message'=>'Core 2.3.7 expanded all six Topic 4.1.3 lessons and verified each at 120 or more readable words per assigned minute. Adult English remains 46/46 lessons and 330/330 minutes.','time'=>current_time('mysql',true)),false);
		}

		// Topic 4.1.2 licensing, credential, vehicle-legality, and disability-program duration hardening.
		if($target_version==='2.3.8'&&version_compare((string)get_option('gb_curriculum_migration_version',''),'2.3.8','<')){
			$registry=get_option(self::COURSE_OPTION,array()); $course_id=absint($registry['adult_en']['learnpress_course_id']??0); global $wpdb; $source=plugin_dir_path(__FILE__).'includes/adult-topic-two-hardening.php';
			if(!$course_id||!is_readable($source)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Adult English course or Gulf Breeze Topic 4.1.2 hardening source is unavailable.','time'=>current_time('mysql',true)),false);return;}
			$expansions=require $source; if(!is_array($expansions)||5!==count($expansions)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.2 hardening source must contain exactly five lesson expansions.','time'=>current_time('mysql',true)),false);return;}
			$required_keys=array('adult_en_005','adult_en_006','adult_en_007','adult_en_008','adult_en_009'); if($required_keys!==array_keys($expansions)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.2 hardening source contains an unexpected lesson key or order.','time'=>current_time('mysql',true)),false);return;}
			foreach($expansions as $key=>$html){
				$lesson_id=absint($wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_gb_blueprint_key' AND meta_value=%s LIMIT 1",$key))); if(!$lesson_id||'lp_lesson'!==get_post_type($lesson_id)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Required Topic 4.1.2 lesson is unavailable: '.$key,'time'=>current_time('mysql',true)),false);return;}
				$content=(string)get_post_field('post_content',$lesson_id); $pattern='/<!-- gb-duration-hardening-2\\.3\\.8:'.preg_quote($key,'/').' -->.*?<!-- \/gb-duration-hardening-2\\.3\\.8 -->/s'; $content=preg_replace($pattern,'',$content); $content=trim($content).'<!-- gb-duration-hardening-2.3.8:'.$key.' -->'.$html.'<!-- /gb-duration-hardening-2.3.8 -->';
				$plain=wp_strip_all_tags($content); preg_match_all("/\\b[\\p{L}\\p{N}][\\p{L}\\p{N}’'-]*\\b/u",$plain,$word_matches); $word_count=count($word_matches[0]); $minutes=absint(get_post_meta($lesson_id,'_gb_required_minutes',true)); if(!$minutes||$word_count<($minutes*120)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.2 strict duration screen failed for '.$key.': '.$word_count.' readable words for '.$minutes.' assigned minutes.','time'=>current_time('mysql',true)),false);return;}
				$result=wp_update_post(array('ID'=>$lesson_id,'post_content'=>$content),true); if(is_wp_error($result)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.2 duration hardening failed for '.$key.': '.$result->get_error_message(),'time'=>current_time('mysql',true)),false);return;} update_post_meta($lesson_id,'_gb_content_status','duration_hardening_2_3_8_dev'); update_post_meta($lesson_id,'_gb_duration_audit_words',$word_count);
			}
			$lesson_ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT si.item_id FROM {$wpdb->learnpress_section_items} si INNER JOIN {$wpdb->learnpress_sections} s ON s.section_id=si.section_id WHERE s.section_course_id=%d AND si.item_type='lp_lesson' ORDER BY si.item_id ASC",$course_id)); $lesson_count=count((array)$lesson_ids); $minute_total=0; foreach((array)$lesson_ids as $regulated_lesson_id)$minute_total+=absint(get_post_meta(absint($regulated_lesson_id),'_gb_required_minutes',true));
			if(46!==$lesson_count||330!==$minute_total){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Core 2.3.8 refused to finalize because the Adult English instructional ledger is '.$lesson_count.'/46 lessons and '.$minute_total.'/330 minutes.','time'=>current_time('mysql',true)),false);return;}
			$this->refresh_learnpress_course_cache($course_id); update_option('gb_curriculum_migration_version','2.3.8',false); update_option('gb_curriculum_migration_status',array('status'=>'success','message'=>'Core 2.3.8 expanded all five Topic 4.1.2 lessons and verified each at 120 or more readable words per assigned minute. Adult English remains 46/46 lessons and 330/330 minutes.','time'=>current_time('mysql',true)),false);
		}

		// Topic 4.1.1 course-purpose, online-study, participation-integrity, and reduced-risk hardening.
		if($target_version==='2.3.9'&&version_compare((string)get_option('gb_curriculum_migration_version',''),'2.3.9','<')){
			$registry=get_option(self::COURSE_OPTION,array()); $course_id=absint($registry['adult_en']['learnpress_course_id']??0); global $wpdb; $source=plugin_dir_path(__FILE__).'includes/adult-topic-one-hardening.php';
			if(!$course_id||!is_readable($source)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Adult English course or Gulf Breeze Topic 4.1.1 hardening source is unavailable.','time'=>current_time('mysql',true)),false);return;}
			$expansions=require $source; if(!is_array($expansions)||4!==count($expansions)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.1 hardening source must contain exactly four lesson expansions.','time'=>current_time('mysql',true)),false);return;}
			$required_keys=array('adult_en_001','adult_en_002','adult_en_003','adult_en_004'); if($required_keys!==array_keys($expansions)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.1 hardening source contains an unexpected lesson key or order.','time'=>current_time('mysql',true)),false);return;}
			foreach($expansions as $key=>$html){
				$lesson_id=absint($wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_gb_blueprint_key' AND meta_value=%s LIMIT 1",$key))); if(!$lesson_id||'lp_lesson'!==get_post_type($lesson_id)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Required Topic 4.1.1 lesson is unavailable: '.$key,'time'=>current_time('mysql',true)),false);return;}
				$content=(string)get_post_field('post_content',$lesson_id); $pattern='/<!-- gb-duration-hardening-2\\.3\\.9:'.preg_quote($key,'/').' -->.*?<!-- \/gb-duration-hardening-2\\.3\\.9 -->/s'; $content=preg_replace($pattern,'',$content); $content=trim($content).'<!-- gb-duration-hardening-2.3.9:'.$key.' -->'.$html.'<!-- /gb-duration-hardening-2.3.9 -->';
				$plain=wp_strip_all_tags($content); preg_match_all("/\\b[\\p{L}\\p{N}][\\p{L}\\p{N}’'-]*\\b/u",$plain,$word_matches); $word_count=count($word_matches[0]); $minutes=absint(get_post_meta($lesson_id,'_gb_required_minutes',true)); if(!$minutes||$word_count<($minutes*120)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.1 strict duration screen failed for '.$key.': '.$word_count.' readable words for '.$minutes.' assigned minutes.','time'=>current_time('mysql',true)),false);return;}
				$result=wp_update_post(array('ID'=>$lesson_id,'post_content'=>$content),true); if(is_wp_error($result)){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Topic 4.1.1 hardening failed for '.$key.': '.$result->get_error_message(),'time'=>current_time('mysql',true)),false);return;} update_post_meta($lesson_id,'_gb_content_status','duration_hardening_2_3_9_dev'); update_post_meta($lesson_id,'_gb_duration_audit_words',$word_count);
			}
			$lesson_ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT si.item_id FROM {$wpdb->learnpress_section_items} si INNER JOIN {$wpdb->learnpress_sections} s ON s.section_id=si.section_id WHERE s.section_course_id=%d AND si.item_type='lp_lesson' ORDER BY si.item_id ASC",$course_id)); $lesson_count=count((array)$lesson_ids); $minute_total=0; foreach((array)$lesson_ids as $regulated_lesson_id)$minute_total+=absint(get_post_meta(absint($regulated_lesson_id),'_gb_required_minutes',true));
			if(46!==$lesson_count||330!==$minute_total){update_option('gb_curriculum_migration_status',array('status'=>'error','message'=>'Core 2.3.9 refused to finalize because the Adult English instructional ledger is '.$lesson_count.'/46 lessons and '.$minute_total.'/330 minutes.','time'=>current_time('mysql',true)),false);return;}
			$this->refresh_learnpress_course_cache($course_id); update_option('gb_curriculum_migration_version','2.3.9',false); update_option('gb_curriculum_migration_status',array('status'=>'success','message'=>'Core 2.3.9 expanded all four Topic 4.1.1 lessons and verified each at 120 or more readable words per assigned minute. Adult English remains 46/46 lessons and 330/330 minutes.','time'=>current_time('mysql',true)),false);
		}
		} finally {
			$this->release_migration_lock( $lock_token );
			$this->finish_curriculum_worker( $before_version, $target_version );
		}
	}

	public function sanitize_course_registry( $submitted ) {
		$submitted = is_array( $submitted ) ? $submitted : array();
		$clean = array();
		foreach ( self::course_definitions() as $course_key => $definition ) {
			$row = isset( $submitted[ $course_key ] ) && is_array( $submitted[ $course_key ] ) ? $submitted[ $course_key ] : array();
			$course_id = absint( $row['learnpress_course_id'] ?? 0 );
			if ( $course_id && 'lp_course' !== get_post_type( $course_id ) ) {
				$course_id = 0;
			}
			$clean[ $course_key ] = array(
				'learnpress_course_id' => $course_id,
				'status'               => in_array( $row['status'] ?? '', array( 'planned', 'building', 'internal_testing', 'ready_for_review', 'approved' ), true ) ? $row['status'] : 'planned',
			);
		}
		$tester_ids = preg_split( '/[\\s,]+/', (string) ( $submitted['_internal_tester_user_ids'] ?? '' ), -1, PREG_SPLIT_NO_EMPTY );
		$tester_ids = array_values( array_unique( array_filter( array_map( 'absint', (array) $tester_ids ) ) ) );
		$clean['_internal_tester_user_ids'] = array_values( array_filter( $tester_ids, 'get_userdata' ) );
		$clean['_updated_at'] = current_time( 'mysql', true );
		$clean['_updated_by'] = get_current_user_id();
		return $clean;
	}

	public function create_course_shells() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to create course shells.', 'gulf-breeze-core' ) );
		}
		check_admin_referer( 'gb_create_course_shells' );

		$registry = get_option( self::COURSE_OPTION, array() );
		$created  = 0;
		foreach ( self::course_definitions() as $course_key => $definition ) {
			$row = isset( $registry[ $course_key ] ) && is_array( $registry[ $course_key ] ) ? $registry[ $course_key ] : array();
			$course_id = absint( $row['learnpress_course_id'] ?? 0 );
			if ( $course_id && 'lp_course' === get_post_type( $course_id ) ) {
				continue;
			}
			$existing = get_posts( array(
				'post_type'      => 'lp_course',
				'post_status'    => array( 'draft', 'pending', 'private', 'publish' ),
				'meta_key'       => '_gb_course_key',
				'meta_value'     => $course_key,
				'posts_per_page' => 1,
				'fields'         => 'ids',
			) );
			if ( $existing ) {
				$course_id = absint( $existing[0] );
			} else {
				$course_id = wp_insert_post( array(
					'post_type'   => 'lp_course',
					'post_status' => 'draft',
					'post_title'  => $definition['label'],
				) );
				if ( is_wp_error( $course_id ) || ! $course_id ) {
					continue;
				}
				update_post_meta( $course_id, '_gb_course_key', $course_key );
				$created++;
			}
			$registry[ $course_key ] = array(
				'learnpress_course_id' => absint( $course_id ),
				'status'               => 'building',
			);
		}
		$registry['_updated_at'] = current_time( 'mysql', true );
		$registry['_updated_by'] = get_current_user_id();
		update_option( self::COURSE_OPTION, $registry );

		$url = add_query_arg( array( 'page' => 'gulf-breeze-course-registry', 'gb_created' => $created ), admin_url( 'admin.php' ) );
		wp_safe_redirect( $url );
		exit;
	}

	public function render_course_registry() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$registry = get_option( self::COURSE_OPTION, array() );
		$lp_courses = get_posts( array( 'post_type' => 'lp_course', 'post_status' => array( 'draft', 'pending', 'private', 'publish' ), 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		$statuses = array(
			'planned'          => 'Planned',
			'building'         => 'Building',
			'internal_testing' => 'Internal testing',
			'ready_for_review' => 'Ready for TDLR review',
			'approved'         => 'TDLR approved',
		);
		?>
		<div class="wrap">
			<h1>Gulf Breeze Course Registry</h1>
			<?php if ( isset( $_GET['gb_created'] ) ) : ?>
				<div class="notice notice-success inline"><p><?php echo esc_html( absint( $_GET['gb_created'] ) ); ?> new private draft course shell(s) created and mapped.</p></div>
			<?php endif; ?>
			<p>These four regulatory course identities are fixed. LearnPress mappings and lifecycle status may be changed here without changing their required program type, language, or instructional-time baseline.</p>
			<div class="notice notice-info inline"><p>No registry status makes an approval claim on the public site. Approval identifiers remain blank until entered on the Configuration page.</p></div>
			<form method="post" action="options.php">
				<?php settings_fields( 'gb_course_registry_group' ); ?>
				<h2>Controlled internal testers</h2>
				<p><label for="gb-internal-tester-user-ids"><strong>Approved WordPress user IDs</strong></label></p>
				<p><input class="regular-text" id="gb-internal-tester-user-ids" name="<?php echo esc_attr( self::COURSE_OPTION . '[_internal_tester_user_ids]' ); ?>" value="<?php echo esc_attr( implode( ', ', array_map( 'absint', (array) ( $registry['_internal_tester_user_ids'] ?? array() ) ) ) ); ?>" autocomplete="off"></p>
				<p class="description">Comma-separated user IDs. These users may open only courses, lessons, and quizzes whose registry status is Internal testing. Everyone else continues to receive a 404.</p>
				<table class="widefat striped"><thead><tr><th>Course</th><th>Program</th><th>Language</th><th>Verified time baseline</th><th>LearnPress course</th><th>Internal status</th><th>Approval identifier</th></tr></thead><tbody>
				<?php foreach ( self::course_definitions() as $course_key => $definition ) :
					$row = isset( $registry[ $course_key ] ) && is_array( $registry[ $course_key ] ) ? $registry[ $course_key ] : array();
					$selected_course = absint( $row['learnpress_course_id'] ?? 0 );
					$status = $row['status'] ?? 'planned';
					$approval = self::get( $definition['approval_key'] );
				?>
				<tr>
					<td><strong><?php echo esc_html( $definition['label'] ); ?></strong><br><code><?php echo esc_html( $course_key ); ?></code></td>
					<td><?php echo esc_html( 'parent_taught' === $definition['program'] ? 'Parent-Taught' : 'Adult Six-Hour' ); ?></td>
					<td><?php echo esc_html( $definition['language'] ); ?></td>
					<td><?php echo esc_html( number_format_i18n( $definition['total_minutes'] ) ); ?> total minutes<br><?php echo esc_html( number_format_i18n( $definition['instruction_minutes'] ) ); ?> instruction + <?php echo esc_html( number_format_i18n( $definition['other_minutes'] ) ); ?> additional/break</td>
					<td><select name="<?php echo esc_attr( self::COURSE_OPTION . '[' . $course_key . '][learnpress_course_id]' ); ?>"><option value="0">Not mapped</option><?php foreach ( $lp_courses as $lp_course ) : ?><option value="<?php echo esc_attr( $lp_course->ID ); ?>" <?php selected( $selected_course, $lp_course->ID ); ?>><?php echo esc_html( $lp_course->post_title . ' (#' . $lp_course->ID . ')' ); ?></option><?php endforeach; ?></select></td>
					<td><select name="<?php echo esc_attr( self::COURSE_OPTION . '[' . $course_key . '][status]' ); ?>"><?php foreach ( $statuses as $status_key => $status_label ) : ?><option value="<?php echo esc_attr( $status_key ); ?>" <?php selected( $status, $status_key ); ?>><?php echo esc_html( $status_label ); ?></option><?php endforeach; ?></select></td>
					<td><?php echo '' === $approval ? '<em>Not entered</em>' : esc_html( $approval ); ?></td>
				</tr>
				<?php endforeach; ?>
				</tbody></table>
				<?php submit_button( 'Save Course Registry' ); ?>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="gb_create_course_shells">
				<?php wp_nonce_field( 'gb_create_course_shells' ); ?>
				<?php submit_button( 'Create or Repair Four Draft Course Shells', 'secondary' ); ?>
				<p class="description">Creates only missing LearnPress course shells as drafts, maps them here, and marks them Building. It does not add curriculum, publish courses, or claim approval.</p>
			</form>
		</div>
		<?php
	}

	public function sanitize( $submitted ) {
		$submitted = is_array( $submitted ) ? $submitted : array();
		$current   = get_option( self::OPTION, array() );
		$clean     = array();

		foreach ( self::schema() as $section ) {
			foreach ( $section['fields'] as $key => $field ) {
				if ( ! empty( $field['readonly'] ) ) {
					$clean[ $key ] = isset( $current[ $key ] ) ? $current[ $key ] : ( $field['default'] ?? '' );
					continue;
				}
				$value = $submitted[ $key ] ?? '';
				if ( 'checkbox' === ( $field['type'] ?? '' ) ) {
					$clean[ $key ] = $value ? '1' : '';
				} elseif ( 'email' === ( $field['type'] ?? '' ) ) {
					$clean[ $key ] = sanitize_email( $value );
				} elseif ( 'textarea' === ( $field['type'] ?? '' ) ) {
					$clean[ $key ] = sanitize_textarea_field( $value );
				} else {
					$clean[ $key ] = sanitize_text_field( $value );
				}
				if ( ! empty( $field['maxlength'] ) ) {
					$clean[ $key ] = substr( $clean[ $key ], 0, (int) $field['maxlength'] );
				}
			}
		}

		$clean['timezone']   = 'America/Chicago';
		$clean['_updated_at']= current_time( 'mysql', true );
		$clean['_updated_by']= get_current_user_id();
		return $clean;
	}

	public static function get( $key, $fallback = '' ) {
		$values = get_option( self::OPTION, array() );
		$value  = isset( $values[ $key ] ) ? $values[ $key ] : $fallback;
		return is_scalar( $value ) ? (string) $value : $fallback;
	}

	public static function field_exists( $key ) {
		foreach ( self::schema() as $section ) {
			if ( isset( $section['fields'][ $key ] ) ) {
				return $section['fields'][ $key ];
			}
		}
		return false;
	}

	public function setting_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'key' => '', 'fallback' => '' ), $atts, 'gb_setting' );
		$field = self::field_exists( $atts['key'] );
		if ( ! $field || ! empty( $field['private'] ) ) {
			return '';
		}
		$value = self::get( $atts['key'] );
		// Missing configuration must never leak a token or fabricated placeholder.
		return '' === $value ? esc_html( $atts['fallback'] ) : esc_html( $value );
	}

	private function missing_required() {
		$missing = array();
		foreach ( self::schema() as $section ) {
			foreach ( $section['fields'] as $key => $field ) {
				if ( ! empty( $field['required'] ) && '' === self::get( $key ) ) {
					$missing[] = $field['label'];
				}
			}
		}
		return $missing;
	}

	public function admin_notice() {
		if ( ! current_user_can( 'manage_options' ) || self::PAGE === ( $_GET['page'] ?? '' ) ) {
			return;
		}
		$missing = $this->missing_required();
		if ( $missing ) {
			$url = admin_url( 'admin.php?page=' . self::PAGE );
			echo '<div class="notice notice-warning"><p><strong>Gulf Breeze configuration is incomplete.</strong> Production output will remain blank for missing legal details. <a href="' . esc_url( $url ) . '">Review configuration</a>.</p></div>';
		}
	}

	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$values  = get_option( self::OPTION, array() );
		$missing = $this->missing_required();
		?>
		<div class="wrap">
			<h1>Gulf Breeze Core — Configuration</h1>
			<p>This page is the authoritative source for reusable business, licensing, contact, and policy details. Blank fields remain blank everywhere; the system does not invent or publish placeholders.</p>
			<?php if ( $missing ) : ?>
				<div class="notice notice-warning inline"><p><strong>Required facts still missing:</strong> <?php echo esc_html( implode( ', ', $missing ) ); ?></p></div>
			<?php else : ?>
				<div class="notice notice-success inline"><p>All required identity fields currently have values.</p></div>
			<?php endif; ?>
			<form method="post" action="options.php">
				<?php settings_fields( 'gb_config_group' ); ?>
				<?php foreach ( self::schema() as $section_key => $section ) : ?>
					<h2><?php echo esc_html( $section['label'] ); ?></h2>
					<table class="form-table" role="presentation"><tbody>
					<?php foreach ( $section['fields'] as $key => $field ) :
						$type  = $field['type'] ?? 'text';
						$value = isset( $values[ $key ] ) ? $values[ $key ] : ( $field['default'] ?? '' );
					?>
					<tr>
						<th scope="row"><label for="gb-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['label'] ); ?><?php echo ! empty( $field['required'] ) ? ' *' : ''; ?></label></th>
						<td>
						<?php if ( 'textarea' === $type ) : ?>
							<textarea class="large-text" rows="3" id="gb-<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( self::OPTION . '[' . $key . ']' ); ?>"><?php echo esc_textarea( $value ); ?></textarea>
						<?php elseif ( 'checkbox' === $type ) : ?>
							<input type="checkbox" value="1" id="gb-<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( self::OPTION . '[' . $key . ']' ); ?>" <?php checked( $value, '1' ); ?> />
						<?php else : ?>
							<input class="regular-text" type="<?php echo esc_attr( $type ); ?>" id="gb-<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( self::OPTION . '[' . $key . ']' ); ?>" value="<?php echo esc_attr( $value ); ?>" <?php echo ! empty( $field['readonly'] ) ? 'readonly' : ''; ?> <?php echo ! empty( $field['maxlength'] ) ? 'maxlength="' . esc_attr( $field['maxlength'] ) . '"' : ''; ?> />
						<?php endif; ?>
						<?php if ( ! empty( $field['private'] ) ) : ?><p class="description">Internal only; unavailable through the public shortcode.</p><?php endif; ?>
						</td>
					</tr>
					<?php endforeach; ?>
					</tbody></table>
				<?php endforeach; ?>
				<?php submit_button( 'Save Gulf Breeze Configuration' ); ?>
			</form>
			<hr>
			<h2>Developer use</h2>
			<p><code>Gulf_Breeze_Configuration::get( 'provider_number' )</code> or <code>[gb_setting key="provider_number"]</code>. Private fields are never exposed by shortcode.</p>
		</div>
		<?php
	}
}

register_activation_hook( __FILE__, array( 'Gulf_Breeze_Configuration', 'activate' ) );
Gulf_Breeze_Configuration::instance();

function gb_config_get( $key, $fallback = '' ) {
	return Gulf_Breeze_Configuration::get( $key, $fallback );
}
