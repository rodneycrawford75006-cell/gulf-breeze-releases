# Gulf Breeze Enrollment & Payment 0.2.0-dev-r5

Revision 5 keeps the checkout, agreement, PayPal, paid-account creation, and LearnPress enrollment path that passed the live Sandbox purchase. It fixes the student-access defects found during the complete paid-order test: first-time password creation, WooCommerce email verification, a visible My Courses destination, paid-course labeling, and prevention of direct free enrollment.

Architectural reset based on a proven native WooCommerce checkout boundary.

## Transaction ownership

- WooCommerce owns the cart, checkout form, order creation, PayPal handoff, and confirmation URL.
- PayPal Payments owns button placement and gateway behavior through its settings.
- This plugin renders and validates the bilingual agreement inside classic WooCommerce checkout.
- The plugin assumes payment responsibility by removing the Catalog plugin's known development-stage payment locks after both plugins load; it does not change catalog mappings or cart data.
- The agreement snapshot is written atomically to the WooCommerce order. There is no separate agreement-page redirect, reusable contract cookie, checkout URL filter, cart initialization, or PayPal-location filter.
- Student account creation and LearnPress enrollment occur only after WooCommerce confirms payment.
- Full refunds and payment reversals revoke course access but retain the user and order records, allowing a later repurchase with the same email.

## Student account and email access

- A paid order is linked to the student WordPress/WooCommerce account and LearnPress course after confirmed PayPal payment.
- The administrator new-order email identifies the student separately from the purchaser without pretending that post-payment processing has already finished.
- The purchaser receipt includes the student login email and a signed-agreement copy.
- A newly created student receives one native bilingual WooCommerce new-account email with a prominent, 24-hour, order-bound **Create My Password** button, course information, login location, and signed-agreement copy. No old password is required.
- The button opens WordPress's normal secure password-reset form. Completing that form triggers WooCommerce 11's native email-verification listener, removing the unverified-account order gate without maintaining a second verification flag.
- A returning student receives a course-access notice without silently replacing the password on the existing account.
- A self-purchasing student also receives a **Create my password** button on the native WooCommerce confirmation page. The button requires the valid paid order key and a server-signed request; no old password is required.
- Student login routes to **My Courses**. The WooCommerce account menu and dashboard expose the same destination.
- Each course card shows the actual amount paid, order number, enrollment status, and a **Start/Continue Course** button.
- Existing paid enrollment metadata is read directly, so an enrollment created by revision 4 appears without migration.
- Administrators can use the WooCommerce order action **Resend student course access**. New accounts receive a fresh password-creation button; existing accounts receive sign-in and forgotten-password links without having their password replaced.
- The plugin records which onboarding route WooCommerce requested. Delivery still requires a correctly configured site mailer.
- Duplicate payment callbacks cannot send duplicate onboarding messages.

## Paid LearnPress course boundary

- A Gulf Breeze course mapped to a WooCommerce product no longer displays LearnPress's misleading **Free** label.
- A paid student sees the actual paid amount. A visitor or unpaid account sees a purchase link and the WooCommerce product price.
- LearnPress's free enrollment button is hidden for mapped courses, and the server-side enrollment permission is denied unless the user has an active, non-revoked Gulf Breeze paid order for that course.

## Protected-site test method

Keep Under Construction enabled. Use the already-whitelisted `Gulf Breeze Test Student` only as the protected-site access shell, then enter a completely new student email in checkout. The order is deliberately kept unassigned until verified payment, so the access-shell account does not become the course owner. After payment, the fresh student account is created, the order is linked to it, and the password-creation flow can be tested without pre-creating or whitelisting that student.

## Deliberately deferred

MFA and the remaining three courses are not part of this checkpoint. This revision finishes the first course's beginning-to-end student path before the same pattern is extended.

## Required site configuration before purchase testing

- WooCommerce Checkout page uses `[woocommerce_checkout]`.
- WooCommerce PayPal Payments Sandbox mode is enabled.
- PayPal button locations are limited to Checkout; Cart, Mini Cart, Product, and Express placements are disabled.
- Under Construction remains enabled.
- A dependable WordPress mailer must be configured before email-delivery acceptance testing. The current site default mail transport is not a delivery guarantee.
