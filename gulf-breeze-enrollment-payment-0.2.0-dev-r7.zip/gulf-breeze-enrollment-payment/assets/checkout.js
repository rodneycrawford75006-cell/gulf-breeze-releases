(function () {
	'use strict';
	var checkoutUpdateTimer = null;

	function value(id) {
		var field = document.getElementById(id);
		return field ? field.value.trim() : '';
	}

	function setValue(id, next) {
		var field = document.getElementById(id);
		if (!field) {
			return;
		}
		field.value = next;
		if (window.jQuery && (id === 'billing_state' || id === 'billing_country')) {
			window.jQuery(field).trigger('change.select2');
		}
	}

	function scheduleCheckoutUpdate() {
		if (!window.jQuery) {
			return;
		}
		if (checkoutUpdateTimer) {
			window.clearTimeout(checkoutUpdateTimer);
		}
		checkoutUpdateTimer = window.setTimeout(function () {
			window.jQuery(document.body).trigger('update_checkout');
			checkoutUpdateTimer = null;
		}, 250);
	}

	function splitName(name) {
		var parts = name.trim().split(/\s+/).filter(Boolean);
		return {
			first: parts.shift() || '',
			last: parts.join(' ')
		};
	}

	function copyStudentToBilling() {
		var checkbox = document.getElementById('gb_ep_purchaser_is_student');
		if (!checkbox || !checkbox.checked) {
			return;
		}
		var name = splitName(value('gb_ep_student_name'));
		setValue('billing_first_name', name.first);
		setValue('billing_last_name', name.last);
		setValue('billing_email', value('gb_ep_student_email'));
		setValue('billing_phone', value('gb_ep_student_phone'));
		setValue('billing_address_1', value('gb_ep_student_address_1'));
		setValue('billing_city', value('gb_ep_student_city'));
		setValue('billing_state', value('gb_ep_student_state'));
		setValue('billing_postcode', value('gb_ep_student_postcode'));
		setValue('billing_country', 'US');
		scheduleCheckoutUpdate();
	}

	function updateGuardianVisibility() {
		var dob = value('gb_ep_student_dob');
		var panel = document.getElementById('gb-ep-guardian');
		if (!panel || !/^\d{4}-\d{2}-\d{2}$/.test(dob)) {
			return;
		}
		var birth = new Date(dob + 'T00:00:00Z');
		var now = new Date();
		var age = now.getUTCFullYear() - birth.getUTCFullYear();
		var beforeBirthday = now.getUTCMonth() < birth.getUTCMonth() || (now.getUTCMonth() === birth.getUTCMonth() && now.getUTCDate() < birth.getUTCDate());
		if (beforeBirthday) {
			age -= 1;
		}
		panel.classList.toggle('gb-ep-minor', age < 18);
		panel.classList.toggle('gb-ep-adult', age >= 18);
	}

	document.addEventListener('change', function (event) {
		if (event.target && event.target.id === 'gb_ep_purchaser_is_student') {
			copyStudentToBilling();
		}
		if (event.target && event.target.id === 'gb_ep_student_dob') {
			updateGuardianVisibility();
		}
	});

	document.addEventListener('input', function (event) {
		if (event.target && event.target.id && event.target.id.indexOf('gb_ep_student_') === 0) {
			copyStudentToBilling();
		}
	});

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', function () {
			updateGuardianVisibility();
			copyStudentToBilling();
		});
	} else {
		updateGuardianVisibility();
		copyStudentToBilling();
	}
}());
