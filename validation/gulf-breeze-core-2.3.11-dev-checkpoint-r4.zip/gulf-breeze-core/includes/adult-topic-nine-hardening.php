<?php
/**
 * Adult English Topic 4.1.9 duration-hardening content.
 *
 * Authored for Gulf Breeze Driving School / Rodney Crawford.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'adult_en_044' => <<<'HTML'
<section class="gb-duration-hardening">
<h2>Highway-sign recognition and response workshop</h2>
<p>A sign question is not complete when you name the sign. A prepared driver recognizes the message early, identifies where it applies, predicts the conflict it controls, and makes the lawful response with enough time for other roadway users to understand. Use this workshop to connect shape, color, symbol, wording, placement, and roadway context.</p>
<h3>Recognition hierarchy</h3>
<ol>
<li><strong>Shape:</strong> Certain shapes communicate a category before the wording is readable. An octagon requires a stop. A downward-pointing triangle requires yielding. A round warning identifies a railroad crossing ahead. A pennant marks a no-passing zone. A pentagon identifies a school-related warning. A diamond warns of a condition or hazard.</li>
<li><strong>Color:</strong> Red emphasizes stop or prohibition. Black and white commonly communicate regulation. Yellow warns of general hazards. Orange identifies temporary construction or maintenance conditions. Green guides destinations and routes. Blue identifies motorist services. Brown identifies recreation or cultural interests.</li>
<li><strong>Symbol and words:</strong> Determine the exact prohibition, warning, movement, destination, or service. A symbol may communicate faster than a sentence, but arrows, plaques, distances, times, and lane information modify the message.</li>
<li><strong>Location:</strong> Decide which approach, lane, movement, distance, or zone the control applies to. A sign positioned over a lane may not apply identically to every lane.</li>
<li><strong>Roadway evidence:</strong> Confirm the message with signals, markings, traffic behavior, sight distance, and temporary controls. Never ignore an active flagger or officer because a familiar permanent sign suggests the usual pattern.</li>
</ol>
<h3>Official sign observation set</h3>
<div class="gb-sign-review-grid">
<figure><img src="{{asset_url}}official-2026-r1-1-stop.svg" alt="Red octagonal STOP sign"><figcaption><strong>STOP:</strong> identify the lawful stopping location, search every conflicting path, yield as required, and enter only when the movement can be completed safely.</figcaption></figure>
<figure><img src="{{asset_url}}official-2026-r1-2-yield.svg" alt="Red and white downward-pointing YIELD sign"><figcaption><strong>YIELD:</strong> reduce speed, search, give required time and space, and stop whenever yielding cannot otherwise be completed.</figcaption></figure>
<figure><img src="{{asset_url}}official-2026-r5-1-do-not-enter.svg" alt="Red and white DO NOT ENTER sign"><figcaption><strong>DO NOT ENTER:</strong> do not proceed into the controlled roadway or movement. Reorient lawfully without backing or turning into a new conflict.</figcaption></figure>
<figure><img src="{{asset_url}}official-2026-r5-1a-wrong-way.svg" alt="Red and white WRONG WAY sign"><figcaption><strong>WRONG WAY:</strong> stop safely, recognize possible opposing traffic, and leave the incorrect path without an impulsive maneuver.</figcaption></figure>
<figure><img src="{{asset_url}}official-2026-w2-1-crossroad.svg" alt="Yellow diamond crossroad warning sign"><figcaption><strong>CROSSROAD:</strong> search for entering or crossing traffic and prepare for users who may fail to yield.</figcaption></figure>
<figure><img src="{{asset_url}}official-2026-w4-1-merge.svg" alt="Yellow diamond merge warning sign"><figcaption><strong>MERGE:</strong> create a cooperative gap, check the blind area, and adjust smoothly rather than competing for position.</figcaption></figure>
<figure><img src="{{asset_url}}official-2026-w6-3-two-way-traffic.svg" alt="Yellow diamond two-way traffic warning sign"><figcaption><strong>TWO-WAY TRAFFIC:</strong> expect opposing traffic, maintain lane discipline, and reassess passing opportunities.</figcaption></figure>
<figure><img src="{{asset_url}}official-2026-w8-5-slippery-when-wet.svg" alt="Yellow diamond slippery when wet warning sign"><figcaption><strong>SLIPPERY WHEN WET:</strong> reduce speed before the hazard, increase space, and avoid abrupt steering or braking.</figcaption></figure>
<figure><img src="{{asset_url}}official-2026-w10-1-railroad-ahead.svg" alt="Round yellow railroad crossing ahead warning sign"><figcaption><strong>RAILROAD AHEAD:</strong> slow, look, listen, obey active controls, and never enter unless the vehicle can clear every track.</figcaption></figure>
<figure><img src="{{asset_url}}official-2026-w20-1-road-work.svg" alt="Orange diamond road work warning sign"><figcaption><strong>ROAD WORK:</strong> reduce speed, follow the active temporary path, protect workers, and obey flaggers and temporary controls.</figcaption></figure>
</div>
<h3>Regulatory-sign decisions</h3>
<p>Regulatory signs state a legal requirement or restriction, but obeying the words is only the minimum response. A STOP sign requires a complete stop at the lawful location; it does not promise that another user will stop. A speed-limit sign states a maximum under favorable conditions; it does not require that speed when visibility, traffic, traction, roadway, vehicle, or driver condition makes it unsafe. A ONE WAY sign controls direction; it does not eliminate pedestrians, bicycles, emergency vehicles, or an unlawful opposing driver.</p>
<p>When a movement is prohibited, continue to a lawful alternative. Do not stop in a moving lane to debate the route, make an abrupt turn, enter a private drive without yielding, or use a shoulder as a substitute road. Navigation instructions never override a sign.</p>
<h3>Warning-sign decisions</h3>
<p>A warning sign gives time to prepare. The response must occur before the curve, merge, intersection, grade, surface change, pedestrian area, railroad crossing, or work zone. Waiting until the vehicle enters the hazard wastes the advantage the sign provides. Adjust speed, lane position, search pattern, following interval, and communication early.</p>
<p>Warning signs describe a condition; they do not assign right-of-way by themselves. At a side-road warning, search for entering traffic but apply the actual intersection controls and right-of-way laws. At a pedestrian warning, search sidewalks, shoulders, medians, driveways, and both sides before turning. At a curve warning, choose entry speed before steering demand and limited sight distance increase.</p>
<h3>Signals and lane-use controls</h3>
<p>A steady red signal requires the legally required stop and permits only movements allowed by current law and posted controls. A green signal allows movement only when the path can be cleared and required yielding is complete. A yellow signal warns that the right-of-way is ending; it is not an invitation to accelerate. Flashing red is treated as a stop control. Flashing yellow requires caution and a prepared response.</p>
<p>Lane arrows and lane-control signals apply to the lane they govern. A green arrow does not remove the need to avoid pedestrians or a blocked path. A red X means the lane is closed to travel. A yellow X warns that lane use is ending or changing. Confirm overhead controls with pavement arrows and temporary markings.</p>
<h3>Pavement-marking workshop</h3>
<ul>
<li><strong>Yellow lines:</strong> separate traffic moving in opposite directions or mark the left edge of certain divided roadways. Determine whether crossing or passing is permitted by the full pattern and current law.</li>
<li><strong>White lines:</strong> separate lanes moving in the same direction or mark the right edge. A broken line does not guarantee that a lane change is safe.</li>
<li><strong>Stop lines and crosswalks:</strong> establish where to stop and where vulnerable users may cross. Do not block them while searching for a gap.</li>
<li><strong>Arrows and words:</strong> assign or restrict lane movements. Choose the correct lane early rather than forcing a late merge.</li>
<li><strong>Railroad markings:</strong> reinforce the upcoming crossing. Never queue where the vehicle cannot clear all tracks.</li>
<li><strong>Temporary markings:</strong> active orange devices, revised lines, channelizers, and flagger directions may replace the normal path.</li>
</ul>
<h3>Ten decision scenarios</h3>
<ol>
<li><strong>The light turns green, but traffic fills the far side.</strong> Remain behind the intersection until there is room to clear it.</li>
<li><strong>A STOP sign is partly hidden by vegetation.</strong> The shape and roadway context still warn of the control. Stop lawfully and report the visibility problem when safely parked.</li>
<li><strong>Navigation directs a turn past a DO NOT ENTER sign.</strong> Obey the sign and continue to a lawful alternate route.</li>
<li><strong>A work-zone flagger displays a lawful stop direction while the permanent signal is green.</strong> Obey the flagger controlling the active operation.</li>
<li><strong>A YIELD approach appears empty.</strong> Reduce speed and search every conflict area; stop if required to yield safely.</li>
<li><strong>A merge sign appears while a vehicle occupies the adjacent blind area.</strong> Adjust early and cooperatively. Do not force the merge or assume the other driver will brake.</li>
<li><strong>A railroad warning appears and traffic is stopped beyond the tracks.</strong> Stop before the tracks because the vehicle cannot clear them.</li>
<li><strong>A slippery-surface warning appears during rain.</strong> Reduce speed before the surface, add following space, and make smooth inputs.</li>
<li><strong>A lane arrow conflicts with the intended route.</strong> Follow the lane movement and reroute; do not cut across traffic.</li>
<li><strong>A school warning is present outside the posted active time.</strong> Apply the posted control and continue searching for children; inactive timing does not eliminate the hazard.</li>
</ol>
<details><summary>Final sign-reading checklist</summary><p>For any sign, state: its category; the shape/color clue; exact message; location or lane controlled; conflict or hazard anticipated; lawful response; and the extra reduced-risk action that protects against another user’s mistake.</p></details>
</section>
HTML,

	'adult_en_045' => <<<'HTML'
<section class="gb-duration-hardening">
<h2>Texas traffic-law application workshop</h2>
<p>This lesson reviews traffic law as a decision system. Memorizing a rule is not enough. For each situation, identify the users, controls, legal duties, developing hazards, available time and space, and the response that is both lawful and least likely to produce a collision.</p>
<h3>Intersections and right-of-way</h3>
<p>Right-of-way rules organize movement; they do not authorize a collision. A driver who is entitled to proceed must still search, control speed, and respond to a user who fails to yield. At a stop-controlled intersection, stop at the required location, search left-right-left and across the intended path, identify pedestrians and bicycles, and yield before entering. At an uncontrolled intersection, reduce speed enough to determine who arrived, roadway configuration, surface, lane count, and whether another user is likely to continue.</p>
<p>A left-turning driver yields to approaching traffic close enough to create a hazard. The decision depends on speed, distance, visibility, weather, vehicle acceleration, crossing width, and vulnerable users—not impatience from following traffic. When entering from a private drive, alley, parking area, or other non-public approach, stop or yield as required and protect sidewalk and roadway users.</p>
<h3>Intersection practice</h3>
<ol>
<li><strong>Two vehicles arrive together at an uncontrolled intersection.</strong> Apply the right-of-way rule, communicate cautiously, and do not proceed merely because the other driver hesitates once.</li>
<li><strong>Your signal is green while a pedestrian remains in the crosswalk.</strong> Yield and wait. A signal does not erase the pedestrian conflict.</li>
<li><strong>You are turning left with a limited view around a large vehicle.</strong> Do not borrow the other driver’s judgment. Wait for a view and gap you can verify.</li>
<li><strong>A driver waves you through contrary to a control.</strong> A courtesy wave does not transfer legal responsibility. Follow the control and verify every conflicting path.</li>
<li><strong>The intersection is blocked beyond your green signal.</strong> Stay out until your vehicle can clear the intersection.</li>
</ol>
<h3>Pedestrians, bicycles, and motorcycles</h3>
<p>Search for pedestrians before every turn, not after steering begins. Check sidewalks, medians, shoulders, parking-lot aisles, bus stops, and driveways. People may move slowly, use mobility devices, have limited vision or hearing, or be difficult to see in darkness. Never use the horn or vehicle movement to pressure a person across faster.</p>
<p>Bicycles are vehicles with roadway rights and duties. A bicyclist may move left to avoid hazards, pass, turn, or use a lane that cannot be shared safely. Check mirrors and the blind area before crossing a bicycle lane or opening a door. Motorcycles are entitled to a full lane. Their narrow profile can make speed and distance difficult to judge; look again, allow a larger gap, and give generous following space.</p>
<h3>School buses and emergency vehicles</h3>
<p>Recognize the school-bus signals and roadway configurations covered by current Texas law. Stop when required, remain stopped until the legal conditions to proceed are met, and continue scanning for children who may cross unexpectedly. Do not assume a wide road or painted center lane creates a legal exception; identify whether a qualifying physical division or other statutory condition exists.</p>
<p>For an approaching authorized emergency vehicle using required signals, yield and position as the law directs without entering an intersection, striking a curb, or stopping where the vehicle cannot pass. For covered vehicles stopped on or beside the roadway, apply the current Move Over or Slow Down requirements. Make the lane change only when safe; otherwise reduce speed as required and provide maximum practical clearance.</p>
<h3>Railroad crossings</h3>
<p>A train cannot swerve and requires a long distance to stop. Slow early, obey gates, lights, bells, signs, and lawful directions, and never drive around a lowered gate. Do not rely on one track, one direction, or the departure of one train. Stop when required and enter only when the entire vehicle can clear every track without stopping. If trapped, leave the vehicle, move away from the tracks in the direction from which the train is approaching, and contact emergency services.</p>
<h3>Speed selection</h3>
<p>A posted limit is a maximum for favorable conditions, not a guarantee of safety. Select speed for traffic, visibility, traction, grade, curves, work activity, vehicle condition, cargo, driver condition, and available stopping distance. Reduce speed before the condition. Do not enter a curve, flooded area, fog bank, work zone, or traffic queue at a speed that depends on hard braking after the hazard appears.</p>
<p>Stopping distance includes perception, reaction, and braking. Higher speed increases distance traveled before braking and sharply increases braking distance and crash energy. Add following interval for darkness, rain, large vehicles, motorcycles, limited view, loose surfaces, work zones, fatigue, and a driver following too closely.</p>
<h3>Speed scenarios</h3>
<ol>
<li><strong>The limit is 70 mph in heavy rain.</strong> Reduce speed to maintain control and stopping distance; the posted maximum does not override conditions.</li>
<li><strong>A tailgater pressures you.</strong> Increase space ahead, remain predictable, and allow a lawful pass when safe. Do not brake-check.</li>
<li><strong>Fog limits sight distance.</strong> Slow so the vehicle can stop within the visible path, use appropriate lights, and leave the roadway if safe travel cannot be maintained.</li>
<li><strong>You miss an exit.</strong> Continue to the next lawful route. Do not stop, reverse, cross the gore, or force a late lane change.</li>
</ol>
<h3>Lane position, signaling, and turning</h3>
<p>Choose the correct lane early. Search mirrors, signal before movement, check the blind area, preserve space, and move smoothly. A signal communicates intent; it does not create right-of-way. Cancel it after the movement if necessary. Maintain lane position through a turn and enter the lawful receiving lane unless controls or roadway design require otherwise.</p>
<p>Before backing, inspect the area around and behind the vehicle. Use direct vision as well as mirrors and camera systems. Back slowly and stop when the path becomes uncertain. Technology can miss small children, low objects, cross traffic, or a person entering after the first check.</p>
<h3>Passing and being passed</h3>
<p>Pass only where legal and where the visible distance, speed difference, traffic, grade, curve, intersection, railroad crossing, and roadway markings allow the entire maneuver. Check behind and ahead, signal, leave space, complete the pass without exceeding lawful speed, and return only when safely clear. Never force another user onto a shoulder.</p>
<p>When being passed, remain predictable and do not accelerate to interfere. If a passing driver misjudges, create space rather than defending position. Around bicycles, motorcycles, horses, slow-moving vehicles, and workers, use the clearance and caution required by law and conditions.</p>
<h3>Stopping, standing, parking, and coasting</h3>
<p>Do not stop or park where the vehicle blocks visibility, crosswalks, intersections, sidewalks, driveways, fire access, traffic-control devices, railroad clearance, or other prohibited areas. Secure the vehicle, set the parking brake, choose gear appropriately, turn wheels when needed on a grade, remove the key, and check traffic before opening a door.</p>
<p>Coasting in neutral or with the clutch disengaged reduces control and may be prohibited under applicable law. Maintain an appropriate gear so engine response and controlled acceleration remain available. Never switch off the engine while moving; steering, braking assistance, and safety systems may be affected.</p>
<h3>Vehicle lights</h3>
<p>Use headlights and other required lights at the times and visibility conditions established by current Texas law. Lights help the driver see and help others detect the vehicle. Dim high beams as required and whenever glare would endanger another user. Keep lenses clean, replace failed lamps, and do not rely solely on automatic systems in fog, rain, dusk, or other changing conditions.</p>
<h3>Freeway entry, travel, and exit</h3>
<p>Use the acceleration lane to observe, match a reasonable traffic speed, identify a gap, signal, and merge without forcing another driver to brake sharply. Yield as required while recognizing that freeway drivers should cooperate when safe. Do not stop at the end of an acceleration lane unless necessary. During travel, maintain lane discipline, following space, and an escape option.</p>
<p>Plan the exit early, signal, enter the deceleration lane, and reduce speed after leaving the main flow unless conditions require earlier adjustment. If the exit is missed, continue. At an interchange, expect sudden decisions by others and avoid remaining beside large vehicles.</p>
<h3>Fatigue and highway hypnosis</h3>
<p>Fatigue reduces attention, judgment, vision, reaction, and lane control and can produce microsleep. Highway hypnosis is reduced awareness associated with monotony and fatigue. Warning signs include repeated yawning, heavy eyelids, drifting, speed variation, missing signs, rubbing the eyes, and not remembering recent miles. Open windows, music, conversation, or caffeine do not replace sleep. Leave the roadway safely and rest or change drivers.</p>
<h3>Breakdowns and vehicle emergencies</h3>
<p>At a breakdown, maintain control, signal, leave the travel lane when possible, stop where the vehicle is most visible, activate hazard warning, and decide whether remaining belted inside or moving to another protected location is safer. Call appropriate assistance and do not stand in a travel lane. Warning devices should be placed only when it can be done safely and lawfully.</p>
<p>For a tire failure, hold the steering wheel, avoid abrupt braking, ease off the accelerator, stabilize direction, slow gradually, and leave the roadway when safe. For brake failure, remain calm, use controlled pumping when appropriate to the system, downshift carefully, apply the parking brake progressively if needed, search for an escape path, and warn others. If wheels leave the pavement, ease off power, maintain control, slow, and return only when speed and edge conditions permit a gradual reentry.</p>
<p>In a skid, look and steer toward the intended path while avoiding abrupt inputs. The correct response depends on the vehicle and system; prevention through speed and smooth control is primary. On a steep hill, select a suitable gear before speed builds and avoid overheating brakes.</p>
<h3>Winter and adverse conditions</h3>
<p>Ice, snow, freezing rain, and cold can reduce traction, hide markings, block visibility, and affect batteries, tires, fluids, and bridges. Bridges and shaded areas may freeze before other pavement. Increase space greatly, reduce speed before steering or braking, use smooth inputs, clear every window and required light, and postpone travel when conditions exceed the driver or vehicle’s safe capability.</p>
<p>Never use cruise control where traction is uncertain. If stranded, contact help, conserve fuel safely, keep exhaust outlets clear, and prevent carbon-monoxide exposure. Do not leave a protected vehicle to walk into severe conditions unless remaining creates greater danger.</p>
<h3>Construction and maintenance work zones</h3>
<p>Work zones may narrow lanes, shift traffic, remove shoulders, create drop-offs, place workers near moving vehicles, and require sudden stops. Obey flaggers, temporary signals, signs, channelizers, markings, and covered reduced speeds. Increase following distance, avoid distraction, merge cooperatively, and never drive through a closed area. Violations can cause bodily injury, death, property damage, fines, and other penalties.</p>
<h3>Integrated law scenarios</h3>
<ol>
<li><strong>A bicyclist moves left around debris.</strong> Slow and leave space; do not force a squeeze pass.</li>
<li><strong>A motorcycle approaches before your left turn.</strong> Look again and wait for a clearly safe gap.</li>
<li><strong>A school bus activates required signals.</strong> Identify the roadway and stop when Texas law requires; remain alert for children.</li>
<li><strong>An emergency vehicle approaches while you are inside an intersection.</strong> Clear the intersection safely, then yield and stop as required.</li>
<li><strong>A train has passed but the gate remains down.</strong> Remain stopped; another train or hazard may be present.</li>
<li><strong>Brake warning appears on a downhill grade.</strong> Reduce demand, select a safe path, and stop for inspection; do not continue until control is lost.</li>
<li><strong>A work-zone lane ends.</strong> Merge cooperatively at the directed point and do not use the closed lane to pass the queue.</li>
<li><strong>A passenger asks you to read a message.</strong> Decline and park safely before interacting with the device.</li>
<li><strong>A pet moves into the driver’s lap.</strong> Stop safely and secure the pet before continuing.</li>
<li><strong>Fatigue causes a missed sign.</strong> Treat it as a warning to stop and rest, not as a reason to concentrate harder.</li>
</ol>
<h3>Law-versus-safety comparison</h3>
<p>For every reviewed rule, separate the minimum legal duty from the additional reduced-risk action. A driver may have right-of-way but still cover the brake. A passing zone may be marked but still lack a safe gap. A posted maximum may be legal but too fast for rain. A lane change may be permitted but unsafe beside a truck. This comparison prevents students from treating legal permission as a command to proceed.</p>
<details><summary>Traffic-law mastery checklist</summary><p>Explain, without guessing, the rules and reduced-risk responses for intersections, turns, pedestrians, bicycles, motorcycles, school buses, emergency vehicles, railroad crossings, speed, following distance, signals, lane changes, passing, parking, backing, freeway travel, fatigue, breakdowns, skids, brake failure, tire failure, adverse weather, lights, and work zones.</p></details>
</section>
HTML,

	'adult_en_046' => <<<'HTML'
<section class="gb-duration-hardening">
<h2>Comprehensive licensing-readiness decision lab</h2>
<p>This final instructional lesson integrates the course. It is not the scored final assessment. Use each stage to explain the law, identify risk, choose a response, and justify why another answer would be less lawful or less safe. Mastery means transferring knowledge to a new situation rather than recognizing a memorized sentence.</p>
<h3>Stage 1: Driver and vehicle readiness</h3>
<p>Before movement, confirm that the driver has the required credential and restrictions, is physically and mentally fit, and has no alcohol, drug, fatigue, illness, emotional, vision, or distraction condition that makes driving unsafe. Confirm registration, financial responsibility, inspection or other vehicle requirements applicable to the transaction, operable lights, tires, brakes, mirrors, windows, restraints, and required equipment.</p>
<p>Adjust seat, head restraint, mirrors, steering position, climate, and controls before moving. Secure children in the correct restraint and every occupant with the required belt. Secure pets, cargo, phones, and loose objects. Enter the destination and review the route while parked. Identify weather, road closures, fuel or charging needs, and a safe alternate route.</p>
<h3>Readiness scenarios</h3>
<ol>
<li><strong>A medicine label warns of drowsiness.</strong> Arrange another driver or transportation until safe operation is confirmed.</li>
<li><strong>A tire shows damage before departure.</strong> Correct the condition; a schedule does not justify known equipment risk.</li>
<li><strong>A child’s shoulder belt is behind the back.</strong> Stop and correct the restraint before movement.</li>
<li><strong>The phone mount blocks part of the windshield.</strong> Reposition it lawfully and preserve the field of view.</li>
<li><strong>The driver is angry after an argument.</strong> Delay the trip until attention and judgment are controlled.</li>
</ol>
<h3>Stage 2: Search and communication</h3>
<p>Search far enough ahead to detect changes early, near enough to maintain lane position, to both sides for entering users, behind for closing traffic, and into blind areas before movement. Move the eyes instead of staring at one point. Recheck mirrors regularly and before slowing, turning, changing lanes, or responding to a hazard.</p>
<p>Communicate through lane position, speed, brake lights, turn signals, headlights, horn when reasonably necessary, and predictable movement. A signal states intent; it does not order another user to yield. Avoid mixed messages such as signaling one direction while positioning for another or stopping unexpectedly to give away right-of-way.</p>
<h3>Search scenarios</h3>
<ol>
<li><strong>A parked van blocks the view of a crosswalk.</strong> Reduce speed, cover the brake, and search for a person emerging from behind it.</li>
<li><strong>A large truck blocks the view ahead.</strong> Increase following distance rather than moving closer for a view.</li>
<li><strong>A vehicle remains beside you.</strong> Treat it as occupying the blind area; do not begin a lane change.</li>
<li><strong>A driver signals but does not slow.</strong> Do not rely on the signal alone. Wait for the vehicle’s actual path.</li>
<li><strong>A pedestrian looks toward traffic but has not entered.</strong> Continue searching and prepare to yield; eye direction is not a legal promise.</li>
</ol>
<h3>Stage 3: Space and speed management</h3>
<p>Maintain a following interval that provides perception, decision, and braking time. Add space for darkness, rain, fog, glare, curves, hills, work zones, motorcycles, large vehicles, blocked views, loose surfaces, heavy loads, fatigue, and a driver following too closely. Preserve an escape option whenever possible.</p>
<p>Select speed for the actual situation. The ability to stay below a posted maximum does not prove the speed is safe. Reduce speed before limited sight distance, poor traction, a curve, a queue, a work zone, an intersection, vulnerable users, or an emergency scene. Avoid driving so slowly without cause that traffic flow is unnecessarily impeded.</p>
<h3>Space scenarios</h3>
<ol>
<li><strong>Rain begins after a long dry period.</strong> Slow and increase space because oil and water may reduce traction.</li>
<li><strong>A tailgater follows closely.</strong> Add space ahead and allow a safe pass; never retaliate.</li>
<li><strong>A motorcycle is ahead on a rough surface.</strong> Add room for sudden path changes around hazards.</li>
<li><strong>Traffic crests a hill and stops.</strong> Approach at a speed that permits stopping within the visible path.</li>
<li><strong>A driver cuts into the following gap.</strong> Reestablish space smoothly instead of defending the gap.</li>
</ol>
<h3>Stage 4: Intersections and turns</h3>
<p>Identify controls, stop at the lawful location, search all conflict paths, determine who must yield, and enter only when the vehicle can clear. Before turning, signal, choose the correct lane, reduce speed, search for pedestrians and bicycles, and maintain lawful lane position. Do not let a following driver’s impatience choose the gap.</p>
<p>At traffic circles or roundabouts, reduce speed, select the appropriate lane, yield as controlled to circulating traffic, watch for vulnerable users, and signal the exit when appropriate. At a T-intersection, private drive, alley, or parking-lot exit, identify the terminating approach and yield as required.</p>
<h3>Intersection scenarios</h3>
<ol>
<li><strong>A green signal faces a blocked intersection.</strong> Wait outside until there is room to clear.</li>
<li><strong>A left turn crosses two lanes of approaching traffic.</strong> Accept only a gap that covers the entire movement.</li>
<li><strong>A vehicle to the right arrives at the same time at an uncontrolled intersection.</strong> Apply the right-of-way rule and proceed only after confirming the other driver’s action.</li>
<li><strong>A pedestrian enters late in the signal cycle.</strong> Continue yielding until the path is clear.</li>
<li><strong>An emergency vehicle approaches during your turn.</strong> Complete only the movement necessary to clear the conflict, then yield and stop as required.</li>
</ol>
<h3>Stage 5: Signs, signals, and markings</h3>
<p>Read controls as a system. Shape and color provide early category information; symbols and words give the exact message; placement identifies the lane or approach; markings define the path; and temporary devices or authorized directions may change normal operation. A familiar control does not eliminate the need to search.</p>
<p>When controls appear to conflict, first identify whether a law-enforcement officer, authorized flagger, temporary control, lane-use signal, or emergency operation changes the routine pattern. Do not improvise a path through cones, closed lanes, gates, or opposing traffic.</p>
<h3>Control scenarios</h3>
<ol>
<li><strong>A flagger stops traffic despite a green permanent signal.</strong> Obey the flagger controlling the work operation.</li>
<li><strong>A round yellow sign appears.</strong> Prepare for a railroad crossing, search both directions, and ensure clearance.</li>
<li><strong>A red X appears above your lane.</strong> Leave the lane safely; it is closed to travel.</li>
<li><strong>A warning sign shows a curve.</strong> Choose speed before entering the curve.</li>
<li><strong>A lane arrow permits only a turn you did not plan.</strong> Make the lawful movement and reroute.</li>
</ol>
<h3>Stage 6: Sharing the roadway</h3>
<p>Vulnerable users have less protection and may be harder to detect. Search deliberately for pedestrians, bicyclists, motorcyclists, people with disabilities, roadway workers, children, and horseback riders. Provide lawful right-of-way, clearance, time, and patience. Never use the vehicle to pressure another person.</p>
<p>Large and oversize vehicles require more turning space, stopping distance, and room for off-tracking and wide turns. Avoid lingering in blind areas. Do not cut closely in front after passing. For buses, light rail, slow-moving vehicles, emergency vehicles, and work equipment, anticipate operating limits before attempting to pass or turn.</p>
<h3>Sharing scenarios</h3>
<ol>
<li><strong>A bicyclist leaves the right edge to avoid debris.</strong> Slow and allow the movement.</li>
<li><strong>A truck swings left before a right turn.</strong> Stay back; do not enter the space on the right.</li>
<li><strong>A motorcycle’s signal remains on.</strong> Do not assume the rider will turn. Verify the path.</li>
<li><strong>A horse becomes unsettled.</strong> Reduce speed, avoid sudden noise, and pass only with ample clearance.</li>
<li><strong>A person using a white cane approaches the crossing.</strong> Stop and yield as required, allowing the person to determine the path without pressure.</li>
</ol>
<h3>Stage 7: Freeways and passing</h3>
<p>On freeway entry, use the acceleration lane to search, identify a gap, signal, and merge smoothly. During travel, stay out of blind areas, preserve following space, and monitor interchanges. On exit, plan early, enter the deceleration lane, and reduce speed for the ramp. Continue to the next exit if the intended exit is missed.</p>
<p>Pass only with lawful markings, clear sight distance, adequate speed difference, and enough room to return without forcing another user to brake or leave the lane. Do not pass where curves, hills, intersections, crossings, work zones, or approaching traffic make completion uncertain. Being legally permitted to cross a broken line does not guarantee safety.</p>
<h3>Freeway scenarios</h3>
<ol>
<li><strong>The acceleration lane ends while no safe gap exists.</strong> Continue controlling the vehicle and yield; never force entry.</li>
<li><strong>You remain beside a truck near an interchange.</strong> Adjust to leave the blind area rather than matching speed indefinitely.</li>
<li><strong>You miss the exit.</strong> Continue to the next lawful route.</li>
<li><strong>A passing zone is legal but an oncoming vehicle is visible.</strong> Wait. Legal markings do not replace the required clear distance.</li>
<li><strong>Another driver passes you.</strong> Maintain a predictable speed and create space if needed.</li>
</ol>
<h3>Stage 8: Adverse conditions and emergencies</h3>
<p>At night, reduce speed for sight distance, control glare, use lights correctly, and search for pedestrians, animals, stopped vehicles, and unlit hazards. In rain, fog, ice, snow, wind, dust, or flooding, reduce speed before control is challenged, increase space, and postpone travel when safe operation cannot be maintained. Never drive into water of uncertain depth or movement.</p>
<p>For a tire failure, hold direction, ease off power, slow gradually, and leave the roadway safely. For brake problems, seek a safe path, use the appropriate controlled emergency procedure, warn others, and stop. For a skid, look and steer toward the intended path and avoid abrupt inputs. If the vehicle leaves the pavement, stabilize and slow before a gradual return.</p>
<h3>Emergency scenarios</h3>
<ol>
<li><strong>A tire fails at highway speed.</strong> Hold control, avoid abrupt braking, ease off power, and slow gradually.</li>
<li><strong>Headlights fail at night.</strong> Use available lighting and warnings, slow, and leave the roadway safely.</li>
<li><strong>Water covers the road.</strong> Stop and choose another route; depth, current, pavement condition, and hidden hazards are unknown.</li>
<li><strong>The vehicle begins to skid.</strong> Look toward the intended path, steer smoothly, and avoid panic braking.</li>
<li><strong>A breakdown occurs near moving traffic.</strong> Maximize separation and visibility, call assistance, and avoid standing in a travel lane.</li>
</ol>
<h3>Stage 9: Impairment, fatigue, distraction, and emotion</h3>
<p>Do not drive after alcohol, cannabis, an impairing medicine, or another drug. Texas intoxication includes loss of normal mental or physical faculties and the statutory alcohol-concentration definition. A number is not permission to drive. Read medication warnings, ask a prescriber or pharmacist about driving and combinations, and arrange transportation before use.</p>
<p>Fatigue, illness, pain, anger, grief, anxiety, passengers, pets, navigation, eating, grooming, reading, work, and wireless-device use can remove attention or control. Set the vehicle and route before movement, secure pets, use do-not-disturb features, and park safely before interacting with a device or addressing a passenger need.</p>
<h3>Fitness scenarios</h3>
<ol>
<li><strong>A message feels urgent.</strong> Park safely before reading or responding.</li>
<li><strong>Repeated yawning and missed signs begin.</strong> Leave the roadway and rest; stimulation is not a substitute for sleep.</li>
<li><strong>A passenger pressures the driver to speed.</strong> Maintain the lawful reduced-risk decision.</li>
<li><strong>A prescription is lawful but impairs reaction.</strong> Do not drive.</li>
<li><strong>Road rage develops after being cut off.</strong> Create distance, disengage, and avoid following or confrontation.</li>
</ol>
<h3>Stage 10: Traffic stops, crashes, and public responsibility</h3>
<p>During a traffic stop, signal, pull to a safe location, remain calm, keep hands visible, follow lawful instructions, and explain before reaching. Use the court or agency process to contest a citation or report conduct. The Texas Driving with Disabilities Program provides voluntary communication indicators and disclosures; it does not remove legal duties.</p>
<p>After a crash, stop, protect the scene without creating another collision, aid injured people within ability, call emergency services when required, exchange required information, and comply with reporting duties. Never leave because the damage appears minor. Avoid admissions or arguments at roadside; provide accurate facts through the proper process.</p>
<p>Secure cargo and towing equipment, prevent litter, avoid carbon-monoxide exposure, protect workers, never leave a child unattended in a vehicle, and make an informed voluntary anatomical-gift decision through the official process. Responsible driving includes conduct before, during, and after the vehicle moves.</p>
<h3>Public-responsibility scenarios</h3>
<ol>
<li><strong>An officer initiates a stop where the shoulder is narrow.</strong> Slow, signal, use hazards, and proceed only far enough to a safer reasonable location.</li>
<li><strong>A minor crash blocks a lane.</strong> Stop and follow legal duties while protecting people from a secondary crash.</li>
<li><strong>Loose trash is in a pickup bed.</strong> Secure it before movement.</li>
<li><strong>A child is sleeping in the rear seat during a quick errand.</strong> Take the child with you or maintain responsible direct supervision; never leave the child unattended.</li>
<li><strong>A communication indicator is present.</strong> It can alert an officer to communication needs but does not change traffic law.</li>
</ol>
<h3>Final integrated cases</h3>
<ol>
<li><strong>Rainy-night left turn:</strong> A motorcycle approaches with glare behind it while a pedestrian waits near the crosswalk. Identify the signal, reduce speed, yield to every conflict, and turn only after verifying a safe gap and clear crosswalk.</li>
<li><strong>Work-zone freeway merge:</strong> A lane closes near a truck and traffic is slowing. Obey temporary controls, increase space, avoid the truck’s blind area, merge cooperatively, and prepare to stop.</li>
<li><strong>Fatigued rural trip:</strong> The driver misses a sign, has no rideshare service, and wants to continue to reach lodging. Leave the roadway at the next safe location and rest; lack of convenience does not restore alertness.</li>
<li><strong>Impaired friend:</strong> The person insists on driving a short distance. Use the planned sober ride, involve responsible help, and call emergency services if driving becomes imminent.</li>
<li><strong>Railroad queue:</strong> The gate is up but traffic beyond the tracks is stopped. Remain before the tracks until the vehicle can clear every rail.</li>
</ol>
<h3>Explain your decision</h3>
<p>For each final case, state: the controlling law or rule; the users at risk; the earliest warning; the space or speed adjustment; the communication; the safest lawful action; and the evidence you would need before proceeding. If you cannot explain a step, return to the relevant lesson before beginning the scored assessment.</p>
<details><summary>Comprehensive readiness checklist</summary><p>You are ready to attempt the controlled final only when you can apply licensing responsibility, traffic controls, right-of-way, traffic-flow laws, roadway sharing, impairment prevention, risk management, emergency procedures, traffic-stop duties, and public responsibilities to unfamiliar scenarios without relying on answer-pattern memorization.</p></details>
</section>
HTML,
);
