# Gulf Breeze Enrollment & Payment 0.1.0-dev-r5

Development checkpoint only. This plugin establishes the contract-first bilingual enrollment state machine, PayPal Sandbox-only payment verification, paid-only account/LearnPress enrollment, local QR/manual-key TOTP MFA, refund access revocation, immutable snapshots, idempotent processing, and administrator-only Order Health diagnostics.

It requires Gulf Breeze Core 2.3.26 or newer, Gulf Breeze Catalog & Cart 0.1.4, WooCommerce, WooCommerce PayPal Payments, and LearnPress. It does not disable Under Construction, enable live PayPal, publish courses, issue certificates, or expose administrator diagnostics to students.

Customer flow: catalog selection → student identity → separate purchaser identity → signed bilingual contract → immutable snapshot/hash → PayPal Sandbox wallet/card capture → account create/link → LearnPress enrollment → bilingual MFA → course access.

The QR encoder is bundled locally from the MIT-licensed `qrcode-terminal` QRCode implementation. No MFA secret is sent to a third-party QR service.

Revision 5 preserves WooCommerce's native checkout and order-received URL construction, limits WooCommerce PayPal Payments smart buttons to Classic Checkout for mapped enrollment purchases, invalidates an unused agreement when a new enrollment begins, atomically claims each agreement for one order, and blocks a second paid enrollment while the same student's course access remains active. It retains the classic Checkout migration and fail-closed Store API boundary. The required sequence is a newly signed agreement, one billing/contact entry, PayPal Sandbox approval, and WooCommerce's native order confirmation.
