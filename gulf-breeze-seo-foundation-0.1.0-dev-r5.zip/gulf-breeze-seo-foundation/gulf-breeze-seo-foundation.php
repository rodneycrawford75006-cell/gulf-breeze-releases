<?php
/**
 * Plugin Name: Gulf Breeze SEO Foundation
 * Description: Controlled bilingual metadata, indexing, schema, and public-entity rules for Gulf Breeze Driving School.
 * Version: 0.1.0-dev-r5
 * Author: Gulf Breeze Driving School
 * Text Domain: gulf-breeze-seo-foundation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Gulf_Breeze_SEO_Foundation {
	const VERSION = '0.1.0-dev-r5';
	const ENTITY_NAME = 'Gulf Breeze Driving School';

	/**
	 * Authority-page data is intentionally small and controlled. Each permanent
	 * page can grow without changing its canonical URL or primary search job.
	 */
	private static function authority_pages() {
		return array(
			'texas-adult-drivers-ed-online' => array(
				'language'    => 'en-US',
				'canonical'   => '/texas-adult-drivers-ed-online/',
				'alternate'   => '/es/curso-de-manejo-para-adultos-en-texas/',
				'title'       => 'Texas Adult Drivers Ed Online – 6-Hour Course | Gulf Breeze',
				'description' => 'Review the six-hour online adult driver education path for first-time Texas applicants ages 18–24, including eligibility and next licensing steps.',
				'og_locale'   => 'en_US',
				'alt_locale'  => 'es_US',
				'page_name'   => 'Texas Adult Drivers Ed Online: Six-Hour Course',
			),
			'curso-de-manejo-para-adultos-en-texas' => array(
				'language'    => 'es-US',
				'canonical'   => '/es/curso-de-manejo-para-adultos-en-texas/',
				'alternate'   => '/texas-adult-drivers-ed-online/',
				'title'       => 'Curso de Manejo para Adultos en Texas – 6 Horas | Gulf Breeze',
				'description' => 'Conozca el curso de seis horas para adultos que solicitan por primera vez una licencia de Texas entre los 18 y 24 años y revise los pasos siguientes.',
				'og_locale'   => 'es_US',
				'alt_locale'  => 'en_US',
				'page_name'   => 'Curso de manejo de seis horas para adultos en Texas',
			),
			'texas-parent-taught-drivers-ed' => array(
				'language'    => 'en-US',
				'canonical'   => '/texas-parent-taught-drivers-ed/',
				'alternate'   => '/es/curso-de-manejo-para-adolescentes-impartido-por-padres/',
				'title'       => 'Texas Parent-Taught Drivers Ed Online | Gulf Breeze',
				'description' => 'Understand Texas parent-taught driver education, parent-instructor authorization, online classroom study and supervised driving requirements before enrolling.',
				'og_locale'   => 'en_US',
				'alt_locale'  => 'es_US',
				'page_name'   => 'Texas Parent-Taught Drivers Ed Online',
			),
			'curso-de-manejo-para-adolescentes-impartido-por-padres' => array(
				'language'    => 'es-US',
				'canonical'   => '/es/curso-de-manejo-para-adolescentes-impartido-por-padres/',
				'alternate'   => '/texas-parent-taught-drivers-ed/',
				'title'       => 'Curso de Manejo Impartido por Padres en Texas | Gulf Breeze',
				'description' => 'Conozca el proceso de educación vial impartida por padres en Texas: autorización del instructor, clases en línea y práctica de manejo supervisada.',
				'og_locale'   => 'es_US',
				'alt_locale'  => 'en_US',
				'page_name'   => 'Curso de manejo para adolescentes impartido por padres en Texas',
			),
			'texas-adult-drivers-ed-requirements' => array(
				'language'    => 'en-US',
				'canonical'   => '/texas-adult-drivers-ed-requirements/',
				'alternate'   => '/es/requisitos-del-curso-de-manejo-para-adultos-en-texas/',
				'title'       => 'Texas Adult Drivers Ed Requirements (Ages 18–24) | Gulf Breeze',
				'description' => 'Learn when Texas requires the six-hour adult driver education course, who may qualify for the new-resident waiver, and what applicants age 25+ should know.',
				'og_locale'   => 'en_US',
				'alt_locale'  => 'es_US',
				'page_name'   => 'Texas Adult Drivers Ed Requirements',
			),
			'requisitos-del-curso-de-manejo-para-adultos-en-texas' => array(
				'language'    => 'es-US',
				'canonical'   => '/es/requisitos-del-curso-de-manejo-para-adultos-en-texas/',
				'alternate'   => '/texas-adult-drivers-ed-requirements/',
				'title'       => 'Requisitos del curso de manejo para adultos en Texas | Gulf Breeze',
				'description' => 'Conozca cuándo Texas exige el curso de seis horas para adultos, la excepción para ciertos nuevos residentes y qué aplica a solicitantes de 25 años o más.',
				'og_locale'   => 'es_US',
				'alt_locale'  => 'en_US',
				'page_name'   => 'Requisitos del curso de manejo para adultos en Texas',
			),
			'texas-driver-license-guide' => array(
				'language'    => 'en-US',
				'canonical'   => '/texas-driver-license-guide/',
				'alternate'   => '/es/guia-para-obtener-la-licencia-de-conducir-en-texas/',
				'title'       => 'How to Get a Texas Driver License as an Adult | Gulf Breeze',
				'description' => 'Follow the Texas adult driver license process: documents, six-hour course rules, DPS appointment, knowledge testing, ITAD, restricted license, and road test.',
				'og_locale'   => 'en_US',
				'alt_locale'  => 'es_US',
				'page_name'   => 'How to Get a Texas Driver License as an Adult',
			),
			'guia-para-obtener-la-licencia-de-conducir-en-texas' => array(
				'language'    => 'es-US',
				'canonical'   => '/es/guia-para-obtener-la-licencia-de-conducir-en-texas/',
				'alternate'   => '/texas-driver-license-guide/',
				'title'       => 'Cómo obtener una licencia de conducir en Texas | Gulf Breeze',
				'description' => 'Siga el trámite de la licencia para adultos en Texas: documentos, curso de seis horas, cita con el DPS, exámenes, ITAD y licencia restringida.',
				'og_locale'   => 'es_US',
				'alt_locale'  => 'en_US',
				'page_name'   => 'Cómo obtener una licencia de conducir en Texas para adultos',
			),
			'texas-parent-taught-drivers-ed-guide' => array(
				'language'    => 'en-US',
				'canonical'   => '/texas-parent-taught-drivers-ed-guide/',
				'alternate'   => '/es/guia-de-educacion-vial-impartida-por-padres-en-texas/',
				'title'       => 'Texas Parent-Taught Drivers Ed Requirements | Gulf Breeze',
				'description' => 'Follow Texas Parent-Taught Driver Education requirements, including TDLR instructor authorization, learner-license steps and 44 in-car hours.',
				'og_locale'   => 'en_US',
				'alt_locale'  => 'es_US',
				'page_name'   => 'Texas Parent-Taught Drivers Ed Requirements',
			),
			'guia-de-educacion-vial-impartida-por-padres-en-texas' => array(
				'language'    => 'es-US',
				'canonical'   => '/es/guia-de-educacion-vial-impartida-por-padres-en-texas/',
				'alternate'   => '/texas-parent-taught-drivers-ed-guide/',
				'title'       => 'Requisitos para Educación Vial por Padres en Texas | Gulf Breeze',
				'description' => 'Conozca los requisitos de Texas para la educación vial impartida por padres: autorización del instructor, licencia de aprendizaje y 44 horas en el vehículo.',
				'og_locale'   => 'es_US',
				'alt_locale'  => 'en_US',
				'page_name'   => 'Requisitos de educación vial impartida por padres en Texas',
			),
		);
	}

	private static function utility_slugs() {
		return array(
			'account-security',
			'become_a_teacher',
			'cart',
			'checkout',
			'choose-your-course',
			'enrollment-agreement',
			'instructor',
			'instructors',
			'lp-checkout',
			'lp-profile',
			'mfa-enroll',
			'mfa-recovery',
			'mfa-setup',
			'mfa-verify',
			'my-account',
			'profile',
			'refund_returns',
			'sample-page',
			'shop',
			'term_conditions',
		);
	}

	public static function init() {
		add_filter( 'pre_get_document_title', array( __CLASS__, 'filter_document_title' ), 20 );
		add_filter( 'get_canonical_url', array( __CLASS__, 'filter_canonical_url' ), 20, 2 );
		add_filter( 'language_attributes', array( __CLASS__, 'filter_language_attributes' ), 20, 2 );
		add_filter( 'wp_robots', array( __CLASS__, 'filter_robots' ), 20 );
		add_filter( 'wp_sitemaps_post_types', array( __CLASS__, 'filter_sitemap_post_types' ), 20 );
		add_filter( 'wp_sitemaps_posts_query_args', array( __CLASS__, 'filter_sitemap_query_args' ), 20, 2 );
		add_filter( 'the_author', array( __CLASS__, 'filter_public_author' ), 20 );
		add_filter( 'get_the_author_display_name', array( __CLASS__, 'filter_public_author' ), 20 );
		add_filter( 'author_link', array( __CLASS__, 'filter_public_author_link' ), 20 );
		add_filter( 'render_block', array( __CLASS__, 'filter_public_entity_text' ), 20, 2 );
		add_action( 'wp', array( __CLASS__, 'prepare_authority_head' ) );
		add_action( 'wp_head', array( __CLASS__, 'render_authority_head' ), 3 );
	}

	public static function prepare_authority_head() {
		if ( self::context() ) {
			remove_action( 'wp_head', 'rel_canonical' );
		}
	}

	private static function context() {
		if ( ! is_singular( 'page' ) ) {
			return null;
		}

		$post = get_queried_object();
		if ( ! $post instanceof WP_Post ) {
			return null;
		}

		$pages = self::authority_pages();
		return isset( $pages[ $post->post_name ] ) ? $pages[ $post->post_name ] : null;
	}

	private static function absolute_url( $path ) {
		return home_url( $path );
	}

	public static function filter_document_title( $title ) {
		$context = self::context();
		return $context ? $context['title'] : $title;
	}

	public static function filter_canonical_url( $canonical_url, $post ) {
		$pages = self::authority_pages();
		if ( $post instanceof WP_Post && isset( $pages[ $post->post_name ] ) ) {
			return self::absolute_url( $pages[ $post->post_name ]['canonical'] );
		}
		return $canonical_url;
	}

	public static function filter_language_attributes( $output, $doctype ) {
		$context = self::context();
		if ( ! $context ) {
			return $output;
		}

		$output = preg_replace( '/lang=("|\')[^"\']*("|\')/i', 'lang="' . esc_attr( $context['language'] ) . '"', $output, 1 );
		if ( false === stripos( $output, 'lang=' ) ) {
			$output = 'lang="' . esc_attr( $context['language'] ) . '" ' . $output;
		}
		return trim( $output );
	}

	public static function filter_robots( $robots ) {
		$post_type = get_post_type();
		$slug      = is_singular() ? get_post_field( 'post_name', get_queried_object_id() ) : '';

		$private_types = array( 'lp_course', 'lp_lesson', 'lp_quiz', 'lp_question', 'product' );
		$must_noindex  = is_author()
			|| in_array( $post_type, $private_types, true )
			|| in_array( $slug, self::utility_slugs(), true );

		if ( $must_noindex ) {
			$robots['noindex'] = true;
			$robots['follow']  = true;
			unset( $robots['index'], $robots['nofollow'] );
		}

		return $robots;
	}

	public static function filter_sitemap_post_types( $post_types ) {
		foreach ( array( 'product', 'lp_course', 'lp_lesson', 'lp_quiz', 'lp_question' ) as $post_type ) {
			unset( $post_types[ $post_type ] );
		}
		return $post_types;
	}

	public static function filter_sitemap_query_args( $args, $post_type ) {
		if ( 'page' !== $post_type ) {
			return $args;
		}

		$excluded = array();
		foreach ( self::utility_slugs() as $slug ) {
			$page = get_page_by_path( $slug, OBJECT, 'page' );
			if ( $page instanceof WP_Post ) {
				$excluded[] = (int) $page->ID;
			}
		}

		if ( $excluded ) {
			$args['post__not_in'] = array_values( array_unique( array_merge( isset( $args['post__not_in'] ) ? (array) $args['post__not_in'] : array(), $excluded ) ) );
		}
		return $args;
	}

	public static function filter_public_author( $author ) {
		return is_admin() ? $author : self::ENTITY_NAME;
	}

	public static function filter_public_author_link( $link ) {
		return is_admin() ? $link : home_url( '/' );
	}

	public static function filter_public_entity_text( $block_content, $block ) {
		if ( is_admin() || '' === $block_content ) {
			return $block_content;
		}

		$replacements = array(
			'© 2026 Rodney Crawford' => '© 2026 Gulf Breeze Driving School',
			'&copy; 2026 Rodney Crawford' => '&copy; 2026 Gulf Breeze Driving School',
		);
		return strtr( $block_content, $replacements );
	}

	public static function render_authority_head() {
		$context = self::context();
		if ( ! $context ) {
			return;
		}

		$canonical = self::absolute_url( $context['canonical'] );
		$alternate = self::absolute_url( $context['alternate'] );
		$is_spanish = 'es-US' === $context['language'];
		$english    = $is_spanish ? $alternate : $canonical;
		$spanish    = $is_spanish ? $canonical : $alternate;

		echo "\n<!-- Gulf Breeze SEO Foundation " . esc_html( self::VERSION ) . " -->\n";
		echo '<meta name="description" content="' . esc_attr( $context['description'] ) . '">' . "\n";
		echo '<meta name="author" content="' . esc_attr( self::ENTITY_NAME ) . '">' . "\n";
		echo '<link rel="canonical" href="' . esc_url( $canonical ) . '">' . "\n";
		echo '<link rel="alternate" hreflang="en-US" href="' . esc_url( $english ) . '">' . "\n";
		echo '<link rel="alternate" hreflang="es-US" href="' . esc_url( $spanish ) . '">' . "\n";
		echo '<link rel="alternate" hreflang="x-default" href="' . esc_url( $english ) . '">' . "\n";
		echo '<meta property="og:type" content="website">' . "\n";
		echo '<meta property="og:site_name" content="' . esc_attr( self::ENTITY_NAME ) . '">' . "\n";
		echo '<meta property="og:title" content="' . esc_attr( $context['title'] ) . '">' . "\n";
		echo '<meta property="og:description" content="' . esc_attr( $context['description'] ) . '">' . "\n";
		echo '<meta property="og:url" content="' . esc_url( $canonical ) . '">' . "\n";
		echo '<meta property="og:locale" content="' . esc_attr( $context['og_locale'] ) . '">' . "\n";
		echo '<meta property="og:locale:alternate" content="' . esc_attr( $context['alt_locale'] ) . '">' . "\n";
		echo '<meta name="twitter:card" content="summary_large_image">' . "\n";

		$image = get_site_icon_url( 512 );
		if ( $image ) {
			echo '<meta property="og:image" content="' . esc_url( $image ) . '">' . "\n";
			echo '<meta name="twitter:image" content="' . esc_url( $image ) . '">' . "\n";
		}

		$root = trailingslashit( home_url( '/' ) );
		$graph = array(
			array(
				'@type' => 'Organization',
				'@id'   => $root . '#organization',
				'name'  => self::ENTITY_NAME,
				'url'   => $root,
				'areaServed' => array(
					'@type' => 'State',
					'name'  => 'Texas',
				),
			),
			array(
				'@type'     => 'WebSite',
				'@id'       => $root . '#website',
				'url'       => $root,
				'name'      => self::ENTITY_NAME,
				'inLanguage'=> array( 'en-US', 'es-US' ),
				'publisher' => array( '@id' => $root . '#organization' ),
			),
			array(
				'@type'      => 'WebPage',
				'@id'        => $canonical . '#webpage',
				'url'        => $canonical,
				'name'       => $context['page_name'],
				'description'=> $context['description'],
				'inLanguage' => $context['language'],
				'isPartOf'   => array( '@id' => $root . '#website' ),
				'about'      => array( '@id' => $root . '#organization' ),
				'author'     => array( '@id' => $root . '#organization' ),
			),
			array(
				'@type' => 'BreadcrumbList',
				'@id'   => $canonical . '#breadcrumb',
				'itemListElement' => array(
					array(
						'@type'    => 'ListItem',
						'position' => 1,
						'name'     => $is_spanish ? 'Inicio' : 'Home',
						'item'     => $is_spanish ? self::absolute_url( '/es/' ) : $root,
					),
					array(
						'@type'    => 'ListItem',
						'position' => 2,
						'name'     => $context['page_name'],
						'item'     => $canonical,
					),
				),
			),
		);

		/**
		 * Course schema is deliberately not emitted in this revision. The locked
		 * claims register requires course authorization, product facts, and the
		 * complete runtime path to be validated first.
		 */
		$schema = array(
			'@context' => 'https://schema.org',
			'@graph'   => $graph,
		);
		echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
		echo "<!-- /Gulf Breeze SEO Foundation -->\n";
	}
}

Gulf_Breeze_SEO_Foundation::init();
