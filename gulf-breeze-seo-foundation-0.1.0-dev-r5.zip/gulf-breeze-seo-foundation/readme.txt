=== Gulf Breeze SEO Foundation ===
Contributors: Gulf Breeze Driving School
Stable tag: 0.1.0-dev-r5
Requires at least: 6.6
Requires PHP: 8.1
License: Proprietary

Controlled SEO foundation for Gulf Breeze Driving School.

This revision provides:

* Final title tags and meta descriptions for the English and Spanish Adult course, Parent-Taught course, Adult eligibility, Adult license-process, and Parent-Taught process-guide authority-page pairs.
* Fixed self-canonicals and reciprocal en-US/es-US/x-default hreflang.
* Open Graph and social metadata.
* Organization, WebSite, WebPage, and BreadcrumbList JSON-LD.
* Noindex/follow rules for transaction, account, LMS, product, test, and utility content.
* Sitemap exclusion for private/utility content types and mapped utility pages.
* Gulf Breeze Driving School as the sole public author/entity.
* Exact replacement of the existing public footer credit that names an individual.

Course schema is intentionally gated out until course authorization, product facts,
and the end-to-end runtime have been verified. FAQ content remains visible HTML; this
revision does not add FAQ rich-result markup.

The plugin does not publish pages, change course content, alter enrollment logic, or
remove Site Protection.
