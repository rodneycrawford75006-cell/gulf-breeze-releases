# Gulf Breeze Video Playback & Quiz Gate

Development version: 0.3.1-dev  
Owner and author: Gulf Breeze Driving School / Rodney Crawford

## Purpose

This LearnPress companion plugin requires server-verified playback of mapped instructional media and a correct answer from the mapped post-video question bank before a student can advance.

Gate mappings remain stored in `gbvqg_gates`. The upgrade migration dynamically discovers supported embedded-video lessons followed immediately by a Video Check quiz and merges missing mappings without replacing existing administrator settings. Course, lesson, quiz, and next-item identifiers come from the current Gulf Breeze curriculum. The plugin contains no built-in production or historical course IDs.

## Playback evidence

Version 0.3.1-dev supports HTML5 video and YouTube iframe playback. An authenticated playback session starts only at the beginning of readable media. Ordered browser heartbeats are evaluated by the server. A queued end-of-media report prevents the final completion event from being lost when a regular heartbeat is still in flight.

Credit requires playing media, a visible and focused browser, normal playback speed, media-clock movement consistent with server elapsed time, an ordered timely report, a logged-in enrolled student, and no seek or forward jump. Paused, background, sped-up, stale, out-of-order, seeking, and implausible intervals earn no credit.

Completion requires an end-of-media event and verified watch time within five seconds of the reported duration. The record is signed with the WordPress authentication salt and binds the student, gate, course, lesson, duration, timestamps, and verification summary.

The post-video question cannot open without valid signed playback evidence. A wrong answer removes that evidence and starts a new required playback cycle before a retry.

## Existing quiz behavior preserved

- one randomized question per attempt from the mapped LearnPress bank;
- wrong answers return the student to the mapped video;
- successful custom validation must reconcile with LearnPress completion;
- gate-state inspection, backups, audit events, and targeted administrator repair remain available; and
- installation preserves existing `gbvqg_gates` mappings.

## Release status

This is a development checkpoint, not a production release. Formal PHP linting, WordPress activation and upgrade testing, disposable-database testing, and browser-level tests for the exact CSEA and Water Safety embeds remain mandatory. Under Construction must remain enabled. Do not deploy this checkpoint.
