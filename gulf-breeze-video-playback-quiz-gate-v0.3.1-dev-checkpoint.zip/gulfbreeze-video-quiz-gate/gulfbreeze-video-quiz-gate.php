<?php
/**
 * Plugin Name: Gulf Breeze Video Playback & Quiz Gate
 * Description: Requires auditable playback of mapped instructional media and a post-video knowledge check before a student may continue in a Gulf Breeze Driving School LearnPress course.
 * Version: 0.3.1-dev
 * Author: Gulf Breeze Driving School / Rodney Crawford
 * Text Domain: gulfbreeze-video-quiz-gate
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class GulfBreeze_Video_Quiz_Gate {
    const VERSION       = '0.3.1-dev';
    const COURSE_POLICY_VERSION = '2026-08-14-v3';
    const OPTION_GATES          = 'gbvqg_gates';
    const OPTION_EVENTS         = 'gbvqg_events';
    const OPTION_BACKUP_LAST    = 'gbvqg_gates_backup_last';
    const OPTION_BACKUP_HISTORY = 'gbvqg_gates_backup_history';
    const NONCE_ACTION          = 'gbvqg_save_gates';
    const PLAYBACK_META_PREFIX  = '_gbvqg_playback_';
    const PLAYBACK_SESSION_TTL  = 7200;
    const OPTION_REGISTRY_VERSION = 'gbvqg_registry_version';

    /** @var self|null */
    private static $instance = null;

    /** @var array|null */
    private $course_items_cache = array();

    /** @var array */
    private $frontend_notice = array();

    /** @var array */
    private $last_lp_write_diagnostic = array();

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_menu', array( $this, 'admin_menu' ) );
        add_action( 'admin_post_gbvqg_save_gates', array( $this, 'handle_save_gates' ) );
        add_action( 'admin_post_gbvqg_export_gates', array( $this, 'handle_export_gates' ) );
        add_action( 'admin_post_gbvqg_restore_last_backup', array( $this, 'handle_restore_last_backup' ) );
        add_action( 'admin_post_gbvqg_clear_events', array( $this, 'handle_clear_events' ) );
        add_action( 'admin_post_gbvqg_repair_gate_state', array( $this, 'handle_repair_gate_state' ) );
        add_action( 'admin_post_gbvqg_reconcile_retired_course', array( $this, 'handle_reconcile_retired_course' ) );
        add_action( 'admin_post_gbvqg_submit_validation', array( $this, 'handle_validation_submit' ) );
        add_action( 'wp_ajax_gbvqg_verify_video_completion', array( $this, 'ajax_verify_video_completion' ) );
        add_action( 'wp_ajax_gbvqg_playback_start', array( $this, 'ajax_playback_start' ) );
        add_action( 'wp_ajax_gbvqg_playback_progress', array( $this, 'ajax_playback_progress' ) );
        add_action( 'init', array( $this, 'maybe_register_adjacent_video_gates' ), 30 );

        // v0.2.9: Render the plugin-controlled validation page before LearnPress can render the mapped quiz.
        add_action( 'template_redirect', array( $this, 'maybe_render_validation_page' ), 0 );
        add_action( 'template_redirect', array( $this, 'capture_next_item_progress_probe' ), 0 );
        add_action( 'template_redirect', array( $this, 'template_redirect_gate' ), 1 );
        add_filter( 'the_content', array( $this, 'inject_frontend_notice' ), 15 );
        add_action( 'wp_footer', array( $this, 'footer_gate_script' ), 99 );
        add_shortcode( 'gb_video_quiz_gate_status', array( $this, 'shortcode_status' ) );

        // v0.2.7: Filter LearnPress quiz questions down to N random per attempt.
        add_filter( 'learn-press/quiz/questions',          array( $this, 'filter_quiz_questions' ), 20, 2 );
        add_filter( 'learn-press/quiz-question-ids',       array( $this, 'filter_quiz_question_ids' ), 20, 2 );
        add_filter( 'learn_press_quiz_questions',          array( $this, 'filter_quiz_questions' ), 20, 2 );
        add_filter( 'learnpress/rest-api/frontend/quiz/questions', array( $this, 'filter_quiz_questions' ), 20, 2 );

        // v0.2.7: Stamp failed_at the moment LP marks a quiz attempt finished
        // so Retake Quiz cannot bypass the return-to-video rule.
        add_action( 'learn-press/user-quiz-finished',  array( $this, 'on_quiz_finished_lp4' ), 10, 3 );
        add_action( 'learn-press/user/quiz-finished',  array( $this, 'on_quiz_finished_lp4' ), 10, 3 );
        add_action( 'learn_press_user_quiz_finished',  array( $this, 'on_quiz_finished_legacy' ), 10, 3 );

        // v0.2.8: For gated quizzes only, force the "show correct answer" /
        // "show explanation" / "review questions" filters to false so the
        // student cannot harvest the correct answer between attempts.
        // This is best-effort across LP4 hook variants. The admin LP quiz
        // settings should still be set to: review off, show correct off.
        add_filter( 'learn-press/quiz/show-correct-answer',  array( $this, 'force_hide_answer_for_gated' ), 99, 2 );
        add_filter( 'learn-press/quiz-show-correct-answer',  array( $this, 'force_hide_answer_for_gated' ), 99, 2 );
        add_filter( 'learn_press_quiz_show_correct_answer',  array( $this, 'force_hide_answer_for_gated' ), 99, 2 );
        add_filter( 'learn-press/quiz/show-explanation',     array( $this, 'force_hide_answer_for_gated' ), 99, 2 );
        add_filter( 'learn-press/quiz-review-questions',     array( $this, 'force_hide_answer_for_gated' ), 99, 2 );
        add_filter( 'learn_press_quiz_review_questions',     array( $this, 'force_hide_answer_for_gated' ), 99, 2 );
        add_filter( 'learn-press/quiz/instant-check',        array( $this, 'force_hide_answer_for_gated' ), 99, 2 );
    }

    public static function activate() {
        if ( false === get_option( self::OPTION_GATES, false ) ) {
            add_option( self::OPTION_GATES, array(), '', false );
        }
        if ( false === get_option( self::OPTION_EVENTS, false ) ) {
            add_option( self::OPTION_EVENTS, array(), '', false );
        }
        if ( false === get_option( self::OPTION_BACKUP_LAST, false ) ) {
            add_option( self::OPTION_BACKUP_LAST, array(), '', false );
        }
        if ( false === get_option( self::OPTION_BACKUP_HISTORY, false ) ) {
            add_option( self::OPTION_BACKUP_HISTORY, array(), '', false );
        }
        if ( false === get_option( self::OPTION_REGISTRY_VERSION, false ) ) {
            add_option( self::OPTION_REGISTRY_VERSION, '', '', false );
        }
    }

    public function maybe_register_adjacent_video_gates() {
        if ( get_option( self::OPTION_REGISTRY_VERSION, '' ) === self::COURSE_POLICY_VERSION ) {
            return;
        }
        if ( ! post_type_exists( 'lp_course' ) || ! post_type_exists( 'lp_lesson' ) || ! post_type_exists( 'lp_quiz' ) ) {
            return;
        }

        $existing = get_option( self::OPTION_GATES, array() );
        $existing = is_array( $existing ) ? $existing : array();
        $known = array();
        foreach ( $existing as $gate ) {
            $known[ absint( $gate['course_id'] ?? 0 ) . ':' . absint( $gate['video_lesson_id'] ?? 0 ) . ':' . absint( $gate['quiz_id'] ?? 0 ) ] = true;
        }

        $added = array();
        foreach ( $this->get_lp_courses() as $course ) {
            $course_id = absint( $course->ID );
            $items = array_values( $this->get_course_items( $course_id ) );
            foreach ( $items as $index => $item ) {
                $lesson_id = absint( $item['item_id'] ?? 0 );
                $quiz_id   = absint( $items[ $index + 1 ]['item_id'] ?? 0 );
                if ( 'lp_lesson' !== get_post_type( $lesson_id ) || 'lp_quiz' !== get_post_type( $quiz_id ) ) {
                    continue;
                }
                $lesson_content = (string) get_post_field( 'post_content', $lesson_id );
                $quiz_title     = (string) get_the_title( $quiz_id );
                $has_supported_media = false !== stripos( $lesson_content, '<video' )
                    || false !== stripos( $lesson_content, 'youtube.com/embed/' )
                    || false !== stripos( $lesson_content, 'youtube-nocookie.com/embed/' );
                if ( ! $has_supported_media || false === stripos( $quiz_title, 'video check' ) ) {
                    continue;
                }
                $fingerprint = $course_id . ':' . $lesson_id . ':' . $quiz_id;
                if ( isset( $known[ $fingerprint ] ) ) {
                    continue;
                }
                $gate = $this->sanitize_gate( array(
                    'enabled' => 1,
                    'enabled_explicitly_saved_v025' => 1,
                    'label' => get_the_title( $lesson_id ),
                    'course_id' => $course_id,
                    'video_lesson_id' => $lesson_id,
                    'quiz_id' => $quiz_id,
                    'next_item_id' => absint( $items[ $index + 2 ]['item_id'] ?? 0 ),
                    'expected_questions' => 4,
                    'show_questions' => 1,
                    'fail_mode' => 'return_video',
                ) );
                $existing[] = $gate;
                $added[] = $gate;
                $known[ $fingerprint ] = true;
            }
        }

        if ( $added ) {
            $this->backup_gate_settings( 'before_dynamic_registry_migration' );
            update_option( self::OPTION_GATES, $existing, false );
            foreach ( $added as $gate ) {
                $this->log_event( 'dynamic_video_gate_registered', 0, $gate, array(
                    'policy_version' => self::COURSE_POLICY_VERSION,
                    'discovery_rule' => 'supported embedded media followed immediately by a Video Check quiz',
                ) );
            }
        }
        update_option( self::OPTION_REGISTRY_VERSION, self::COURSE_POLICY_VERSION, false );
    }

    public function admin_menu() {
        add_menu_page(
            'GulfBreeze Video Quiz Gate',
            'Video Quiz Gate',
            'manage_options',
            'gb-video-quiz-gate',
            array( $this, 'render_admin_page' ),
            'dashicons-controls-play',
            58
        );
    }

    public function render_admin_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $all_gates     = $this->get_gates();
        $courses       = $this->get_lp_courses();
        $reader_course = isset( $_GET['gbvqg_reader_course'] ) ? absint( $_GET['gbvqg_reader_course'] ) : 0;
        $all_events    = get_option( self::OPTION_EVENTS, array() );
        $all_events    = is_array( $all_events ) ? $all_events : array();
        $events        = array_slice( array_reverse( $all_events ), 0, 50 );

        $report_requested = isset( $_GET['gbvqg_report'] );
        $report_user_id   = isset( $_GET['gbvqg_report_user'] ) ? absint( $_GET['gbvqg_report_user'] ) : 0;
        $report_course_id = isset( $_GET['gbvqg_report_course'] ) ? absint( $_GET['gbvqg_report_course'] ) : 0;
        $report_from      = isset( $_GET['gbvqg_report_from'] ) ? sanitize_text_field( wp_unslash( $_GET['gbvqg_report_from'] ) ) : '';
        $report_to        = isset( $_GET['gbvqg_report_to'] ) ? sanitize_text_field( wp_unslash( $_GET['gbvqg_report_to'] ) ) : '';
        $report_events    = $report_requested ? $this->filter_inspection_report_events( $all_events, $report_user_id, $report_course_id, $report_from, $report_to ) : array();

        $repair_user_id  = isset( $_GET['gbvqg_repair_user'] ) ? absint( $_GET['gbvqg_repair_user'] ) : 0;
        $repair_gate_id  = isset( $_GET['gbvqg_repair_gate'] ) ? sanitize_key( wp_unslash( $_GET['gbvqg_repair_gate'] ) ) : '';
        $repair_gate     = $repair_gate_id ? $this->find_gate_by_id( $repair_gate_id ) : array();
        $repair_analysis = ( $repair_user_id && $repair_gate ) ? $this->analyze_gate_state_evidence( $repair_user_id, $repair_gate ) : array();
        $audit_requested = isset( $_GET['gbvqg_mismatch_audit'] );
        $audit_course_id = isset( $_GET['gbvqg_audit_course'] ) ? absint( $_GET['gbvqg_audit_course'] ) : 0;
        $audit_rows      = $audit_requested ? $this->get_gate_state_audit_rows( 2000, $audit_course_id ) : array();

        $legacy_course_id       = isset( $_GET['gbvqg_legacy_course'] ) ? absint( $_GET['gbvqg_legacy_course'] ) : 0;
        $legacy_preview_requested = isset( $_GET['gbvqg_legacy_preview'] );
        $legacy_rows            = ( $legacy_preview_requested && $this->is_retired_legacy_course( $legacy_course_id ) ) ? $this->get_retired_course_reconciliation_rows( $legacy_course_id ) : array();

        // Group real (non-blank) gates by course_id.
        $gates_by_course = array();
        foreach ( $all_gates as $gate ) {
            $cid = absint( $gate['course_id'] ?? 0 );
            if ( $cid ) {
                $gates_by_course[ $cid ][] = $gate;
            }
        }

        // Pre-load lesson and quiz options for every course that has gates.
        // These power the dropdowns so you pick from a list instead of typing IDs.
        $lesson_opts = array(); // [ course_id => [ ['id'=>N,'label'=>'...'], ... ] ]
        $quiz_opts   = array();
        foreach ( array_keys( $gates_by_course ) as $cid ) {
            $items = $this->get_course_items( $cid );
            $lesson_opts[ $cid ] = array();
            $quiz_opts[ $cid ]   = array();
            foreach ( $items as $item ) {
                $type  = get_post_type( $item['item_id'] );
                $title = get_the_title( $item['item_id'] );
                $iid   = absint( $item['item_id'] );
                $lbl   = '#' . $iid . ' — ' . $title;
                if ( 'lp_lesson' === $type ) {
                    $lesson_opts[ $cid ][] = array( 'id' => $iid, 'label' => $lbl );
                } elseif ( 'lp_quiz' === $type ) {
                    $quiz_opts[ $cid ][] = array( 'id' => $iid, 'label' => $lbl );
                }
            }
        }

        ?>
        <div class="wrap gbvqg-wrap">
            <h1>GulfBreeze Video Quiz Gate <span style="font-size:14px;font-weight:400;">v<?php echo esc_html( self::VERSION ); ?></span></h1>
            <p>This plugin handles the missing post-video quiz loop: <strong>watch video lesson → answer required quiz → correct continues → wrong returns to video before retry</strong>.</p>

            <?php echo wp_kses_post( $this->render_gate_diagnostics( $all_gates ) ); ?>

            <?php if ( isset( $_GET['gbvqg_saved'] ) ) : ?>
                <div class="notice notice-success is-dismissible"><p>Video quiz gate settings saved. A backup of the previous settings was created before saving.</p></div>
            <?php endif; ?>
            <?php if ( ! empty( $_GET['gbvqg_removed'] ) ) : ?>
                <div class="notice notice-success is-dismissible"><p><?php echo esc_html( absint( $_GET['gbvqg_removed'] ) ); ?> gate mapping(s) removed. All remaining mappings were preserved.</p></div>
            <?php endif; ?>
            <?php if ( isset( $_GET['gbvqg_restored'] ) ) : ?>
                <div class="notice notice-success is-dismissible"><p>Last saved backup restored. Review the gate mappings below, then test one gate before opening to students.</p></div>
            <?php endif; ?>
            <?php if ( isset( $_GET['gbvqg_restore_missing'] ) ) : ?>
                <div class="notice notice-warning is-dismissible"><p>No saved gate backup was available to restore.</p></div>
            <?php endif; ?>
            <?php if ( isset( $_GET['gbvqg_repair_done'] ) ) : ?>
                <div class="notice notice-success is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['gbvqg_repair_done'] ) ) ); ?></p></div>
            <?php endif; ?>
            <?php if ( isset( $_GET['gbvqg_repair_error'] ) ) : ?>
                <div class="notice notice-error is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['gbvqg_repair_error'] ) ) ); ?></p></div>
            <?php endif; ?>
            <?php if ( isset( $_GET['gbvqg_legacy_done'] ) ) : ?>
                <div class="notice notice-success is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['gbvqg_legacy_done'] ) ) ); ?></p></div>
            <?php endif; ?>
            <?php if ( isset( $_GET['gbvqg_legacy_error'] ) ) : ?>
                <div class="notice notice-error is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['gbvqg_legacy_error'] ) ) ); ?></p></div>
            <?php endif; ?>

            <style>
                /* ── base ── */
                .gbvqg-wrap table.widefat td,
                .gbvqg-wrap table.widefat th { vertical-align: top; }
                .gbvqg-small   { color: #646970; font-size: 12px; }
                .gbvqg-code    { font-family: Consolas, Monaco, monospace; background: #f6f7f7; padding: 2px 4px; border-radius: 3px; }
                .gbvqg-invalid { color: #b32d2e; font-weight: 600; }
                .gbvqg-ok      { color: #008a20; font-weight: 600; }
                .gbvqg-warn    { color: #996800; font-weight: 600; }
                .gbvqg-card    { background: #fff; border: 1px solid #c3c4c7; padding: 16px; margin: 16px 0; }
                .gbvqg-validation ul { margin: 4px 0 0 18px; list-style: disc; }

                /* ── per-course collapsible sections ── */
                .gbvqg-course-section {
                    background: #fff;
                    border: 1px solid #c3c4c7;
                    border-radius: 4px;
                    margin: 14px 0;
                }
                .gbvqg-course-section > summary {
                    display: flex;
                    align-items: center;
                    gap: 14px;
                    padding: 12px 16px;
                    cursor: pointer;
                    user-select: none;
                    border-bottom: 1px solid #e2e4e7;
                    list-style: none;
                }
                .gbvqg-course-section > summary::-webkit-details-marker { display: none; }
                .gbvqg-course-section > summary::before {
                    content: '\25B6';
                    font-size: 11px;
                    color: #646970;
                    transition: transform .15s;
                    flex-shrink: 0;
                }
                .gbvqg-course-section[open] > summary::before { transform: rotate(90deg); }
                .gbvqg-course-section > summary h2 {
                    margin: 0;
                    font-size: 15px;
                    font-weight: 600;
                    flex: 1;
                }
                .gbvqg-course-badges { display: flex; gap: 6px; flex-shrink: 0; }
                .gbvqg-badge {
                    display: inline-block;
                    padding: 2px 9px;
                    border-radius: 10px;
                    font-size: 12px;
                    font-weight: 600;
                }
                .gbvqg-badge-ok      { background: #d6ffe4; color: #006b2b; }
                .gbvqg-badge-invalid { background: #fde8e8; color: #8b1f1f; }
                .gbvqg-badge-total   { background: #f0f0f1; color: #3c434a; }
                .gbvqg-course-inner  { padding: 0 16px 16px; }

                /* ── gate table inside a course section ── */
                .gbvqg-gate-table { margin-top: 12px; border-collapse: collapse; }
                .gbvqg-gate-table th,
                .gbvqg-gate-table td   { padding: 7px 9px; }
                .gbvqg-gate-table thead th { background: #f6f7f7; }
                .gbvqg-gate-table tbody tr:nth-child(odd) { background: #fafafa; }
                .gbvqg-gate-table tbody tr.gbvqg-row-invalid td { background: #fff1f1 !important; border-top: 2px solid #d63638; border-bottom: 2px solid #d63638; }
                .gbvqg-gate-table tbody tr.gbvqg-row-invalid td:first-child { border-left: 4px solid #d63638; }
                .gbvqg-gate-table select { max-width: 300px; }
                .gbvqg-gate-table .gbvqg-input       { width: 80px; }
                .gbvqg-gate-table .gbvqg-title-input { width: 180px; }
                .gbvqg-blank-row td { border-top: 2px dashed #c3c4c7 !important; background: #f6f7f7; }
                .gbvqg-health-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 10px; margin-top: 10px; }
                .gbvqg-health-course { border: 1px solid #dcdcde; border-left: 4px solid #72aee6; background: #fff; padding: 10px 12px; }
                .gbvqg-health-course.gbvqg-health-invalid { border-left-color: #d63638; background: #fff8f8; }
                .gbvqg-safety-actions { display:flex; gap:10px; flex-wrap:wrap; align-items:center; }
                .gbvqg-curriculum-hint { margin-top: 8px; padding: 8px; background: #f6f7f7; border-left: 3px solid #72aee6; }
                .gbvqg-row-invalid .gbvqg-curriculum-hint { background: #fff; border-left-color: #d63638; }
                .gbvqg-danger { color:#b32d2e; font-weight:700; }

                /* ── new-course section ── */
                .gbvqg-new-course-section { background: #f9f9fb; border-style: dashed; }
                .gbvqg-new-course-section > summary h2 { color: #646970; font-weight: 400; }

                /* ── report styles ── */
                .gbvqg-report-header { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px 20px; margin: 12px 0; }
                .gbvqg-report-header div { padding: 4px 0; }
                .gbvqg-report-actions { margin: 10px 0 0; }
                .gbvqg-report-table th, .gbvqg-report-table td { font-size: 12px; }

                @media print {
                    body * { visibility: hidden !important; }
                    #gbvqg-student-inspection-report,
                    #gbvqg-student-inspection-report * { visibility: visible !important; }
                    #gbvqg-student-inspection-report { position: absolute; left: 0; top: 0; width: 100%; background: #fff; color: #000; padding: 0; margin: 0; }
                    #adminmenumain, #wpadminbar, #wpfooter, .notice, .gbvqg-no-print, .gbvqg-report-actions { display: none !important; }
                    #gbvqg-student-inspection-report table { border-collapse: collapse; width: 100%; }
                    #gbvqg-student-inspection-report th,
                    #gbvqg-student-inspection-report td { border: 1px solid #777; padding: 5px; vertical-align: top; }
                    #gbvqg-student-inspection-report h2,
                    #gbvqg-student-inspection-report h3 { margin: 0 0 8px; }
                    #gbvqg-student-inspection-report .gbvqg-report-header { display: grid; grid-template-columns: 1fr 1fr; gap: 4px 14px; }
                }
            </style>

            <div class="gbvqg-card gbvqg-no-print">
                <h2>Production Safety Tools</h2>
                <?php $backup = $this->get_last_gate_backup(); ?>
                <p class="gbvqg-small">Gate settings are backed up before every save. v0.2.31 changes no student record on activation, disables new automatic grandfather creation, and adds read-only analysis plus targeted repair controls.</p>
                <div class="gbvqg-safety-actions">
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <?php wp_nonce_field( 'gbvqg_export_gates' ); ?>
                        <input type="hidden" name="action" value="gbvqg_export_gates" />
                        <button type="submit" class="button">Export Gate Settings JSON</button>
                    </form>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Restore the last saved gate backup? This will replace current gate mappings.');">
                        <?php wp_nonce_field( 'gbvqg_restore_last_backup' ); ?>
                        <input type="hidden" name="action" value="gbvqg_restore_last_backup" />
                        <button type="submit" class="button" <?php disabled( empty( $backup['gates'] ) ); ?>>Restore Last Backup</button>
                    </form>
                    <span class="gbvqg-small">
                        <?php if ( ! empty( $backup['created_utc'] ) ) : ?>
                            Last backup: <?php echo esc_html( $backup['created_utc'] ); ?> UTC
                            <?php if ( ! empty( $backup['gate_count'] ) ) : ?> · <?php echo esc_html( absint( $backup['gate_count'] ) ); ?> gate(s)<?php endif; ?>
                        <?php else : ?>
                            No backup has been created yet. A backup will be created the next time you save.
                        <?php endif; ?>
                    </span>
                </div>
            </div>

            <div class="gbvqg-card gbvqg-no-print">
                <h2>Course Health Summary</h2>
                <div class="gbvqg-health-grid">
                    <?php foreach ( $gates_by_course as $health_cid => $health_gates ) :
                        $health_ok = $health_invalid = $health_disabled = 0;
                        foreach ( $health_gates as $health_gate ) {
                            $health_validation = $this->validate_gate( $health_gate );
                            if ( 'invalid' === $health_validation['status'] ) {
                                $health_invalid++;
                            } elseif ( 'disabled' === $health_validation['status'] ) {
                                $health_disabled++;
                            } else {
                                $health_ok++;
                            }
                        }
                        $health_title = get_the_title( $health_cid ) ?: 'Course #' . $health_cid;
                    ?>
                        <div class="gbvqg-health-course <?php echo $health_invalid ? 'gbvqg-health-invalid' : ''; ?>">
                            <strong><?php echo esc_html( $health_title ); ?></strong><br>
                            <span class="gbvqg-small">Course #<?php echo esc_html( absint( $health_cid ) ); ?></span><br>
                            <span class="gbvqg-badge gbvqg-badge-total"><?php echo esc_html( count( $health_gates ) ); ?> gate(s)</span>
                            <span class="gbvqg-badge gbvqg-badge-ok"><?php echo esc_html( $health_ok ); ?> OK</span>
                            <?php if ( $health_disabled ) : ?><span class="gbvqg-badge gbvqg-badge-total"><?php echo esc_html( $health_disabled ); ?> disabled</span><?php endif; ?>
                            <?php if ( $health_invalid ) : ?><span class="gbvqg-badge gbvqg-badge-invalid"><?php echo esc_html( $health_invalid ); ?> invalid</span><?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                    <?php if ( empty( $gates_by_course ) ) : ?>
                        <p class="gbvqg-small">No saved gates yet.</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- ═══════════════════════════════════════════════════ -->
            <!-- Gate mappings — one collapsible section per course -->
            <!-- Clean courses start collapsed; invalid courses open automatically. -->
            <!-- ═══════════════════════════════════════════════════ -->
            <form id="gbvqg-gates-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="if (this.querySelector('input[name$=&quot;[remove]&quot;]:checked')) { return window.confirm('Remove the selected gate mapping(s)? A backup of the current mappings will be created first.'); } return true;">
                <?php wp_nonce_field( self::NONCE_ACTION ); ?>
                <input type="hidden" name="action" value="gbvqg_save_gates" />

                <?php
                $gate_idx = 0; // global index across all sections so field names stay unique

                foreach ( $gates_by_course as $cid => $course_gates ) :
                    $course_title = get_the_title( $cid ) ?: 'Course #' . $cid;

                    // Badge counts.
                    $count_ok = $count_invalid = 0;
                    foreach ( $course_gates as $g ) {
                        $v = $this->validate_gate( $g );
                        if ( in_array( $v['status'], array( 'ok', 'disabled' ), true ) ) {
                            $count_ok++;
                        } elseif ( 'invalid' === $v['status'] ) {
                            $count_invalid++;
                        }
                    }
                    $total = count( $course_gates );
                ?>
                <details class="gbvqg-course-section"<?php echo $count_invalid ? ' open' : ''; ?>>
                    <summary>
                        <h2><?php echo esc_html( $course_title ); ?> <span style="font-size:13px;font-weight:400;color:#646970;">#<?php echo esc_html( $cid ); ?></span></h2>
                        <div class="gbvqg-course-badges">
                            <span class="gbvqg-badge gbvqg-badge-total"><?php echo esc_html( $total ); ?> gate<?php echo 1 !== $total ? 's' : ''; ?></span>
                            <?php if ( $count_ok ) : ?>
                                <span class="gbvqg-badge gbvqg-badge-ok"><?php echo esc_html( $count_ok ); ?> ✓</span>
                            <?php endif; ?>
                            <?php if ( $count_invalid ) : ?>
                                <span class="gbvqg-badge gbvqg-badge-invalid"><?php echo esc_html( $count_invalid ); ?> ✗</span>
                            <?php endif; ?>
                        </div>
                    </summary>

                    <div class="gbvqg-course-inner">
                        <table class="widefat gbvqg-gate-table">
                            <thead>
                                <tr>
                                    <th>Active</th>
                                    <th>Label</th>
                                    <th>Video Lesson</th>
                                    <th>Quiz Bank</th>
                                    <th>Next Item</th>
                                    <th>Questions</th>
                                    <th>Failed attempt</th>
                                    <th>Validation</th>
                                    <th>Remove</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ( $course_gates as $gate ) :
                                $validation = $this->validate_gate( $gate );
                                $row_class  = 'invalid' === $validation['status'] ? 'gbvqg-row-invalid' : '';
                            ?>
                                <tr class="<?php echo esc_attr( $row_class ); ?>">
                                    <td>
                                        <input type="hidden" name="gates[<?php echo esc_attr( $gate_idx ); ?>][enabled_explicitly_saved_v025]" value="1" />
                                        <input type="hidden" name="gates[<?php echo esc_attr( $gate_idx ); ?>][course_id]" value="<?php echo esc_attr( $cid ); ?>" />
                                        <label><input type="checkbox" name="gates[<?php echo esc_attr( $gate_idx ); ?>][enabled]" value="1" <?php checked( $this->is_gate_enabled( $gate ) ); ?> /> Active</label>
                                    </td>
                                    <td>
                                        <input class="gbvqg-title-input" type="text"
                                            name="gates[<?php echo esc_attr( $gate_idx ); ?>][label]"
                                            value="<?php echo esc_attr( $gate['label'] ); ?>"
                                            placeholder="e.g. Module 1 Rules" />
                                    </td>
                                    <td>
                                        <?php if ( ! empty( $lesson_opts[ $cid ] ) ) : ?>
                                            <select name="gates[<?php echo esc_attr( $gate_idx ); ?>][video_lesson_id]">
                                                <option value="0">— select lesson —</option>
                                                <?php foreach ( $lesson_opts[ $cid ] as $opt ) : ?>
                                                    <option value="<?php echo esc_attr( $opt['id'] ); ?>" <?php selected( absint( $gate['video_lesson_id'] ), $opt['id'] ); ?>>
                                                        <?php echo esc_html( $opt['label'] ); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        <?php else : ?>
                                            <input class="gbvqg-input" type="number" min="0"
                                                name="gates[<?php echo esc_attr( $gate_idx ); ?>][video_lesson_id]"
                                                value="<?php echo esc_attr( absint( $gate['video_lesson_id'] ) ); ?>" />
                                            <?php if ( ! empty( $gate['video_lesson_id'] ) ) : ?>
                                                <div class="gbvqg-small"><?php echo esc_html( get_the_title( absint( $gate['video_lesson_id'] ) ) ); ?></div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ( ! empty( $quiz_opts[ $cid ] ) ) : ?>
                                            <select name="gates[<?php echo esc_attr( $gate_idx ); ?>][quiz_id]">
                                                <option value="0">— select quiz bank —</option>
                                                <?php foreach ( $quiz_opts[ $cid ] as $opt ) : ?>
                                                    <option value="<?php echo esc_attr( $opt['id'] ); ?>" <?php selected( absint( $gate['quiz_id'] ), $opt['id'] ); ?>>
                                                        <?php echo esc_html( $opt['label'] ); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        <?php else : ?>
                                            <input class="gbvqg-input" type="number" min="0"
                                                name="gates[<?php echo esc_attr( $gate_idx ); ?>][quiz_id]"
                                                value="<?php echo esc_attr( absint( $gate['quiz_id'] ) ); ?>" />
                                            <?php if ( ! empty( $gate['quiz_id'] ) ) : ?>
                                                <div class="gbvqg-small"><?php echo esc_html( get_the_title( absint( $gate['quiz_id'] ) ) ); ?></div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <input class="gbvqg-input" type="number" min="0"
                                            name="gates[<?php echo esc_attr( $gate_idx ); ?>][next_item_id]"
                                            value="<?php echo esc_attr( absint( $gate['next_item_id'] ) ); ?>" />
                                        <div class="gbvqg-small">0 = auto</div>
                                    </td>
                                    <td>
                                        <label class="gbvqg-small">Expected
                                            <input class="gbvqg-input" type="number" min="0"
                                                name="gates[<?php echo esc_attr( $gate_idx ); ?>][expected_questions]"
                                                value="<?php echo esc_attr( absint( $gate['expected_questions'] ) ); ?>" />
                                        </label><br>
                                        <label class="gbvqg-small">Show
                                            <input class="gbvqg-input" type="number" min="0"
                                                name="gates[<?php echo esc_attr( $gate_idx ); ?>][show_questions]"
                                                value="<?php echo esc_attr( absint( $gate['show_questions'] ) ); ?>" />
                                        </label>
                                    </td>
                                    <td>
                                        <select name="gates[<?php echo esc_attr( $gate_idx ); ?>][fail_mode]">
                                            <option value="return_video"      <?php selected( $gate['fail_mode'], 'return_video' ); ?>>Return to video once</option>
                                            <option value="none"              <?php selected( $gate['fail_mode'], 'none' ); ?>>No forced return</option>
                                            <option value="fresh_completion"  <?php selected( $gate['fail_mode'], 'fresh_completion' ); ?>>Strict re-completion</option>
                                        </select>
                                        <div class="gbvqg-small">Use strict only if LearnPress lets the student complete the lesson again.</div>
                                    </td>
                                    <td class="gbvqg-validation">
                                        <?php echo wp_kses_post( $this->format_validation( $validation ) ); ?>
                                        <?php echo wp_kses_post( $this->format_curriculum_hint( $gate ) ); ?>
                                    </td>
                                    <td>
                                        <label class="gbvqg-danger"><input type="checkbox" name="gates[<?php echo esc_attr( $gate_idx ); ?>][remove]" value="1" /> Remove</label>
                                        <div class="gbvqg-small">Removed when settings are saved.</div>
                                    </td>
                                </tr>
                                <?php $gate_idx++; ?>
                            <?php endforeach; ?>

                            <!-- Blank row: add a new gate to this course -->
                            <tr class="gbvqg-blank-row">
                                <td>
                                    <input type="hidden" name="gates[<?php echo esc_attr( $gate_idx ); ?>][enabled_explicitly_saved_v025]" value="1" />
                                    <input type="hidden" name="gates[<?php echo esc_attr( $gate_idx ); ?>][course_id]" value="<?php echo esc_attr( $cid ); ?>" />
                                    <label><input type="checkbox" name="gates[<?php echo esc_attr( $gate_idx ); ?>][enabled]" value="1" /> Active</label>
                                </td>
                                <td>
                                    <input class="gbvqg-title-input" type="text"
                                        name="gates[<?php echo esc_attr( $gate_idx ); ?>][label]"
                                        value="" placeholder="New gate label…" />
                                </td>
                                <td>
                                    <?php if ( ! empty( $lesson_opts[ $cid ] ) ) : ?>
                                        <select name="gates[<?php echo esc_attr( $gate_idx ); ?>][video_lesson_id]">
                                            <option value="0">— select lesson —</option>
                                            <?php foreach ( $lesson_opts[ $cid ] as $opt ) : ?>
                                                <option value="<?php echo esc_attr( $opt['id'] ); ?>"><?php echo esc_html( $opt['label'] ); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    <?php else : ?>
                                        <input class="gbvqg-input" type="number" min="0"
                                            name="gates[<?php echo esc_attr( $gate_idx ); ?>][video_lesson_id]" value="0" />
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ( ! empty( $quiz_opts[ $cid ] ) ) : ?>
                                        <select name="gates[<?php echo esc_attr( $gate_idx ); ?>][quiz_id]">
                                            <option value="0">— select quiz bank —</option>
                                            <?php foreach ( $quiz_opts[ $cid ] as $opt ) : ?>
                                                <option value="<?php echo esc_attr( $opt['id'] ); ?>"><?php echo esc_html( $opt['label'] ); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    <?php else : ?>
                                        <input class="gbvqg-input" type="number" min="0"
                                            name="gates[<?php echo esc_attr( $gate_idx ); ?>][quiz_id]" value="0" />
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <input class="gbvqg-input" type="number" min="0"
                                        name="gates[<?php echo esc_attr( $gate_idx ); ?>][next_item_id]" value="0" />
                                    <div class="gbvqg-small">0 = auto</div>
                                </td>
                                <td>
                                    <label class="gbvqg-small">Expected <input class="gbvqg-input" type="number" min="0" name="gates[<?php echo esc_attr( $gate_idx ); ?>][expected_questions]" value="4" /></label><br>
                                    <label class="gbvqg-small">Show <input class="gbvqg-input" type="number" min="0" name="gates[<?php echo esc_attr( $gate_idx ); ?>][show_questions]" value="1" /></label>
                                </td>
                                <td>
                                    <select name="gates[<?php echo esc_attr( $gate_idx ); ?>][fail_mode]">
                                        <option value="return_video">Return to video once</option>
                                        <option value="none">No forced return</option>
                                        <option value="fresh_completion">Strict re-completion</option>
                                    </select>
                                </td>
                                <td class="gbvqg-small">Fill in above to add a gate.</td>
                                <td class="gbvqg-small">—</td>
                            </tr>
                            <?php $gate_idx++; ?>
                            </tbody>
                        </table>
                    </div><!-- .gbvqg-course-inner -->
                </details>
                <?php endforeach; ?>

                <!-- ── New course gate ── -->
                <details class="gbvqg-course-section gbvqg-new-course-section">
                    <summary>
                        <h2>Add a gate for a new or unlisted course</h2>
                    </summary>
                    <div class="gbvqg-course-inner">
                        <p class="gbvqg-small">Enter the Course ID, then use the Course Item Reader below to look up the Video Lesson ID and Quiz Bank ID for that course. Once saved, the course will appear as its own section above.</p>
                        <table class="widefat gbvqg-gate-table">
                            <thead>
                                <tr>
                                    <th>Active</th><th>Label</th><th>Course ID</th>
                                    <th>Video Lesson ID</th><th>Quiz Bank ID</th>
                                    <th>Next Item ID</th><th>Questions</th><th>Failed attempt</th>
                                </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>
                                    <input type="hidden" name="gates[<?php echo esc_attr( $gate_idx ); ?>][enabled_explicitly_saved_v025]" value="1" />
                                    <label><input type="checkbox" name="gates[<?php echo esc_attr( $gate_idx ); ?>][enabled]" value="1" /> Active</label>
                                </td>
                                <td><input class="gbvqg-title-input" type="text" name="gates[<?php echo esc_attr( $gate_idx ); ?>][label]" value="" placeholder="e.g. Module 1 Rules" /></td>
                                <td><input class="gbvqg-input" type="number" min="0" name="gates[<?php echo esc_attr( $gate_idx ); ?>][course_id]" value="0" /></td>
                                <td><input class="gbvqg-input" type="number" min="0" name="gates[<?php echo esc_attr( $gate_idx ); ?>][video_lesson_id]" value="0" /></td>
                                <td><input class="gbvqg-input" type="number" min="0" name="gates[<?php echo esc_attr( $gate_idx ); ?>][quiz_id]" value="0" /></td>
                                <td>
                                    <input class="gbvqg-input" type="number" min="0" name="gates[<?php echo esc_attr( $gate_idx ); ?>][next_item_id]" value="0" />
                                    <div class="gbvqg-small">0 = auto</div>
                                </td>
                                <td>
                                    <label class="gbvqg-small">Expected <input class="gbvqg-input" type="number" min="0" name="gates[<?php echo esc_attr( $gate_idx ); ?>][expected_questions]" value="4" /></label><br>
                                    <label class="gbvqg-small">Show <input class="gbvqg-input" type="number" min="0" name="gates[<?php echo esc_attr( $gate_idx ); ?>][show_questions]" value="1" /></label>
                                </td>
                                <td>
                                    <select name="gates[<?php echo esc_attr( $gate_idx ); ?>][fail_mode]">
                                        <option value="return_video">Return to video once</option>
                                        <option value="none">No forced return</option>
                                        <option value="fresh_completion">Strict re-completion</option>
                                    </select>
                                </td>
                            </tr>
                            <?php $gate_idx++; ?>
                            </tbody>
                        </table>
                    </div>
                </details>

                <p style="margin-top: 16px;">
                    <button type="submit" class="button button-primary button-large">Save all gate mappings</button>
                </p>
            </form>

            <!-- Course Item Reader -->
            <div class="gbvqg-card">
                <h2>Course Item Reader</h2>
                <form method="get">
                    <input type="hidden" name="page" value="gb-video-quiz-gate" />
                    <select name="gbvqg_reader_course">
                        <option value="0">Select a LearnPress course…</option>
                        <?php foreach ( $courses as $course ) : ?>
                            <option value="<?php echo esc_attr( $course->ID ); ?>" <?php selected( $reader_course, $course->ID ); ?>>
                                <?php echo esc_html( $course->post_title . ' #' . $course->ID ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button class="button">Load Course Items</button>
                </form>
                <?php if ( $reader_course ) :
                    $items = $this->get_course_items( $reader_course );
                    ?>
                    <h3><?php echo esc_html( get_the_title( $reader_course ) ); ?> #<?php echo esc_html( $reader_course ); ?></h3>
                    <?php if ( empty( $items ) ) : ?>
                        <p class="gbvqg-invalid">No curriculum items found through the LearnPress section tables.</p>
                    <?php else : ?>
                        <table class="widefat striped">
                            <thead><tr><th>#</th><th>Section</th><th>Title</th><th>Type</th><th>ID</th><th>Timer meta</th><th>Course item URL</th></tr></thead>
                            <tbody>
                            <?php foreach ( $items as $idx => $item ) :
                                $timer = get_post_meta( $item['item_id'], '_ds_required_seconds', true );
                                $url   = $this->get_course_item_url( $reader_course, $item['item_id'] );
                                ?>
                                <tr>
                                    <td><?php echo esc_html( $idx + 1 ); ?></td>
                                    <td><?php echo esc_html( $item['section_name'] ); ?></td>
                                    <td><?php echo esc_html( get_the_title( $item['item_id'] ) ); ?></td>
                                    <td><span class="gbvqg-code"><?php echo esc_html( get_post_type( $item['item_id'] ) ); ?></span></td>
                                    <td><span class="gbvqg-code"><?php echo esc_html( $item['item_id'] ); ?></span></td>
                                    <td><?php echo $timer ? esc_html( $timer . ' sec' ) : '<span class="gbvqg-small">not written yet</span>'; ?></td>
                                    <td><a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener noreferrer">open</a></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <!-- Student Inspection Report -->
            <div class="gbvqg-card">
                <h2>Student Inspection Report</h2>
                <p class="gbvqg-small">Print a student-specific video validation and progress-handoff record. When a student is stuck after a video quiz, load this report <strong>before</strong> using Course Progress Fix so the original LearnPress rows and recognition state remain visible.</p>
                <form class="gbvqg-no-print" method="get" action="">
                    <input type="hidden" name="page" value="gb-video-quiz-gate" />
                    <input type="hidden" name="gbvqg_report" value="1" />
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><label for="gbvqg_report_user">Student User ID</label></th>
                            <td><input id="gbvqg_report_user" class="regular-text" style="max-width:160px;" type="number" min="0" name="gbvqg_report_user" value="<?php echo esc_attr( $report_user_id ); ?>" /></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="gbvqg_report_course">Course ID</label></th>
                            <td><input id="gbvqg_report_course" class="regular-text" style="max-width:160px;" type="number" min="0" name="gbvqg_report_course" value="<?php echo esc_attr( $report_course_id ); ?>" /></td>
                        </tr>
                        <tr>
                            <th scope="row">Date range <span class="gbvqg-small">(Texas/Central date)</span></th>
                            <td>
                                <input type="date" name="gbvqg_report_from" value="<?php echo esc_attr( $report_from ); ?>" />
                                to
                                <input type="date" name="gbvqg_report_to" value="<?php echo esc_attr( $report_to ); ?>" />
                                <span class="gbvqg-small">Optional. Uses Texas/Central business dates: <?php echo esc_html( $this->get_report_timezone_label() ); ?>. WordPress site timezone is currently <?php echo esc_html( $this->get_site_timezone_label() ); ?>.</span>
                            </td>
                        </tr>
                    </table>
                    <p>
                        <button class="button button-primary">Load Report</button>
                        <?php if ( $report_requested ) : ?>
                            <button type="button" class="button" onclick="window.print();">Print Report</button>
                        <?php endif; ?>
                    </p>
                </form>

                <?php if ( $report_requested ) : ?>
                    <?php
                    $student       = $report_user_id ? get_userdata( $report_user_id ) : false;
                    $current_admin = wp_get_current_user();
                    $first_course_id = $report_course_id;
                    if ( ! $first_course_id && ! empty( $report_events[0]['course_id'] ) ) {
                        $first_course_id = absint( $report_events[0]['course_id'] );
                    }
                    ?>
                    <div id="gbvqg-student-inspection-report">
                        <h2>Gulf Breeze Driving School</h2>
                        <h3>Video Validation Inspection Report</h3>
                        <div class="gbvqg-report-header">
                            <div><strong>Generated UTC:</strong> <?php echo esc_html( gmdate( 'Y-m-d H:i:s' ) ); ?></div>
                            <div><strong>Generated by:</strong> <?php echo esc_html( $current_admin && $current_admin->exists() ? $current_admin->display_name . ' (user #' . $current_admin->ID . ')' : 'Administrator' ); ?></div>
                            <div><strong>Student User ID:</strong> <?php echo esc_html( $report_user_id ? $report_user_id : 'Not filtered' ); ?></div>
                            <div><strong>Student Name:</strong> <?php echo esc_html( $student ? $student->display_name : ( $report_user_id ? 'User not found' : 'Not filtered' ) ); ?></div>
                            <div><strong>Student Email:</strong> <?php echo esc_html( $student ? $student->user_email : '' ); ?></div>
                            <div><strong>Course:</strong> <?php echo esc_html( $first_course_id ? ( $first_course_id . ' — ' . get_the_title( $first_course_id ) ) : 'Not filtered' ); ?></div>
                            <div><strong>Date Range:</strong> <?php echo esc_html( ( $report_from ? $report_from : 'beginning' ) . ' to ' . ( $report_to ? $report_to : 'present' ) ); ?> <span class="gbvqg-small">(Texas/Central, <?php echo esc_html( $this->get_report_timezone_label() ); ?>)</span></div>
                            <div><strong>UTC Window Used:</strong> <?php echo esc_html( ( $report_from ? $this->report_local_date_to_utc( $report_from, false ) : 'beginning' ) . ' to ' . ( $report_to ? $this->report_local_date_to_utc( $report_to, true ) : 'present' ) ); ?></div>
                            <div><strong>Total Events in Report:</strong> <?php echo esc_html( count( $report_events ) ); ?></div>
                        </div>
                        <?php if ( empty( $report_events ) ) : ?>
                            <p><strong>No matching video validation events found.</strong></p>
                            <p class="gbvqg-small">Tip: v0.2.17 treats the selected date range as the Texas/Central business date and converts it to UTC for matching. The UTC window used is shown above.</p>
                        <?php else : ?>
                            <table class="widefat striped gbvqg-report-table">
                                <thead>
                                    <tr>
                                        <th>UTC Timestamp</th><th>Event</th><th>Student User ID</th><th>Course ID</th>
                                        <th>Video Lesson ID</th><th>Quiz Bank ID</th><th>Question ID Selected</th>
                                        <th>Submitted Answer</th><th>Correct?</th><th>Returned to Video?</th><th>Attempt / Rewatch</th><th>Diagnostic Details</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach ( $report_events as $event ) :
                                    $details = isset( $event['details'] ) && is_array( $event['details'] ) ? $event['details'] : array();
                                    $qid = ! empty( $details['question_id_selected'] ) ? absint( $details['question_id_selected'] ) : ( ! empty( $details['selected'][0] ) ? absint( $details['selected'][0] ) : 0 );
                                    $answer = '';
                                    if ( ! empty( $details['submitted_answer_id'] ) || ! empty( $details['submitted_answer_text'] ) ) {
                                        $answer = trim( (string) ( $details['submitted_answer_id'] ?? '' ) . ( ! empty( $details['submitted_answer_text'] ) ? ' — ' . $details['submitted_answer_text'] : '' ) );
                                    }
                                    $correct  = array_key_exists( 'answer_correct', $details ) && null !== $details['answer_correct'] ? ( $details['answer_correct'] ? 'Correct' : 'Incorrect' ) : '';
                                    $returned = ! empty( $details['returned_to_video'] ) ? 'Yes' : ( array_key_exists( 'returned_to_video', $details ) ? 'No' : '' );
                                    $attempt_parts = array();
                                    if ( ! empty( $details['attempt_no'] ) )                    { $attempt_parts[] = 'Attempt ' . absint( $details['attempt_no'] ); }
                                    if ( ! empty( $details['rewatch_cycle'] ) )                 { $attempt_parts[] = 'Rewatch ' . absint( $details['rewatch_cycle'] ); }
                                    if ( ! empty( $details['next_question_after_rewatch'] ) )   { $attempt_parts[] = 'Next question after rewatch'; }
                                ?>
                                    <tr>
                                        <td><?php echo esc_html( $event['time'] ?? '' ); ?></td>
                                        <td><?php echo esc_html( $event['event'] ?? '' ); ?></td>
                                        <td><?php echo esc_html( $event['user_id'] ?? '' ); ?></td>
                                        <td><?php echo esc_html( ( $event['course_id'] ?? '' ) . ( ! empty( $event['course_id'] ) ? ' — ' . get_the_title( absint( $event['course_id'] ) ) : '' ) ); ?></td>
                                        <td><?php echo esc_html( ( $event['lesson_id'] ?? '' ) . ( ! empty( $event['lesson_id'] ) ? ' — ' . get_the_title( absint( $event['lesson_id'] ) ) : '' ) ); ?></td>
                                        <td><?php echo esc_html( ( $event['quiz_id'] ?? '' ) . ( ! empty( $event['quiz_id'] ) ? ' — ' . get_the_title( absint( $event['quiz_id'] ) ) : '' ) ); ?></td>
                                        <td><?php echo esc_html( $qid ? $qid . ' — ' . get_the_title( $qid ) : '' ); ?></td>
                                        <td><?php echo esc_html( $answer ); ?></td>
                                        <td><?php echo esc_html( $correct ); ?></td>
                                        <td><?php echo esc_html( $returned ); ?></td>
                                        <td><?php echo esc_html( implode( ' / ', $attempt_parts ) ); ?></td>
                                        <td><pre style="white-space:pre-wrap;max-width:720px;word-break:break-word;"><?php echo esc_html( wp_json_encode( $details, JSON_PRETTY_PRINT ) ); ?></pre></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                            <p class="gbvqg-small"><strong>Note:</strong> This report includes video-validation events, the raw LearnPress progress rows written by the gate, and the next-item recognition probe used to diagnose a post-quiz lock before repair.</p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Gate State Audit and Targeted Repair -->
            <div class="gbvqg-card gbvqg-no-print" id="gbvqg-gate-state-repair">
                <h2>Gate State Mismatch Audit &amp; Targeted Repair</h2>
                <p>This tool does not change any student during analysis or audit. It separates a verified video-check pass, a documented exemption, an administrator-required quiz, and an unresolved legacy grandfather mismatch.</p>

                <form method="get" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap;">
                    <input type="hidden" name="page" value="gb-video-quiz-gate" />
                    <p><label><strong>Student User ID</strong><br><input type="number" min="1" name="gbvqg_repair_user" value="<?php echo esc_attr( $repair_user_id ); ?>" required></label></p>
                    <p><label><strong>Gate</strong><br><select name="gbvqg_repair_gate" required>
                        <option value="">Select a gate…</option>
                        <?php foreach ( $all_gates as $repair_gate_option ) :
                            $repair_option_id = $this->gate_id( $repair_gate_option ); ?>
                            <option value="<?php echo esc_attr( $repair_option_id ); ?>" <?php selected( $repair_gate_id, $repair_option_id ); ?>><?php echo esc_html( ( $repair_gate_option['label'] ?? 'Video gate' ) . ' — Course #' . absint( $repair_gate_option['course_id'] ?? 0 ) . ' / Quiz #' . absint( $repair_gate_option['quiz_id'] ?? 0 ) ); ?></option>
                        <?php endforeach; ?>
                    </select></label></p>
                    <p><button class="button button-primary">Analyze Student Gate</button></p>
                </form>

                <?php if ( $repair_analysis ) :
                    $repair_user = get_userdata( $repair_user_id );
                    $repair_class = (string) ( $repair_analysis['classification'] ?? 'unknown' );
                    $repair_state = is_array( $repair_analysis['state'] ?? null ) ? $repair_analysis['state'] : array();
                ?>
                    <h3>Read-Only Analysis</h3>
                    <table class="widefat striped" style="max-width:1100px;">
                        <tbody>
                            <tr><th style="width:250px;">Student</th><td><?php echo esc_html( $repair_user ? $repair_user->display_name . ' (#' . $repair_user_id . ')' : 'User #' . $repair_user_id ); ?></td></tr>
                            <tr><th>Gate</th><td><?php echo esc_html( ( $repair_gate['label'] ?? 'Video gate' ) . ' / Video #' . absint( $repair_gate['video_lesson_id'] ?? 0 ) . ' / Quiz #' . absint( $repair_gate['quiz_id'] ?? 0 ) ); ?></td></tr>
                            <tr><th>Course policy</th><td><strong><?php echo esc_html( $this->course_policy_label( absint( $repair_gate['course_id'] ?? 0 ) ) ); ?></strong></td></tr>
                            <tr><th>Classification</th><td><strong><?php echo esc_html( $this->gate_evidence_label( $repair_class ) ); ?></strong></td></tr>
                            <tr><th>Private gate says passed</th><td><?php echo ! empty( $repair_analysis['state_claims_pass'] ) ? 'Yes' : 'No'; ?></td></tr>
                            <tr><th>Force quiz marker</th><td><?php echo ! empty( $repair_analysis['force_validation_required'] ) ? 'Yes' : 'No'; ?></td></tr>
                            <tr><th>Verified passing attempt</th><td><?php echo ! empty( $repair_analysis['verified_pass_attempt'] ) ? 'Yes' : 'No'; ?></td></tr>
                            <tr><th>LearnPress status</th><td><?php echo esc_html( (string) ( $repair_analysis['lp_state']['status'] ?? 'unknown' ) ); ?> / user_item_id <?php echo esc_html( absint( $repair_analysis['lp_state']['user_item_id'] ?? 0 ) ); ?></td></tr>
                            <tr><th>Sequential Drip would lock next item</th><td><?php echo ! empty( $repair_analysis['would_sequential_drip_lock'] ) ? 'Yes' : 'No'; ?></td></tr>
                            <tr><th>Grandfather reason</th><td><?php echo esc_html( (string) ( $repair_state['grandfather_reason'] ?? '' ) ); ?></td></tr>
                            <tr><th>Raw private state</th><td><pre style="white-space:pre-wrap;word-break:break-word;max-width:800px;"><?php echo esc_html( wp_json_encode( $repair_state, JSON_PRETTY_PRINT ) ); ?></pre></td></tr>
                            <tr><th>LearnPress rows</th><td><pre style="white-space:pre-wrap;word-break:break-word;max-width:800px;"><?php echo esc_html( wp_json_encode( $repair_analysis['lp_rows'] ?? array(), JSON_PRETTY_PRINT ) ); ?></pre></td></tr>
                        </tbody>
                    </table>

                    <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:16px;align-items:flex-start;">
                        <?php if ( in_array( $repair_class, array( 'unverified_legacy_grandfather', 'quiz_required_by_admin' ), true ) ) : ?>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Require this student to take this specific video quiz? Only this student and gate will be changed.');">
                                <?php wp_nonce_field( 'gbvqg_repair_gate_state' ); ?>
                                <input type="hidden" name="action" value="gbvqg_repair_gate_state">
                                <input type="hidden" name="repair_mode" value="require_quiz">
                                <input type="hidden" name="student_user_id" value="<?php echo esc_attr( $repair_user_id ); ?>">
                                <input type="hidden" name="gate_id" value="<?php echo esc_attr( $repair_gate_id ); ?>">
                                <input type="hidden" name="return_url" value="<?php echo esc_url( $this->current_admin_repair_url( $repair_user_id, $repair_gate_id ) ); ?>">
                                <button class="button button-primary">Require This Quiz</button>
                            </form>
                        <?php endif; ?>

                        <?php if ( 'verified_attempt_missing_learnpress' === $repair_class ) : ?>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Rebuild the LearnPress quiz row from the verified passing attempt shown above?');">
                                <?php wp_nonce_field( 'gbvqg_repair_gate_state' ); ?>
                                <input type="hidden" name="action" value="gbvqg_repair_gate_state">
                                <input type="hidden" name="repair_mode" value="rebuild_from_attempt">
                                <input type="hidden" name="student_user_id" value="<?php echo esc_attr( $repair_user_id ); ?>">
                                <input type="hidden" name="gate_id" value="<?php echo esc_attr( $repair_gate_id ); ?>">
                                <input type="hidden" name="return_url" value="<?php echo esc_url( $this->current_admin_repair_url( $repair_user_id, $repair_gate_id ) ); ?>">
                                <button class="button button-primary">Rebuild From Verified Attempt</button>
                            </form>
                        <?php endif; ?>

                        <?php if ( in_array( $repair_class, array( 'unverified_legacy_grandfather', 'quiz_required_by_admin' ), true ) && ! $this->is_retired_legacy_course( absint( $repair_gate['course_id'] ?? 0 ) ) ) : ?>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Grant a documented exemption instead of requiring this quiz? This records an exemption, not a scored quiz pass.');" style="border:1px solid #dcdcde;padding:10px;">
                                <?php wp_nonce_field( 'gbvqg_repair_gate_state' ); ?>
                                <input type="hidden" name="action" value="gbvqg_repair_gate_state">
                                <input type="hidden" name="repair_mode" value="grant_exemption">
                                <input type="hidden" name="student_user_id" value="<?php echo esc_attr( $repair_user_id ); ?>">
                                <input type="hidden" name="gate_id" value="<?php echo esc_attr( $repair_gate_id ); ?>">
                                <input type="hidden" name="return_url" value="<?php echo esc_url( $this->current_admin_repair_url( $repair_user_id, $repair_gate_id ) ); ?>">
                                <label><strong>Documented exemption reason</strong><br><input type="text" name="exemption_reason" minlength="10" style="width:420px;max-width:100%;" required></label><br>
                                <button class="button" style="margin-top:8px;">Grant Documented Exemption</button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <hr style="margin:22px 0;">
                <form method="get" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap;">
                    <input type="hidden" name="page" value="gb-video-quiz-gate" />
                    <input type="hidden" name="gbvqg_mismatch_audit" value="1" />
                    <p><label><strong>Course filter</strong><br><select name="gbvqg_audit_course">
                        <option value="0">All mapped courses</option>
                        <?php foreach ( array_keys( $gates_by_course ) as $policy_course_id ) : ?>
                            <option value="<?php echo esc_attr( $policy_course_id ); ?>" <?php selected( $audit_course_id, $policy_course_id ); ?>>#<?php echo esc_html( $policy_course_id . ' — ' . $this->course_policy_label( $policy_course_id ) ); ?></option>
                        <?php endforeach; ?>
                    </select></label></p>
                    <p><button class="button">Run Read-Only Gate-State Audit</button></p>
                    <span class="gbvqg-small">Scans saved Video Quiz Gate state only; it does not change students.</span>
                </form>

                <?php if ( $audit_requested ) : ?>
                    <h3>Audit Results</h3>
                    <?php if ( empty( $audit_rows ) ) : ?>
                        <p>No saved gate-state mismatches or repair candidates were found.</p>
                    <?php else : ?>
                        <table class="widefat striped">
                            <thead><tr><th>Student</th><th>Course / Gate</th><th>Policy</th><th>Classification</th><th>LearnPress</th><th>Action</th></tr></thead>
                            <tbody>
                            <?php foreach ( $audit_rows as $audit_row ) : ?>
                                <tr>
                                    <td><?php echo esc_html( $audit_row['student_label'] ); ?></td>
                                    <td><?php echo esc_html( $audit_row['gate_label'] ); ?></td>
                                    <td><?php echo esc_html( $audit_row['policy_label'] ); ?></td>
                                    <td><strong><?php echo esc_html( $this->gate_evidence_label( $audit_row['classification'] ) ); ?></strong></td>
                                    <td><?php echo esc_html( $audit_row['lp_status'] . ' / row #' . absint( $audit_row['lp_user_item_id'] ) ); ?></td>
                                    <td><a class="button button-small" href="<?php echo esc_url( $this->current_admin_repair_url( $audit_row['user_id'], $audit_row['gate_id'] ) ); ?>">Analyze</a></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <!-- Retired Course Legacy Reconciliation -->
            <div class="gbvqg-card gbvqg-no-print" id="gbvqg-retired-course-reconciliation">
                <h2>Retired Course Legacy Reconciliation</h2>
                <p>No retired-course identifiers are built into this Gulf Breeze release. Historical reconciliation is available only when a retired course is explicitly registered by a Gulf Breeze migration.</p>
                <p><strong>This tool does not send anything to TDLR.</strong> It prepares clear course records for your front office certificate workflow.</p>

                <form method="get" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap;">
                    <input type="hidden" name="page" value="gb-video-quiz-gate" />
                    <input type="hidden" name="gbvqg_legacy_preview" value="1" />
                    <p><label><strong>Retired course</strong><br><select name="gbvqg_legacy_course" required>
                        <option value="">Select…</option>
                        <?php foreach ( apply_filters( 'gbvqg_retired_course_ids', array() ) as $retired_course_id ) : ?>
                            <option value="<?php echo esc_attr( $retired_course_id ); ?>" <?php selected( $legacy_course_id, $retired_course_id ); ?>>#<?php echo esc_html( $retired_course_id . ' — ' . get_the_title( $retired_course_id ) ); ?></option>
                        <?php endforeach; ?>
                    </select></label></p>
                    <p><button class="button button-primary">Preview Retired-Course Reconciliation</button></p>
                </form>

                <?php if ( $legacy_preview_requested && $this->is_retired_legacy_course( $legacy_course_id ) ) : ?>
                    <h3>Read-Only Preview — Course #<?php echo esc_html( $legacy_course_id ); ?></h3>
                    <?php if ( empty( $legacy_rows ) ) : ?>
                        <p>No saved legacy gate records were found for this course.</p>
                    <?php else : ?>
                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Apply documented retired-course legacy exemptions only to the selected eligible records? Existing lesson, quiz, score, and seat-time progress will not be removed or reset.');">
                            <?php wp_nonce_field( 'gbvqg_reconcile_retired_course' ); ?>
                            <input type="hidden" name="action" value="gbvqg_reconcile_retired_course">
                            <input type="hidden" name="course_id" value="<?php echo esc_attr( $legacy_course_id ); ?>">
                            <input type="hidden" name="return_url" value="<?php echo esc_url( add_query_arg( array( 'page' => 'gb-video-quiz-gate', 'gbvqg_legacy_preview' => 1, 'gbvqg_legacy_course' => $legacy_course_id ), admin_url( 'admin.php' ) ) ); ?>">
                            <table class="widefat striped">
                                <thead><tr><th style="width:42px;">Apply</th><th>Student</th><th>Gate</th><th>Video</th><th>Verified later progress</th><th>Classification</th><th>Proposed record</th></tr></thead>
                                <tbody>
                                <?php foreach ( $legacy_rows as $legacy_row ) :
                                    $eligible = 'eligible_retired_legacy_exemption' === ( $legacy_row['legacy_classification'] ?? '' ); ?>
                                    <tr>
                                        <td><?php if ( $eligible ) : ?><input type="checkbox" name="legacy_records[]" value="<?php echo esc_attr( absint( $legacy_row['user_id'] ) . ':' . sanitize_key( $legacy_row['gate_id'] ) ); ?>"><?php else : ?>—<?php endif; ?></td>
                                        <td><?php echo esc_html( $legacy_row['student_label'] ); ?></td>
                                        <td><?php echo esc_html( $legacy_row['gate_label'] ); ?></td>
                                        <td><?php echo esc_html( ! empty( $legacy_row['video_completed'] ) ? 'Completed' : 'Not verified' ); ?></td>
                                        <td><?php echo esc_html( ! empty( $legacy_row['later_completed']['item_id'] ) ? '#' . absint( $legacy_row['later_completed']['item_id'] ) . ' — ' . (string) $legacy_row['later_completed']['title'] . ' (' . (string) $legacy_row['later_completed']['status'] . ')' : 'None found' ); ?></td>
                                        <td><strong><?php echo esc_html( $this->retired_legacy_classification_label( $legacy_row['legacy_classification'] ?? '' ) ); ?></strong></td>
                                        <td><?php echo esc_html( $legacy_row['proposed_record'] ); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                            <p><label><strong>Front-office record reason</strong><br><input type="text" name="legacy_reason" minlength="20" value="Retired course closeout: required video completed and verified later course progress exists. No scored video-quiz attempt is claimed." style="width:900px;max-width:100%;" required></label></p>
                            <p><button class="button button-primary">Apply Selected Documented Legacy Exemptions</button></p>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <!-- Recent Gate Events -->
            <div class="gbvqg-card">
                <h2>Recent Gate Events</h2>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="float:right;">
                    <?php wp_nonce_field( 'gbvqg_clear_events' ); ?>
                    <input type="hidden" name="action" value="gbvqg_clear_events" />
                    <button class="button">Clear Events</button>
                </form>
                <?php if ( empty( $events ) ) : ?>
                    <p>No events yet.</p>
                <?php else : ?>
                    <table class="widefat striped">
                        <thead>
                            <tr>
                                <th>UTC Time</th><th>Event</th><th>Student User ID</th><th>Course ID</th>
                                <th>Video Lesson ID</th><th>Quiz Bank ID</th><th>Question ID Selected</th>
                                <th>Answer Choice Submitted</th><th>Correct?</th><th>Returned to Video?</th>
                                <th>Attempt / Rewatch</th><th>Details</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ( $events as $event ) :
                            $details = isset( $event['details'] ) && is_array( $event['details'] ) ? $event['details'] : array();
                            $question_id_selected = ! empty( $details['question_id_selected'] ) ? absint( $details['question_id_selected'] ) : ( ! empty( $details['selected'][0] ) ? absint( $details['selected'][0] ) : 0 );
                            $submitted_answer = '';
                            if ( ! empty( $details['submitted_answer_id'] ) || ! empty( $details['submitted_answer_text'] ) ) {
                                $submitted_answer = trim( (string) ( $details['submitted_answer_id'] ?? '' ) . ( ! empty( $details['submitted_answer_text'] ) ? ' — ' . $details['submitted_answer_text'] : '' ) );
                            }
                            $correct_label  = array_key_exists( 'answer_correct', $details ) && null !== $details['answer_correct'] ? ( $details['answer_correct'] ? 'Yes' : 'No' ) : '';
                            $returned_label = ! empty( $details['returned_to_video'] ) ? 'Yes' : ( array_key_exists( 'returned_to_video', $details ) ? 'No' : '' );
                            $attempt_rewatch = array();
                            if ( ! empty( $details['attempt_no'] ) )                    { $attempt_rewatch[] = 'Attempt ' . absint( $details['attempt_no'] ); }
                            if ( ! empty( $details['rewatch_cycle'] ) )                 { $attempt_rewatch[] = 'Rewatch ' . absint( $details['rewatch_cycle'] ); }
                            if ( ! empty( $details['next_question_after_rewatch'] ) )   { $attempt_rewatch[] = 'Next after rewatch'; }
                        ?>
                            <tr>
                                <td><?php echo esc_html( $event['time'] ?? '' ); ?></td>
                                <td><span class="gbvqg-code"><?php echo esc_html( $event['event'] ?? '' ); ?></span></td>
                                <td><?php echo esc_html( $event['user_id'] ?? '' ); ?></td>
                                <td><?php echo esc_html( ( $event['course_id'] ?? '' ) . ( ! empty( $event['course_id'] ) ? ' — ' . get_the_title( absint( $event['course_id'] ) ) : '' ) ); ?></td>
                                <td><?php echo esc_html( ( $event['lesson_id'] ?? '' ) . ( ! empty( $event['lesson_id'] ) ? ' — ' . get_the_title( absint( $event['lesson_id'] ) ) : '' ) ); ?></td>
                                <td><?php echo esc_html( ( $event['quiz_id'] ?? '' ) . ( ! empty( $event['quiz_id'] ) ? ' — ' . get_the_title( absint( $event['quiz_id'] ) ) : '' ) ); ?></td>
                                <td><?php echo esc_html( $question_id_selected ? $question_id_selected . ' — ' . get_the_title( $question_id_selected ) : '' ); ?></td>
                                <td><?php echo esc_html( $submitted_answer ); ?></td>
                                <td><?php echo esc_html( $correct_label ); ?></td>
                                <td><?php echo esc_html( $returned_label ); ?></td>
                                <td><?php echo esc_html( implode( ' / ', $attempt_rewatch ) ); ?></td>
                                <td><pre style="white-space:pre-wrap;max-width:450px;margin:0;"><?php echo esc_html( wp_json_encode( $details, JSON_PRETTY_PRINT ) ); ?></pre></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    private function get_report_timezone() {
        // Inspection reports use Texas business dates.
        // The WordPress timezone on staging may be UTC (+00:00), which caused
        // evening Texas events stored as next-day UTC to disappear from reports.
        return new DateTimeZone( 'America/Chicago' );
    }

    private function get_report_timezone_label() {
        return 'America/Chicago (Texas/Central)';
    }

    private function report_local_date_to_utc( $date, $end_of_day = false ) {
        $date = (string) $date;
        if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
            return '';
        }

        $time = $end_of_day ? '23:59:59' : '00:00:00';

        try {
            $dt = new DateTimeImmutable( $date . ' ' . $time, $this->get_report_timezone() );
            return $dt->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
        } catch ( Exception $e ) {
            return $date . ' ' . $time;
        }
    }

    private function get_site_timezone_label() {
        if ( function_exists( 'wp_timezone_string' ) ) {
            $label = wp_timezone_string();
            if ( $label ) {
                return $label;
            }
        }

        $offset = (float) get_option( 'gmt_offset', 0 );
        $sign   = $offset < 0 ? '-' : '+';
        $abs    = abs( $offset );
        $hours  = floor( $abs );
        $mins   = ( $abs - $hours ) * 60;

        return sprintf( 'UTC%s%02d:%02d', $sign, $hours, $mins );
    }

    private function filter_inspection_report_events( $events, $user_id = 0, $course_id = 0, $date_from = '', $date_to = '' ) {
        $events = is_array( $events ) ? $events : array();
        $user_id = absint( $user_id );
        $course_id = absint( $course_id );

        // v0.2.16: The stored event timestamps are UTC, but inspectors/admins pick
        // calendar dates in the site's local timezone. Convert the chosen local
        // calendar day boundaries to UTC so evening Texas events do not disappear
        // into the next UTC date.
        $date_from = $this->report_local_date_to_utc( $date_from, false );
        $date_to   = $this->report_local_date_to_utc( $date_to, true );

        $allowed_events = array(
            'validation_question_selected',
            'validation_submit_received',
            'validation_answer_correct',
            'validation_answer_wrong',
            'rewatch_video_visited',
            'redirect_later_item_to_video_after_fail',
            'redirect_lp_quiz_to_custom_validation',
            'redirect_passed_quiz_to_mapped_next_item',
            'quiz_passed',
            'quiz_failed',
        );

        $filtered = array();
        foreach ( $events as $event ) {
            if ( ! is_array( $event ) ) {
                continue;
            }

            if ( ! empty( $event['event'] ) && ! in_array( (string) $event['event'], $allowed_events, true ) ) {
                continue;
            }

            if ( $user_id && absint( $event['user_id'] ?? 0 ) !== $user_id ) {
                continue;
            }

            if ( $course_id && absint( $event['course_id'] ?? 0 ) !== $course_id ) {
                continue;
            }

            $time = (string) ( $event['time'] ?? '' );
            if ( $date_from && $time && strcmp( $time, $date_from ) < 0 ) {
                continue;
            }
            if ( $date_to && $time && strcmp( $time, $date_to ) > 0 ) {
                continue;
            }

            $filtered[] = $event;
        }

        return array_reverse( $filtered );
    }

    private function backup_gate_settings( $reason = 'manual' ) {
        $current_gates = get_option( self::OPTION_GATES, array() );
        if ( ! is_array( $current_gates ) ) {
            $current_gates = array();
        }

        $backup = array(
            'created_utc'   => gmdate( 'Y-m-d H:i:s' ),
            'reason'        => sanitize_key( $reason ),
            'admin_user_id' => get_current_user_id(),
            'gate_count'    => count( $current_gates ),
            'gates'         => $current_gates,
        );

        update_option( self::OPTION_BACKUP_LAST, $backup, false );

        $history = get_option( self::OPTION_BACKUP_HISTORY, array() );
        if ( ! is_array( $history ) ) {
            $history = array();
        }
        array_unshift( $history, $backup );
        $history = array_slice( $history, 0, 10 );
        update_option( self::OPTION_BACKUP_HISTORY, $history, false );
    }

    private function get_last_gate_backup() {
        $backup = get_option( self::OPTION_BACKUP_LAST, array() );
        return is_array( $backup ) ? $backup : array();
    }

    private function format_curriculum_hint( $gate ) {
        $course_id = absint( $gate['course_id'] ?? 0 );
        $lesson_id = absint( $gate['video_lesson_id'] ?? 0 );
        $quiz_id   = absint( $gate['quiz_id'] ?? 0 );
        if ( ! $course_id || ! $lesson_id || ! $quiz_id ) {
            return '';
        }

        $expected_next = $this->get_next_item_after( $course_id, $lesson_id );
        $items         = $this->get_course_items( $course_id );
        $positions     = $this->positions_from_items( $items );
        $expected_text = $expected_next ? ( '#' . $expected_next . ' — ' . get_the_title( $expected_next ) ) : 'Not found';
        $mapped_text   = '#' . $quiz_id . ' — ' . get_the_title( $quiz_id );
        $is_match      = $expected_next && $expected_next === $quiz_id;

        $html  = '<div class="gbvqg-curriculum-hint">';
        $html .= '<strong>Curriculum check:</strong><br>';
        $html .= 'Expected next item after video: <span class="gbvqg-code">' . esc_html( $expected_text ) . '</span><br>';
        $html .= 'Mapped quiz bank: <span class="gbvqg-code">' . esc_html( $mapped_text ) . '</span><br>';
        if ( $is_match ) {
            $html .= '<span class="gbvqg-ok">Placement matches: quiz is immediately after the video.</span>';
        } else {
            $html .= '<span class="gbvqg-danger">Fix needed: the mapped quiz should be the immediate next course item after the video.</span>';
            if ( isset( $positions[ $lesson_id ], $positions[ $quiz_id ] ) ) {
                $html .= '<br><span class="gbvqg-small">Video position: ' . esc_html( $positions[ $lesson_id ] + 1 ) . '; mapped quiz position: ' . esc_html( $positions[ $quiz_id ] + 1 ) . '.</span>';
            }
        }
        $html .= '</div>';
        return $html;
    }

    private function render_gate_diagnostics( $gates ) {
        $real_gates = array();
        foreach ( $gates as $gate ) {
            if ( ! empty( $gate['course_id'] ) || ! empty( $gate['video_lesson_id'] ) || ! empty( $gate['quiz_id'] ) ) {
                $real_gates[] = $gate;
            }
        }

        if ( empty( $real_gates ) ) {
            return '<div class="notice notice-info"><p><strong>Video Quiz Gate setup:</strong> No gate mappings are saved yet. Add a row, keep it <strong>Active</strong>, then save.</p></div>';
        }

        $html = '<div class="notice notice-info" style="padding:12px 14px;"><p style="margin-top:0;"><strong>Quick setup check:</strong> A gate fires when the row is <strong>Active</strong>, the video lesson is in the course, and the Quiz ID is a real <code>lp_quiz</code>. Existing complete rows from older versions are treated as Active automatically so an empty old checkbox cannot silently disable the gate.</p><ul style="margin-left:18px;list-style:disc;">';

        foreach ( $real_gates as $idx => $gate ) {
            $course_id  = absint( $gate['course_id'] );
            $lesson_id  = absint( $gate['video_lesson_id'] );
            $quiz_id    = absint( $gate['quiz_id'] );
            $next_id    = absint( $gate['next_item_id'] );
            $validation = $this->validate_gate( $gate );
            $auto_next  = $this->get_next_item_after( $course_id, $lesson_id );

            $bits   = array();
            $bits[] = ! $this->is_gate_enabled( $gate ) ? '<span style="color:#b32d2e;font-weight:600;">INACTIVE</span>' : '<span style="color:#008a20;font-weight:600;">ACTIVE</span>';
            $bits[] = 'course #' . $course_id;
            $bits[] = 'video #' . $lesson_id . ' (' . esc_html( get_the_title( $lesson_id ) ) . ')';
            $bits[] = 'quiz #' . $quiz_id . ' (' . esc_html( get_the_title( $quiz_id ) ) . ', type ' . esc_html( get_post_type( $quiz_id ) ? get_post_type( $quiz_id ) : 'missing' ) . ')';

            if ( $next_id ) {
                $bits[] = 'after-pass next #' . $next_id . ' (' . esc_html( get_the_title( $next_id ) ) . ')';
            } elseif ( $auto_next ) {
                $bits[] = 'auto next after video #' . $auto_next . ' (' . esc_html( get_the_title( $auto_next ) ) . ')';
            }

            $html .= '<li>Gate ' . esc_html( $idx + 1 ) . ': ' . implode( ' · ', $bits );

            if ( 'invalid' === $validation['status'] ) {
                $html .= '<br><span style="color:#b32d2e;font-weight:600;">Invalid:</span> ' . esc_html( implode( '; ', $validation['messages'] ) );
            }

            $html .= '</li>';
        }

        $html .= '</ul><p style="margin-bottom:0;">If a student goes straight to the next lesson and <strong>Recent Gate Events</strong> is still empty, the gate did not fire. Most common causes: the row is not Active, the Quiz ID is not an <code>lp_quiz</code>, the Quiz ID is not in that LearnPress course, or LearnPress is advancing inside the page without a full page reload. v0.2.31 also stops unverified legacy grandfather state from causing a redirect loop and requires administrator review before changing that student&#039;s gate state.</p></div>';

        return $html;
    }

    public function handle_save_gates() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to save these settings.', 'gulfbreeze-video-quiz-gate' ) );
        }
        check_admin_referer( self::NONCE_ACTION );

        $raw   = isset( $_POST['gates'] ) && is_array( $_POST['gates'] ) ? wp_unslash( $_POST['gates'] ) : array();
        $gates   = array();
        $removed = 0;

        foreach ( $raw as $row ) {
            if ( ! empty( $row['remove'] ) ) {
                if ( ! empty( $row['course_id'] ) && ! empty( $row['video_lesson_id'] ) && ! empty( $row['quiz_id'] ) ) {
                    $removed++;
                }
                continue;
            }

            $gate = $this->sanitize_gate( $row );
            if ( ! empty( $gate['course_id'] ) && ! empty( $gate['video_lesson_id'] ) && ! empty( $gate['quiz_id'] ) ) {
                $gates[] = $gate;
            }
        }

        $this->backup_gate_settings( 'before_save' );
        update_option( self::OPTION_GATES, $gates, false );
        $redirect_args = array( 'page' => 'gb-video-quiz-gate', 'gbvqg_saved' => 1 );
        if ( $removed ) {
            $redirect_args['gbvqg_removed'] = $removed;
        }
        wp_safe_redirect( add_query_arg( $redirect_args, admin_url( 'admin.php' ) ) );
        exit;
    }

    public function handle_export_gates() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to export these settings.', 'gulfbreeze-video-quiz-gate' ) );
        }
        check_admin_referer( 'gbvqg_export_gates' );

        $payload = array(
            'plugin'       => 'gulfbreeze-video-quiz-gate',
            'version'      => self::VERSION,
            'exported_utc' => gmdate( 'Y-m-d H:i:s' ),
            'site_url'     => site_url(),
            'gates'        => $this->get_gates(),
        );

        nocache_headers();
        header( 'Content-Type: application/json; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="gbvqg-gate-settings-' . gmdate( 'Ymd-His' ) . '.json"' );
        echo wp_json_encode( $payload, JSON_PRETTY_PRINT );
        exit;
    }

    public function handle_restore_last_backup() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to restore these settings.', 'gulfbreeze-video-quiz-gate' ) );
        }
        check_admin_referer( 'gbvqg_restore_last_backup' );

        $backup = $this->get_last_gate_backup();
        if ( empty( $backup['gates'] ) || ! is_array( $backup['gates'] ) ) {
            wp_safe_redirect( add_query_arg( array( 'page' => 'gb-video-quiz-gate', 'gbvqg_restore_missing' => 1 ), admin_url( 'admin.php' ) ) );
            exit;
        }

        $this->backup_gate_settings( 'before_restore' );
        update_option( self::OPTION_GATES, $backup['gates'], false );
        wp_safe_redirect( add_query_arg( array( 'page' => 'gb-video-quiz-gate', 'gbvqg_restored' => 1 ), admin_url( 'admin.php' ) ) );
        exit;
    }

    public function handle_clear_events() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to clear events.', 'gulfbreeze-video-quiz-gate' ) );
        }
        check_admin_referer( 'gbvqg_clear_events' );
        update_option( self::OPTION_EVENTS, array(), false );
        wp_safe_redirect( add_query_arg( array( 'page' => 'gb-video-quiz-gate' ), admin_url( 'admin.php' ) ) );
        exit;
    }

    public function handle_repair_gate_state() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You are not allowed to repair video gate state.', 'gulfbreeze-video-quiz-gate' ) );
        }
        check_admin_referer( 'gbvqg_repair_gate_state' );

        $mode       = isset( $_POST['repair_mode'] ) ? sanitize_key( wp_unslash( $_POST['repair_mode'] ) ) : '';
        $user_id    = isset( $_POST['student_user_id'] ) ? absint( $_POST['student_user_id'] ) : 0;
        $gate_id    = isset( $_POST['gate_id'] ) ? sanitize_key( wp_unslash( $_POST['gate_id'] ) ) : '';
        $return_url = isset( $_POST['return_url'] ) ? esc_url_raw( wp_unslash( $_POST['return_url'] ) ) : admin_url( 'admin.php?page=gb-video-quiz-gate' );
        $gate       = $this->find_gate_by_id( $gate_id );

        if ( ! $user_id || ! get_userdata( $user_id ) || ! $gate ) {
            $this->redirect_repair_result( $return_url, '', 'Student or gate was not found.' );
        }

        $analysis = $this->analyze_gate_state_evidence( $user_id, $gate );
        $class    = (string) ( $analysis['classification'] ?? 'unknown' );
        $admin_id = get_current_user_id();

        if ( 'require_quiz' === $mode ) {
            if ( ! in_array( $class, array( 'unverified_legacy_grandfather', 'quiz_required_by_admin' ), true ) ) {
                $this->redirect_repair_result( $return_url, '', 'Require Quiz was refused because this record is not an unverified grandfather mismatch.' );
            }
            $backup_key = $this->backup_gate_repair_state( $user_id, $gate, $analysis, $mode );

            $state = is_array( $analysis['state'] ?? null ) ? $analysis['state'] : array();
            unset(
                $state['passed_at'],
                $state['grandfathered_at'],
                $state['grandfather_reason'],
                $state['manual_exemption'],
                $state['exemption_reason'],
                $state['exemption_admin_user_id'],
                $state['exemption_at']
            );
            $state['passed']                    = 0;
            $state['grandfathered']             = 0;
            $state['force_validation_required'] = 1;
            $state['force_validation_set_at']   = current_time( 'mysql', true );
            $state['force_validation_admin_id'] = $admin_id;
            $state['force_validation_reason']   = 'Unverified private pass/grandfather state with no passing attempt and no LearnPress completion.';
            $state['repair_backup_key']         = $backup_key;
            $state['last_status']               = 'quiz_required_by_admin';
            $this->set_gate_state( $user_id, $gate, $state );

            $this->log_event( 'admin_require_quiz_repair', $user_id, $gate, array(
                'admin_user_id' => $admin_id,
                'backup_key'    => $backup_key,
                'classification_before' => $class,
                'previous_state' => $analysis['state'] ?? array(),
            ) );
            $this->redirect_repair_result( $return_url, 'The selected student is now required to take this video quiz. No other student or gate was changed.', '' );
        }

        if ( 'rebuild_from_attempt' === $mode ) {
            if ( 'verified_attempt_missing_learnpress' !== $class || empty( $analysis['verified_pass_attempt'] ) ) {
                $this->redirect_repair_result( $return_url, '', 'Rebuild was refused because no verified passing attempt with missing LearnPress completion was found.' );
            }
            $backup_key = $this->backup_gate_repair_state( $user_id, $gate, $analysis, $mode );
            $attempt = $analysis['verified_pass_attempt'];
            $checked = ! empty( $attempt['checked'] ) && is_array( $attempt['checked'] ) ? $attempt['checked'] : ( ! empty( $attempt['questions'] ) && is_array( $attempt['questions'] ) ? $attempt['questions'] : array() );
            $user_item_id = $this->mark_lp_quiz_item_result( $user_id, $gate, true, array(
                'checked'       => $checked,
                'correct_count' => absint( $attempt['correct_count'] ?? count( $checked ) ),
                'shown_count'   => max( 1, absint( $attempt['shown_count'] ?? count( $checked ) ) ),
            ) );
            $recognition = $this->get_learnpress_item_recognition( $user_id, absint( $gate['course_id'] ), absint( $gate['quiz_id'] ) );
            if ( ! $user_item_id || empty( $recognition['is_completed'] ) || empty( $recognition['is_passed'] ) ) {
                if ( $user_item_id && empty( $analysis['lp_rows'] ) ) {
                    $this->delete_lp_user_item_and_meta( $user_item_id );
                }
                $this->redirect_repair_result( $return_url, '', 'The LearnPress row write did not verify as completed and passed. The new row was rolled back when possible; evidence was logged.' );
            }
            $state = is_array( $analysis['state'] ?? null ) ? $analysis['state'] : array();
            $state['passed']      = 1;
            $state['passed_at']   = (string) ( $attempt['submitted_at'] ?? current_time( 'mysql', true ) );
            $state['last_status'] = 'passed_rebuilt_from_verified_attempt';
            unset( $state['force_validation_required'], $state['force_validation_set_at'], $state['force_validation_admin_id'], $state['force_validation_reason'] );
            $this->set_gate_state( $user_id, $gate, $state );
            $this->log_event( 'admin_rebuilt_learnpress_from_verified_attempt', $user_id, $gate, array(
                'admin_user_id' => $admin_id,
                'backup_key'    => $backup_key,
                'user_item_id'  => $user_item_id,
                'recognition'   => $recognition,
            ) );
            $this->redirect_repair_result( $return_url, 'The missing LearnPress record was rebuilt from the verified passing attempt.', '' );
        }

        if ( 'grant_exemption' === $mode ) {
            if ( $this->is_retired_legacy_course( absint( $gate['course_id'] ?? 0 ) ) ) {
                $this->redirect_repair_result( $return_url, '', 'Use the Gulf Breeze retired-course reconciliation workflow so the record is labeled and supported correctly.' );
            }
            if ( ! in_array( $class, array( 'unverified_legacy_grandfather', 'quiz_required_by_admin' ), true ) ) {
                $this->redirect_repair_result( $return_url, '', 'Exemption was refused because this record is not an unresolved grandfather/quiz-required case.' );
            }
            $reason = isset( $_POST['exemption_reason'] ) ? sanitize_text_field( wp_unslash( $_POST['exemption_reason'] ) ) : '';
            if ( strlen( $reason ) < 10 ) {
                $this->redirect_repair_result( $return_url, '', 'A specific exemption reason of at least 10 characters is required.' );
            }
            if ( ! empty( $analysis['lp_rows'] ) ) {
                $this->redirect_repair_result( $return_url, '', 'Exemption was refused because an existing LearnPress quiz row must be reviewed rather than overwritten.' );
            }
            $backup_key = $this->backup_gate_repair_state( $user_id, $gate, $analysis, $mode );
            $user_item_id = $this->mark_lp_quiz_item_exemption( $user_id, $gate, $reason, $admin_id );
            $recognition = $this->get_learnpress_item_recognition( $user_id, absint( $gate['course_id'] ), absint( $gate['quiz_id'] ) );
            if ( ! $user_item_id || empty( $recognition['is_completed'] ) ) {
                if ( $user_item_id ) {
                    $this->delete_lp_user_item_and_meta( $user_item_id );
                }
                $this->redirect_repair_result( $return_url, '', 'The documented exemption did not verify as a completed sequence item. The new row was rolled back; no pass or exemption state was recorded.' );
            }
            $now = current_time( 'mysql', true );
            $state = is_array( $analysis['state'] ?? null ) ? $analysis['state'] : array();
            $state['passed']                    = 1;
            $state['passed_at']                 = $now;
            $state['grandfathered']             = 1;
            $state['grandfathered_at']          = $now;
            $state['grandfather_reason']        = 'manual_documented_exemption';
            $state['manual_exemption']          = 1;
            $state['exemption_type']            = 'administrator';
            $state['exemption_reason']          = $reason;
            $state['exemption_admin_user_id']   = $admin_id;
            $state['exemption_at']              = $now;
            $state['repair_backup_key']         = $backup_key;
            $state['course_policy_version']     = self::COURSE_POLICY_VERSION;
            $state['mapping_fingerprint']       = $this->gate_mapping_fingerprint( $gate );
            $state['last_status']               = 'documented_exemption';
            unset( $state['force_validation_required'], $state['force_validation_set_at'], $state['force_validation_admin_id'], $state['force_validation_reason'] );
            $this->set_gate_state( $user_id, $gate, $state );
            $this->store_documented_exemption_evidence( $user_id, $gate, $reason, $admin_id, $user_item_id, 'administrator', array() );
            $this->log_event( 'admin_documented_gate_exemption', $user_id, $gate, array(
                'admin_user_id' => $admin_id,
                'backup_key'    => $backup_key,
                'reason'        => $reason,
                'user_item_id'  => $user_item_id,
                'recognition'   => $recognition,
            ) );
            $this->redirect_repair_result( $return_url, 'A documented exemption was recorded for only this student and gate. It was not recorded as a scored quiz attempt.', '' );
        }

        $this->redirect_repair_result( $return_url, '', 'Unknown repair action.' );
    }

    public function handle_reconcile_retired_course() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Unauthorized.' );
        }
        check_admin_referer( 'gbvqg_reconcile_retired_course' );

        $course_id = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0;
        $return_url = isset( $_POST['return_url'] ) ? esc_url_raw( wp_unslash( $_POST['return_url'] ) ) : admin_url( 'admin.php?page=gb-video-quiz-gate' );
        $reason = isset( $_POST['legacy_reason'] ) ? sanitize_text_field( wp_unslash( $_POST['legacy_reason'] ) ) : '';
        $records = isset( $_POST['legacy_records'] ) && is_array( $_POST['legacy_records'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['legacy_records'] ) ) : array();

        if ( ! $this->is_retired_legacy_course( $course_id ) ) {
            $this->redirect_legacy_result( $return_url, '', 'This course is not registered as a retired Gulf Breeze course.' );
        }
        if ( strlen( $reason ) < 20 ) {
            $this->redirect_legacy_result( $return_url, '', 'A specific front-office record reason of at least 20 characters is required.' );
        }
        if ( empty( $records ) ) {
            $this->redirect_legacy_result( $return_url, '', 'No eligible records were selected.' );
        }

        $admin_id = get_current_user_id();
        $applied = 0;
        $skipped = 0;
        $failed = 0;
        $seen = array();

        foreach ( array_slice( $records, 0, 500 ) as $token ) {
            $parts = explode( ':', (string) $token, 2 );
            $user_id = absint( $parts[0] ?? 0 );
            $gate_id = sanitize_key( $parts[1] ?? '' );
            $dedupe = $user_id . ':' . $gate_id;
            if ( ! $user_id || ! $gate_id || isset( $seen[ $dedupe ] ) ) {
                $skipped++;
                continue;
            }
            $seen[ $dedupe ] = true;
            $gate = $this->find_gate_by_id( $gate_id );
            if ( ! $gate || absint( $gate['course_id'] ?? 0 ) !== $course_id || ! $this->is_retired_legacy_course( absint( $gate['course_id'] ?? 0 ) ) ) {
                $skipped++;
                continue;
            }

            $legacy = $this->analyze_retired_course_legacy_candidate( $user_id, $gate );
            if ( 'eligible_retired_legacy_exemption' !== ( $legacy['legacy_classification'] ?? '' ) ) {
                $skipped++;
                continue;
            }

            $analysis = $legacy['analysis'];
            $backup_key = $this->backup_gate_repair_state( $user_id, $gate, $analysis, 'retired_course_legacy_exemption' );
            $user_item_id = $this->mark_lp_quiz_item_exemption( $user_id, $gate, $reason, $admin_id, 'retired_course_legacy' );
            $recognition = $this->get_learnpress_item_recognition( $user_id, $course_id, absint( $gate['quiz_id'] ) );
            if ( ! $user_item_id || empty( $recognition['is_completed'] ) ) {
                if ( $user_item_id && empty( $analysis['lp_rows'] ) ) {
                    $this->delete_lp_user_item_and_meta( $user_item_id );
                }
                $this->log_event( 'retired_course_legacy_reconciliation_failed', $user_id, $gate, array(
                    'admin_user_id' => $admin_id,
                    'backup_key' => $backup_key,
                    'recognition' => $recognition,
                    'legacy_analysis' => $legacy,
                ) );
                $failed++;
                continue;
            }

            $now = current_time( 'mysql', true );
            $state = is_array( $analysis['state'] ?? null ) ? $analysis['state'] : array();
            $state['passed'] = 1;
            $state['passed_at'] = $now;
            $state['grandfathered'] = 1;
            $state['grandfathered_at'] = $now;
            $state['grandfather_reason'] = 'retired_course_documented_legacy_exemption';
            $state['manual_exemption'] = 1;
            $state['exemption_type'] = 'retired_course_legacy';
            $state['exemption_reason'] = $reason;
            $state['exemption_admin_user_id'] = $admin_id;
            $state['exemption_at'] = $now;
            $state['repair_backup_key'] = $backup_key;
            $state['course_policy_version'] = self::COURSE_POLICY_VERSION;
            $state['mapping_fingerprint'] = $legacy['mapping_fingerprint'];
            $state['legacy_supporting_progress'] = $legacy['later_completed'];
            $state['last_status'] = 'retired_course_legacy_exemption';
            unset( $state['force_validation_required'], $state['force_validation_set_at'], $state['force_validation_admin_id'], $state['force_validation_reason'] );
            $this->set_gate_state( $user_id, $gate, $state );

            $this->store_documented_exemption_evidence(
                $user_id,
                $gate,
                $reason,
                $admin_id,
                $user_item_id,
                'retired_course_legacy',
                array(
                    'video_completion' => $legacy['lesson_state'],
                    'later_completed_item' => $legacy['later_completed'],
                    'mapping_fingerprint' => $legacy['mapping_fingerprint'],
                    'course_policy_version' => self::COURSE_POLICY_VERSION,
                    'backup_key' => $backup_key,
                )
            );
            $this->log_event( 'admin_retired_course_legacy_exemption', $user_id, $gate, array(
                'admin_user_id' => $admin_id,
                'backup_key' => $backup_key,
                'reason' => $reason,
                'user_item_id' => $user_item_id,
                'recognition' => $recognition,
                'later_completed_item' => $legacy['later_completed'],
                'mapping_fingerprint' => $legacy['mapping_fingerprint'],
                'course_policy_version' => self::COURSE_POLICY_VERSION,
            ) );
            $applied++;
        }

        $message = sprintf( 'Retired-course reconciliation finished: %d documented legacy exemption(s) applied, %d skipped after re-check, %d failed and rolled back when possible. No lesson, score, seat-time, or existing quiz progress was removed.', $applied, $skipped, $failed );
        $this->redirect_legacy_result( $return_url, $message, '' );
    }

    private function redirect_legacy_result( $return_url, $done, $error ) {
        $return_url = $return_url ? $return_url : admin_url( 'admin.php?page=gb-video-quiz-gate' );
        $args = array();
        if ( $done ) { $args['gbvqg_legacy_done'] = $done; }
        if ( $error ) { $args['gbvqg_legacy_error'] = $error; }
        wp_safe_redirect( add_query_arg( $args, $return_url ) );
        exit;
    }

    private function is_active_strict_course( $course_id ) {
        $course_id = absint( $course_id );
        foreach ( $this->get_gates() as $gate ) {
            if ( $this->is_gate_enabled( $gate ) && absint( $gate['course_id'] ) === $course_id ) {
                return true;
            }
        }
        return false;
    }

    private function is_retired_legacy_course( $course_id ) {
        return in_array( absint( $course_id ), apply_filters( 'gbvqg_retired_course_ids', array() ), true );
    }

    private function course_policy( $course_id ) {
        if ( $this->is_active_strict_course( $course_id ) ) { return 'active_strict'; }
        if ( $this->is_retired_legacy_course( $course_id ) ) { return 'retired_legacy'; }
        return 'standard';
    }

    private function course_policy_label( $course_id ) {
        $labels = array(
            'active_strict' => 'Active course — strict verified-attempt policy',
            'retired_legacy' => 'Retired course — documented closeout policy',
            'standard' => 'Standard mapped-course policy',
        );
        return $labels[ $this->course_policy( $course_id ) ];
    }

    private function gate_mapping_fingerprint( $gate ) {
        $payload = array(
            'course_id' => absint( $gate['course_id'] ?? 0 ),
            'video_lesson_id' => absint( $gate['video_lesson_id'] ?? 0 ),
            'quiz_id' => absint( $gate['quiz_id'] ?? 0 ),
            'next_item_id' => absint( $gate['next_item_id'] ?? 0 ),
            'label' => (string) ( $gate['label'] ?? '' ),
            'show_questions' => absint( $gate['show_questions'] ?? 1 ),
            'pass_percent' => absint( $gate['pass_percent'] ?? 100 ),
            'fail_mode' => (string) ( $gate['fail_mode'] ?? '' ),
        );
        return hash( 'sha256', wp_json_encode( $payload ) );
    }

    private function analyze_retired_course_legacy_candidate( $user_id, $gate, $state = null ) {
        $user_id = absint( $user_id );
        $course_id = absint( $gate['course_id'] ?? 0 );
        $quiz_id = absint( $gate['quiz_id'] ?? 0 );
        $lesson_id = absint( $gate['video_lesson_id'] ?? 0 );
        $state = is_array( $state ) ? $state : $this->get_gate_state( $user_id, $gate );
        $analysis = $this->analyze_gate_state_evidence( $user_id, $gate, null, $state );
        $lesson_state = $this->get_lp_item_state( $user_id, $course_id, $lesson_id );
        $video_completed = in_array( (string) ( $lesson_state['status'] ?? '' ), array( 'passed', 'completed' ), true );
        $items = $this->get_course_items( $course_id );
        $positions = $this->positions_from_items( $items );
        $quiz_pos = $positions[ $quiz_id ] ?? null;
        $later_completed = $this->find_completed_course_item_after_position_read_only( $user_id, $course_id, $items, $quiz_pos );
        $classification = (string) ( $analysis['classification'] ?? 'unknown' );

        if ( ! $this->is_retired_legacy_course( $course_id ) ) {
            $legacy_classification = 'not_retired_course';
        } elseif ( 'retired_course_legacy_exemption' === $classification ) {
            $legacy_classification = 'already_documented_legacy_exemption';
        } elseif ( in_array( $classification, array( 'verified_pass', 'documented_exemption', 'learnpress_completed_without_private_pass' ), true ) ) {
            $legacy_classification = 'already_resolved';
        } elseif ( 'unverified_legacy_grandfather' !== $classification ) {
            $legacy_classification = 'not_eligible_state';
        } elseif ( ! empty( $analysis['verified_pass_attempt'] ) || ! empty( $analysis['lp_rows'] ) ) {
            $legacy_classification = 'conflicting_evidence_review';
        } elseif ( ! $video_completed ) {
            $legacy_classification = 'video_not_completed';
        } elseif ( empty( $later_completed ) ) {
            $legacy_classification = 'quiz_required_or_individual_review';
        } else {
            $legacy_classification = 'eligible_retired_legacy_exemption';
        }

        return array(
            'legacy_classification' => $legacy_classification,
            'analysis' => $analysis,
            'lesson_state' => $lesson_state,
            'video_completed' => $video_completed,
            'later_completed' => $later_completed,
            'mapping_fingerprint' => $this->gate_mapping_fingerprint( $gate ),
        );
    }

    private function retired_legacy_classification_label( $classification ) {
        $labels = array(
            'eligible_retired_legacy_exemption' => 'Eligible — video complete and later progress verified',
            'already_documented_legacy_exemption' => 'Already documented legacy exemption',
            'already_resolved' => 'Already resolved',
            'quiz_required_or_individual_review' => 'No later completion — quiz or individual review required',
            'video_not_completed' => 'Required video completion not verified',
            'conflicting_evidence_review' => 'Conflicting evidence — individual review',
            'not_eligible_state' => 'Not an eligible legacy mismatch',
            'not_retired_course' => 'Blocked — not a retired course',
        );
        return $labels[ $classification ] ?? ucwords( str_replace( '_', ' ', (string) $classification ) );
    }

    private function get_retired_course_reconciliation_rows( $course_id ) {
        global $wpdb;
        $course_id = absint( $course_id );
        if ( ! $this->is_retired_legacy_course( $course_id ) ) { return array(); }
        $rows_out = array();
        foreach ( $this->get_gates() as $gate ) {
            if ( absint( $gate['course_id'] ?? 0 ) !== $course_id ) { continue; }
            $meta_key = $this->get_gate_state_key( $gate );
            $state_rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT user_id, meta_value FROM {$wpdb->usermeta} WHERE meta_key = %s ORDER BY umeta_id DESC",
                $meta_key
            ), ARRAY_A );
            $seen_users = array();
            foreach ( (array) $state_rows as $row ) {
                $user_id = absint( $row['user_id'] ?? 0 );
                if ( ! $user_id || isset( $seen_users[ $user_id ] ) ) { continue; }
                $seen_users[ $user_id ] = true;
                $state = maybe_unserialize( $row['meta_value'] ?? '' );
                $state = is_array( $state ) ? $state : array();
                if ( empty( $state['passed'] ) && empty( $state['grandfathered'] ) && empty( $state['force_validation_required'] ) ) { continue; }
                $legacy = $this->analyze_retired_course_legacy_candidate( $user_id, $gate, $state );
                $user = get_userdata( $user_id );
                $rows_out[] = array(
                    'user_id' => $user_id,
                    'student_label' => $user ? $user->display_name . ' (#' . $user_id . ')' : 'User #' . $user_id,
                    'gate_id' => $this->gate_id( $gate ),
                    'gate_label' => (string) ( $gate['label'] ?? 'Video gate' ) . ' / Video #' . absint( $gate['video_lesson_id'] ?? 0 ) . ' / Quiz #' . absint( $gate['quiz_id'] ?? 0 ),
                    'legacy_classification' => $legacy['legacy_classification'],
                    'video_completed' => $legacy['video_completed'],
                    'later_completed' => $legacy['later_completed'],
                    'proposed_record' => 'eligible_retired_legacy_exemption' === $legacy['legacy_classification'] ? 'Documented retired-course legacy exemption — no scored attempt' : 'No automatic change',
                );
            }
        }
        usort( $rows_out, function( $a, $b ) {
            $a_eligible = 'eligible_retired_legacy_exemption' === ( $a['legacy_classification'] ?? '' ) ? 0 : 1;
            $b_eligible = 'eligible_retired_legacy_exemption' === ( $b['legacy_classification'] ?? '' ) ? 0 : 1;
            if ( $a_eligible !== $b_eligible ) { return $a_eligible <=> $b_eligible; }
            return strcasecmp( (string) ( $a['student_label'] ?? '' ), (string) ( $b['student_label'] ?? '' ) );
        } );
        return $rows_out;
    }

    private function redirect_repair_result( $return_url, $done, $error ) {
        $return_url = $return_url ? $return_url : admin_url( 'admin.php?page=gb-video-quiz-gate' );
        $args = array();
        if ( $done ) {
            $args['gbvqg_repair_done'] = $done;
        }
        if ( $error ) {
            $args['gbvqg_repair_error'] = $error;
        }
        wp_safe_redirect( add_query_arg( $args, $return_url ) );
        exit;
    }

    private function blank_gate() {
        return array(
            'gate_id'          => '',
            'enabled'          => 0,
            'enabled_explicitly_saved_v025' => 0,
            'label'            => '',
            'course_id'        => 0,
            'video_lesson_id'  => 0,
            'quiz_id'          => 0,
            'next_item_id'     => 0,
            'expected_questions' => 4,
            'show_questions'   => 1,
            'fail_mode'        => 'return_video',
        );
    }

    private function sanitize_gate( $row ) {
        $gate = $this->blank_gate();

        $gate['enabled']            = empty( $row['enabled'] ) ? 0 : 1;
        $gate['enabled_explicitly_saved_v025'] = empty( $row['enabled_explicitly_saved_v025'] ) ? 0 : 1;
        $gate['label']              = isset( $row['label'] ) ? sanitize_text_field( $row['label'] ) : '';
        $gate['course_id']          = isset( $row['course_id'] ) ? absint( $row['course_id'] ) : 0;
        $gate['video_lesson_id']    = isset( $row['video_lesson_id'] ) ? absint( $row['video_lesson_id'] ) : 0;
        $gate['quiz_id']            = isset( $row['quiz_id'] ) ? absint( $row['quiz_id'] ) : 0;
        $gate['next_item_id']       = isset( $row['next_item_id'] ) ? absint( $row['next_item_id'] ) : 0;
        $gate['expected_questions'] = isset( $row['expected_questions'] ) ? absint( $row['expected_questions'] ) : 4;
        $gate['show_questions']     = isset( $row['show_questions'] ) ? absint( $row['show_questions'] ) : 1;

        $allowed_fail_modes = array( 'return_video', 'fresh_completion', 'none' );
        $gate['fail_mode'] = isset( $row['fail_mode'] ) && in_array( $row['fail_mode'], $allowed_fail_modes, true ) ? $row['fail_mode'] : 'return_video';

        $gate['gate_id'] = $this->gate_id( $gate );
        return $gate;
    }

    private function gate_id( $gate ) {
        return substr( md5( absint( $gate['course_id'] ) . ':' . absint( $gate['video_lesson_id'] ) . ':' . absint( $gate['quiz_id'] ) ), 0, 12 );
    }

    private function gate_has_required_ids( $gate ) {
        return ! empty( $gate['course_id'] ) && ! empty( $gate['video_lesson_id'] ) && ! empty( $gate['quiz_id'] );
    }

    private function is_gate_enabled( $gate ) {
        if ( ! $this->gate_has_required_ids( $gate ) ) {
            return false;
        }

        // v0.2.5 migration safety:
        // Older builds saved visually confusing rows with enabled=0 even though they looked usable.
        // Treat those old complete rows as active until they are saved again in v0.2.5.
        if ( empty( $gate['enabled_explicitly_saved_v025'] ) ) {
            return true;
        }

        return ! empty( $gate['enabled'] );
    }

    private function get_gates() {
        $gates = get_option( self::OPTION_GATES, array() );
        if ( ! is_array( $gates ) ) {
            return array();
        }
        $out = array();
        foreach ( $gates as $gate ) {
            $gate = wp_parse_args( $gate, $this->blank_gate() );
            if ( empty( $gate['gate_id'] ) ) {
                $gate['gate_id'] = $this->gate_id( $gate );
            }
            $out[] = $gate;
        }
        return $out;
    }

    private function get_lp_courses() {
        if ( ! post_type_exists( 'lp_course' ) ) {
            return array();
        }
        return get_posts( array(
            'post_type'      => 'lp_course',
            'post_status'    => array( 'publish', 'private', 'draft' ),
            'numberposts'    => 200,
            'orderby'        => 'title',
            'order'          => 'ASC',
            'suppress_filters' => false,
        ) );
    }

    private function validate_gate( $gate ) {
        $messages = array();
        $ok       = true;

        $course_id = absint( $gate['course_id'] );
        $lesson_id = absint( $gate['video_lesson_id'] );
        $quiz_id   = absint( $gate['quiz_id'] );

        if ( ! $course_id && ! $lesson_id && ! $quiz_id ) {
            return array( 'status' => 'blank', 'messages' => array( 'Blank row.' ) );
        }

        if ( $this->gate_has_required_ids( $gate ) && ! $this->is_gate_enabled( $gate ) ) {
            $messages[] = 'Row is complete but not Active. It will not fire until Active is checked and saved.';
        }

        if ( 'lp_course' !== get_post_type( $course_id ) ) {
            $ok = false;
            $messages[] = 'Course ID is not an lp_course.';
        }
        if ( 'lp_lesson' !== get_post_type( $lesson_id ) ) {
            $ok = false;
            $messages[] = 'Video Lesson ID is not an lp_lesson.';
        }
        if ( 'lp_quiz' !== get_post_type( $quiz_id ) ) {
            $ok = false;
            $messages[] = 'Quiz ID is not an lp_quiz.';
        }

        $items     = $this->get_course_items( $course_id );
        $positions = $this->positions_from_items( $items );

        if ( $course_id && $lesson_id && ! isset( $positions[ $lesson_id ] ) ) {
            $ok = false;
            $messages[] = 'Video lesson is not found in this course curriculum.';
        }
        if ( $course_id && $quiz_id && ! isset( $positions[ $quiz_id ] ) ) {
            $ok = false;
            $messages[] = 'Quiz is not found in this course curriculum.';
        }
        if ( isset( $positions[ $lesson_id ], $positions[ $quiz_id ] ) ) {
            if ( $positions[ $quiz_id ] === $positions[ $lesson_id ] + 1 ) {
                $messages[] = 'Quiz is immediately after video.';
            } elseif ( $positions[ $quiz_id ] > $positions[ $lesson_id ] ) {
                // v0.2.7: Out-of-order placement is INVALID. Sequential Drip
                // will block "complete Hour 8 first" if the quiz is later.
                $ok = false;
                $messages[] = 'INVALID: video-check quiz must be placed immediately after the video lesson in this course curriculum.';
            } else {
                $ok = false;
                $messages[] = 'Quiz appears before the video lesson in the curriculum.';
            }
        }

        $expected = absint( $gate['expected_questions'] );
        $actual   = $this->get_quiz_question_count( $quiz_id );
        if ( $expected && null !== $actual && $actual !== $expected ) {
            $messages[] = 'Question count is ' . $actual . ', expected ' . $expected . '.';
        } elseif ( $expected && null === $actual ) {
            $messages[] = 'Could not read question count from LearnPress tables/meta.';
        } elseif ( $expected && $actual === $expected ) {
            $messages[] = 'Question count matches expected ' . $expected . '.';
        }

        $status = $ok ? 'ok' : 'invalid';
        if ( $ok && $this->gate_has_required_ids( $gate ) && ! $this->is_gate_enabled( $gate ) ) {
            $status = 'disabled';
        }

        return array(
            'status'   => $status,
            'messages' => $messages,
        );
    }

    private function format_validation( $validation ) {
        if ( empty( $validation['messages'] ) ) {
            return '<span class="gbvqg-small">No validation messages.</span>';
        }
        $class = 'ok' === $validation['status'] ? 'gbvqg-ok' : ( 'blank' === $validation['status'] ? 'gbvqg-small' : ( 'disabled' === $validation['status'] ? 'gbvqg-warn' : 'gbvqg-invalid' ) );
        $html  = '<span class="' . esc_attr( $class ) . '">' . esc_html( strtoupper( $validation['status'] ) ) . '</span><ul>';
        foreach ( $validation['messages'] as $message ) {
            $is_warn = false !== stripos( $message, 'not immediately' ) || false !== stripos( $message, 'Question count is' ) || false !== stripos( $message, 'Could not read' );
            $html   .= '<li class="' . ( $is_warn ? 'gbvqg-warn' : '' ) . '">' . esc_html( $message ) . '</li>';
        }
        $html .= '</ul>';
        return $html;
    }

    public function template_redirect_gate() {
        if ( is_admin() || ! is_user_logged_in() || current_user_can( 'manage_options' ) || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
            return;
        }

        $gates = $this->get_gates();
        if ( empty( $gates ) ) {
            return;
        }

        $context = $this->detect_context();
        if ( empty( $context['item_id'] ) ) {
            return;
        }

        $user_id = get_current_user_id();

        foreach ( $gates as $gate ) {
            if ( ! $this->is_gate_enabled( $gate ) ) {
                continue;
            }
            if ( ! $this->context_matches_gate( $context, $gate ) ) {
                continue;
            }

            $decision = $this->evaluate_gate( $gate, $context, $user_id );
            if ( empty( $decision['action'] ) || 'allow' === $decision['action'] ) {
                if ( ! empty( $decision['notice'] ) || ! empty( $decision['notice_type'] ) || ! empty( $decision['button_url'] ) ) {
                    $this->frontend_notice = $decision;
                    return;
                }

                // v0.2.10: Do not let an earlier already-passed gate short-circuit later gates.
                // The old loop returned "allow" for Gate 1 anywhere later in the same course,
                // so Gate 2 never got a chance to intercept its own quiz/next item. Keep looping
                // unless this allow decision applies directly to the current gate's own video/quiz.
                $direct_gate_item = in_array(
                    absint( $context['item_id'] ),
                    array( absint( $gate['video_lesson_id'] ), absint( $gate['quiz_id'] ) ),
                    true
                );
                if ( $direct_gate_item ) {
                    return;
                }
                continue;
            }

            $this->frontend_notice = $decision;

            if ( ! empty( $decision['redirect_to'] ) && ! $this->is_current_url( $decision['redirect_to'] ) ) {
                $this->log_event( $decision['event'] ?? 'redirect', $user_id, $gate, array(
                    'current_item_id' => $context['item_id'],
                    'current_url'     => $this->current_url(),
                    'redirect_to'     => $decision['redirect_to'],
                    'reason'          => $decision['message'] ?? '',
                ) );
                wp_safe_redirect( add_query_arg( 'gbvqg_gate', $gate['gate_id'], $decision['redirect_to'] ) );
                exit;
            }

            return;
        }
    }

    private function evaluate_gate( $gate, $context, $user_id ) {
        $course_id = absint( $gate['course_id'] );
        $lesson_id = absint( $gate['video_lesson_id'] );
        $quiz_id   = absint( $gate['quiz_id'] );
        $item_id   = absint( $context['item_id'] );
        $fail_mode = $gate['fail_mode'];

        // v0.2.25 safety: never let a video gate for a course the current user is
        // not enrolled in hijack the request. If context detection ever points at
        // the wrong course, LearnPress should handle access normally; GBVQG should
        // not redirect the student into an unenrolled gate/quiz path.
        if ( ! $this->user_has_lp_course_record( $user_id, $course_id ) ) {
            $this->log_event_once( 'skip_gate_no_course_enrollment_record', $user_id, $gate, array(
                'current_item_id' => $item_id,
                'context_source'  => isset( $context['source'] ) ? $context['source'] : '',
            ) );
            return array( 'action' => 'allow' );
        }

        $items     = $this->get_course_items( $course_id );
        $positions = $this->positions_from_items( $items );
        if ( empty( $positions[ $lesson_id ] ) && ! isset( $positions[ $lesson_id ] ) ) {
            return array( 'action' => 'allow' );
        }

        $video_pos   = $positions[ $lesson_id ] ?? null;
        $quiz_pos    = $positions[ $quiz_id ] ?? null;
        $current_pos = $positions[ $item_id ] ?? null;

        // Sync state from LearnPress user item rows before making decisions.
        $quiz_state   = $this->sync_quiz_state( $user_id, $gate );
        $lesson_state = $this->get_lp_item_state( $user_id, $course_id, $lesson_id );
        $state        = $this->get_gate_state( $user_id, $gate );

        $quiz_url       = $this->get_course_item_url( $course_id, $quiz_id );
        $validation_url = $this->get_validation_url( $gate );
        $lesson_url     = $this->get_course_item_url( $course_id, $lesson_id );

        $lesson_completed = $this->has_verified_playback( $user_id, $gate );
        $quiz_passed      = $lesson_completed && ( 'passed' === $quiz_state['status'] || ! empty( $state['passed'] ) );
        $quiz_failed      = 'failed' === $quiz_state['status'] || ( ! empty( $state['failed_at'] ) && empty( $state['passed'] ) );

        // v0.2.31: Do not create new automatic grandfather/pass state from course
        // position or later progress. Historical state is preserved for read-only audit,
        // but any new exemption must be an explicit, documented administrator action.

        $evidence = $this->analyze_gate_state_evidence( $user_id, $gate, $quiz_state, $state );
        if ( 'unverified_legacy_grandfather' === ( $evidence['classification'] ?? '' ) ) {
            $review_url = add_query_arg( array(
                'gbvqg_validation' => 1,
                'gbvqg_gate'       => $gate['gate_id'],
                'gbvqg_review'     => 1,
            ), home_url( '/' ) );
            $this->log_event_once( 'gate_state_mismatch_detected', $user_id, $gate, array(
                'current_item_id' => $item_id,
                'state'           => $state,
                'lp_state'        => $quiz_state,
                'classification'  => $evidence['classification'],
            ) );
            return array(
                'action'      => 'redirect',
                'event'       => 'redirect_gate_state_mismatch_to_review',
                'message'     => 'The saved video-check state does not match the LearnPress course record. The school must review this gate before the student continues.',
                'redirect_to' => $review_url,
                'button_url'  => $review_url,
                'button_text' => 'Course Record Review',
            );
        }

        // Read-only legacy protection: if no gate pass exists but a genuinely
        // completed LearnPress item is already after this quiz, do not guess whether the
        // student should be exempted or retested. Stop for administrator review without
        // writing a grandfather flag.
        if (
            'not_passed' === ( $evidence['classification'] ?? '' )
            && $lesson_completed
            && null !== $quiz_pos
            && null !== $current_pos
            && $current_pos >= $quiz_pos
        ) {
            $later_completed = $this->find_completed_course_item_after_position_read_only( $user_id, $course_id, $items, $quiz_pos );
            if ( $later_completed ) {
                $review_url = add_query_arg( array(
                    'gbvqg_validation' => 1,
                    'gbvqg_gate'       => $gate['gate_id'],
                    'gbvqg_review'     => 1,
                ), home_url( '/' ) );
                $this->log_event_once( 'legacy_later_progress_requires_admin_review', $user_id, $gate, array(
                    'current_item_id'      => $item_id,
                    'later_completed_item' => $later_completed,
                    'state'                => $state,
                    'lp_state'             => $quiz_state,
                ) );
                return array(
                    'action'      => 'redirect',
                    'event'       => 'redirect_legacy_later_progress_to_review',
                    'message'     => 'Existing course progress is already beyond this video check, so the school must review whether a quiz or documented exemption is appropriate.',
                    'redirect_to' => $review_url,
                    'button_url'  => $review_url,
                    'button_text' => 'Course Record Review',
                );
            }
        }

        if ( $quiz_passed ) {
            // v0.2.22: The mapped LearnPress quiz is only a source bank. After a student
            // passes the plugin-controlled validation, do not show LearnPress's native
            // quiz/result screen again on revisit. It can display a confusing 0/0 failed
            // screen even though the video gate is already satisfied. Send the student
            // forward to the next curriculum item instead.
            if ( $item_id === $quiz_id ) {
                $next_id = absint( $gate['next_item_id'] );
                if ( ! $next_id ) {
                    $next_id = $this->get_next_item_after( $course_id, $quiz_id );
                }
                if ( $next_id ) {
                    $next_url = $this->get_course_item_url( $course_id, $next_id );
                    $this->clear_gate_sequence( $user_id, $gate );
                    return array(
                        'action'      => 'redirect',
                        'event'       => 'redirect_already_passed_bank_quiz_to_next_item',
                        'message'     => 'Video check already completed. Continue to the next required course item.',
                        'redirect_to' => $next_url,
                        'button_url'  => $next_url,
                        'button_text' => 'Continue Course',
                    );
                }
            }

            return array(
                'action' => 'allow',
                'notice' => '',
            );
        }

        // If they are on the required video page, help them get to the quiz when appropriate.
        if ( $item_id === $lesson_id ) {
            if ( $quiz_failed && 'none' !== $fail_mode ) {
                $state = $this->mark_rewatch_visit( $user_id, $gate );
                return array(
                    'action'      => 'allow',
                    'notice_type' => 'rewatch',
                    'message'     => 'Review this required video lesson before retaking the video-check quiz.',
                    'button_url'  => $validation_url,
                    'button_text' => 'Retake Video Check Quiz',
                    'gate_id'      => $this->gate_id( $gate ),
                    'course_id'    => $course_id,
                    'video_lesson_id' => $lesson_id,
                );
            }

            if ( $lesson_completed ) {
                $this->mark_gate_sequence( $user_id, $gate, array(
                    'from_item_id' => $lesson_id,
                    'to_quiz_id'   => $quiz_id,
                ) );

                return array(
                    'action'      => 'allow',
                    'notice_type' => 'ready_for_quiz',
                    'message'     => 'This video lesson has a required video-check quiz before you continue.',
                    'button_url'  => $validation_url,
                    'button_text' => 'Go to Video Check Quiz',
                    'gate_id'      => $this->gate_id( $gate ),
                    'course_id'    => $course_id,
                    'video_lesson_id' => $lesson_id,
                );
            }

            // The lesson is not completed yet, so do not redirect the Complete button.
            // But if LearnPress later swaps in a Next/Continue button via AJAX, the footer guard will send that Next click to the quiz.
            return array(
                'action'      => 'allow',
                'notice_type' => 'video_next_guard',
                'message'     => '',
                'button_url'  => $validation_url,
                'button_text' => 'Go to Video Check Quiz',
                'gate_id'      => $this->gate_id( $gate ),
                'course_id'    => $course_id,
                'video_lesson_id' => $lesson_id,
            );
        }

        // If they try the quiz before the lesson is completed, send them back to the video.
        if ( $item_id === $quiz_id && ! $lesson_completed ) {
            return array(
                'action'      => 'redirect',
                'event'       => 'redirect_quiz_to_video_lesson_not_completed',
                'message'     => 'You must complete the required video lesson before taking the video-check quiz.',
                'redirect_to' => $lesson_url,
                'button_url'  => $lesson_url,
                'button_text' => 'Return to Required Video Lesson',
            );
        }

        // If the student failed and strict or return-to-video mode is enabled, make them return before another quiz attempt.
        if ( $item_id === $quiz_id && $quiz_failed && 'none' !== $fail_mode ) {
            if ( 'fresh_completion' === $fail_mode ) {
                $failed_at = ! empty( $state['failed_at'] ) ? strtotime( $state['failed_at'] ) : 0;
                $completed_at = ! empty( $lesson_state['updated_at'] ) ? strtotime( $lesson_state['updated_at'] ) : 0;
                if ( ! $completed_at || ! $failed_at || $completed_at <= $failed_at ) {
                    return array(
                        'action'      => 'redirect',
                        'event'       => 'redirect_quiz_to_video_fresh_completion_required',
                        'message'     => 'You must rewatch and complete the required video lesson before retaking this quiz.',
                        'redirect_to' => $lesson_url,
                        'button_url'  => $lesson_url,
                        'button_text' => 'Return to Required Video Lesson',
                    );
                }
            } else {
                $rewatched = ! empty( $state['rewatch_visited_at'] ) && ( empty( $state['failed_at'] ) || strtotime( $state['rewatch_visited_at'] ) >= strtotime( $state['failed_at'] ) );
                if ( ! $rewatched ) {
                    return array(
                        'action'      => 'redirect',
                        'event'       => 'redirect_quiz_to_video_rewatch_required',
                        'message'     => 'You must return to the required video lesson before retaking this quiz.',
                        'redirect_to' => $lesson_url,
                        'button_url'  => $lesson_url,
                        'button_text' => 'Return to Required Video Lesson',
                    );
                }
            }
        }

        if ( $item_id === $quiz_id ) {
            return array(
                'action'      => 'redirect',
                'event'       => 'redirect_lp_quiz_to_custom_validation',
                'message'     => 'Use the required video-check validation question before continuing.',
                'redirect_to' => $validation_url,
                'button_url'  => $validation_url,
                'button_text' => 'Open Video Check Question',
            );
        }

        // v0.2.31: Automatic grandfather creation was removed. Students with a
        // verified pass continue normally; a documented exemption is explicit; an
        // unresolved historical mismatch is stopped on the review page above.

        // If current item is after the video and quiz is not passed, force the quiz or the rewatch page.
        if ( null !== $current_pos && null !== $video_pos && $current_pos > $video_pos ) {
            if ( $quiz_failed && 'none' !== $fail_mode ) {
                if ( 'return_video' === $fail_mode ) {
                    $rewatched = ! empty( $state['rewatch_visited_at'] ) && ( empty( $state['failed_at'] ) || strtotime( $state['rewatch_visited_at'] ) >= strtotime( $state['failed_at'] ) );
                    if ( ! $rewatched ) {
                        return array(
                            'action'      => 'redirect',
                            'event'       => 'redirect_later_item_to_video_after_fail',
                            'message'     => 'You must return to the required video lesson before retaking the video-check quiz.',
                            'redirect_to' => $lesson_url,
                            'button_url'  => $lesson_url,
                            'button_text' => 'Return to Required Video Lesson',
                        );
                    }
                } elseif ( 'fresh_completion' === $fail_mode ) {
                    return array(
                        'action'      => 'redirect',
                        'event'       => 'redirect_later_item_to_video_fresh_completion_required',
                        'message'     => 'You must rewatch and complete the required video lesson before retaking the video-check quiz.',
                        'redirect_to' => $lesson_url,
                        'button_url'  => $lesson_url,
                        'button_text' => 'Return to Required Video Lesson',
                    );
                }
            }

            $this->mark_gate_sequence( $user_id, $gate, array(
                'from_item_id' => $item_id,
                'to_quiz_id'   => $quiz_id,
            ) );

            return array(
                'action'      => 'redirect',
                'event'       => 'redirect_later_item_to_required_quiz',
                'message'     => 'You must pass the required video-check quiz before continuing.',
                'redirect_to' => $validation_url,
                'button_url'  => $validation_url,
                'button_text' => 'Go to Video Check Question',
            );
        }

        return array( 'action' => 'allow' );
    }

    public function inject_frontend_notice( $content ) {
        if ( empty( $this->frontend_notice ) || ! is_singular() ) {
            return $content;
        }
        $notice      = $this->frontend_notice;
        $notice_type = isset( $notice['notice_type'] ) ? sanitize_key( $notice['notice_type'] ) : '';

        // v0.2.7: Suppress the visible box on the video / quiz pages.
        // The Next-button JS rewrite handles routing; the box was the
        // "showing above the video" complaint.
        $suppressed = array( 'ready_for_quiz', 'video_next_guard', 'rewatch', 'quiz_gate' );
        if ( in_array( $notice_type, $suppressed, true ) ) {
            return $content;
        }

        $message = ! empty( $notice['message'] ) ? $notice['message'] : '';
        if ( ! $message ) {
            return $content;
        }

        $button = '';
        if ( ! empty( $notice['button_url'] ) ) {
            $button = sprintf(
                '<p><a class="button gbvqg-button" style="display:inline-block;padding:10px 16px;background:#1d4ed8;color:#fff;text-decoration:none;border-radius:6px;" href="%s">%s</a></p>',
                esc_url( $notice['button_url'] ),
                esc_html( $notice['button_text'] ?? 'Continue' )
            );
        }

        $box = '<div class="gbvqg-notice" style="border:2px solid #1d4ed8;background:#eff6ff;padding:16px;margin:16px 0;border-radius:8px;"><strong>Video Quiz Gate:</strong><p style="margin:8px 0;">' . esc_html( $message ) . '</p>' . $button . '</div>';
        return $box . $content;
    }


    public function footer_gate_script() {
        if ( empty( $this->frontend_notice ) || empty( $this->frontend_notice['button_url'] ) || is_admin() ) {
            return;
        }

        $notice_type = ! empty( $this->frontend_notice['notice_type'] ) ? sanitize_key( $this->frontend_notice['notice_type'] ) : '';
        if ( ! in_array( $notice_type, array( 'ready_for_quiz', 'rewatch', 'video_next_guard' ), true ) ) {
            return;
        }

        $target = esc_url_raw( $this->frontend_notice['button_url'] );
        if ( ! $target ) {
            return;
        }

        $gate_id = ! empty( $this->frontend_notice['gate_id'] ) ? sanitize_key( $this->frontend_notice['gate_id'] ) : '';
        $ajax_url = admin_url( 'admin-ajax.php' );
        $ajax_nonce = $gate_id ? wp_create_nonce( 'gbvqg_verify_video_' . $gate_id ) : '';
        ?>
        <script>
        (function(){
            var target = <?php echo wp_json_encode( $target ); ?>;
            var noticeType = <?php echo wp_json_encode( $notice_type ); ?>;
            var gateId = <?php echo wp_json_encode( $gate_id ); ?>;
            var ajaxUrl = <?php echo wp_json_encode( $ajax_url ); ?>;
            var ajaxNonce = <?php echo wp_json_encode( $ajax_nonce ); ?>;
            var verifying = false;
            if (!target) { return; }

            var playbackToken = '';
            var playbackSequence = 0;
            var playbackStarted = false;
            var playbackBusy = false;
            var playbackSeeking = false;
            var playbackPendingEnd = null;

            function playbackPost(action, data) {
                var body = new URLSearchParams();
                body.set('action', action);
                body.set('gate_id', gateId);
                body.set('nonce', ajaxNonce);
                Object.keys(data || {}).forEach(function(key){ body.set(key, String(data[key])); });
                return fetch(ajaxUrl, {
                    method: 'POST', credentials: 'same-origin',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
                    body: body.toString()
                }).then(function(response){ return response.json(); });
            }

            function beginPlayback(position, duration) {
                if (playbackStarted || playbackBusy || !duration || position > 3) { return; }
                playbackBusy = true;
                playbackPost('gbvqg_playback_start', {position: position, duration: duration}).then(function(payload){
                    if (payload && payload.success && payload.data && payload.data.token) {
                        playbackToken = payload.data.token;
                        playbackSequence = 0;
                        playbackStarted = true;
                    }
                }).finally(function(){ playbackBusy = false; });
            }

            function reportPlayback(position, duration, rate, playing, ended) {
                if (!playbackStarted) { return; }
                if (playbackBusy) {
                    if (ended) { playbackPendingEnd = {position: position, duration: duration, rate: rate}; }
                    return;
                }
                playbackBusy = true;
                playbackSequence += 1;
                playbackPost('gbvqg_playback_progress', {
                    token: playbackToken, sequence: playbackSequence,
                    position: position, duration: duration, rate: rate,
                    playing: playing ? 1 : 0, ended: ended ? 1 : 0,
                    visible: document.visibilityState === 'visible' ? 1 : 0,
                    focused: document.hasFocus() ? 1 : 0,
                    seeking: playbackSeeking ? 1 : 0
                }).then(function(payload){
                    if (!payload || !payload.success) { playbackStarted = false; }
                }).finally(function(){
                    playbackBusy = false;
                    playbackSeeking = false;
                    if (playbackPendingEnd) {
                        var pending = playbackPendingEnd;
                        playbackPendingEnd = null;
                        window.setTimeout(function(){ reportPlayback(pending.position, pending.duration, pending.rate, true, true); }, 25);
                    }
                });
            }

            function attachHtml5Playback() {
                var video = document.querySelector('video');
                if (!video) { return false; }
                video.playbackRate = 1;
                video.addEventListener('ratechange', function(){ if (Math.abs(video.playbackRate - 1) > 0.01) { video.playbackRate = 1; } });
                video.addEventListener('seeking', function(){ playbackSeeking = true; });
                video.addEventListener('play', function(){ beginPlayback(video.currentTime || 0, video.duration || 0); });
                video.addEventListener('ended', function(){ reportPlayback(video.currentTime, video.duration, video.playbackRate, true, true); });
                window.setInterval(function(){
                    if (!video.paused && !video.ended) {
                        if (!playbackStarted) { beginPlayback(video.currentTime || 0, video.duration || 0); }
                        else { reportPlayback(video.currentTime, video.duration, video.playbackRate, true, false); }
                    }
                }, 5000);
                return true;
            }

            function attachYouTubePlayback() {
                var iframe = document.querySelector('iframe[src*="youtube.com/embed"],iframe[src*="youtube-nocookie.com/embed"]');
                if (!iframe) { return false; }
                if (!iframe.id) { iframe.id = 'gbvqg-youtube-player'; }
                var src = new URL(iframe.src, window.location.href);
                src.searchParams.set('enablejsapi', '1');
                src.searchParams.set('playsinline', '1');
                iframe.src = src.toString();
                window.onYouTubeIframeAPIReady = function(){
                    var player = new YT.Player(iframe.id, {events: {onStateChange: function(event){
                        if (event.data === YT.PlayerState.PLAYING) {
                            if (player.getPlaybackRate() !== 1) { player.setPlaybackRate(1); }
                            beginPlayback(player.getCurrentTime(), player.getDuration());
                        }
                        if (event.data === YT.PlayerState.ENDED) {
                            reportPlayback(player.getCurrentTime(), player.getDuration(), player.getPlaybackRate(), true, true);
                        }
                    }}});
                    window.setInterval(function(){
                        if (player.getPlayerState && player.getPlayerState() === YT.PlayerState.PLAYING) {
                            if (!playbackStarted) { beginPlayback(player.getCurrentTime(), player.getDuration()); }
                            else { reportPlayback(player.getCurrentTime(), player.getDuration(), player.getPlaybackRate(), true, false); }
                        }
                    }, 5000);
                };
                var tag = document.createElement('script');
                tag.src = 'https://www.youtube.com/iframe_api';
                document.head.appendChild(tag);
                return true;
            }

            if (noticeType === 'video_next_guard') {
                if (!attachHtml5Playback()) { attachYouTubePlayback(); }
            }

            function isNextContinue(el) {
                if (!el) { return false; }
                var text = (el.textContent || el.value || '').toLowerCase().trim();
                var cls = (el.className || '').toString().toLowerCase();
                return (
                    text === 'next' ||
                    text === 'continue' ||
                    text.indexOf('next') !== -1 ||
                    text.indexOf('continue') !== -1 ||
                    cls.indexOf('next') !== -1 ||
                    cls.indexOf('continue') !== -1
                );
            }

            function shouldRewrite(el) {
                if (!el) { return false; }
                var text = (el.textContent || el.value || '').toLowerCase().trim();
                var cls = (el.className || '').toString().toLowerCase();
                var href = (el.getAttribute && el.getAttribute('href')) ? el.getAttribute('href').toLowerCase() : '';
                if (href.indexOf('wp-admin') !== -1 || href.indexOf('logout') !== -1) { return false; }

                if (noticeType === 'video_next_guard') {
                    return isNextContinue(el);
                }

                return (
                    isNextContinue(el) ||
                    text === 'complete' ||
                    cls.indexOf('lp-button') !== -1
                );
            }

            function rewriteLinks() {
                if (noticeType === 'video_next_guard') { return; }
                document.querySelectorAll('a[href]').forEach(function(a){
                    if (shouldRewrite(a) && a.href !== target) {
                        a.setAttribute('data-gbvqg-original-href', a.href);
                        a.href = target;
                    }
                });
            }

            function verifyVideoCompletion(attempt) {
                attempt = attempt || 1;
                var body = new URLSearchParams();
                body.set('action', 'gbvqg_verify_video_completion');
                body.set('gate_id', gateId);
                body.set('nonce', ajaxNonce);

                return fetch(ajaxUrl, {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
                    body: body.toString()
                }).then(function(response){
                    return response.json();
                }).then(function(payload){
                    if (payload && payload.success && payload.data && payload.data.completed) {
                        window.location.href = target;
                        return;
                    }
                    if (attempt < 5) {
                        window.setTimeout(function(){ verifyVideoCompletion(attempt + 1); }, 350);
                        return;
                    }
                    window.location.reload();
                }).catch(function(){
                    window.location.reload();
                });
            }

            function interceptClicks(ev) {
                var el = ev.target && ev.target.closest ? ev.target.closest('a,button,input[type="button"],input[type="submit"]') : null;
                if (!el || !shouldRewrite(el)) { return; }

                if (noticeType === 'video_next_guard') {
                    if (!gateId || !ajaxNonce || verifying) {
                        ev.preventDefault();
                        ev.stopImmediatePropagation();
                        return;
                    }
                    ev.preventDefault();
                    ev.stopImmediatePropagation();
                    verifying = true;
                    if (typeof el.setAttribute === 'function') {
                        el.setAttribute('aria-busy', 'true');
                    }
                    verifyVideoCompletion(1);
                    return;
                }

                if (el.tagName && el.tagName.toLowerCase() === 'a') {
                    return;
                }

                ev.preventDefault();
                ev.stopImmediatePropagation();
                window.location.href = target;
            }

            rewriteLinks();
            document.addEventListener('click', interceptClicks, true);

            if (window.MutationObserver) {
                var observer = new MutationObserver(function(){ rewriteLinks(); });
                observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['href', 'class'] });
            }
        })();
        </script>
        <?php
    }

    public function ajax_verify_video_completion() {
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => 'Login required.' ), 403 );
        }

        $gate_id = isset( $_POST['gate_id'] ) ? sanitize_key( wp_unslash( $_POST['gate_id'] ) ) : '';
        $nonce   = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
        if ( ! $gate_id || ! wp_verify_nonce( $nonce, 'gbvqg_verify_video_' . $gate_id ) ) {
            wp_send_json_error( array( 'message' => 'Invalid verification request.' ), 403 );
        }

        $gate = $this->find_gate_by_id( $gate_id );
        if ( ! $gate || ! $this->is_gate_enabled( $gate ) ) {
            wp_send_json_error( array( 'message' => 'Gate not found or inactive.' ), 404 );
        }

        $user_id   = get_current_user_id();
        $course_id = absint( $gate['course_id'] );
        $lesson_id = absint( $gate['video_lesson_id'] );
        if ( ! $this->user_has_lp_course_record( $user_id, $course_id ) ) {
            wp_send_json_error( array( 'message' => 'Course enrollment was not found.' ), 403 );
        }

        $state     = $this->get_lp_item_state( $user_id, $course_id, $lesson_id );
        $completed = $this->has_verified_playback( $user_id, $gate );

        if ( ! $completed ) {
            $this->log_event_once( 'video_next_waiting_for_server_completion', $user_id, $gate, array(
                'lesson_status'       => $state['status'],
                'lesson_user_item_id' => absint( $state['user_item_id'] ),
                'lesson_updated_at'   => $state['updated_at'],
                'reason'              => 'Next/Continue appeared before the server held verified playback evidence for the mapped media.',
            ) );
        }

        wp_send_json_success( array(
            'completed'    => $completed,
            'status'       => $state['status'],
            'user_item_id' => absint( $state['user_item_id'] ),
            'updated_at'   => $state['updated_at'],
        ) );
    }

    private function playback_meta_key( $gate ) {
        return self::PLAYBACK_META_PREFIX . sanitize_key( $gate['gate_id'] ?? $this->gate_id( $gate ) );
    }

    private function get_playback_evidence( $user_id, $gate ) {
        $evidence = get_user_meta( absint( $user_id ), $this->playback_meta_key( $gate ), true );
        return is_array( $evidence ) ? $evidence : array();
    }

    private function has_verified_playback( $user_id, $gate ) {
        $evidence = $this->get_playback_evidence( $user_id, $gate );
        $stored_hash = (string) ( $evidence['record_hash'] ?? '' );
        $hash_record = $evidence;
        unset( $hash_record['record_hash'] );
        $valid_hash = $stored_hash && hash_equals( $stored_hash, hash_hmac( 'sha256', wp_json_encode( $hash_record ), wp_salt( 'auth' ) ) );
        return $valid_hash && ! empty( $evidence['complete'] )
            && ! empty( $evidence['completed_at_utc'] )
            && hash_equals( (string) ( $evidence['gate_id'] ?? '' ), (string) ( $gate['gate_id'] ?? $this->gate_id( $gate ) ) )
            && absint( $evidence['course_id'] ?? 0 ) === absint( $gate['course_id'] )
            && absint( $evidence['lesson_id'] ?? 0 ) === absint( $gate['video_lesson_id'] );
    }

    private function invalidate_playback_evidence( $user_id, $gate, $reason ) {
        $prior = $this->get_playback_evidence( $user_id, $gate );
        delete_user_meta( absint( $user_id ), $this->playback_meta_key( $gate ) );
        delete_transient( 'gbvqg_pb_' . absint( $user_id ) . '_' . $gate['gate_id'] );
        $this->log_event( 'playback_evidence_invalidated', $user_id, $gate, array(
            'reason' => sanitize_key( $reason ),
            'prior_record_hash' => (string) ( $prior['record_hash'] ?? '' ),
        ) );
    }

    private function playback_request_gate() {
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => 'Login required.' ), 403 );
        }
        $gate_id = isset( $_POST['gate_id'] ) ? sanitize_key( wp_unslash( $_POST['gate_id'] ) ) : '';
        $nonce   = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
        if ( ! $gate_id || ! wp_verify_nonce( $nonce, 'gbvqg_verify_video_' . $gate_id ) ) {
            wp_send_json_error( array( 'message' => 'Invalid playback request.' ), 403 );
        }
        $gate = $this->find_gate_by_id( $gate_id );
        if ( ! $gate || ! $this->is_gate_enabled( $gate ) ) {
            wp_send_json_error( array( 'message' => 'Gate not found or inactive.' ), 404 );
        }
        if ( ! $this->user_has_lp_course_record( get_current_user_id(), absint( $gate['course_id'] ) ) ) {
            wp_send_json_error( array( 'message' => 'Course enrollment was not found.' ), 403 );
        }
        return $gate;
    }

    public function ajax_playback_start() {
        $gate     = $this->playback_request_gate();
        $duration = isset( $_POST['duration'] ) ? (float) $_POST['duration'] : 0.0;
        $position = isset( $_POST['position'] ) ? (float) $_POST['position'] : 0.0;
        if ( $duration < 10 || $duration > 14400 || $position < 0 || $position > 3.0 ) {
            wp_send_json_error( array( 'message' => 'Playback must begin at the start of a readable video.' ), 409 );
        }
        $user_id = get_current_user_id();
        $token   = wp_generate_password( 48, false, false );
        $session = array(
            'token_hash' => hash( 'sha256', $token ),
            'user_id'    => $user_id,
            'gate_id'    => $gate['gate_id'],
            'course_id'  => absint( $gate['course_id'] ),
            'lesson_id'  => absint( $gate['video_lesson_id'] ),
            'duration'   => $duration,
            'last_media' => $position,
            'furthest_media' => $position,
            'last_wall'  => microtime( true ),
            'watched'    => 0.0,
            'sequence'   => 0,
            'violations' => array(),
            'started_at_utc' => gmdate( 'Y-m-d H:i:s' ),
        );
        set_transient( 'gbvqg_pb_' . $user_id . '_' . $gate['gate_id'], $session, self::PLAYBACK_SESSION_TTL );
        $this->log_event( 'playback_session_started', $user_id, $gate, array( 'duration_seconds' => $duration ) );
        wp_send_json_success( array( 'token' => $token, 'sequence' => 0 ) );
    }

    public function ajax_playback_progress() {
        $gate    = $this->playback_request_gate();
        $user_id = get_current_user_id();
        $key     = 'gbvqg_pb_' . $user_id . '_' . $gate['gate_id'];
        $session = get_transient( $key );
        $token   = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
        $seq     = isset( $_POST['sequence'] ) ? absint( $_POST['sequence'] ) : 0;
        if ( ! is_array( $session ) || ! $token || ! hash_equals( (string) $session['token_hash'], hash( 'sha256', $token ) ) || $seq !== absint( $session['sequence'] ) + 1 ) {
            wp_send_json_error( array( 'message' => 'Playback session expired or was received out of order.' ), 409 );
        }

        $now      = microtime( true );
        $position = isset( $_POST['position'] ) ? (float) $_POST['position'] : -1.0;
        $duration = isset( $_POST['duration'] ) ? (float) $_POST['duration'] : 0.0;
        $rate     = isset( $_POST['rate'] ) ? (float) $_POST['rate'] : 0.0;
        $playing  = ! empty( $_POST['playing'] );
        $visible  = ! empty( $_POST['visible'] );
        $focused  = ! empty( $_POST['focused'] );
        $seeking  = ! empty( $_POST['seeking'] );
        $ended    = ! empty( $_POST['ended'] );
        $wall_delta  = max( 0.0, $now - (float) $session['last_wall'] );
        $media_delta = $position - (float) $session['last_media'];
        $valid = $playing && $visible && $focused && ! $seeking
            && $rate >= 0.95 && $rate <= 1.05
            && abs( $duration - (float) $session['duration'] ) <= 1.0
            && $wall_delta >= 1.0 && $wall_delta <= 20.0
            && $media_delta >= 0.25 && $media_delta <= $wall_delta + 1.5
            && $position <= (float) $session['furthest_media'] + $wall_delta + 1.5;

        if ( $valid ) {
            $new_contiguous = min( $position, (float) $session['furthest_media'] + $wall_delta );
            if ( $new_contiguous > (float) $session['furthest_media'] ) {
                $session['furthest_media'] = $new_contiguous;
                $session['watched'] = max( (float) $session['watched'], $new_contiguous );
            }
        } else {
            $session['violations'][] = array(
                'at_utc' => gmdate( 'Y-m-d H:i:s' ), 'position' => $position, 'rate' => $rate,
                'playing' => $playing, 'visible' => $visible, 'focused' => $focused, 'seeking' => $seeking,
            );
            $session['violations'] = array_slice( $session['violations'], -25 );
        }
        $session['last_media'] = max( 0.0, $position );
        $session['last_wall']  = $now;
        $session['sequence']   = $seq;

        $threshold = max( 8.0, (float) $session['duration'] - 5.0 );
        $complete  = $ended && $position >= (float) $session['duration'] - 2.5 && (float) $session['watched'] >= $threshold;
        if ( $complete ) {
            $evidence = array(
                'schema' => 1, 'complete' => 1, 'gate_id' => $gate['gate_id'],
                'course_id' => absint( $gate['course_id'] ), 'lesson_id' => absint( $gate['video_lesson_id'] ),
                'duration_seconds' => round( (float) $session['duration'], 3 ),
                'verified_watch_seconds' => round( (float) $session['watched'], 3 ),
                'started_at_utc' => $session['started_at_utc'], 'completed_at_utc' => gmdate( 'Y-m-d H:i:s' ),
                'heartbeat_count' => $seq, 'violation_count' => count( $session['violations'] ),
            );
            $evidence['record_hash'] = hash_hmac( 'sha256', wp_json_encode( $evidence ), wp_salt( 'auth' ) );
            update_user_meta( $user_id, $this->playback_meta_key( $gate ), $evidence );
            delete_transient( $key );
            $this->log_event( 'verified_playback_completed', $user_id, $gate, $evidence );
            wp_send_json_success( array( 'complete' => true, 'watched' => $evidence['verified_watch_seconds'] ) );
        }
        set_transient( $key, $session, self::PLAYBACK_SESSION_TTL );
        wp_send_json_success( array( 'complete' => false, 'accepted' => $valid, 'watched' => round( (float) $session['watched'], 3 ), 'sequence' => $seq ) );
    }

    public function capture_next_item_progress_probe() {
        if ( is_admin() || ! is_user_logged_in() || current_user_can( 'manage_options' ) || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
            return;
        }

        $context = $this->detect_context();
        $item_id = absint( $context['item_id'] ?? 0 );
        if ( ! $item_id ) {
            return;
        }

        $user_id = get_current_user_id();
        foreach ( $this->get_gates() as $gate ) {
            if ( ! $this->is_gate_enabled( $gate ) ) {
                continue;
            }

            $course_id = absint( $gate['course_id'] );
            if ( ! empty( $context['course_id'] ) && absint( $context['course_id'] ) !== $course_id ) {
                continue;
            }

            $next_id = absint( $gate['next_item_id'] );
            if ( ! $next_id ) {
                $next_id = $this->get_next_item_after( $course_id, absint( $gate['quiz_id'] ) );
            }
            if ( ! $next_id || $item_id !== $next_id ) {
                continue;
            }

            $gate_state  = $this->get_gate_state( $user_id, $gate );
            $rows        = $this->get_lp_item_rows_snapshot( $user_id, $course_id, absint( $gate['quiz_id'] ) );
            $db_passed   = $this->lp_rows_have_status( $rows, 'passed' );
            $db_complete = $this->lp_rows_have_status( $rows, 'completed' );
            if ( empty( $gate_state['passed'] ) && ! $db_passed && ! $db_complete ) {
                continue;
            }

            $recognition = $this->get_learnpress_item_recognition( $user_id, $course_id, absint( $gate['quiz_id'] ) );
            $this->log_event_once( 'next_item_progress_probe', $user_id, $gate, array(
                'requested_next_item_id'       => $item_id,
                'custom_gate_passed'           => ! empty( $gate_state['passed'] ),
                'database_has_completed_row'   => $db_complete,
                'database_has_passed_row'      => $db_passed,
                'learnpress_recognition'       => $recognition,
                'would_sequential_drip_lock'   => empty( $recognition['is_completed'] ),
                'quiz_user_item_rows'          => $rows,
                'instruction'                  => 'Capture this report before using Course Progress Fix if the student is redirected or remains locked.',
            ) );
            break;
        }
    }

    public function shortcode_status() {
        if ( ! is_user_logged_in() ) {
            return '';
        }
        $context = $this->detect_context();
        if ( empty( $context['item_id'] ) ) {
            return '';
        }
        $user_id = get_current_user_id();
        foreach ( $this->get_gates() as $gate ) {
            if ( $this->is_gate_enabled( $gate ) && $this->context_matches_gate( $context, $gate ) ) {
                $quiz_state = $this->get_lp_item_state( $user_id, absint( $gate['course_id'] ), absint( $gate['quiz_id'] ) );
                return '<div class="gbvqg-status">Video quiz gate status: ' . esc_html( $quiz_state['status'] ) . '</div>';
            }
        }
        return '';
    }

    private function detect_context() {
        $context = array(
            'course_id' => 0,
            'item_id'   => 0,
            'source'    => 'unknown',
        );

        $qid             = absint( get_queried_object_id() );
        $path            = $this->current_request_path();
        $path_course_id  = $this->detect_course_id_from_request_path( $path );

        if ( $qid && in_array( get_post_type( $qid ), array( 'lp_lesson', 'lp_quiz' ), true ) ) {
            $context['item_id']   = $qid;
            $context['course_id'] = $path_course_id ? $path_course_id : $this->find_course_for_item( $qid );
            $context['source']    = $path_course_id ? 'queried_object_course_path' : 'queried_object';
        }

        if ( empty( $context['item_id'] ) ) {
            global $post;
            if ( $post instanceof WP_Post && in_array( get_post_type( $post ), array( 'lp_lesson', 'lp_quiz' ), true ) ) {
                $context['item_id']   = absint( $post->ID );
                $context['course_id'] = $path_course_id ? $path_course_id : $this->find_course_for_item( $post->ID );
                $context['source']    = $path_course_id ? 'global_post_course_path' : 'global_post';
            }
        }

        // Some LearnPress themes keep the queried object as the course and pass the current item by query var.
        // This catches URLs/forms such as ?item_id=1662, ?item=1662, ?course_item=1662, etc.
        if ( empty( $context['item_id'] ) ) {
            $request_item_id = $this->detect_item_id_from_request();
            if ( $request_item_id ) {
                $context['item_id']   = $request_item_id;
                $context['course_id'] = $path_course_id ? $path_course_id : $this->find_course_for_item( $request_item_id );
                $context['source']    = $path_course_id ? 'request_param_course_path' : 'request_param';
            }
        }

        // v0.2.25: Prefer the course slug in the URL when present.
        // A LearnPress item can be reused in more than one course, and find_course_for_item()
        // may return the first matching gated course instead of the course currently in the URL.
        // That wrong course context is exactly the kind of thing that can send a switched/legacy
        // student to a gate path where LearnPress says "please enroll".
        if ( $path_course_id ) {
            $context['course_id'] = $path_course_id;
        }

        // LearnPress often renders course-item URLs with the course path plus /lessons/slug or /quizzes/slug.
        // If WP's queried object is the course instead of the item, infer the item from the request path.
        if ( empty( $context['item_id'] ) || 'lp_course' === get_post_type( $qid ) ) {
            $candidate_courses = array();
            if ( $path_course_id ) {
                $candidate_courses[] = $path_course_id;
            } else {
                foreach ( $this->get_gates() as $gate ) {
                    if ( ! $this->is_gate_enabled( $gate ) ) {
                        continue;
                    }
                    $candidate_courses[] = absint( $gate['course_id'] );
                }
                $candidate_courses = array_values( array_unique( array_filter( $candidate_courses ) ) );
            }

            foreach ( $candidate_courses as $course_id ) {
                $items = $this->get_course_items( $course_id );
                foreach ( $items as $item ) {
                    $item_id = absint( $item['item_id'] );
                    $slug    = get_post_field( 'post_name', $item_id );
                    if ( ! $slug ) {
                        continue;
                    }
                    $type_path = 'lp_quiz' === get_post_type( $item_id ) ? 'quizzes' : 'lessons';
                    if ( false !== strpos( $path, '/' . $type_path . '/' . $slug ) || preg_match( '#/' . preg_quote( $slug, '#' ) . '/?$#', $path ) ) {
                        $context['item_id']   = $item_id;
                        $context['course_id'] = $course_id;
                        $context['source']    = $path_course_id ? 'request_path_course_slug' : 'request_path';
                        break 2;
                    }
                }
            }
        }

        if ( empty( $context['course_id'] ) && ! empty( $context['item_id'] ) ) {
            $context['course_id'] = $this->find_course_for_item( $context['item_id'] );
        }

        return $context;
    }

    private function detect_course_id_from_request_path( $path = '' ) {
        $path = $path ? (string) $path : $this->current_request_path();
        $parts = array_values( array_filter( explode( '/', trim( $path, '/' ) ) ) );
        $count = count( $parts );
        for ( $i = 0; $i < $count - 1; $i++ ) {
            if ( 'courses' !== $parts[ $i ] ) {
                continue;
            }
            $slug = sanitize_title( $parts[ $i + 1 ] );
            if ( ! $slug ) {
                continue;
            }
            $course = get_page_by_path( $slug, OBJECT, 'lp_course' );
            if ( $course instanceof WP_Post && 'lp_course' === get_post_type( $course ) ) {
                return absint( $course->ID );
            }
        }
        return 0;
    }

    private function detect_item_id_from_request() {
        $keys = array(
            'item_id',
            'item',
            'course_item',
            'course_item_id',
            'course-item',
            'learnpress_item',
            'learn_press_item',
            'lp_item',
            'lp_lesson',
            'lp_quiz',
            'lesson_id',
            'quiz_id',
        );

        foreach ( $keys as $key ) {
            $value = 0;
            if ( isset( $_GET[ $key ] ) ) {
                $value = absint( wp_unslash( $_GET[ $key ] ) );
            } elseif ( isset( $_POST[ $key ] ) ) {
                $value = absint( wp_unslash( $_POST[ $key ] ) );
            } else {
                $qv = get_query_var( $key );
                if ( $qv ) {
                    $value = absint( $qv );
                }
            }

            if ( $value && in_array( get_post_type( $value ), array( 'lp_lesson', 'lp_quiz' ), true ) ) {
                return $value;
            }
        }

        return 0;
    }


    private function context_matches_gate( $context, $gate ) {
        $course_id = absint( $gate['course_id'] );
        $item_id   = absint( $context['item_id'] );
        if ( ! $item_id ) {
            return false;
        }

        $items     = $this->get_course_items( $course_id );
        $positions = $this->positions_from_items( $items );
        if ( ! isset( $positions[ $item_id ] ) ) {
            return false;
        }

        // v0.2.26: Only fire when the current LearnPress course context is known
        // and matches this gate's course. If course context is uncertain, skip GBVQG
        // and let LearnPress handle the page normally rather than guessing.
        if ( empty( $context['course_id'] ) || absint( $context['course_id'] ) !== $course_id ) {
            return false;
        }
        return true;
    }

    private function get_course_items( $course_id ) {
        global $wpdb;
        $course_id = absint( $course_id );
        if ( ! $course_id ) {
            return array();
        }
        if ( isset( $this->course_items_cache[ $course_id ] ) ) {
            return $this->course_items_cache[ $course_id ];
        }

        $sections_table = $wpdb->prefix . 'learnpress_sections';
        $items_table    = $wpdb->prefix . 'learnpress_section_items';
        $out            = array();

        if ( $this->table_exists( $sections_table ) && $this->table_exists( $items_table ) ) {
            $sql = $wpdb->prepare(
                "SELECT s.section_id, s.section_name, s.section_order, si.item_id, si.item_order
                 FROM {$sections_table} s
                 INNER JOIN {$items_table} si ON si.section_id = s.section_id
                 WHERE s.section_course_id = %d
                 ORDER BY s.section_order ASC, si.item_order ASC, si.section_item_id ASC",
                $course_id
            );
            $rows = $wpdb->get_results( $sql, ARRAY_A );
            if ( is_array( $rows ) ) {
                foreach ( $rows as $row ) {
                    $out[] = array(
                        'section_id'    => absint( $row['section_id'] ),
                        'section_name'  => sanitize_text_field( $row['section_name'] ),
                        'section_order' => intval( $row['section_order'] ),
                        'item_id'       => absint( $row['item_id'] ),
                        'item_order'    => intval( $row['item_order'] ),
                    );
                }
            }
        }

        $this->course_items_cache[ $course_id ] = $out;
        return $out;
    }

    private function positions_from_items( $items ) {
        $positions = array();
        foreach ( array_values( $items ) as $idx => $item ) {
            $positions[ absint( $item['item_id'] ) ] = $idx;
        }
        return $positions;
    }

    private function get_next_item_after( $course_id, $item_id ) {
        $items = array_values( $this->get_course_items( $course_id ) );
        foreach ( $items as $idx => $item ) {
            if ( absint( $item['item_id'] ) === absint( $item_id ) ) {
                return ! empty( $items[ $idx + 1 ]['item_id'] ) ? absint( $items[ $idx + 1 ]['item_id'] ) : 0;
            }
        }
        return 0;
    }

    private function find_course_for_item( $item_id ) {
        global $wpdb;
        $item_id = absint( $item_id );
        if ( ! $item_id ) {
            return 0;
        }

        foreach ( $this->get_gates() as $gate ) {
            $course_id = absint( $gate['course_id'] );
            $positions = $this->positions_from_items( $this->get_course_items( $course_id ) );
            if ( isset( $positions[ $item_id ] ) ) {
                return $course_id;
            }
        }

        $sections_table = $wpdb->prefix . 'learnpress_sections';
        $items_table    = $wpdb->prefix . 'learnpress_section_items';
        if ( $this->table_exists( $sections_table ) && $this->table_exists( $items_table ) ) {
            return absint( $wpdb->get_var( $wpdb->prepare(
                "SELECT s.section_course_id
                 FROM {$sections_table} s
                 INNER JOIN {$items_table} si ON si.section_id = s.section_id
                 WHERE si.item_id = %d
                 ORDER BY s.section_id DESC
                 LIMIT 1",
                $item_id
            ) ) );
        }
        return 0;
    }

    private function get_quiz_question_count( $quiz_id ) {
        global $wpdb;
        $quiz_id = absint( $quiz_id );
        if ( ! $quiz_id ) {
            return null;
        }

        $table = $wpdb->prefix . 'learnpress_quiz_questions';
        if ( $this->table_exists( $table ) ) {
            $cols = $this->table_columns( $table );
            if ( in_array( 'quiz_id', $cols, true ) ) {
                return absint( $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE quiz_id = %d", $quiz_id ) ) );
            }
        }

        $possible_meta_keys = array( '_lp_questions', '_quiz_questions', '_lp_quiz_questions', 'questions' );
        foreach ( $possible_meta_keys as $key ) {
            $raw = get_post_meta( $quiz_id, $key, true );
            if ( empty( $raw ) ) {
                continue;
            }
            if ( is_array( $raw ) ) {
                return count( $raw );
            }
            $maybe = maybe_unserialize( $raw );
            if ( is_array( $maybe ) ) {
                return count( $maybe );
            }
            $json = json_decode( $raw, true );
            if ( is_array( $json ) ) {
                return count( $json );
            }
        }
        return null;
    }

    private function sync_quiz_state( $user_id, $gate ) {
        $course_id = absint( $gate['course_id'] );
        $quiz_id   = absint( $gate['quiz_id'] );
        $lp_state  = $this->get_lp_item_state( $user_id, $course_id, $quiz_id );
        $state     = $this->get_gate_state( $user_id, $gate );

        // v0.2.31: Private state is authoritative only when backed by a verified
        // passing attempt, an actual LearnPress pass, or a documented manual exemption.
        // A legacy automatic grandfather flag without those records is a mismatch, not a pass.
        if ( ! empty( $state['force_validation_required'] ) ) {
            return $lp_state;
        }

        // v0.2.32: Active courses may recover a missing LearnPress row only from
        // a stored, question-level, verified passing attempt. No attempt means no pass.
        if ( $this->is_active_strict_course( $course_id ) && ! in_array( (string) ( $lp_state['status'] ?? '' ), array( 'passed', 'completed' ), true ) ) {
            $verified_attempt = $this->get_latest_verified_pass_attempt( $user_id, $gate );
            $lp_rows = $this->get_lp_item_rows_snapshot( $user_id, $course_id, $quiz_id );
            if ( $verified_attempt && empty( $lp_rows ) ) {
                $checked = ! empty( $verified_attempt['checked'] ) && is_array( $verified_attempt['checked'] ) ? $verified_attempt['checked'] : ( ! empty( $verified_attempt['questions'] ) && is_array( $verified_attempt['questions'] ) ? $verified_attempt['questions'] : array() );
                $user_item_id = $this->mark_lp_quiz_item_result( $user_id, $gate, true, array(
                    'checked' => $checked,
                    'correct_count' => absint( $verified_attempt['correct_count'] ?? count( $checked ) ),
                    'shown_count' => max( 1, absint( $verified_attempt['shown_count'] ?? count( $checked ) ) ),
                ) );
                $recognition = $this->get_learnpress_item_recognition( $user_id, $course_id, $quiz_id );
                if ( $user_item_id && ! empty( $recognition['is_completed'] ) && ! empty( $recognition['is_passed'] ) ) {
                    $state['passed'] = 1;
                    $state['passed_at'] = (string) ( $verified_attempt['submitted_at'] ?? current_time( 'mysql', true ) );
                    $state['last_status'] = 'passed_auto_recovered_from_verified_attempt';
                    $state['course_policy_version'] = self::COURSE_POLICY_VERSION;
                    $this->set_gate_state( $user_id, $gate, $state );
                    $this->log_event_once( 'active_course_auto_recovered_learnpress_from_verified_attempt', $user_id, $gate, array(
                        'user_item_id' => $user_item_id,
                        'recognition' => $recognition,
                        'course_policy_version' => self::COURSE_POLICY_VERSION,
                    ) );
                    return $this->get_lp_item_state( $user_id, $course_id, $quiz_id );
                }
                if ( $user_item_id ) {
                    $this->delete_lp_user_item_and_meta( $user_item_id );
                }
                $this->log_event_once( 'active_course_verified_attempt_recovery_failed', $user_id, $gate, array(
                    'recognition' => $recognition,
                    'course_policy_version' => self::COURSE_POLICY_VERSION,
                ) );
            }
        }

        if ( ! empty( $state['passed'] ) ) {
            $verified_attempt = $this->get_latest_verified_pass_attempt( $user_id, $gate );
            $manual_exemption = ! empty( $state['manual_exemption'] ) && in_array( (string) ( $state['grandfather_reason'] ?? '' ), array( 'manual_documented_exemption', 'retired_course_documented_legacy_exemption' ), true );
            if ( 'passed' === $lp_state['status'] || $verified_attempt || $manual_exemption ) {
                $lp_state['status'] = 'passed';
                return $lp_state;
            }
            $this->log_event_once( 'private_pass_without_supporting_record', $user_id, $gate, array(
                'state'    => $state,
                'lp_state' => $lp_state,
            ) );
        }

        if ( 'passed' === $lp_state['status'] ) {
            $state['passed']      = 1;
            $state['passed_at']   = $lp_state['updated_at'] ? $lp_state['updated_at'] : current_time( 'mysql', true );
            $state['failed_at']   = '';
            $state['last_status'] = 'passed';
            $state['course_policy_version'] = self::COURSE_POLICY_VERSION;
            $this->set_gate_state( $user_id, $gate, $state );
            $this->log_event_once( 'quiz_passed', $user_id, $gate, array( 'user_item_id' => $lp_state['user_item_id'] ) );
        } elseif ( 'failed' === $lp_state['status'] ) {
            if ( empty( $state['last_failed_user_item_id'] ) || absint( $state['last_failed_user_item_id'] ) !== absint( $lp_state['user_item_id'] ) ) {
                $state['passed']                   = 0;
                $state['failed_at']                = $lp_state['updated_at'] ? $lp_state['updated_at'] : current_time( 'mysql', true );
                $state['rewatch_visited_at']       = '';
                $state['last_status']              = 'failed';
                $state['last_failed_user_item_id'] = absint( $lp_state['user_item_id'] );
                $this->set_gate_state( $user_id, $gate, $state );
                $this->log_event( 'quiz_failed', $user_id, $gate, array( 'user_item_id' => $lp_state['user_item_id'] ) );
            }
        }

        return $this->get_lp_item_state( $user_id, $course_id, $quiz_id );
    }

    private function mark_rewatch_visit( $user_id, $gate ) {
        $state = $this->get_gate_state( $user_id, $gate );
        $state['rewatch_visited_at'] = current_time( 'mysql', true );
        $this->set_gate_state( $user_id, $gate, $state );
        $this->log_event_once( 'rewatch_video_visited', $user_id, $gate, array( 'failed_at' => $state['failed_at'] ?? '' ) );
        return $state;
    }

    private function get_gate_state_key( $gate ) {
        return '_gbvqg_state_' . $this->gate_id( $gate );
    }

    private function get_gate_state( $user_id, $gate ) {
        $state = get_user_meta( $user_id, $this->get_gate_state_key( $gate ), true );
        return is_array( $state ) ? $state : array();
    }

    private function set_gate_state( $user_id, $gate, $state ) {
        update_user_meta( $user_id, $this->get_gate_state_key( $gate ), is_array( $state ) ? $state : array() );
    }

    private function mark_gate_sequence( $user_id, $gate, $details = array() ) {
        $state = $this->get_gate_state( $user_id, $gate );
        if ( empty( $state['sequence_started_at'] ) ) {
            $state['sequence_started_at'] = current_time( 'mysql', true );
        }
        $state['sequence_details'] = is_array( $details ) ? $details : array();
        $this->set_gate_state( $user_id, $gate, $state );
    }

    private function clear_gate_sequence( $user_id, $gate ) {
        $state = $this->get_gate_state( $user_id, $gate );
        unset( $state['sequence_started_at'], $state['sequence_details'] );
        $this->set_gate_state( $user_id, $gate, $state );
    }

    private function user_has_lp_course_record( $user_id, $course_id ) {
        global $wpdb;
        $user_id   = absint( $user_id );
        $course_id = absint( $course_id );
        if ( ! $user_id || ! $course_id ) {
            return false;
        }

        $table = $wpdb->prefix . 'learnpress_user_items';
        if ( ! $this->table_exists( $table ) ) {
            // Fail open if the LearnPress table cannot be inspected. The gate should
            // not become a site-wide lockout because a diagnostic query is unavailable.
            return true;
        }
        $cols = $this->table_columns( $table );
        if ( ! in_array( 'user_id', $cols, true ) || ! in_array( 'item_id', $cols, true ) ) {
            return true;
        }

        $count = absint( $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND item_id = %d",
            $user_id,
            $course_id
        ) ) );

        return $count > 0;
    }

    private function find_completed_course_item_after_position_read_only( $user_id, $course_id, $items, $after_position ) {
        if ( null === $after_position ) {
            return array();
        }
        foreach ( array_values( (array) $items ) as $idx => $item ) {
            $position = absint( $idx );
            if ( $position <= $after_position ) {
                continue;
            }
            $item_id = absint( $item['item_id'] ?? 0 );
            if ( ! $item_id || ! in_array( get_post_type( $item_id ), array( 'lp_lesson', 'lp_quiz' ), true ) ) {
                continue;
            }
            $item_state = $this->get_lp_item_state( $user_id, $course_id, $item_id );
            if ( in_array( $item_state['status'], array( 'passed', 'completed' ), true ) ) {
                return array(
                    'item_id'    => $item_id,
                    'position'   => $position,
                    'title'      => get_the_title( $item_id ),
                    'status'     => $item_state['status'],
                    'updated_at' => $item_state['updated_at'],
                );
            }
        }
        return array();
    }

    private function get_latest_verified_pass_attempt( $user_id, $gate ) {
        $user_id = absint( $user_id );
        $gate_id = $this->gate_id( $gate );
        if ( ! $user_id || ! $gate_id ) {
            return array();
        }

        $candidates = array();
        $history = get_user_meta( $user_id, '_gbvqg_attempt_history_' . $gate_id, true );
        if ( is_array( $history ) ) {
            $candidates = array_merge( $candidates, array_reverse( $history ) );
        }
        $detail = get_user_meta( $user_id, '_gbvqg_attempt_detail_' . $gate_id, true );
        if ( is_array( $detail ) ) {
            array_unshift( $candidates, $detail );
        }

        foreach ( $candidates as $attempt ) {
            if ( ! is_array( $attempt ) || empty( $attempt['passed'] ) ) {
                continue;
            }
            $shown   = absint( $attempt['shown_count'] ?? $attempt['question_count'] ?? 0 );
            $correct = absint( $attempt['correct_count'] ?? $attempt['question_correct'] ?? 0 );
            $rows    = ! empty( $attempt['questions'] ) && is_array( $attempt['questions'] ) ? $attempt['questions'] : ( ! empty( $attempt['checked'] ) && is_array( $attempt['checked'] ) ? $attempt['checked'] : array() );
            if ( $shown > 0 && $correct >= $shown && ! empty( $rows ) ) {
                return $attempt;
            }
        }
        return array();
    }

    private function analyze_gate_state_evidence( $user_id, $gate, $lp_state = null, $state = null ) {
        $user_id   = absint( $user_id );
        $course_id = absint( $gate['course_id'] ?? 0 );
        $quiz_id   = absint( $gate['quiz_id'] ?? 0 );
        $state     = is_array( $state ) ? $state : $this->get_gate_state( $user_id, $gate );
        $lp_state  = is_array( $lp_state ) ? $lp_state : $this->get_lp_item_state( $user_id, $course_id, $quiz_id );
        $lp_rows   = $this->get_lp_item_rows_snapshot( $user_id, $course_id, $quiz_id );
        $attempt   = $this->get_latest_verified_pass_attempt( $user_id, $gate );

        $state_claims_pass = ! empty( $state['passed'] ) || ! empty( $state['grandfathered'] );
        $force_required    = ! empty( $state['force_validation_required'] );
        $grandfather_reason = (string) ( $state['grandfather_reason'] ?? '' );
        $manual_exemption  = ! empty( $state['manual_exemption'] ) && in_array( $grandfather_reason, array( 'manual_documented_exemption', 'retired_course_documented_legacy_exemption' ), true );
        $retired_legacy_exemption = $manual_exemption && 'retired_course_documented_legacy_exemption' === $grandfather_reason;
        $lp_passed         = 'passed' === (string) ( $lp_state['status'] ?? '' );
        $lp_completed      = in_array( (string) ( $lp_state['status'] ?? '' ), array( 'passed', 'completed' ), true );

        if ( $force_required ) {
            $classification = 'quiz_required_by_admin';
        } elseif ( $retired_legacy_exemption ) {
            $classification = 'retired_course_legacy_exemption';
        } elseif ( $manual_exemption ) {
            $classification = 'documented_exemption';
        } elseif ( $attempt && ! $lp_completed && empty( $lp_rows ) ) {
            $classification = 'verified_attempt_missing_learnpress';
        } elseif ( $attempt && ! $lp_completed ) {
            $classification = 'verified_attempt_conflicts_with_learnpress';
        } elseif ( $lp_passed || $attempt ) {
            $classification = 'verified_pass';
        } elseif ( $state_claims_pass && ! $lp_completed ) {
            $classification = 'unverified_legacy_grandfather';
        } elseif ( $lp_completed ) {
            $classification = 'learnpress_completed_without_private_pass';
        } else {
            $classification = 'not_passed';
        }

        return array(
            'classification'               => $classification,
            'state'                        => $state,
            'lp_state'                     => $lp_state,
            'lp_rows'                      => $lp_rows,
            'state_claims_pass'            => $state_claims_pass,
            'force_validation_required'    => $force_required,
            'manual_exemption'             => $manual_exemption,
            'retired_legacy_exemption'      => $retired_legacy_exemption,
            'course_policy'                  => $this->course_policy( $course_id ),
            'course_policy_label'            => $this->course_policy_label( $course_id ),
            'verified_pass_attempt'         => $attempt,
            'database_has_completed_row'   => $this->lp_rows_have_status( $lp_rows, 'completed' ),
            'database_has_passed_row'      => $this->lp_rows_have_status( $lp_rows, 'passed' ),
            'would_sequential_drip_lock'   => ! $lp_completed,
        );
    }

    private function gate_evidence_label( $classification ) {
        $labels = array(
            'verified_pass'                          => 'Verified video-check pass',
            'verified_attempt_missing_learnpress'    => 'Verified pass attempt; LearnPress record missing',
            'verified_attempt_conflicts_with_learnpress' => 'Verified pass attempt conflicts with existing LearnPress row',
            'documented_exemption'                   => 'Documented administrator exemption',
            'retired_course_legacy_exemption'         => 'Documented retired-course legacy exemption',
            'quiz_required_by_admin'                 => 'Quiz required by administrator',
            'unverified_legacy_grandfather'           => 'Unverified legacy grandfather mismatch',
            'learnpress_completed_without_private_pass' => 'LearnPress completed; private state not passed',
            'not_passed'                             => 'Quiz not passed',
            'unknown'                                => 'Unknown',
        );
        return $labels[ $classification ] ?? ucwords( str_replace( '_', ' ', (string) $classification ) );
    }

    private function current_admin_repair_url( $user_id, $gate_id ) {
        return add_query_arg( array(
            'page'               => 'gb-video-quiz-gate',
            'gbvqg_repair_user'  => absint( $user_id ),
            'gbvqg_repair_gate'  => sanitize_key( $gate_id ),
        ), admin_url( 'admin.php' ) );
    }

    private function get_gate_state_audit_rows( $limit = 500, $course_filter = 0 ) {
        global $wpdb;
        $limit = max( 1, min( 2000, absint( $limit ) ) );
        $prefix = $wpdb->esc_like( '_gbvqg_state_' ) . '%';
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE meta_key LIKE %s ORDER BY umeta_id DESC LIMIT %d",
            $prefix,
            $limit
        ), ARRAY_A );
        $results = array();
        $seen = array();
        foreach ( (array) $rows as $row ) {
            $user_id = absint( $row['user_id'] ?? 0 );
            $meta_key = (string) ( $row['meta_key'] ?? '' );
            $gate_id = sanitize_key( substr( $meta_key, strlen( '_gbvqg_state_' ) ) );
            $dedupe = $user_id . ':' . $gate_id;
            if ( ! $user_id || ! $gate_id || isset( $seen[ $dedupe ] ) ) {
                continue;
            }
            $seen[ $dedupe ] = true;
            $gate = $this->find_gate_by_id( $gate_id );
            if ( ! $gate ) {
                continue;
            }
            if ( $course_filter && absint( $gate['course_id'] ?? 0 ) !== absint( $course_filter ) ) {
                continue;
            }
            $state = maybe_unserialize( $row['meta_value'] ?? '' );
            $state = is_array( $state ) ? $state : array();
            if ( empty( $state['passed'] ) && empty( $state['grandfathered'] ) && empty( $state['force_validation_required'] ) ) {
                continue;
            }
            $analysis = $this->analyze_gate_state_evidence( $user_id, $gate, null, $state );
            if ( ! in_array( $analysis['classification'], array( 'unverified_legacy_grandfather', 'verified_attempt_missing_learnpress', 'verified_attempt_conflicts_with_learnpress', 'quiz_required_by_admin', 'documented_exemption', 'retired_course_legacy_exemption' ), true ) ) {
                continue;
            }
            $user = get_userdata( $user_id );
            $results[] = array(
                'user_id'         => $user_id,
                'student_label'   => $user ? $user->display_name . ' (#' . $user_id . ')' : 'User #' . $user_id,
                'gate_id'         => $gate_id,
                'gate_label'      => (string) ( $gate['label'] ?? 'Video gate' ) . ' — Course #' . absint( $gate['course_id'] ?? 0 ) . ' / Quiz #' . absint( $gate['quiz_id'] ?? 0 ),
                'classification'  => $analysis['classification'],
                'lp_status'       => (string) ( $analysis['lp_state']['status'] ?? 'unknown' ),
                'lp_user_item_id' => absint( $analysis['lp_state']['user_item_id'] ?? 0 ),
                'policy_label'     => $this->course_policy_label( absint( $gate['course_id'] ?? 0 ) ),
            );
        }
        return $results;
    }

    private function backup_gate_repair_state( $user_id, $gate, $analysis, $mode ) {
        $key = '_gbvqg_repair_backup_' . $this->gate_id( $gate ) . '_' . gmdate( 'YmdHis' );
        update_user_meta( absint( $user_id ), $key, array(
            'created_utc'    => gmdate( 'Y-m-d H:i:s' ),
            'admin_user_id'  => get_current_user_id(),
            'repair_mode'    => sanitize_key( $mode ),
            'plugin_version' => self::VERSION,
            'gate'           => $gate,
            'analysis'       => $analysis,
        ) );
        return $key;
    }

    private function delete_lp_user_item_and_meta( $user_item_id ) {
        global $wpdb;
        $user_item_id = absint( $user_item_id );
        if ( ! $user_item_id ) {
            return;
        }
        $meta_table = $wpdb->prefix . 'learnpress_user_itemmeta';
        if ( $this->table_exists( $meta_table ) ) {
            $meta_cols = $this->table_columns( $meta_table );
            $id_col = in_array( 'learnpress_user_item_id', $meta_cols, true ) ? 'learnpress_user_item_id' : ( in_array( 'user_item_id', $meta_cols, true ) ? 'user_item_id' : '' );
            if ( $id_col ) {
                $wpdb->delete( $meta_table, array( $id_col => $user_item_id ) );
            }
        }
        $items_table = $wpdb->prefix . 'learnpress_user_items';
        if ( $this->table_exists( $items_table ) && in_array( 'user_item_id', $this->table_columns( $items_table ), true ) ) {
            $wpdb->delete( $items_table, array( 'user_item_id' => $user_item_id ) );
        }
    }

    private function mark_lp_quiz_item_exemption( $user_id, $gate, $reason, $admin_id, $exemption_type = 'administrator' ) {
        global $wpdb;
        $user_id   = absint( $user_id );
        $course_id = absint( $gate['course_id'] );
        $quiz_id   = absint( $gate['quiz_id'] );
        $table     = $wpdb->prefix . 'learnpress_user_items';
        if ( ! $this->table_exists( $table ) ) {
            return 0;
        }
        $cols = $this->table_columns( $table );
        if ( ! in_array( 'user_id', $cols, true ) || ! in_array( 'item_id', $cols, true ) ) {
            return 0;
        }
        $existing = $this->get_lp_item_state( $user_id, $course_id, $quiz_id );
        $user_item_id = absint( $existing['user_item_id'] );
        $now = current_time( 'mysql', true );
        $data = array( 'user_id' => $user_id, 'item_id' => $quiz_id );
        if ( in_array( 'item_type', $cols, true ) ) { $data['item_type'] = 'lp_quiz'; }
        if ( in_array( 'ref_id', $cols, true ) ) { $data['ref_id'] = $course_id; }
        if ( in_array( 'ref_type', $cols, true ) ) { $data['ref_type'] = 'lp_course'; }
        if ( in_array( 'status', $cols, true ) ) { $data['status'] = 'completed'; }
        if ( in_array( 'graduation', $cols, true ) ) { $data['graduation'] = 'exempted'; }
        if ( in_array( 'access_level', $cols, true ) ) { $data['access_level'] = 50; }
        foreach ( array( 'end_time', 'graduation_time', 'update_time', 'updated_at' ) as $time_col ) {
            if ( in_array( $time_col, $cols, true ) ) { $data[ $time_col ] = $now; }
        }
        if ( ! $user_item_id ) {
            foreach ( array( 'start_time', 'created_at' ) as $time_col ) {
                if ( in_array( $time_col, $cols, true ) ) { $data[ $time_col ] = $now; }
            }
            if ( in_array( 'parent_id', $cols, true ) ) { $data['parent_id'] = $this->find_course_user_item_id( $user_id, $course_id ); }
        }
        $wpdb->last_error = '';
        if ( $user_item_id && in_array( 'user_item_id', $cols, true ) ) {
            $write_result = $wpdb->update( $table, $data, array( 'user_item_id' => $user_item_id ) );
        } else {
            $write_result = $wpdb->insert( $table, $data );
            $user_item_id = absint( $wpdb->insert_id );
        }
        if ( false === $write_result || ! $user_item_id ) {
            $this->log_event( 'lp_quiz_exemption_write_failed', $user_id, $gate, array( 'wpdb_error' => (string) $wpdb->last_error, 'write_result' => $write_result ) );
            return 0;
        }
        $payload = array(
            'gbvqg_exemption' => 1,
            'exemption_type'   => sanitize_key( $exemption_type ),
            'status'          => 'completed',
            'graduation'      => 'exempted',
            'result'          => 'exempted',
            'reason'          => $reason,
            'admin_user_id'   => absint( $admin_id ),
            'time'            => $now,
        );
        $this->upsert_lp_user_itemmeta( $user_item_id, 'result', $payload );
        $this->upsert_lp_user_itemmeta( $user_item_id, 'grade', 'exempted' );
        $this->upsert_lp_user_itemmeta( $user_item_id, '_gbvqg_exemption', $payload );
        $this->log_event( 'lp_quiz_documented_exemption_write', $user_id, $gate, array(
            'write_result'  => $write_result,
            'wpdb_error'    => (string) $wpdb->last_error,
            'user_item_id'  => $user_item_id,
            'after_rows'    => $this->get_lp_item_rows_snapshot( $user_id, $course_id, $quiz_id ),
            'recognition'   => $this->get_learnpress_item_recognition( $user_id, $course_id, $quiz_id ),
        ) );
        return $user_item_id;
    }

    private function store_documented_exemption_evidence( $user_id, $gate, $reason, $admin_id, $user_item_id, $exemption_type = 'administrator', $supporting_evidence = array() ) {
        $gate_id = $this->gate_id( $gate );
        $exemption_type = sanitize_key( $exemption_type );
        $is_retired_legacy = 'retired_course_legacy' === $exemption_type;
        $record_label = $is_retired_legacy ? 'Documented retired-course legacy exemption — no scored attempt' : 'Documented administrator exemption — no scored attempt';
        $later_item = ! empty( $supporting_evidence['later_completed_item'] ) && is_array( $supporting_evidence['later_completed_item'] ) ? $supporting_evidence['later_completed_item'] : array();
        $later_text = ! empty( $later_item['item_id'] ) ? ' Verified later progress: item #' . absint( $later_item['item_id'] ) . ' — ' . (string) ( $later_item['title'] ?? '' ) . ' (' . (string) ( $later_item['status'] ?? '' ) . ').' : '';
        $payload = array(
            'gbvqg_attempt_detail' => 1,
            'plugin'               => 'gulfbreeze-video-quiz-gate',
            'plugin_version'       => self::VERSION,
            'submitted_at'         => current_time( 'mysql', true ),
            'student_user_id'      => absint( $user_id ),
            'course_id'            => absint( $gate['course_id'] ),
            'gate_id'              => $gate_id,
            'gate_label'           => (string) ( $gate['label'] ?? '' ),
            'video_lesson_id'      => absint( $gate['video_lesson_id'] ),
            'quiz_bank_id'         => absint( $gate['quiz_id'] ),
            'attempt_no'           => 0,
            'score_percent'        => '',
            'correct_count'        => 0,
            'shown_count'          => 0,
            'passed'               => 1,
            'grandfathered'        => 1,
            'manual_exemption'     => 1,
            'exemption_type'       => $exemption_type,
            'record_label'         => $record_label,
            'course_policy'        => $this->course_policy( absint( $gate['course_id'] ) ),
            'course_policy_version'=> self::COURSE_POLICY_VERSION,
            'mapping_fingerprint'  => $this->gate_mapping_fingerprint( $gate ),
            'supporting_evidence'  => is_array( $supporting_evidence ) ? $supporting_evidence : array(),
            'exemption_reason'     => $reason,
            'exemption_admin_user_id' => absint( $admin_id ),
            'questions'            => array(),
            'checked'              => array(),
            'note'                 => $record_label . '.' . $later_text . ' Reason: ' . $reason,
        );
        $history_key = '_gbvqg_attempt_history_' . $gate_id;
        $history = get_user_meta( $user_id, $history_key, true );
        $history = is_array( $history ) ? $history : array();
        $history[] = $payload;
        update_user_meta( $user_id, $history_key, $history );
        update_user_meta( $user_id, '_gbvqg_attempt_detail_' . $gate_id, $payload );
        if ( $user_item_id ) {
            $this->upsert_lp_user_itemmeta( $user_item_id, '_gbvqg_attempt_detail', $payload );
            $this->upsert_lp_user_itemmeta( $user_item_id, '_gbvqg_attempt_history', array( $payload ) );
        }
    }

    private function get_lp_item_rows_snapshot( $user_id, $course_id, $item_id ) {
        global $wpdb;

        $table = $wpdb->prefix . 'learnpress_user_items';
        if ( ! $this->table_exists( $table ) ) {
            return array();
        }

        $cols = $this->table_columns( $table );
        if ( ! in_array( 'user_id', $cols, true ) || ! in_array( 'item_id', $cols, true ) ) {
            return array();
        }

        $where = array( 'user_id = %d', 'item_id = %d' );
        $args  = array( absint( $user_id ), absint( $item_id ) );
        if ( $course_id && in_array( 'ref_id', $cols, true ) ) {
            $where[] = 'ref_id = %d';
            $args[]  = absint( $course_id );
        }

        $order_col = in_array( 'user_item_id', $cols, true ) ? 'user_item_id' : 'item_id';
        $sql       = "SELECT * FROM {$table} WHERE " . implode( ' AND ', $where ) . " ORDER BY {$order_col} DESC LIMIT 20";
        $rows      = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
        if ( ! is_array( $rows ) ) {
            return array();
        }

        $safe_rows = array();
        foreach ( $rows as $row ) {
            $safe = array();
            foreach ( array( 'user_item_id', 'user_id', 'item_id', 'item_type', 'status', 'graduation', 'ref_id', 'ref_type', 'parent_id', 'start_time', 'end_time', 'access_level' ) as $key ) {
                if ( array_key_exists( $key, $row ) ) {
                    $safe[ $key ] = $row[ $key ];
                }
            }
            if ( ! empty( $safe['user_item_id'] ) ) {
                $safe['itemmeta_status'] = $this->get_lp_user_itemmeta_status( absint( $safe['user_item_id'] ) );
            }
            $safe_rows[] = $safe;
        }

        return $safe_rows;
    }

    private function lp_rows_have_status( $rows, $wanted ) {
        $wanted = strtolower( (string) $wanted );
        foreach ( (array) $rows as $row ) {
            $values = array(
                strtolower( (string) ( $row['status'] ?? '' ) ),
                strtolower( (string) ( $row['graduation'] ?? '' ) ),
                strtolower( (string) ( $row['itemmeta_status'] ?? '' ) ),
            );
            if ( in_array( $wanted, $values, true ) ) {
                return true;
            }
        }
        return false;
    }

    private function get_learnpress_item_recognition( $user_id, $course_id, $item_id ) {
        $result = array(
            'available'     => false,
            'object_class'  => '',
            'user_item_id'  => 0,
            'status'        => '',
            'graduation'    => '',
            'is_completed'  => false,
            'is_passed'     => false,
            'error'         => '',
        );

        if ( ! function_exists( 'learn_press_get_user' ) ) {
            $result['error'] = 'learn_press_get_user is unavailable.';
            return $result;
        }

        try {
            $user = learn_press_get_user( absint( $user_id ) );
            if ( ! $user || ! method_exists( $user, 'get_item_data' ) ) {
                $result['error'] = 'LearnPress user item API is unavailable.';
                return $result;
            }

            $item = $user->get_item_data( absint( $item_id ), absint( $course_id ) );
            if ( ! $item ) {
                $result['available'] = true;
                $result['error']     = 'LearnPress returned no user-item object.';
                return $result;
            }

            $result['available']    = true;
            $result['object_class'] = get_class( $item );
            if ( method_exists( $item, 'get_user_item_id' ) ) {
                $result['user_item_id'] = absint( $item->get_user_item_id() );
            }
            if ( method_exists( $item, 'get_status' ) ) {
                $result['status'] = (string) $item->get_status();
            }
            if ( method_exists( $item, 'get_graduation' ) ) {
                $result['graduation'] = (string) $item->get_graduation();
            }
            if ( method_exists( $item, 'is_completed' ) ) {
                $result['is_completed'] = (bool) $item->is_completed();
            }
            if ( method_exists( $item, 'is_passed' ) ) {
                $result['is_passed'] = (bool) $item->is_passed();
            } else {
                $result['is_passed'] = 'passed' === strtolower( $result['graduation'] );
            }
        } catch ( Throwable $e ) {
            $result['error'] = $e->getMessage();
        }

        return $result;
    }

    private function get_lp_item_state( $user_id, $course_id, $item_id ) {
        global $wpdb;
        $state = array(
            'status'       => 'unknown',
            'updated_at'   => '',
            'user_item_id' => 0,
            'raw'          => array(),
        );

        $table = $wpdb->prefix . 'learnpress_user_items';
        if ( ! $this->table_exists( $table ) ) {
            return $state;
        }
        $cols = $this->table_columns( $table );
        if ( ! in_array( 'user_id', $cols, true ) || ! in_array( 'item_id', $cols, true ) ) {
            return $state;
        }

        $where = array( 'user_id = %d', 'item_id = %d' );
        $args  = array( absint( $user_id ), absint( $item_id ) );
        if ( in_array( 'ref_id', $cols, true ) && $course_id ) {
            $where[] = 'ref_id = %d';
            $args[]  = absint( $course_id );
        }
        $order_col = in_array( 'user_item_id', $cols, true ) ? 'user_item_id' : ( in_array( 'item_id', $cols, true ) ? 'item_id' : 'user_id' );

        // v0.2.23: LearnPress can occasionally leave duplicate user_item rows for a
        // lesson. A newer blank/started row must not hide an older completed/passed
        // row, or legacy students can be incorrectly treated as not having completed
        // a gated video. For lessons only, inspect the recent rows and prefer the
        // newest completed/passed row. Quizzes remain latest-row first because failed
        // attempts need to stay meaningful.
        if ( 'lp_lesson' === get_post_type( $item_id ) ) {
            $recent_sql  = "SELECT * FROM {$table} WHERE " . implode( ' AND ', $where ) . " ORDER BY {$order_col} DESC LIMIT 20";
            $recent_rows = $wpdb->get_results( $wpdb->prepare( $recent_sql, $args ), ARRAY_A );
            if ( ! empty( $recent_rows ) ) {
                $row = $recent_rows[0];

                foreach ( $recent_rows as $candidate ) {
                    $candidate_bits = array();
                    foreach ( array( 'graduation', 'status', 'item_status', 'result' ) as $col ) {
                        if ( isset( $candidate[ $col ] ) ) {
                            $candidate_bits[] = strtolower( (string) $candidate[ $col ] );
                        }
                    }
                    $candidate_blob = implode( ' ', $candidate_bits );
                    $candidate_meta = ! empty( $candidate['user_item_id'] ) ? $this->get_lp_user_itemmeta_status( absint( $candidate['user_item_id'] ) ) : '';

                    if (
                        in_array( $candidate_meta, array( 'passed', 'completed' ), true )
                        || false !== strpos( $candidate_blob, 'passed' )
                        || preg_match( '/\bpass\b/', $candidate_blob )
                        || false !== strpos( $candidate_blob, 'completed' )
                        || false !== strpos( $candidate_blob, 'complete' )
                    ) {
                        $row = $candidate;
                        break;
                    }
                }
            } else {
                return $state;
            }
        } else {
            $sql = "SELECT * FROM {$table} WHERE " . implode( ' AND ', $where ) . " ORDER BY {$order_col} DESC LIMIT 1";
            $row = $wpdb->get_row( $wpdb->prepare( $sql, $args ), ARRAY_A );
            if ( ! $row ) {
                return $state;
            }
        }

        $state['raw']          = $row;
        $state['user_item_id'] = ! empty( $row['user_item_id'] ) ? absint( $row['user_item_id'] ) : 0;

        $status_bits = array();
        foreach ( array( 'graduation', 'status', 'item_status', 'result' ) as $col ) {
            if ( isset( $row[ $col ] ) ) {
                $status_bits[] = strtolower( (string) $row[ $col ] );
            }
        }
        $status_blob = implode( ' ', $status_bits );

        if ( false !== strpos( $status_blob, 'passed' ) || preg_match( '/\bpass\b/', $status_blob ) ) {
            $state['status'] = 'passed';
        } elseif ( false !== strpos( $status_blob, 'failed' ) || false !== strpos( $status_blob, 'fail' ) ) {
            $state['status'] = 'failed';
        } elseif ( false !== strpos( $status_blob, 'completed' ) || false !== strpos( $status_blob, 'complete' ) ) {
            $state['status'] = 'completed';
        } elseif ( false !== strpos( $status_blob, 'started' ) || false !== strpos( $status_blob, 'doing' ) ) {
            $state['status'] = 'started';
        }

        $meta_status = $this->get_lp_user_itemmeta_status( $state['user_item_id'] );
        if ( in_array( $meta_status, array( 'passed', 'failed', 'completed' ), true ) ) {
            $state['status'] = $meta_status;
        }

        foreach ( array( 'end_time', 'graduation_time', 'update_time', 'updated_at', 'start_time' ) as $time_col ) {
            if ( ! empty( $row[ $time_col ] ) ) {
                $state['updated_at'] = $row[ $time_col ];
                break;
            }
        }
        if ( empty( $state['updated_at'] ) ) {
            $state['updated_at'] = current_time( 'mysql', true );
        }

        return $state;
    }

    private function get_lp_user_itemmeta_status( $user_item_id ) {
        global $wpdb;
        $user_item_id = absint( $user_item_id );
        if ( ! $user_item_id ) {
            return '';
        }
        $table = $wpdb->prefix . 'learnpress_user_itemmeta';
        if ( ! $this->table_exists( $table ) ) {
            return '';
        }
        $cols = $this->table_columns( $table );
        $id_col = in_array( 'learnpress_user_item_id', $cols, true ) ? 'learnpress_user_item_id' : ( in_array( 'user_item_id', $cols, true ) ? 'user_item_id' : '' );
        if ( ! $id_col || ! in_array( 'meta_key', $cols, true ) || ! in_array( 'meta_value', $cols, true ) ) {
            return '';
        }

        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT meta_key, meta_value FROM {$table} WHERE {$id_col} = %d", $user_item_id ), ARRAY_A );
        if ( ! is_array( $rows ) ) {
            return '';
        }
        foreach ( $rows as $row ) {
            $key = strtolower( (string) $row['meta_key'] );
            $val = maybe_unserialize( $row['meta_value'] );
            $blob = is_scalar( $val ) ? strtolower( (string) $val ) : strtolower( wp_json_encode( $val ) );
            if ( false !== strpos( $key, 'result' ) || false !== strpos( $key, 'grade' ) || false !== strpos( $blob, 'graduation' ) ) {
                if ( false !== strpos( $blob, 'passed' ) || preg_match( '/\bpass\b/', $blob ) ) {
                    return 'passed';
                }
                if ( false !== strpos( $blob, 'failed' ) || false !== strpos( $blob, 'fail' ) ) {
                    return 'failed';
                }
            }
        }
        return '';
    }

    private function get_course_item_url( $course_id, $item_id ) {
        $course_id = absint( $course_id );
        $item_id   = absint( $item_id );

        $candidates = array();
        $home_root  = trailingslashit( home_url( '/' ) );

        // v0.2.12: Prefer a deterministic LearnPress course-item URL first.
        // Some LP helpers can return the site root when called outside the course context;
        // using that first is what can dump a student on the website home page.
        $course_url = get_permalink( $course_id );
        $item_slug  = get_post_field( 'post_name', $item_id );
        $item_type  = get_post_type( $item_id );
        if ( $course_url && $item_slug && in_array( $item_type, array( 'lp_lesson', 'lp_quiz' ), true ) ) {
            $path = 'lp_quiz' === $item_type ? 'quizzes' : 'lessons';
            $candidates[] = trailingslashit( $course_url ) . trailingslashit( $path ) . trailingslashit( $item_slug );
        }

        if ( function_exists( 'learn_press_get_course_item_permalink' ) ) {
            $url = learn_press_get_course_item_permalink( $course_id, $item_id );
            if ( $url ) {
                $candidates[] = $url;
            }
        }

        if ( function_exists( 'learn_press_get_course_item_url' ) ) {
            $url = learn_press_get_course_item_url( $course_id, $item_id );
            if ( $url ) {
                $candidates[] = $url;
            }
        }

        if ( function_exists( 'learn_press_get_item_link' ) ) {
            $url = learn_press_get_item_link( $item_id, $course_id );
            if ( $url ) {
                $candidates[] = $url;
            }
        }

        if ( function_exists( 'learn_press_get_course' ) ) {
            $course = learn_press_get_course( $course_id );
            if ( is_object( $course ) ) {
                foreach ( array( 'get_item_link', 'get_item_permalink', 'get_item_url' ) as $method ) {
                    if ( method_exists( $course, $method ) ) {
                        try {
                            $url = $course->{$method}( $item_id );
                            if ( $url ) {
                                $candidates[] = $url;
                            }
                        } catch ( Throwable $e ) {
                            // Keep trying fallbacks.
                        }
                    }
                }
            }
        }

        $plain = get_permalink( $item_id );
        if ( $plain ) {
            $candidates[] = $plain;
        }

        foreach ( $candidates as $candidate ) {
            $candidate = esc_url_raw( $candidate );
            if ( ! $candidate ) {
                continue;
            }

            // Do not accept the site homepage as a course-item URL unless the item itself
            // somehow genuinely has that permalink. This protects pass/fail redirects.
            if ( trailingslashit( $candidate ) === $home_root && $item_id !== absint( get_option( 'page_on_front' ) ) ) {
                continue;
            }

            return $candidate;
        }

        // Last-resort fallback: course page is still safer than dumping to the home page.
        $course_url = esc_url_raw( get_permalink( $course_id ) );
        if ( $course_url && trailingslashit( $course_url ) !== $home_root ) {
            return $course_url;
        }

        return home_url( '/' );
    }

    private function table_exists( $table ) {
        global $wpdb;
        return $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
    }

    private function table_columns( $table ) {
        global $wpdb;
        static $cache = array();
        if ( isset( $cache[ $table ] ) ) {
            return $cache[ $table ];
        }
        if ( ! $this->table_exists( $table ) ) {
            $cache[ $table ] = array();
            return array();
        }
        $cols = $wpdb->get_col( "DESCRIBE {$table}", 0 );
        $cache[ $table ] = is_array( $cols ) ? $cols : array();
        return $cache[ $table ];
    }

    private function current_url() {
        $scheme = is_ssl() ? 'https://' : 'http://';
        $host   = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : wp_parse_url( home_url(), PHP_URL_HOST );
        $uri    = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';
        return $scheme . $host . $uri;
    }

    private function current_request_path() {
        $uri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';
        $path = wp_parse_url( $uri, PHP_URL_PATH );
        return '/' . ltrim( (string) $path, '/' );
    }

    private function is_current_url( $url ) {
        $current = wp_parse_url( remove_query_arg( array( 'gbvqg_gate' ), $this->current_url() ) );
        $target  = wp_parse_url( remove_query_arg( array( 'gbvqg_gate' ), $url ) );
        if ( empty( $current['path'] ) || empty( $target['path'] ) ) {
            return false;
        }
        $current_path = untrailingslashit( $current['path'] );
        $target_path  = untrailingslashit( $target['path'] );
        return $current_path === $target_path;
    }

    private function get_answer_audit_info( $question_id, $answer_id ) {
        $question_id = absint( $question_id );
        $answer_id   = (string) $answer_id;
        $info = array(
            'question_id'    => $question_id,
            'question_title' => get_the_title( $question_id ),
            'answer_id'      => $answer_id,
            'answer_text'    => '',
            'correct'        => false,
        );

        foreach ( $this->get_validation_answers( $question_id ) as $answer ) {
            if ( (string) $answer['id'] === $answer_id ) {
                $info['answer_text'] = isset( $answer['text'] ) ? wp_strip_all_tags( (string) $answer['text'] ) : '';
                $info['correct']     = ! empty( $answer['is_true'] );
                break;
            }
        }

        return $info;
    }

    private function enrich_audit_details( $user_id, $gate, $details = array() ) {
        $details = is_array( $details ) ? $details : array();

        $details = array_merge(
            array(
                'audit_utc'           => gmdate( 'Y-m-d H:i:s' ),
                'student_user_id'     => absint( $user_id ),
                'course_id'           => absint( $gate['course_id'] ?? 0 ),
                'video_lesson_id'     => absint( $gate['video_lesson_id'] ?? 0 ),
                'quiz_bank_id'        => absint( $gate['quiz_id'] ?? 0 ),
                'question_id_selected'=> isset( $details['question_id_selected'] ) ? absint( $details['question_id_selected'] ) : 0,
                'submitted_answer_id' => isset( $details['submitted_answer_id'] ) ? (string) $details['submitted_answer_id'] : '',
                'submitted_answer_text' => isset( $details['submitted_answer_text'] ) ? wp_strip_all_tags( (string) $details['submitted_answer_text'] ) : '',
                'answer_correct'      => array_key_exists( 'answer_correct', $details ) ? (bool) $details['answer_correct'] : null,
                'returned_to_video'   => array_key_exists( 'returned_to_video', $details ) ? (bool) $details['returned_to_video'] : false,
                'rewatch_cycle'       => isset( $details['rewatch_cycle'] ) ? absint( $details['rewatch_cycle'] ) : 0,
            ),
            $details
        );

        return $details;
    }

    private function log_event_once( $event, $user_id, $gate, $details = array() ) {
        $key = '_gbvqg_last_event_' . md5( $event . ':' . $this->gate_id( $gate ) . ':' . wp_json_encode( $details ) );
        $last = get_user_meta( $user_id, $key, true );
        if ( $last && ( time() - absint( $last ) ) < 60 ) {
            return;
        }
        update_user_meta( $user_id, $key, time() );
        $this->log_event( $event, $user_id, $gate, $details );
    }

    private function log_event( $event, $user_id, $gate, $details = array() ) {
        $events = get_option( self::OPTION_EVENTS, array() );
        if ( ! is_array( $events ) ) {
            $events = array();
        }

        $details = $this->enrich_audit_details( $user_id, $gate, $details );

        $events[] = array(
            'time'      => gmdate( 'Y-m-d H:i:s' ),
            'event'     => sanitize_key( $event ),
            'user_id'   => absint( $user_id ),
            'course_id' => absint( $gate['course_id'] ),
            'lesson_id' => absint( $gate['video_lesson_id'] ),
            'quiz_id'   => absint( $gate['quiz_id'] ),
            'gate_id'   => $this->gate_id( $gate ),
            'details'   => $details,
        );
        if ( count( $events ) > 250 ) {
            $events = array_slice( $events, -250 );
        }
        update_option( self::OPTION_EVENTS, $events, false );
    }

    /* ====================================================================
     * v0.2.7 — Question filter (1 random per attempt, persisted)
     * ==================================================================== */


    private function find_gate_by_id( $gate_id ) {
        $gate_id = sanitize_key( $gate_id );
        if ( ! $gate_id ) {
            return null;
        }
        foreach ( $this->get_gates() as $gate ) {
            if ( $this->is_gate_enabled( $gate ) && ! empty( $gate['gate_id'] ) && $gate['gate_id'] === $gate_id ) {
                return $gate;
            }
        }
        return null;
    }

    private function get_validation_url( $gate ) {
        return add_query_arg(
            array(
                'gbvqg_validation' => 1,
                'gbvqg_gate'       => $gate['gate_id'],
            ),
            home_url( '/' )
        );
    }

    public function maybe_render_validation_page() {
        if ( empty( $_GET['gbvqg_validation'] ) ) {
            return;
        }

        if ( ! is_user_logged_in() ) {
            auth_redirect();
            exit;
        }

        // v0.2.12: handle the custom validation form on the same front-end URL.
        // This avoids admin-post/wp-admin routing surprises for student/customer roles.
        if ( 'POST' === strtoupper( $_SERVER['REQUEST_METHOD'] ?? '' ) && ! empty( $_POST['gbvqg_frontend_submit'] ) ) {
            $this->handle_validation_submit();
            exit;
        }

        $gate_id = isset( $_GET['gbvqg_gate'] ) ? sanitize_key( wp_unslash( $_GET['gbvqg_gate'] ) ) : '';

        // v0.2.11 recovery: older JS embedded esc_url() output inside JSON, which could
        // produce URLs like ?gbvqg_validation=1&#038;gbvqg_gate=abc123. In a browser,
        // the #038 part becomes a fragment, so PHP may not receive gbvqg_gate. If a
        // malformed value does arrive server-side, recover it here. A client-side
        // fragment repair script in render_validation_shell handles the common case.
        if ( ! $gate_id && isset( $_GET['gbvqg_validation'] ) ) {
            $raw_validation = (string) wp_unslash( $_GET['gbvqg_validation'] );
            if ( preg_match( '/gbvqg_gate=([a-z0-9_\-]+)/i', $raw_validation, $m ) ) {
                $gate_id = sanitize_key( $m[1] );
            }
        }

        $gate    = $this->find_gate_by_id( $gate_id );
        if ( ! $gate ) {
            $this->render_validation_shell( '<h1>Video Check Not Ready</h1><p>We could not load this video check. Please return to your course and try the video again.</p>' );
        }

        $user_id   = get_current_user_id();
        $course_id = absint( $gate['course_id'] );
        $lesson_id = absint( $gate['video_lesson_id'] );
        $quiz_id   = absint( $gate['quiz_id'] );

        $lesson_state = $this->get_lp_item_state( $user_id, $course_id, $lesson_id );
        $state        = $this->get_gate_state( $user_id, $gate );
        $lesson_url   = $this->get_course_item_url( $course_id, $lesson_id );

        $lesson_completed = $this->has_verified_playback( $user_id, $gate );
        if ( ! $lesson_completed ) {
            wp_safe_redirect( add_query_arg( 'gbvqg_need_video', 1, $lesson_url ) );
            exit;
        }

        $evidence = $this->analyze_gate_state_evidence( $user_id, $gate, null, $state );
        if ( 'unverified_legacy_grandfather' === ( $evidence['classification'] ?? '' ) && empty( $state['force_validation_required'] ) ) {
            $this->log_event_once( 'gate_state_mismatch_review_page_shown', $user_id, $gate, array(
                'state'    => $state,
                'lp_state' => $evidence['lp_state'] ?? array(),
            ) );
            $this->render_validation_shell(
                '<h1>Course Record Needs Review</h1>' .
                '<p>Your saved video-check status does not match the course completion record. The system stopped an automatic redirect loop and did not mark this quiz complete.</p>' .
                '<p>Please contact Gulf Breeze Driving School so this one video check can be reviewed. Your completed lesson time and other course progress remain saved.</p>'
            );
        }

        if ( ! empty( $state['failed_at'] ) && empty( $state['passed'] ) && 'none' !== $gate['fail_mode'] ) {
            if ( 'fresh_completion' === $gate['fail_mode'] ) {
                $failed_at    = strtotime( $state['failed_at'] );
                $completed_at = ! empty( $lesson_state['updated_at'] ) ? strtotime( $lesson_state['updated_at'] ) : 0;
                if ( ! $completed_at || $completed_at <= $failed_at ) {
                    wp_safe_redirect( add_query_arg( 'gbvqg_rewatch_required', 1, $lesson_url ) );
                    exit;
                }
            } else {
                $rewatched = ! empty( $state['rewatch_visited_at'] ) && strtotime( $state['rewatch_visited_at'] ) >= strtotime( $state['failed_at'] );
                if ( ! $rewatched ) {
                    wp_safe_redirect( add_query_arg( 'gbvqg_rewatch_required', 1, $lesson_url ) );
                    exit;
                }
            }
        }

        $question_ids = $this->get_quiz_question_ids( $quiz_id );
        if ( empty( $question_ids ) ) {
            $this->render_validation_shell( '<h1>Video Check Not Ready</h1><p>The mapped LearnPress quiz does not have readable questions.</p>' );
        }

        $selected_ids = $this->get_or_select_validation_questions( $user_id, $gate, $question_ids );
        if ( empty( $selected_ids ) ) {
            $this->render_validation_shell( '<h1>Video Check Not Ready</h1><p>The plugin could not select a validation question.</p>' );
        }

        $questions_html = '';
        foreach ( $selected_ids as $question_id ) {
            $question = $this->get_validation_question( $question_id );
            if ( empty( $question['answers'] ) ) {
                $questions_html .= '<div class="gbvqg-error"><strong>Question setup problem:</strong> Question #' . esc_html( $question_id ) . ' has no readable answer choices.</div>';
                continue;
            }

            $q_title = $question['title'] ? $question['title'] : 'Validation Question';
            $q_body  = $question['content'] ? $question['content'] : '';

            $questions_html .= '<fieldset class="gbvqg-question">';
            $questions_html .= '<legend>' . esc_html( $q_title ) . '</legend>';
            if ( $q_body ) {
                $questions_html .= '<div class="gbvqg-question-body">' . wp_kses_post( wpautop( $q_body ) ) . '</div>';
            }
            $questions_html .= '<input type="hidden" name="question_ids[]" value="' . esc_attr( $question_id ) . '" />';

            foreach ( $question['answers'] as $answer ) {
                $answer_id = (string) $answer['id'];
                $field_id  = 'gbvqg_' . absint( $question_id ) . '_' . md5( $answer_id );
                $questions_html .= '<label class="gbvqg-answer" for="' . esc_attr( $field_id ) . '">';
                $questions_html .= '<input id="' . esc_attr( $field_id ) . '" type="radio" name="answers[' . esc_attr( $question_id ) . ']" value="' . esc_attr( $answer_id ) . '" required /> ';
                $questions_html .= '<span>' . wp_kses_post( $answer['text'] ) . '</span>';
                $questions_html .= '</label>';
            }
            $questions_html .= '</fieldset>';
        }

        // v0.2.12: post back to the same front-end validation URL instead of admin-post.php.
        // The handler is still the same PHP method, but the student stays outside wp-admin.
        $action = esc_url( $this->get_validation_url( $gate ) );
        $nonce  = wp_create_nonce( 'gbvqg_validation_' . $gate['gate_id'] );
        $title  = get_the_title( $quiz_id );
        $lesson = get_the_title( $lesson_id );

        ob_start();
        ?>
        <h1>Quick Video Check</h1>
        <p class="gbvqg-intro">Before you move on from <strong><?php echo esc_html( $lesson ); ?></strong>, please answer one quick question about the video you just watched.</p>
        <p class="gbvqg-note">You only need to answer one question on this page. Choose the best answer, then click <strong>Submit Answer</strong>.</p>
        <p class="gbvqg-note">If you miss it, no problem — you’ll go back to the video, review it again, and then receive a different question.</p>
        <p class="gbvqg-small-note"><em>For fairness, refreshing this page keeps the same question for this attempt. Correct answers are not shown after submission.</em></p>
        <form class="gbvqg-validation-form" method="post" action="<?php echo $action; ?>">
            <input type="hidden" name="action" value="gbvqg_submit_validation" />
            <input type="hidden" name="gbvqg_frontend_submit" value="1" />
            <input type="hidden" name="gbvqg_gate" value="<?php echo esc_attr( $gate['gate_id'] ); ?>" />
            <input type="hidden" name="_wpnonce" value="<?php echo esc_attr( $nonce ); ?>" />
            <?php echo $questions_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            <p><button type="submit" class="gbvqg-submit">Submit Answer</button></p>
        </form>
        <?php
        $html = ob_get_clean();
        $this->render_validation_shell( $html );
    }

    private function render_validation_shell( $inner_html ) {
        status_header( 200 );
        nocache_headers();

        get_header();
        ?>
        <main class="gbvqg-validation-page" style="max-width:900px;margin:40px auto;padding:24px;">
            <style>
                .gbvqg-validation-page { font-size: 18px; line-height: 1.5; }
                .gbvqg-intro, .gbvqg-note { margin: 0 0 16px; }
                .gbvqg-note { color: #555; }
                .gbvqg-question { border: 1px solid #c3c4c7; border-radius: 10px; padding: 20px; margin: 24px 0; background: #fff; }
                .gbvqg-question legend { font-weight: 700; padding: 0 8px; }
                .gbvqg-question-body { margin: 12px 0 16px; }
                .gbvqg-answer { display: block; padding: 12px; border: 1px solid #dcdcde; border-radius: 8px; margin: 10px 0; background: #f8fafc; cursor: pointer; }
                .gbvqg-answer:hover { background: #eef6ff; }
                .gbvqg-submit { padding: 12px 22px; border: 0; border-radius: 8px; background: #1d4ed8; color: #fff; font-weight: 700; cursor: pointer; }
                .gbvqg-error { border: 1px solid #b32d2e; background: #fcf0f1; color: #8a2424; padding: 14px; border-radius: 8px; margin: 16px 0; }
            </style>
            <script>
            (function(){
                // v0.2.11 self-heal for old malformed links such as:
                // ?gbvqg_validation=1&#038;gbvqg_gate=fc4fe58b4227
                // When used through JS, the browser treats #038;gbvqg_gate=... as
                // a fragment and PHP cannot see the gate id. Repair it once here.
                try {
                    var search = window.location.search || '';
                    var hash = window.location.hash || '';
                    if (search.indexOf('gbvqg_validation=1') !== -1 &&
                        search.indexOf('gbvqg_gate=') === -1 &&
                        hash.indexOf('gbvqg_gate=') !== -1) {
                        var m = hash.match(/gbvqg_gate=([a-z0-9_\-]+)/i);
                        if (m && m[1]) {
                            var repaired = window.location.origin + window.location.pathname +
                                '?gbvqg_validation=1&gbvqg_gate=' + encodeURIComponent(m[1]);
                            window.location.replace(repaired);
                        }
                    }
                } catch(e) {}
            })();
            </script>
            <?php echo $inner_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
        </main>
        <?php
        get_footer();
        exit;
    }

    public function handle_validation_submit() {
        if ( ! is_user_logged_in() ) {
            auth_redirect();
            exit;
        }

        $gate_id = isset( $_POST['gbvqg_gate'] ) ? sanitize_key( wp_unslash( $_POST['gbvqg_gate'] ) ) : '';
        $gate    = $this->find_gate_by_id( $gate_id );
        if ( ! $gate ) {
            wp_die( esc_html__( 'Video-check gate not found.', 'gulfbreeze-video-quiz-gate' ) );
        }

        if ( empty( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'gbvqg_validation_' . $gate['gate_id'] ) ) {
            wp_die( esc_html__( 'Invalid video-check submission. Please go back and try again.', 'gulfbreeze-video-quiz-gate' ) );
        }

        $user_id   = get_current_user_id();
        $course_id = absint( $gate['course_id'] );
        $lesson_id = absint( $gate['video_lesson_id'] );
        $quiz_id   = absint( $gate['quiz_id'] );

        $submit_state = $this->get_gate_state( $user_id, $gate );
        $this->log_event( 'validation_submit_received', $user_id, $gate, array(
            'posted_question_ids' => isset( $_POST['question_ids'] ) && is_array( $_POST['question_ids'] ) ? array_values( array_map( 'absint', wp_unslash( $_POST['question_ids'] ) ) ) : array(),
            'attempt_no'          => max( 1, absint( $submit_state['validation_attempt'] ?? 1 ) ),
            'rewatch_cycle'       => max( 0, absint( $submit_state['rewatch_cycle'] ?? 0 ) ),
        ) );

        $lesson_url     = $this->get_course_item_url( $course_id, $lesson_id );
        $validation_url = $this->get_validation_url( $gate );

        $lesson_state = $this->get_lp_item_state( $user_id, $course_id, $lesson_id );
        if ( ! in_array( $lesson_state['status'], array( 'passed', 'completed' ), true ) ) {
            wp_safe_redirect( add_query_arg( 'gbvqg_need_video', 1, $lesson_url ) );
            exit;
        }

        $posted_question_ids = isset( $_POST['question_ids'] ) && is_array( $_POST['question_ids'] ) ? array_map( 'absint', wp_unslash( $_POST['question_ids'] ) ) : array();
        $posted_answers      = isset( $_POST['answers'] ) && is_array( $_POST['answers'] ) ? wp_unslash( $_POST['answers'] ) : array();

        $bank_ids     = $this->get_quiz_question_ids( $quiz_id );
        $selected_ids = $this->get_or_select_validation_questions( $user_id, $gate, $bank_ids );

        $posted_question_ids = array_values( array_intersect( $posted_question_ids, $selected_ids ) );
        if ( empty( $posted_question_ids ) || count( $posted_question_ids ) !== count( $selected_ids ) ) {
            $this->log_event( 'validation_submit_mismatch', $user_id, $gate, array(
                'posted_question_ids' => $posted_question_ids,
                'selected_ids'        => $selected_ids,
            ) );
            wp_safe_redirect( $validation_url );
            exit;
        }

        $state  = $this->get_gate_state( $user_id, $gate );
        $current_attempt_no = max( 1, absint( $state['validation_attempt'] ?? 1 ) );

        $correct_count = 0;
        $checked       = array();

        foreach ( $selected_ids as $question_id ) {
            $answer_id = isset( $posted_answers[ $question_id ] ) ? sanitize_text_field( (string) $posted_answers[ $question_id ] ) : '';
            $answer_info = $this->get_answer_audit_info( $question_id, $answer_id );
            $is_correct = $answer_id && ! empty( $answer_info['correct'] );
            if ( $is_correct ) {
                $correct_count++;
            }
            $checked[] = array(
                'question_id'    => absint( $question_id ),
                'question_title' => $answer_info['question_title'],
                'answer_id'      => $answer_id,
                'answer_text'    => $answer_info['answer_text'],
                'correct'        => $is_correct ? 1 : 0,
            );
        }

        $first_checked = ! empty( $checked[0] ) && is_array( $checked[0] ) ? $checked[0] : array();
        $current_rewatch_cycle = max( 0, absint( $state['rewatch_cycle'] ?? 0 ) );

        $passed = ( $correct_count === count( $selected_ids ) );
        $now    = current_time( 'mysql', true );

        $state['last_validation_attempt_at'] = $now;
        $state['last_validation_questions']  = array_values( array_map( 'absint', $selected_ids ) );
        $state['validation_attempt']         = max( 1, absint( $state['validation_attempt'] ?? 1 ) ) + 1;

        if ( $passed ) {
            $user_item_id = $this->mark_lp_quiz_item_result( $user_id, $gate, true, array(
                'checked'       => $checked,
                'correct_count' => $correct_count,
                'shown_count'   => count( $selected_ids ),
            ) );

            $this->store_validation_attempt_detail( $user_id, $gate, true, array(
                'checked'           => $checked,
                'correct_count'     => $correct_count,
                'shown_count'       => count( $selected_ids ),
                'attempt_no'        => $current_attempt_no,
                'rewatch_cycle'     => $current_rewatch_cycle,
                'returned_to_video' => false,
                'user_item_id'      => $user_item_id,
            ) );

            $recognition = $this->get_learnpress_item_recognition( $user_id, $course_id, $quiz_id );
            $write_verified = $user_item_id && ! empty( $recognition['is_completed'] ) && ! empty( $recognition['is_passed'] );

            if ( ! $write_verified ) {
                $state['passed']                    = 0;
                $state['passed_at']                 = '';
                $state['failed_at']                 = '';
                $state['last_status']               = 'verified_pass_pending_learnpress_repair';
                $state['force_validation_required'] = 1;
                $state['force_validation_set_at']   = $now;
                $state['force_validation_reason']   = 'Student answered correctly, but LearnPress did not verify the completion row.';
                $this->set_gate_state( $user_id, $gate, $state );

                $this->log_event( 'validation_pass_learnpress_write_unverified', $user_id, $gate, array(
                    'selected'              => array_values( array_map( 'absint', $selected_ids ) ),
                    'question_id_selected'  => absint( $first_checked['question_id'] ?? 0 ),
                    'submitted_answer_id'   => (string) ( $first_checked['answer_id'] ?? '' ),
                    'submitted_answer_text' => (string) ( $first_checked['answer_text'] ?? '' ),
                    'answer_correct'        => true,
                    'correct_count'         => $correct_count,
                    'shown_count'           => count( $selected_ids ),
                    'user_item_id'          => $user_item_id,
                    'recognition'           => $recognition,
                    'lp_write_diagnostic'   => $this->last_lp_write_diagnostic,
                ) );

                $this->render_validation_shell(
                    '<h1>Your Answer Was Correct</h1>' .
                    '<p>Your passing answer was saved, but the course did not confirm the completion record. The system did not unlock the next lesson or create a false pass.</p>' .
                    '<p>Please contact Gulf Breeze Driving School. The administrator can rebuild the missing LearnPress record from your verified answer.</p>'
                );
            }

            $state['passed']        = 1;
            $state['passed_at']     = $now;
            $state['failed_at']     = '';
            $state['last_status']   = 'passed';
            $state['course_policy_version'] = self::COURSE_POLICY_VERSION;
            $state['grandfathered'] = 0;
            unset(
                $state['grandfathered_at'],
                $state['grandfather_reason'],
                $state['manual_exemption'],
                $state['exemption_type'],
                $state['exemption_reason'],
                $state['exemption_admin_user_id'],
                $state['exemption_at'],
                $state['legacy_supporting_progress'],
                $state['mapping_fingerprint'],
                $state['force_validation_required'],
                $state['force_validation_set_at'],
                $state['force_validation_admin_id'],
                $state['force_validation_reason']
            );
            $this->set_gate_state( $user_id, $gate, $state );

            $next_id  = absint( $gate['next_item_id'] );
            if ( ! $next_id ) {
                $next_id = $this->get_next_item_after( $course_id, $quiz_id );
            }
            $next_url = $next_id ? $this->get_course_item_url( $course_id, $next_id ) : $this->get_course_item_url( $course_id, $quiz_id );

            $this->log_event( 'validation_answer_correct', $user_id, $gate, array(
                'selected'              => array_values( array_map( 'absint', $selected_ids ) ),
                'question_id_selected'  => absint( $first_checked['question_id'] ?? 0 ),
                'question_title'        => (string) ( $first_checked['question_title'] ?? '' ),
                'submitted_answer_id'   => (string) ( $first_checked['answer_id'] ?? '' ),
                'submitted_answer_text' => (string) ( $first_checked['answer_text'] ?? '' ),
                'answer_correct'        => true,
                'returned_to_video'     => false,
                'redirect_to'           => $next_url,
                'next_item_id'          => $next_id,
                'correct_count'         => $correct_count,
                'shown_count'           => count( $selected_ids ),
                'rewatch_cycle'         => $current_rewatch_cycle,
                'user_item_id'          => $user_item_id,
                'learnpress_recognition'=> $recognition,
                'lp_write_diagnostic'   => $this->last_lp_write_diagnostic,
            ) );

            $this->render_validation_result_page(
                true,
                $correct_count,
                count( $selected_ids ),
                $next_url,
                'Continue Course'
            );
        }

        $state['passed']             = 0;
        $state['failed_at']          = $now;
        $state['rewatch_visited_at'] = '';
        $state['last_status']        = 'failed';
        $state['rewatch_cycle']      = max( 0, absint( $state['rewatch_cycle'] ?? 0 ) ) + 1;
        $this->set_gate_state( $user_id, $gate, $state );
        $this->invalidate_playback_evidence( $user_id, $gate, 'validation_answer_wrong' );

        $user_item_id = $this->mark_lp_quiz_item_result( $user_id, $gate, false, array(
            'checked'       => $checked,
            'correct_count' => $correct_count,
            'shown_count'   => count( $selected_ids ),
        ) );

        $this->store_validation_attempt_detail( $user_id, $gate, false, array(
            'checked'           => $checked,
            'correct_count'     => $correct_count,
            'shown_count'       => count( $selected_ids ),
            'attempt_no'        => $current_attempt_no,
            'rewatch_cycle'     => max( 0, absint( $state['rewatch_cycle'] ?? 0 ) ),
            'returned_to_video' => true,
            'user_item_id'      => $user_item_id,
        ) );

        $return_url = add_query_arg( 'gbvqg_wrong', 1, $lesson_url );

        $this->log_event( 'validation_answer_wrong', $user_id, $gate, array(
            'selected'              => array_values( array_map( 'absint', $selected_ids ) ),
            'question_id_selected'  => absint( $first_checked['question_id'] ?? 0 ),
            'question_title'        => (string) ( $first_checked['question_title'] ?? '' ),
            'submitted_answer_id'   => (string) ( $first_checked['answer_id'] ?? '' ),
            'submitted_answer_text' => (string) ( $first_checked['answer_text'] ?? '' ),
            'answer_correct'        => false,
            'returned_to_video'     => true,
            'redirect_to'           => $return_url,
            'correct_count'         => $correct_count,
            'shown_count'           => count( $selected_ids ),
            'rewatch_cycle'         => max( 0, absint( $state['rewatch_cycle'] ?? 0 ) ),
            'user_item_id'          => $user_item_id,
            'lp_write_diagnostic'    => $this->last_lp_write_diagnostic,
        ) );

        $this->render_validation_result_page(
            false,
            $correct_count,
            count( $selected_ids ),
            $return_url,
            'Return to Video'
        );
    }

    private function render_validation_result_page( $passed, $correct_count, $shown_count, $button_url, $button_text ) {
        $shown_count   = max( 1, absint( $shown_count ) );
        $correct_count = max( 0, absint( $correct_count ) );
        $score         = (int) round( ( $correct_count / $shown_count ) * 100 );
        $button_url    = esc_url( $button_url );
        $button_text   = $button_text ? $button_text : ( $passed ? 'Continue Course' : 'Return to Video' );

        if ( $passed ) {
            $headline = 'Video Check Passed';
            $message  = 'Nice work. You passed this video check and may continue to the next course item.';
            $class    = 'gbvqg-result-pass';
            $border   = '#16a34a';
            $bg       = '#f0fdf4';
        } else {
            $headline = 'Video Check Needs Review';
            $message  = 'You missed the video-check question, so you need to go back to the video and review it before retaking the check. This helps make sure you saw and understood the video content. Your next attempt will use a different question when available.';
            $class    = 'gbvqg-result-fail';
            $border   = '#dc2626';
            $bg       = '#fef2f2';
        }

        ob_start();
        ?>
        <section class="gbvqg-result <?php echo esc_attr( $class ); ?>" style="border:2px solid <?php echo esc_attr( $border ); ?>;background:<?php echo esc_attr( $bg ); ?>;padding:24px;border-radius:12px;">
            <h1 style="margin-top:0;"><?php echo esc_html( $headline ); ?></h1>
            <p style="font-size:20px;margin:0 0 12px;"><strong>Your score: <?php echo esc_html( $score ); ?>%</strong></p>
            <p style="margin:0 0 16px;">You answered <?php echo esc_html( $correct_count ); ?> out of <?php echo esc_html( $shown_count ); ?> correctly.</p>
            <p style="margin:0 0 20px;"><?php echo esc_html( $message ); ?></p>
            <p style="margin:0;"><a class="button gbvqg-button" style="display:inline-block;padding:12px 18px;background:#1d4ed8;color:#fff;text-decoration:none;border-radius:8px;font-weight:700;" href="<?php echo $button_url; ?>"><?php echo esc_html( $button_text ); ?></a></p>
        </section>
        <?php
        $this->render_validation_shell( ob_get_clean() );
    }

    private function get_quiz_question_ids( $quiz_id ) {
        global $wpdb;
        $quiz_id = absint( $quiz_id );
        if ( ! $quiz_id ) {
            return array();
        }

        $table = $wpdb->prefix . 'learnpress_quiz_questions';
        if ( $this->table_exists( $table ) ) {
            $cols = $this->table_columns( $table );
            if ( in_array( 'quiz_id', $cols, true ) && in_array( 'question_id', $cols, true ) ) {
                $order_col = '';
                foreach ( array( 'question_order', 'order', 'sort_order', 'ID', 'id' ) as $candidate ) {
                    if ( in_array( $candidate, $cols, true ) ) {
                        $order_col = $candidate;
                        break;
                    }
                }
                $order_sql = $order_col ? " ORDER BY `{$order_col}` ASC" : '';
                $ids = $wpdb->get_col( $wpdb->prepare( "SELECT question_id FROM {$table} WHERE quiz_id = %d{$order_sql}", $quiz_id ) );
                $ids = array_values( array_unique( array_map( 'absint', $ids ) ) );
                if ( ! empty( $ids ) ) {
                    return $ids;
                }
            }
        }

        foreach ( array( '_lp_questions', '_quiz_questions', '_lp_quiz_questions', 'questions' ) as $key ) {
            $raw = get_post_meta( $quiz_id, $key, true );
            if ( empty( $raw ) ) {
                continue;
            }
            $maybe = is_array( $raw ) ? $raw : maybe_unserialize( $raw );
            if ( ! is_array( $maybe ) ) {
                $maybe = json_decode( (string) $raw, true );
            }
            if ( is_array( $maybe ) ) {
                $ids = array();
                foreach ( $maybe as $k => $v ) {
                    if ( is_numeric( $v ) ) {
                        $ids[] = absint( $v );
                    } elseif ( is_numeric( $k ) ) {
                        $ids[] = absint( $k );
                    } elseif ( is_array( $v ) && ! empty( $v['id'] ) ) {
                        $ids[] = absint( $v['id'] );
                    }
                }
                $ids = array_values( array_unique( array_filter( $ids ) ) );
                if ( ! empty( $ids ) ) {
                    return $ids;
                }
            }
        }

        return array();
    }

    private function get_or_select_validation_questions( $user_id, $gate, $all_question_ids ) {
        $user_id = absint( $user_id );
        $quiz_id = absint( $gate['quiz_id'] );
        $show    = max( 1, absint( $gate['show_questions'] ) );

        $all_question_ids = array_values( array_unique( array_map( 'absint', $all_question_ids ) ) );
        if ( empty( $all_question_ids ) ) {
            return array();
        }

        // v0.2.29: Always use the attempt-specific pool, even when the admin
        // setting asks to show the entire bank. Earlier versions returned the
        // full bank immediately when bank_size <= show_questions, which meant a
        // failed retake could show the exact same questions in the exact same
        // order. For compliance, a failed video-check retake must get a fresh
        // draw when possible; if the entire bank is shown, at minimum provide a
        // fresh order after rewatch while preserving refresh-stability inside
        // the same attempt.
        $show = min( $show, count( $all_question_ids ) );

        $state       = $this->get_gate_state( $user_id, $gate );
        $attempt_no  = max( 1, absint( $state['validation_attempt'] ?? 1 ) );
        $pool_key    = '_gbvqg_validation_qpool_' . $gate['gate_id'] . '_' . $attempt_no;
        $seen_key    = '_gbvqg_seen_' . $quiz_id;

        $stored = get_user_meta( $user_id, $pool_key, true );
        if ( is_array( $stored ) && ! empty( $stored ) ) {
            $stored = array_values( array_intersect( array_map( 'absint', $stored ), $all_question_ids ) );
            if ( count( $stored ) === $show ) {
                return $stored;
            }
        }

        $seen   = get_user_meta( $user_id, $seen_key, true );
        $seen   = is_array( $seen ) ? array_values( array_map( 'absint', $seen ) ) : array();
        $unseen = array_values( array_diff( $all_question_ids, $seen ) );

        $rotation_reset = false;
        if ( count( $unseen ) < $show ) {
            $seen = array();
            $unseen = $all_question_ids;
            $rotation_reset = true;
        }

        shuffle( $unseen );
        $picked = array_slice( $unseen, 0, $show );

        $previous_questions = array();
        if ( ! empty( $state['last_validation_questions'] ) && is_array( $state['last_validation_questions'] ) ) {
            $previous_questions = array_values( array_map( 'absint', $state['last_validation_questions'] ) );
        }

        // If the entire available bank is being shown, the question set cannot
        // be different after failure, but the order still can be. Avoid the
        // exact same order as the previous attempt when possible.
        $forced_different_order = false;
        if ( $show >= count( $all_question_ids ) && count( $picked ) > 1 && $previous_questions === $picked ) {
            for ( $i = 0; $i < 5 && $previous_questions === $picked; $i++ ) {
                shuffle( $picked );
            }
            if ( $previous_questions === $picked ) {
                $shift = $attempt_no % count( $picked );
                if ( $shift < 1 ) {
                    $shift = 1;
                }
                $picked = array_merge( array_slice( $picked, $shift ), array_slice( $picked, 0, $shift ) );
            }
            $forced_different_order = true;
        }

        update_user_meta( $user_id, $pool_key, $picked );
        $new_seen = array_values( array_unique( array_merge( $seen, $picked ) ) );
        update_user_meta( $user_id, $seen_key, $new_seen );

        $rewatch_cycle = max( 0, absint( $state['rewatch_cycle'] ?? 0 ) );
        $after_rewatch = ! empty( $state['rewatch_visited_at'] ) && ! empty( $state['failed_at'] );

        $this->log_event( 'validation_question_selected', $user_id, $gate, array(
            'selected'                    => $picked,
            'question_id_selected'        => ! empty( $picked[0] ) ? absint( $picked[0] ) : 0,
            'question_title'              => ! empty( $picked[0] ) ? get_the_title( absint( $picked[0] ) ) : '',
            'attempt_no'                  => $attempt_no,
            'rewatch_cycle'               => $rewatch_cycle,
            'next_question_after_rewatch' => $after_rewatch,
            'bank_size'                   => count( $all_question_ids ),
            'show_questions'              => $show,
            'seen_before_count'           => count( $seen ),
            'seen_after_count'            => count( $new_seen ),
            'rotation_reset'              => $rotation_reset,
            'previous_selected'           => $previous_questions,
            'forced_different_order'      => $forced_different_order,
        ) );

        return $picked;
    }

    private function get_validation_question( $question_id ) {
        $question_id = absint( $question_id );
        $post        = get_post( $question_id );
        return array(
            'id'      => $question_id,
            'title'   => $post ? get_the_title( $post ) : '',
            'content' => $post ? $post->post_content : '',
            'answers' => $this->get_validation_answers( $question_id ),
        );
    }

    private function get_validation_answers( $question_id ) {
        global $wpdb;
        $question_id = absint( $question_id );
        $answers     = array();

        $table = $wpdb->prefix . 'learnpress_question_answers';
        if ( $this->table_exists( $table ) ) {
            $cols = $this->table_columns( $table );
            if ( in_array( 'question_id', $cols, true ) ) {
                $id_col = '';
                foreach ( array( 'question_answer_id', 'answer_id', 'id', 'ID' ) as $candidate ) {
                    if ( in_array( $candidate, $cols, true ) ) {
                        $id_col = $candidate;
                        break;
                    }
                }
                $text_col = '';
                foreach ( array( 'title', 'answer_title', 'text', 'content', 'value' ) as $candidate ) {
                    if ( in_array( $candidate, $cols, true ) ) {
                        $text_col = $candidate;
                        break;
                    }
                }
                $true_col = '';
                foreach ( array( 'is_true', 'is_correct', 'correct' ) as $candidate ) {
                    if ( in_array( $candidate, $cols, true ) ) {
                        $true_col = $candidate;
                        break;
                    }
                }
                $order_col = '';
                foreach ( array( 'question_answer_order', 'answer_order', 'order', 'sort_order' ) as $candidate ) {
                    if ( in_array( $candidate, $cols, true ) ) {
                        $order_col = $candidate;
                        break;
                    }
                }

                if ( $id_col && $text_col ) {
                    $order_sql = $order_col ? " ORDER BY `{$order_col}` ASC" : '';
                    $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE question_id = %d{$order_sql}", $question_id ), ARRAY_A );
                    foreach ( (array) $rows as $i => $row ) {
                        $raw_true = $true_col && isset( $row[ $true_col ] ) ? strtolower( (string) $row[ $true_col ] ) : '';
                        $answers[] = array(
                            'id'      => (string) $row[ $id_col ],
                            'text'    => (string) $row[ $text_col ],
                            'is_true' => in_array( $raw_true, array( '1', 'yes', 'true', 'on', 'y' ), true ),
                        );
                    }
                    if ( ! empty( $answers ) ) {
                        return $answers;
                    }
                }
            }
        }

        foreach ( array( '_lp_answers', '_question_answers', 'answers' ) as $key ) {
            $raw = get_post_meta( $question_id, $key, true );
            if ( empty( $raw ) ) {
                continue;
            }
            $maybe = is_array( $raw ) ? $raw : maybe_unserialize( $raw );
            if ( ! is_array( $maybe ) ) {
                $maybe = json_decode( (string) $raw, true );
            }
            if ( is_array( $maybe ) ) {
                foreach ( $maybe as $i => $answer ) {
                    if ( is_array( $answer ) ) {
                        $id   = isset( $answer['id'] ) ? (string) $answer['id'] : (string) $i;
                        $text = isset( $answer['title'] ) ? $answer['title'] : ( $answer['text'] ?? ( $answer['value'] ?? '' ) );
                        $true = ! empty( $answer['is_true'] ) || ! empty( $answer['is_correct'] );
                        if ( $text ) {
                            $answers[] = array( 'id' => $id, 'text' => (string) $text, 'is_true' => (bool) $true );
                        }
                    }
                }
                if ( ! empty( $answers ) ) {
                    return $answers;
                }
            }
        }

        return array();
    }

    private function is_validation_answer_correct( $question_id, $answer_id ) {
        foreach ( $this->get_validation_answers( $question_id ) as $answer ) {
            if ( (string) $answer['id'] === (string) $answer_id ) {
                return ! empty( $answer['is_true'] );
            }
        }
        return false;
    }

    /**
     * v0.2.27: Persist video-validation attempt detail for Grade Book reporting.
     * This is storage-only and does not alter gate flow, pass/fail, redirects,
     * or LearnPress progress. The existing event log already contains the detail;
     * this stores the same evidence in stable per-student meta for inspection.
     */
    private function store_validation_attempt_detail( $user_id, $gate, $passed, $details = array() ) {
        $user_id = absint( $user_id );
        $details = is_array( $details ) ? $details : array();
        if ( ! $user_id || empty( $gate['gate_id'] ) ) {
            return;
        }

        $course_id = absint( $gate['course_id'] ?? 0 );
        $lesson_id = absint( $gate['video_lesson_id'] ?? 0 );
        $quiz_id   = absint( $gate['quiz_id'] ?? 0 );
        $gate_id   = $this->gate_id( $gate );
        $checked_raw = isset( $details['checked'] ) && is_array( $details['checked'] ) ? $details['checked'] : array();

        $questions = array();
        $n = 1;
        foreach ( $checked_raw as $row ) {
            if ( ! is_array( $row ) ) {
                continue;
            }
            $qid = absint( $row['question_id'] ?? 0 );
            if ( ! $qid ) {
                continue;
            }
            $correct_answer_ids = array();
            $correct_answer_texts = array();
            foreach ( $this->get_validation_answers( $qid ) as $ans ) {
                if ( ! empty( $ans['is_true'] ) ) {
                    $correct_answer_ids[] = (string) ( $ans['id'] ?? '' );
                    $correct_answer_texts[] = wp_strip_all_tags( (string) ( $ans['text'] ?? '' ) );
                }
            }
            $questions[] = array(
                'order'                => $n++,
                'question_id'          => $qid,
                'question_title'       => (string) ( $row['question_title'] ?? get_the_title( $qid ) ),
                'question_text'        => wp_strip_all_tags( (string) get_post_field( 'post_content', $qid ) ),
                'answer_id'            => (string) ( $row['answer_id'] ?? '' ),
                'answer_text'          => wp_strip_all_tags( (string) ( $row['answer_text'] ?? '' ) ),
                'correct'              => ! empty( $row['correct'] ) ? 1 : 0,
                'correct_answer_ids'   => $correct_answer_ids,
                'correct_answer_texts' => $correct_answer_texts,
                'video_lesson_id'      => $lesson_id,
                'video_lesson_title'   => $lesson_id ? get_the_title( $lesson_id ) : '',
                'quiz_bank_id'         => $quiz_id,
                'quiz_bank_title'      => $quiz_id ? get_the_title( $quiz_id ) : '',
            );
        }

        $shown_count   = max( 1, absint( $details['shown_count'] ?? count( $questions ) ) );
        $correct_count = absint( $details['correct_count'] ?? 0 );
        $score_percent = round( ( $correct_count / $shown_count ) * 100, 2 );
        $now           = current_time( 'mysql', true );
        $attempt_no    = max( 1, absint( $details['attempt_no'] ?? 1 ) );
        $rewatch_cycle = max( 0, absint( $details['rewatch_cycle'] ?? 0 ) );
        $returned      = ! empty( $details['returned_to_video'] );

        $payload = array(
            'gbvqg_attempt_detail' => 1,
            'plugin'               => 'gulfbreeze-video-quiz-gate',
            'plugin_version'       => self::VERSION,
            'stored_at_utc'        => gmdate( 'Y-m-d H:i:s' ),
            'submitted_at'         => $now,
            'student_user_id'      => $user_id,
            'course_id'            => $course_id,
            'gate_id'              => $gate_id,
            'gate_label'           => (string) ( $gate['label'] ?? '' ),
            'video_lesson_id'      => $lesson_id,
            'video_lesson_title'   => $lesson_id ? get_the_title( $lesson_id ) : '',
            'quiz_bank_id'         => $quiz_id,
            'quiz_bank_title'      => $quiz_id ? get_the_title( $quiz_id ) : '',
            'next_item_id'         => absint( $gate['next_item_id'] ?? 0 ),
            'attempt_no'           => $attempt_no,
            'rewatch_cycle'        => $rewatch_cycle,
            'score_percent'        => $score_percent,
            'correct_count'        => $correct_count,
            'shown_count'          => $shown_count,
            'passed'               => $passed ? 1 : 0,
            'returned_to_video'    => $returned ? 1 : 0,
            'questions'            => $questions,
            'checked'              => $questions,
        );

        $detail_key = '_gbvqg_attempt_detail_' . $gate_id;
        $history_key = '_gbvqg_attempt_history_' . $gate_id;
        update_user_meta( $user_id, $detail_key, $payload );
        $history = get_user_meta( $user_id, $history_key, true );
        $history = is_array( $history ) ? $history : array();
        $history[] = $payload;
        // v0.2.28: keep the complete per-student video validation attempt history
        // for inspection records, including failed attempts that required rewatch.
        update_user_meta( $user_id, $history_key, $history );

        $user_item_id = absint( $details['user_item_id'] ?? 0 );
        if ( $user_item_id ) {
            $this->upsert_lp_user_itemmeta( $user_item_id, '_gbvqg_attempt_detail', $payload );
            $existing_history = $this->get_lp_user_itemmeta_value( $user_item_id, '_gbvqg_attempt_history' );
            $existing_history = is_array( $existing_history ) ? $existing_history : array();
            $existing_history[] = $payload;
            // v0.2.28: do not trim itemmeta history; retain all attempts for inspection.
            $this->upsert_lp_user_itemmeta( $user_item_id, '_gbvqg_attempt_history', $existing_history );
        }

        $this->log_event( 'validation_attempt_detail_stored', $user_id, $gate, array(
            'user_item_id'            => $user_item_id,
            'checked_count'           => count( $questions ),
            'question_detail_present' => ! empty( $questions ),
            'score_percent'           => $score_percent,
            'correct_count'           => $correct_count,
            'shown_count'             => $shown_count,
            'passed'                  => $passed ? true : false,
            'returned_to_video'       => $returned ? true : false,
            'attempt_no'              => $attempt_no,
            'rewatch_cycle'           => $rewatch_cycle,
            'user_meta_detail_key'    => $detail_key,
            'user_meta_history_key'   => $history_key,
        ) );
    }

    private function get_lp_user_itemmeta_value( $user_item_id, $key ) {
        global $wpdb;
        $user_item_id = absint( $user_item_id );
        if ( ! $user_item_id || ! $key ) {
            return null;
        }
        $table = $wpdb->prefix . 'learnpress_user_itemmeta';
        if ( ! $this->table_exists( $table ) ) {
            return null;
        }
        $cols = $this->table_columns( $table );
        $id_col = in_array( 'learnpress_user_item_id', $cols, true ) ? 'learnpress_user_item_id' : ( in_array( 'user_item_id', $cols, true ) ? 'user_item_id' : '' );
        if ( ! $id_col || ! in_array( 'meta_key', $cols, true ) || ! in_array( 'meta_value', $cols, true ) ) {
            return null;
        }
        $order_col = in_array( 'meta_id', $cols, true ) ? 'meta_id' : '';
        $order_sql = $order_col ? " ORDER BY {$order_col} DESC" : '';
        $raw = $wpdb->get_var( $wpdb->prepare( "SELECT meta_value FROM {$table} WHERE {$id_col} = %d AND meta_key = %s{$order_sql} LIMIT 1", $user_item_id, $key ) );
        if ( null === $raw ) {
            return null;
        }
        return maybe_unserialize( $raw );
    }

    private function mark_lp_quiz_item_result( $user_id, $gate, $passed, $details = array() ) {
        global $wpdb;

        $user_id   = absint( $user_id );
        $course_id = absint( $gate['course_id'] );
        $quiz_id   = absint( $gate['quiz_id'] );
        $before_rows = $this->get_lp_item_rows_snapshot( $user_id, $course_id, $quiz_id );

        $table = $wpdb->prefix . 'learnpress_user_items';
        if ( ! $this->table_exists( $table ) ) {
            $this->last_lp_write_diagnostic = array(
                'write_action' => 'none',
                'write_result' => false,
                'wpdb_error'   => 'LearnPress user-items table does not exist.',
                'before_rows'  => $before_rows,
                'after_rows'   => array(),
            );
            $this->log_event( 'lp_quiz_item_write_diagnostic', $user_id, $gate, $this->last_lp_write_diagnostic );
            return 0;
        }

        $cols = $this->table_columns( $table );
        if ( ! in_array( 'user_id', $cols, true ) || ! in_array( 'item_id', $cols, true ) ) {
            $this->last_lp_write_diagnostic = array(
                'write_action' => 'none',
                'write_result' => false,
                'wpdb_error'   => 'Required LearnPress user-items columns are missing.',
                'before_rows'  => $before_rows,
                'after_rows'   => array(),
            );
            $this->log_event( 'lp_quiz_item_write_diagnostic', $user_id, $gate, $this->last_lp_write_diagnostic );
            return 0;
        }

        $existing     = $this->get_lp_item_state( $user_id, $course_id, $quiz_id );
        $user_item_id = absint( $existing['user_item_id'] );

        $now  = current_time( 'mysql', true );
        $data = array();

        if ( in_array( 'user_id', $cols, true ) ) {
            $data['user_id'] = $user_id;
        }
        if ( in_array( 'item_id', $cols, true ) ) {
            $data['item_id'] = $quiz_id;
        }
        if ( in_array( 'item_type', $cols, true ) ) {
            $data['item_type'] = 'lp_quiz';
        }
        if ( in_array( 'ref_id', $cols, true ) ) {
            $data['ref_id'] = $course_id;
        }
        if ( in_array( 'ref_type', $cols, true ) ) {
            $data['ref_type'] = 'lp_course';
        }
        if ( in_array( 'status', $cols, true ) ) {
            $data['status'] = 'completed';
        }
        if ( in_array( 'graduation', $cols, true ) ) {
            $data['graduation'] = $passed ? 'passed' : 'failed';
        }
        if ( in_array( 'access_level', $cols, true ) ) {
            $data['access_level'] = 50;
        }
        foreach ( array( 'end_time', 'graduation_time', 'update_time', 'updated_at' ) as $time_col ) {
            if ( in_array( $time_col, $cols, true ) ) {
                $data[ $time_col ] = $now;
            }
        }
        if ( ! $user_item_id ) {
            foreach ( array( 'start_time', 'created_at' ) as $time_col ) {
                if ( in_array( $time_col, $cols, true ) ) {
                    $data[ $time_col ] = $now;
                }
            }
            if ( in_array( 'parent_id', $cols, true ) ) {
                $parent_id = $this->find_course_user_item_id( $user_id, $course_id );
                $data['parent_id'] = $parent_id ? $parent_id : 0;
            }
        }

        $wpdb->last_error = '';
        $write_action = $user_item_id && in_array( 'user_item_id', $cols, true ) ? 'update' : 'insert';
        if ( 'update' === $write_action ) {
            $write_result = $wpdb->update( $table, $data, array( 'user_item_id' => $user_item_id ) );
        } else {
            $write_result = $wpdb->insert( $table, $data );
            $user_item_id = absint( $wpdb->insert_id );
        }
        $write_error = (string) $wpdb->last_error;

        if ( $user_item_id ) {
            $shown   = max( 1, absint( $details['shown_count'] ?? 1 ) );
            $correct = absint( $details['correct_count'] ?? 0 );
            $score   = $passed ? 100 : 0;

            $result = array(
                'gbvqg_validation' => 1,
                'status'           => 'completed',
                'graduation'       => $passed ? 'passed' : 'failed',
                'result'           => $passed ? 'passed' : 'failed',
                'score'            => $score,
                'user_mark'        => $correct,
                'question_count'   => $shown,
                'question_correct' => $correct,
                'question_wrong'   => $shown - $correct,
                'question_empty'   => 0,
                'checked'          => $details['checked'] ?? array(),
                'time'             => $now,
            );

            $this->upsert_lp_user_itemmeta( $user_item_id, 'result', $result );
            $this->upsert_lp_user_itemmeta( $user_item_id, 'grade', $passed ? 'passed' : 'failed' );
            $this->upsert_lp_user_itemmeta( $user_item_id, 'score', $score );
            $this->upsert_lp_user_itemmeta( $user_item_id, '_gbvqg_validation_result', $result );
        }

        $after_rows  = $this->get_lp_item_rows_snapshot( $user_id, $course_id, $quiz_id );
        $recognition = $this->get_learnpress_item_recognition( $user_id, $course_id, $quiz_id );
        $this->last_lp_write_diagnostic = array(
            'write_action'               => $write_action,
            'write_result'               => $write_result,
            'wpdb_error'                 => $write_error,
            'expected_status'            => 'completed',
            'expected_graduation'        => $passed ? 'passed' : 'failed',
            'selected_user_item_id'      => $user_item_id,
            'before_rows'                => $before_rows,
            'after_rows'                 => $after_rows,
            'database_has_completed_row' => $this->lp_rows_have_status( $after_rows, 'completed' ),
            'database_has_passed_row'    => $this->lp_rows_have_status( $after_rows, 'passed' ),
            'learnpress_recognition'     => $recognition,
            'cache_was_not_cleared'      => true,
            'diagnostic_mode'            => 'Evidence only: this version does not automatically run Course Progress Fix or alter duplicate rows.',
        );

        $this->log_event( 'lp_quiz_item_write_diagnostic', $user_id, $gate, $this->last_lp_write_diagnostic );
        return $user_item_id;
    }

    private function find_course_user_item_id( $user_id, $course_id ) {
        global $wpdb;
        $table = $wpdb->prefix . 'learnpress_user_items';
        if ( ! $this->table_exists( $table ) ) {
            return 0;
        }
        $cols = $this->table_columns( $table );
        if ( ! in_array( 'user_item_id', $cols, true ) || ! in_array( 'user_id', $cols, true ) || ! in_array( 'item_id', $cols, true ) ) {
            return 0;
        }
        return absint( $wpdb->get_var( $wpdb->prepare( "SELECT user_item_id FROM {$table} WHERE user_id = %d AND item_id = %d ORDER BY user_item_id DESC LIMIT 1", absint( $user_id ), absint( $course_id ) ) ) );
    }

    private function upsert_lp_user_itemmeta( $user_item_id, $key, $value ) {
        global $wpdb;
        $user_item_id = absint( $user_item_id );
        if ( ! $user_item_id ) {
            return;
        }
        $table = $wpdb->prefix . 'learnpress_user_itemmeta';
        if ( ! $this->table_exists( $table ) ) {
            return;
        }

        $cols = $this->table_columns( $table );
        $id_col = in_array( 'learnpress_user_item_id', $cols, true ) ? 'learnpress_user_item_id' : ( in_array( 'user_item_id', $cols, true ) ? 'user_item_id' : '' );
        if ( ! $id_col || ! in_array( 'meta_key', $cols, true ) || ! in_array( 'meta_value', $cols, true ) ) {
            return;
        }

        $encoded     = maybe_serialize( $value );
        $meta_id_col = in_array( 'meta_id', $cols, true ) ? 'meta_id' : '';

        if ( $meta_id_col ) {
            $exists = $wpdb->get_var( $wpdb->prepare( "SELECT {$meta_id_col} FROM {$table} WHERE {$id_col} = %d AND meta_key = %s LIMIT 1", $user_item_id, $key ) );
            if ( $exists ) {
                $wpdb->update( $table, array( 'meta_value' => $encoded ), array( $meta_id_col => absint( $exists ) ) );
                return;
            }
        } else {
            $exists = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$id_col} = %d AND meta_key = %s", $user_item_id, $key ) );
            if ( $exists ) {
                $wpdb->update( $table, array( 'meta_value' => $encoded ), array( $id_col => $user_item_id, 'meta_key' => $key ) );
                return;
            }
        }

        $wpdb->insert( $table, array(
            $id_col      => $user_item_id,
            'meta_key'   => $key,
            'meta_value' => $encoded,
        ) );
    }


    private function find_gate_for_quiz( $quiz_id ) {
        $quiz_id = absint( $quiz_id );
        if ( ! $quiz_id ) {
            return null;
        }
        foreach ( $this->get_gates() as $gate ) {
            if ( $this->is_gate_enabled( $gate ) && absint( $gate['quiz_id'] ) === $quiz_id ) {
                return $gate;
            }
        }
        return null;
    }

    private function attempt_key_for( $user_id, $course_id, $quiz_id ) {
        $user_id   = absint( $user_id );
        $course_id = absint( $course_id );
        $quiz_id   = absint( $quiz_id );
        $state = $this->get_lp_item_state( $user_id, $course_id, $quiz_id );
        if ( ! empty( $state['user_item_id'] ) ) {
            return 'ui:' . absint( $state['user_item_id'] );
        }
        return 'fallback:' . $user_id . ':' . $course_id . ':' . $quiz_id . ':' . substr( md5( $user_id . ':' . $quiz_id . ':' . gmdate( 'YmdH' ) ), 0, 12 );
    }

    /**
     * v0.2.8: Rotation-aware selection.
     *
     *   - Same attempt? Return the persisted selection (refreshes are stable).
     *   - New attempt? Pick `show` IDs from (bank - seen). Mark them seen.
     *   - When the unseen pool is too small, RESET the seen set and pick fresh.
     *
     * "Seen" is per-user, per-quiz, persisted in user_meta. So the moment the
     * student is shown question X, X cannot reappear until all 4 have been
     * shown at least once.
     */
    private function get_or_select_question_pool( $user_id, $gate, $all_question_ids ) {
        $user_id   = absint( $user_id );
        $quiz_id   = absint( $gate['quiz_id'] );
        $course_id = absint( $gate['course_id'] );
        $show      = max( 1, absint( $gate['show_questions'] ) );

        if ( ! $user_id || empty( $all_question_ids ) ) {
            return $all_question_ids;
        }

        $all_question_ids = array_values( array_unique( array_map( 'absint', $all_question_ids ) ) );
        if ( count( $all_question_ids ) <= $show ) {
            return $all_question_ids;
        }

        $attempt_key = $this->attempt_key_for( $user_id, $course_id, $quiz_id );
        $pool_key    = '_gbvqg_qpool_' . $quiz_id . '_' . md5( $attempt_key );
        $seen_key    = '_gbvqg_seen_'  . $quiz_id;

        // 1) Same attempt — return the already-picked selection.
        $stored = get_user_meta( $user_id, $pool_key, true );
        if ( is_array( $stored ) && ! empty( $stored ) ) {
            $stored = array_values( array_intersect( array_map( 'absint', $stored ), $all_question_ids ) );
            if ( count( $stored ) === $show ) {
                return $stored;
            }
        }

        // 2) Determine unseen pool.
        $seen   = get_user_meta( $user_id, $seen_key, true );
        $seen   = is_array( $seen ) ? array_values( array_map( 'absint', $seen ) ) : array();
        $unseen = array_values( array_diff( $all_question_ids, $seen ) );

        $rotation_reset = false;
        if ( count( $unseen ) < $show ) {
            // Bank exhausted (or close enough to satisfy `show`). Reset rotation.
            $seen   = array();
            $unseen = $all_question_ids;
            $rotation_reset = true;
        }

        // 3) Pick `show` distinct random IDs from unseen.
        shuffle( $unseen );
        $picked = array_slice( $unseen, 0, $show );

        // 4) Persist for this attempt + mark seen.
        update_user_meta( $user_id, $pool_key, $picked );
        $new_seen = array_values( array_unique( array_merge( $seen, $picked ) ) );
        update_user_meta( $user_id, $seen_key, $new_seen );

        $this->gc_question_pool_keys( $user_id, $quiz_id, $pool_key, 5 );

        $this->log_event( 'question_selected', $user_id, $gate, array(
            'selected'           => $picked,
            'attempt_key'        => $attempt_key,
            'bank_size'          => count( $all_question_ids ),
            'seen_before_count'  => count( $seen ),
            'seen_after_count'   => count( $new_seen ),
            'rotation_reset'     => $rotation_reset,
        ) );

        return $picked;
    }

    /**
     * v0.2.8: Force-hide answer reveal for gated quizzes regardless of the
     * default LP quiz setting. Hook signature varies across LP versions; we
     * accept ($value, $quiz_id) AND ($value, $quiz_obj) shapes and try to
     * resolve a quiz id from either.
     */
    public function force_hide_answer_for_gated( $value, $quiz = null ) {
        $quiz_id = 0;
        if ( is_numeric( $quiz ) ) {
            $quiz_id = absint( $quiz );
        } elseif ( is_object( $quiz ) ) {
            if ( isset( $quiz->ID ) )                 { $quiz_id = absint( $quiz->ID ); }
            elseif ( isset( $quiz->id ) )             { $quiz_id = absint( $quiz->id ); }
            elseif ( method_exists( $quiz, 'get_id' ) ) { $quiz_id = absint( $quiz->get_id() ); }
        } elseif ( is_array( $quiz ) ) {
            if ( isset( $quiz['ID'] ) )            { $quiz_id = absint( $quiz['ID'] ); }
            elseif ( isset( $quiz['id'] ) )        { $quiz_id = absint( $quiz['id'] ); }
            elseif ( isset( $quiz['quiz_id'] ) )   { $quiz_id = absint( $quiz['quiz_id'] ); }
        }
        if ( ! $quiz_id ) {
            // Fall back to the queried/global post.
            $qid = absint( get_queried_object_id() );
            if ( $qid && 'lp_quiz' === get_post_type( $qid ) ) {
                $quiz_id = $qid;
            }
        }
        if ( ! $quiz_id ) {
            return $value;
        }
        if ( $this->find_gate_for_quiz( $quiz_id ) ) {
            return false;
        }
        return $value;
    }

    private function gc_question_pool_keys( $user_id, $quiz_id, $keep_key, $max_keep ) {
        global $wpdb;
        $like = $wpdb->esc_like( '_gbvqg_qpool_' . absint( $quiz_id ) . '_' ) . '%';
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT umeta_id, meta_key FROM {$wpdb->usermeta} WHERE user_id=%d AND meta_key LIKE %s ORDER BY umeta_id DESC",
            absint( $user_id ),
            $like
        ), ARRAY_A );
        if ( ! is_array( $rows ) ) {
            return;
        }
        $kept = 0;
        foreach ( $rows as $row ) {
            if ( $row['meta_key'] === $keep_key ) { $kept++; continue; }
            $kept++;
            if ( $kept > $max_keep ) {
                delete_user_meta( $user_id, $row['meta_key'] );
            }
        }
    }

    public function filter_quiz_questions( $questions, $quiz_id = 0 ) {
        $quiz_id = absint( $quiz_id );
        if ( ! $quiz_id ) {
            return $questions;
        }
        $gate = $this->find_gate_for_quiz( $quiz_id );
        if ( ! $gate ) {
            return $questions;
        }
        $user_id = get_current_user_id();
        if ( ! $user_id || ! is_array( $questions ) || empty( $questions ) ) {
            return $questions;
        }

        $extract_id = function( $q ) {
            if ( is_numeric( $q ) ) { return absint( $q ); }
            if ( is_object( $q ) ) {
                if ( isset( $q->ID ) )          { return absint( $q->ID ); }
                if ( isset( $q->id ) )          { return absint( $q->id ); }
                if ( isset( $q->question_id ) ) { return absint( $q->question_id ); }
                if ( method_exists( $q, 'get_id' ) ) { return absint( $q->get_id() ); }
            }
            if ( is_array( $q ) ) {
                if ( isset( $q['ID'] ) )          { return absint( $q['ID'] ); }
                if ( isset( $q['id'] ) )          { return absint( $q['id'] ); }
                if ( isset( $q['question_id'] ) ) { return absint( $q['question_id'] ); }
            }
            return 0;
        };

        $all_ids = array();
        foreach ( $questions as $q ) {
            $id = $extract_id( $q );
            if ( $id ) { $all_ids[] = $id; }
        }
        if ( empty( $all_ids ) ) {
            return $questions;
        }

        $keep = $this->get_or_select_question_pool( $user_id, $gate, $all_ids );
        $keep = array_flip( array_map( 'intval', $keep ) );

        $filtered = array();
        foreach ( $questions as $q ) {
            $id = $extract_id( $q );
            if ( $id && isset( $keep[ $id ] ) ) {
                $filtered[] = $q;
            }
        }
        return ! empty( $filtered ) ? $filtered : $questions;
    }

    public function filter_quiz_question_ids( $question_ids, $quiz_id = 0 ) {
        $quiz_id = absint( $quiz_id );
        $gate = $quiz_id ? $this->find_gate_for_quiz( $quiz_id ) : null;
        if ( ! $gate ) {
            return $question_ids;
        }
        $user_id = get_current_user_id();
        if ( ! $user_id || ! is_array( $question_ids ) || empty( $question_ids ) ) {
            return $question_ids;
        }
        return $this->get_or_select_question_pool( $user_id, $gate, array_map( 'absint', $question_ids ) );
    }

    /* ====================================================================
     * v0.2.7 — Stamp failed_at on quiz finish so Retake cannot bypass video
     * ==================================================================== */

    public function on_quiz_finished_lp4( $a, $b, $c ) {
        $candidates = array(
            array( 'user_id' => absint( $a ), 'quiz_id' => absint( $b ), 'course_id' => absint( $c ) ),
            array( 'user_id' => absint( $b ), 'quiz_id' => absint( $a ), 'course_id' => absint( $c ) ),
        );
        foreach ( $candidates as $c1 ) {
            if ( $c1['user_id'] && $c1['quiz_id'] ) {
                $this->stamp_quiz_outcome( $c1['user_id'], $c1['course_id'], $c1['quiz_id'] );
                return;
            }
        }
    }

    public function on_quiz_finished_legacy( $quiz_id, $user_id, $extra = null ) {
        $this->stamp_quiz_outcome( absint( $user_id ), 0, absint( $quiz_id ) );
    }

    private function stamp_quiz_outcome( $user_id, $course_id, $quiz_id ) {
        $user_id = absint( $user_id );
        $quiz_id = absint( $quiz_id );
        if ( ! $user_id || ! $quiz_id ) {
            return;
        }
        $gate = $this->find_gate_for_quiz( $quiz_id );
        if ( ! $gate ) {
            return;
        }
        if ( ! $course_id ) {
            $course_id = absint( $gate['course_id'] );
        }

        $lp_state = $this->get_lp_item_state( $user_id, $course_id, $quiz_id );
        $state    = $this->get_gate_state( $user_id, $gate );

        $passed = ( 'passed' === $lp_state['status'] );
        $failed = ( 'failed' === $lp_state['status'] );

        if ( ! $passed && ! $failed ) {
            // LP didn't stamp pass/fail yet (mid-grading). Be conservative:
            // treat ambiguous as failed so the rewatch loop kicks in.
            if ( in_array( $lp_state['status'], array( 'completed', 'started' ), true ) ) {
                $failed = true;
            }
        }

        if ( $passed ) {
            $state['passed']      = 1;
            $state['passed_at']   = current_time( 'mysql', true );
            $state['failed_at']   = '';
            $state['last_status'] = 'passed';
            $this->set_gate_state( $user_id, $gate, $state );
            $this->log_event_once( 'quiz_passed_via_finished_hook', $user_id, $gate, array( 'user_item_id' => $lp_state['user_item_id'] ) );
            return;
        }

        if ( $failed ) {
            $state['passed']                   = 0;
            $state['failed_at']                = current_time( 'mysql', true );
            $state['rewatch_visited_at']       = '';
            $state['last_status']              = 'failed';
            $state['last_failed_user_item_id'] = absint( $lp_state['user_item_id'] );
            $this->set_gate_state( $user_id, $gate, $state );
            $this->invalidate_playback_evidence( $user_id, $gate, 'learnpress_quiz_failed' );
            $this->log_event( 'quiz_failed_via_finished_hook', $user_id, $gate, array( 'user_item_id' => $lp_state['user_item_id'] ) );
        }
    }
}

register_activation_hook( __FILE__, array( 'GulfBreeze_Video_Quiz_Gate', 'activate' ) );
add_action( 'plugins_loaded', array( 'GulfBreeze_Video_Quiz_Gate', 'instance' ) );
