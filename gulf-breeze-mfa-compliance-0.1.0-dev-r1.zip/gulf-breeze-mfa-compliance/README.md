# Gulf Breeze MFA & Compliance

Development revision: `0.1.0-dev-r1`

This plugin consolidates the proven Drive Smart self-hosted TOTP gate, profile enforcement, lockout/reset controls, and student audit dashboard into one Gulf Breeze-branded plugin. It adds a bilingual mobile-first enrollment flow, same-phone manual setup, local QR rendering, one-time recovery codes, session-bound verification, direct-route enforcement, critical exam checkpoints, Gulf Breeze Core seat-time integration, LearnPress progress integration, certificate issuance/download evidence, and a permanent exact-user owner exemption.

## Installation behavior

- Creates `/mfa-enroll/`, `/mfa-verify/`, and `/mfa-recovery/` pages when missing.
- Creates the append-only `wp_gb_mfa_events` table using the active WordPress prefix.
- Grants `gb_view_student_compliance` to the Administrator role.
- Pins the WordPress user ID of the administrator who activates the plugin as the immune owner account. For a configuration-level pin, define `GB_MFA_OWNER_USER_ID` in `wp-config.php`.
- Marks the Gulf Breeze Adult English quiz whose `_gb_assessment_key` is `adult_en_final` as a fresh-MFA final-exam checkpoint.
- Does not disable or alter Under Construction.

## Student controls

- Full English/Spanish setup, verification, recovery, reset, lockout, and error guidance.
- Same-phone setup key with a large copy control.
- Two-device QR path generated in the browser. No authenticator secret is sent to an external QR service.
- Authenticator-neutral wording; no emailed/texted-code confusion.
- Eight single-use recovery codes stored only as WordPress password hashes.
- Recovery consumes one code, revokes the old authenticator, and forces re-enrollment.
- Verification is bound to the current WordPress login session.
- Default Drive Smart-compatible policy: 60-minute verification, six failures, 30-minute lockout.
- Final-exam/certificate checkpoint default freshness: 30 minutes.

## Enforcement

- Protects LearnPress course, lesson, and quiz pages.
- Protects the My Account certificate endpoint and student certificate download action.
- Protects Gulf Breeze Core seat-time AJAX calls.
- Protects matched LearnPress/Gulf Breeze course, progress, quiz, seat-time, and certificate REST requests.
- Exposes `gb_mfa_protected_request`, `gb_mfa_protected_action`, and `gb_mfa_protected_rest_route` integration filters.
- Exposes `gb_mfa_is_verified()`, `gb_mfa_require_recent()`, and `gb_mfa_is_owner_immune()` for other Gulf Breeze modules.

## Compliance evidence

The administrator-only Student Compliance screen joins:

- student legal identity and MFA state;
- immutable MFA enrollment, challenge, failure, lockout, recovery, reset, and administrative-action events;
- Gulf Breeze Core seat-time records;
- LearnPress progress and examination records;
- Gulf Breeze certificate issuance/reporting records; and
- certificate download audit records.

The screen exports an inspection PDF and a complete MFA event CSV. Records are never automatically deleted, supporting the required minimum retention period. Raw TOTP codes, plaintext recovery codes, and decrypted authenticator secrets are never written to audit records.

## Administrator recovery controls

Unlock, force-reverify, and reset operations require a written reason and log the internal actor user ID. The student-facing reset notice never exposes administrator identity or account information. There is deliberately no “mark student verified” button because mandatory student verification must not be bypassed administratively.

## Validation boundary

This is a development package. Complete PHP 8.4 and exact-stack WordPress runtime validation must pass before live installation. Under Construction must remain enabled through the full bilingual phone-first student-journey test.

