<?php
/**
 * Plugin Name: Gulf Breeze Certificates
 * Description: Protected test certificate inventory, eligibility verification, PDF delivery, email, and audit records for Gulf Breeze Driving School.
 * Version: 0.1.0-dev-r3
 * Author: Gulf Breeze Driving School / Rodney Crawford
 * Text Domain: gulf-breeze-certificates
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Gulf_Breeze_Certificates {
	const VERSION = '0.1.0-dev-r3';
	const MODE = 'test';
	const TYPE_ADEE = 'ADEE-1317';
	const ACCOUNT_ENDPOINT = 'certificates';
	const CRON_HOOK = 'gb_certificates_reconcile';
	const LOW_STOCK = 100;
	const SCHEMA_VERSION = '0.4.0';
	const REPORTING_DAYS = 15;
	const REPORT_HEADERS = array(
		'Record Type', 'Certificate Type', 'CertNo', 'Provider Number', 'Course Type',
		'LNAME', 'FNAME', 'MINITIAL', 'DOB', 'Gender', 'Classroom Hours',
		'Classroom Completion Date', '7Hrs_Observation Hours', '7Hrs_Behind_The_Wheel Hours',
		'Laboratory Completion Date ', 'Cert. Issue Date', 'Instructor Last Name',
		'Instructor First Name', 'Instructor License Number', 'Void Code',
		'Replaced Certificate Number',
	);

	private static $instance;
	private $pending = array();

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'init', array( $this, 'register_endpoint' ) );
		add_action( 'init', array( $this, 'maybe_refresh_endpoint' ), 20 );
		add_action( 'plugins_loaded', array( $this, 'dependency_notice' ) );
		add_action( 'plugins_loaded', array( $this, 'maybe_install_schema' ), 5 );
		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'admin_notices', array( $this, 'inventory_notice' ) );
		add_action( 'admin_post_gb_cert_generate_mock', array( $this, 'handle_generate_mock' ) );
		add_action( 'admin_post_gb_cert_reconcile', array( $this, 'handle_reconcile' ) );
		add_action( 'admin_post_gb_cert_download', array( $this, 'handle_download' ) );
		add_action( 'admin_post_nopriv_gb_cert_download', array( $this, 'handle_download' ) );
		add_action( 'admin_post_gb_cert_resend_email', array( $this, 'handle_resend_email' ) );
		add_action( 'admin_post_gb_cert_export_report', array( $this, 'handle_export_report' ) );
		add_action( 'admin_post_gb_cert_mark_reported', array( $this, 'handle_mark_reported' ) );
		add_action( 'admin_post_gb_cert_save_settings', array( $this, 'handle_save_settings' ) );
		add_action( 'show_user_profile', array( $this, 'student_reporting_fields' ) );
		add_action( 'edit_user_profile', array( $this, 'student_reporting_fields' ) );
		add_action( 'personal_options_update', array( $this, 'save_student_reporting_fields' ) );
		add_action( 'edit_user_profile_update', array( $this, 'save_student_reporting_fields' ) );
		add_action( 'updated_user_meta', array( $this, 'capture_mastery_state' ), 20, 4 );
		add_action( 'added_user_meta', array( $this, 'capture_mastery_state' ), 20, 4 );
		add_action( 'shutdown', array( $this, 'process_pending' ), 20 );
		add_action( self::CRON_HOOK, array( $this, 'reconcile_eligible_completions' ) );
		add_filter( 'woocommerce_account_menu_items', array( $this, 'account_menu' ), 30, 2 );
		add_action( 'woocommerce_account_' . self::ACCOUNT_ENDPOINT . '_endpoint', array( $this, 'account_certificates' ) );
	}

	public static function activate() {
		$self = self::instance();
		$self->install_schema();
		$self->register_endpoint();
		flush_rewrite_rules( false );
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', self::CRON_HOOK );
		}
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( self::CRON_HOOK );
		flush_rewrite_rules( false );
	}

	private function serial_table() {
		global $wpdb;
		return $wpdb->prefix . 'gb_certificate_serials';
	}

	private function issuance_table() {
		global $wpdb;
		return $wpdb->prefix . 'gb_certificate_issuances';
	}

	private function download_table() {
		global $wpdb;
		return $wpdb->prefix . 'gb_certificate_download_log';
	}

	private function issuance_columns( $include_pdf = false ) {
		$columns = array(
			'id', 'eligibility_key', 'certificate_type', 'serial_number', 'user_id', 'course_id', 'order_id',
			'course_key', 'locale', 'legal_name', 'student_dob', 'student_first_name', 'student_last_name',
			'student_middle_initial', 'student_gender', 'provider_number', 'instructor_first_name',
			'instructor_last_name', 'instructor_license_number', 'school_name', 'chief_official_name',
			'final_score', 'final_passed_utc', 'course_completed_utc', 'issued_utc', 'contract_signed_utc',
			'student_download_until_utc', 'report_due_utc',
			'report_status', 'report_exported_utc', 'report_filename', 'reported_utc', 'pdf_sha256',
			'template_sha256', 'email_status', 'email_sent_utc', 'email_recipient', 'test_mode',
			'voided_utc', 'void_reason',
		);
		if ( $include_pdf ) { $columns[] = 'pdf_blob_b64'; }
		return implode( ',', $columns );
	}

	public function install_schema() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$serials = $this->serial_table();
		$issuances = $this->issuance_table();
		$downloads = $this->download_table();
		dbDelta( "CREATE TABLE {$serials} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			certificate_type varchar(24) NOT NULL,
			serial_number char(8) NOT NULL,
			status varchar(16) NOT NULL DEFAULT 'available',
			issuance_id bigint(20) unsigned NOT NULL DEFAULT 0,
			issued_to_user bigint(20) unsigned NOT NULL DEFAULT 0,
			course_id bigint(20) unsigned NOT NULL DEFAULT 0,
			created_utc datetime NOT NULL,
			issued_utc datetime NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY type_serial (certificate_type,serial_number),
			KEY status_type (status,certificate_type)
		) {$charset};" );
		dbDelta( "CREATE TABLE {$issuances} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			eligibility_key char(64) NOT NULL,
			certificate_type varchar(24) NOT NULL,
			serial_number char(8) NOT NULL,
			user_id bigint(20) unsigned NOT NULL,
			course_id bigint(20) unsigned NOT NULL,
			order_id bigint(20) unsigned NOT NULL,
			course_key varchar(40) NOT NULL,
			locale varchar(12) NOT NULL,
			legal_name varchar(190) NOT NULL,
			student_dob varchar(20) NOT NULL,
			student_first_name varchar(100) NOT NULL,
			student_last_name varchar(100) NOT NULL,
			student_middle_initial varchar(4) NOT NULL DEFAULT '',
			student_gender char(1) NOT NULL,
			provider_number varchar(32) NOT NULL,
			instructor_first_name varchar(100) NOT NULL,
			instructor_last_name varchar(100) NOT NULL,
			instructor_license_number varchar(40) NOT NULL,
			school_name varchar(190) NOT NULL,
			chief_official_name varchar(190) NOT NULL,
			final_score decimal(6,2) NOT NULL,
			final_passed_utc datetime NOT NULL,
			course_completed_utc datetime NOT NULL,
			issued_utc datetime NOT NULL,
			contract_signed_utc datetime NULL,
			student_download_until_utc datetime NULL,
			report_due_utc datetime NOT NULL,
			report_status varchar(24) NOT NULL DEFAULT 'pending',
			report_exported_utc datetime NULL,
			report_filename varchar(190) NOT NULL DEFAULT '',
			reported_utc datetime NULL,
			pdf_sha256 char(64) NOT NULL DEFAULT '',
			template_sha256 char(64) NOT NULL DEFAULT '',
			pdf_blob_b64 longtext NULL,
			email_status varchar(24) NOT NULL DEFAULT 'pending',
			email_sent_utc datetime NULL,
			email_recipient varchar(190) NOT NULL,
			test_mode tinyint(1) unsigned NOT NULL DEFAULT 1,
			voided_utc datetime NULL,
			void_reason text NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY eligibility_key (eligibility_key),
			UNIQUE KEY type_serial (certificate_type,serial_number),
			KEY user_course (user_id,course_id),
			KEY issued_utc (issued_utc),
			KEY student_download_until_utc (student_download_until_utc)
		) {$charset};" );
		dbDelta( "CREATE TABLE {$downloads} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			issuance_id bigint(20) unsigned NOT NULL DEFAULT 0,
			certificate_type varchar(24) NOT NULL DEFAULT '',
			serial_number char(8) NOT NULL DEFAULT '',
			subject_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			actor_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			actor_role varchar(24) NOT NULL,
			outcome varchar(16) NOT NULL,
			reason varchar(64) NOT NULL,
			requested_utc datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY issuance_time (issuance_id,requested_utc),
			KEY actor_time (actor_user_id,requested_utc),
			KEY outcome_time (outcome,requested_utc)
		) {$charset};" );
		$this->backfill_contract_dates();
		update_option( 'gb_certificates_schema_version', self::SCHEMA_VERSION, false );
	}

	public function maybe_install_schema() {
		if ( get_option( 'gb_certificates_schema_version' ) !== self::SCHEMA_VERSION ) {
			$this->install_schema();
		}
	}

	public function register_endpoint() {
		add_rewrite_endpoint( self::ACCOUNT_ENDPOINT, EP_ROOT | EP_PAGES );
	}

	public function maybe_refresh_endpoint() {
		if ( get_option( 'gb_certificates_endpoint_version' ) === self::VERSION ) {
			return;
		}
		flush_rewrite_rules( false );
		update_option( 'gb_certificates_endpoint_version', self::VERSION, false );
	}

	public function dependency_notice() {
		if ( ! is_admin() || ( class_exists( 'WooCommerce' ) && function_exists( 'learn_press_get_user' ) ) ) {
			return;
		}
		add_action( 'admin_notices', function() {
			echo '<div class="notice notice-error"><p><strong>Gulf Breeze Certificates:</strong> WooCommerce and LearnPress are required.</p></div>';
		} );
	}

	public function capture_mastery_state( $meta_id, $user_id, $meta_key, $meta_value ) {
		if ( 0 !== strpos( (string) $meta_key, '_gbcmg_state_' ) || ! is_array( $meta_value ) || empty( $meta_value['passed_at'] ) ) {
			return;
		}
		foreach ( $this->adult_final_maps() as $map ) {
			if ( $meta_key === '_gbcmg_state_' . $this->mapping_id( $map ) ) {
				$this->pending[ absint( $user_id ) . ':' . absint( $map['course_id'] ) ] = array( absint( $user_id ), absint( $map['course_id'] ) );
				break;
			}
		}
	}

	public function process_pending() {
		foreach ( $this->pending as $candidate ) {
			$this->maybe_issue( $candidate[0], $candidate[1] );
		}
		$this->pending = array();
	}

	private function mapping_id( $map ) {
		return substr( hash( 'sha256', implode( ':', array(
			absint( $map['course_id'] ?? 0 ),
			sanitize_key( $map['unit_type'] ?? '' ),
			absint( $map['unit_number'] ?? 0 ),
			absint( $map['bank_quiz_id'] ?? 0 ),
			absint( $map['second_bank_quiz_id'] ?? 0 ),
		) ) ), 0, 12 );
	}

	private function adult_final_maps() {
		$maps = get_option( 'gbcmg_mappings', array() );
		$out = array();
		foreach ( is_array( $maps ) ? $maps : array() as $map ) {
			if ( ! empty( $map['active'] ) && 'adult_final' === sanitize_key( $map['unit_type'] ?? '' ) && absint( $map['course_id'] ?? 0 ) ) {
				$out[] = $map;
			}
		}
		return $out;
	}

	private function final_evidence( $user_id, $course_id ) {
		foreach ( $this->adult_final_maps() as $map ) {
			if ( absint( $map['course_id'] ) !== absint( $course_id ) ) {
				continue;
			}
			$state = get_user_meta( $user_id, '_gbcmg_state_' . $this->mapping_id( $map ), true );
			$state = is_array( $state ) ? $state : array();
			$last = isset( $state['last_result'] ) && is_array( $state['last_result'] ) ? $state['last_result'] : array();
			$score = isset( $last['score_percent'] ) ? (float) $last['score_percent'] : 0;
			$required = max( 70, absint( $map['pass_percent'] ?? 70 ) );
			if ( ! empty( $state['passed_at'] ) && ! empty( $last['passed'] ) && $score >= $required ) {
				return array( 'score' => $score, 'passed_utc' => sanitize_text_field( $state['passed_at'] ), 'map_id' => $this->mapping_id( $map ) );
			}
		}
		return new WP_Error( 'gb_cert_final', 'A verified Adult final score of at least 70% was not found.' );
	}

	private function completion_evidence( $user_id, $course_id ) {
		global $wpdb;
		$table = $wpdb->prefix . 'learnpress_user_items';
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( $exists !== $table ) {
			return new WP_Error( 'gb_cert_lp_table', 'LearnPress completion records are unavailable.' );
		}
		$columns = $wpdb->get_col( "SHOW COLUMNS FROM {$table}", 0 );
		$required = array( 'status', 'graduation' );
		if ( array_diff( $required, $columns ) ) {
			return new WP_Error( 'gb_cert_lp_columns', 'LearnPress completion fields are unavailable.' );
		}
		$select = array( 'status', 'graduation' );
		foreach ( array( 'graduation_time', 'end_time', 'update_time' ) as $optional ) {
			if ( in_array( $optional, $columns, true ) ) {
				$select[] = $optional;
			}
		}
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT " . implode( ',', $select ) . " FROM {$table} WHERE user_id=%d AND item_id=%d AND item_type='lp_course' ORDER BY user_item_id DESC LIMIT 1",
			$user_id,
			$course_id
		), ARRAY_A );
		if ( ! $row || ! in_array( sanitize_key( $row['status'] ?? '' ), array( 'completed', 'finished' ), true ) || ! in_array( sanitize_key( $row['graduation'] ?? '' ), array( 'passed', 'completed' ), true ) ) {
			return new WP_Error( 'gb_cert_course', 'LearnPress does not show the course as completed and passed.' );
		}
		foreach ( array( 'graduation_time', 'end_time', 'update_time' ) as $key ) {
			if ( ! empty( $row[ $key ] ) && '0000-00-00 00:00:00' !== $row[ $key ] ) {
				return sanitize_text_field( $row[ $key ] );
			}
		}
		return current_time( 'mysql', true );
	}

	private function paid_enrollment_evidence( $user_id, $course_id ) {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return new WP_Error( 'gb_cert_wc', 'WooCommerce is unavailable.' );
		}
		$order_id = absint( get_user_meta( $user_id, '_gb_ep_active_course_' . $course_id, true ) );
		$order = $order_id ? wc_get_order( $order_id ) : false;
		if ( ! $order || ! $order->is_paid() || 'paid_enrolled' !== $order->get_meta( '_gb_ep_state' ) || 'yes' === $order->get_meta( '_gb_ep_access_revoked' ) ) {
			return new WP_Error( 'gb_cert_payment', 'An active verified paid enrollment was not found.' );
		}
		if ( absint( $order->get_customer_id() ) !== absint( $user_id ) || absint( $order->get_meta( '_gb_ep_student_user_id' ) ) !== absint( $user_id ) || absint( $order->get_meta( '_gb_ep_course_id' ) ) !== absint( $course_id ) ) {
			return new WP_Error( 'gb_cert_identity', 'The paid order, student, and course do not match.' );
		}
		return $order;
	}

	private function normalize_utc_mysql( $value ) {
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return '';
		}
		try {
			$date = new DateTimeImmutable( $value, new DateTimeZone( 'UTC' ) );
			return $date->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
		} catch ( Exception $error ) {
			return '';
		}
	}

	private function contract_dates( $order, $persist = true ) {
		if ( ! $order || ! is_a( $order, 'WC_Order' ) ) {
			return new WP_Error( 'gb_cert_contract_order', 'The signed enrollment order is unavailable.' );
		}
		$signed = $this->normalize_utc_mysql( $order->get_meta( '_gb_ep_contract_signed_at_utc' ) );
		if ( ! $signed ) {
			return new WP_Error( 'gb_cert_contract_signed', 'The signed enrollment time is unavailable.' );
		}
		try {
			$expected = ( new DateTimeImmutable( $signed, new DateTimeZone( 'UTC' ) ) )->modify( '+1 year' )->format( 'Y-m-d H:i:s' );
		} catch ( Exception $error ) {
			return new WP_Error( 'gb_cert_contract_date', 'The contract expiration date could not be calculated.' );
		}
		$saved = $this->normalize_utc_mysql( $order->get_meta( '_gb_ep_contract_expires_at_utc' ) );
		if ( $saved && ! hash_equals( $expected, $saved ) ) {
			return new WP_Error( 'gb_cert_contract_conflict', 'The frozen contract expiration does not match one year from contract signing.' );
		}
		if ( ! $saved && $persist ) {
			$order->update_meta_data( '_gb_ep_contract_expires_at_utc', $expected );
			$order->add_order_note( 'Gulf Breeze froze the student contract expiration at one calendar year from the signed enrollment time for certificate-access control.' );
			$order->save();
			$saved = $expected;
		}
		return array(
			'signed_utc' => $signed,
			'expires_utc' => $saved ? $saved : $expected,
		);
	}

	private function backfill_contract_dates() {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return;
		}
		global $wpdb;
		$table = $this->issuance_table();
		$rows = $wpdb->get_results( "SELECT id,order_id FROM {$table} WHERE contract_signed_utc IS NULL OR student_download_until_utc IS NULL ORDER BY id ASC", ARRAY_A );
		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$order = wc_get_order( absint( $row['order_id'] ?? 0 ) );
			$dates = $this->contract_dates( $order, true );
			if ( is_wp_error( $dates ) ) {
				continue;
			}
			$wpdb->update(
				$table,
				array(
					'contract_signed_utc' => $dates['signed_utc'],
					'student_download_until_utc' => $dates['expires_utc'],
				),
				array( 'id' => absint( $row['id'] ) ),
				array( '%s', '%s' ),
				array( '%d' )
			);
		}
	}

	private function student_download_access( $row, $actor_user_id ) {
		$actor_user_id = absint( $actor_user_id );
		if ( ! $row || ! $actor_user_id || absint( $row['user_id'] ?? 0 ) !== $actor_user_id ) {
			return new WP_Error( 'owner_mismatch', 'Certificate not found or access denied.' );
		}
		if ( ! empty( $row['voided_utc'] ) ) {
			return new WP_Error( 'certificate_voided', 'This certificate is no longer available.' );
		}
		$expires = $this->normalize_utc_mysql( $row['student_download_until_utc'] ?? '' );
		if ( ! $expires ) {
			return new WP_Error( 'contract_expiration_unavailable', 'Certificate access is unavailable because the contract expiration could not be verified.' );
		}
		if ( time() > strtotime( $expires . ' UTC' ) ) {
			return new WP_Error( 'contract_expired', 'Student certificate access has expired.' );
		}
		$order = function_exists( 'wc_get_order' ) ? wc_get_order( absint( $row['order_id'] ?? 0 ) ) : false;
		if ( ! $order ) {
			return new WP_Error( 'enrollment_record_unavailable', 'Certificate access is unavailable because the enrollment record could not be verified.' );
		}
		if ( absint( $order->get_meta( '_gb_ep_student_user_id' ) ) !== $actor_user_id || absint( $order->get_meta( '_gb_ep_course_id' ) ) !== absint( $row['course_id'] ?? 0 ) ) {
			return new WP_Error( 'enrollment_identity_mismatch', 'Certificate not found or access denied.' );
		}
		if ( 'yes' === $order->get_meta( '_gb_ep_access_revoked' ) || in_array( $order->get_status(), array( 'refunded', 'cancelled', 'failed' ), true ) ) {
			return new WP_Error( 'enrollment_revoked', 'Student certificate access is unavailable because enrollment access was revoked.' );
		}
		return true;
	}

	private function record_download_event( $row, $actor_user_id, $actor_role, $outcome, $reason ) {
		global $wpdb;
		$inserted = $wpdb->insert(
			$this->download_table(),
			array(
				'issuance_id' => absint( $row['id'] ?? 0 ),
				'certificate_type' => sanitize_text_field( $row['certificate_type'] ?? '' ),
				'serial_number' => sanitize_text_field( $row['serial_number'] ?? '' ),
				'subject_user_id' => absint( $row['user_id'] ?? 0 ),
				'actor_user_id' => absint( $actor_user_id ),
				'actor_role' => sanitize_key( $actor_role ),
				'outcome' => sanitize_key( $outcome ),
				'reason' => sanitize_key( $reason ),
				'requested_utc' => current_time( 'mysql', true ),
			),
			array( '%d', '%s', '%s', '%d', '%d', '%s', '%s', '%s', '%s' )
		);
		return false !== $inserted;
	}

	private function eligible_course_key( $course_id ) {
		$key = sanitize_key( get_post_meta( $course_id, '_gb_course_key', true ) );
		return in_array( $key, array( 'adult_en', 'adult_es' ), true ) ? $key : '';
	}

	public function student_reporting_fields( $user ) {
		if ( ! current_user_can( 'manage_options' ) || ! $user || ! isset( $user->ID ) ) { return; }
		?>
		<h2>Gulf Breeze TDLR Reporting Identity</h2>
		<p>Use the student's legal certificate identity. These fields are required when a signed full name has more than two parts; they do not alter the signed enrollment evidence.</p>
		<?php wp_nonce_field( 'gb_cert_student_identity_' . absint( $user->ID ), 'gb_cert_student_identity_nonce' ); ?>
		<table class="form-table"><tbody>
		<tr><th><label for="gb-cert-first">First name</label></th><td><input id="gb-cert-first" class="regular-text" name="gb_cert_tdlr_first_name" value="<?php echo esc_attr( get_user_meta( $user->ID, '_gb_cert_tdlr_first_name', true ) ); ?>"></td></tr>
		<tr><th><label for="gb-cert-middle">Middle initial</label></th><td><input id="gb-cert-middle" name="gb_cert_tdlr_middle_initial" maxlength="1" size="2" value="<?php echo esc_attr( get_user_meta( $user->ID, '_gb_cert_tdlr_middle_initial', true ) ); ?>"></td></tr>
		<tr><th><label for="gb-cert-last">Last name</label></th><td><input id="gb-cert-last" class="regular-text" name="gb_cert_tdlr_last_name" value="<?php echo esc_attr( get_user_meta( $user->ID, '_gb_cert_tdlr_last_name', true ) ); ?>"></td></tr>
		</tbody></table>
		<?php
	}

	public function save_student_reporting_fields( $user_id ) {
		if ( ! current_user_can( 'manage_options' ) || ! current_user_can( 'edit_user', $user_id ) ) { return; }
		$nonce = sanitize_text_field( wp_unslash( $_POST['gb_cert_student_identity_nonce'] ?? '' ) );
		if ( ! wp_verify_nonce( $nonce, 'gb_cert_student_identity_' . absint( $user_id ) ) ) { return; }
		$fields = array(
			'_gb_cert_tdlr_first_name' => sanitize_text_field( wp_unslash( $_POST['gb_cert_tdlr_first_name'] ?? '' ) ),
			'_gb_cert_tdlr_middle_initial' => strtoupper( substr( sanitize_text_field( wp_unslash( $_POST['gb_cert_tdlr_middle_initial'] ?? '' ) ), 0, 1 ) ),
			'_gb_cert_tdlr_last_name' => sanitize_text_field( wp_unslash( $_POST['gb_cert_tdlr_last_name'] ?? '' ) ),
		);
		foreach ( $fields as $key => $value ) {
			if ( false !== strpos( $value, ',' ) ) { continue; }
			if ( '' === $value ) { delete_user_meta( $user_id, $key ); } else { update_user_meta( $user_id, $key, $value ); }
		}
	}

	private function settings() {
		$saved = get_option( 'gb_certificates_settings', array() );
		$saved = is_array( $saved ) ? $saved : array();
		$provider = '';
		if ( class_exists( 'Gulf_Breeze_Configuration' ) && is_callable( array( 'Gulf_Breeze_Configuration', 'get' ) ) ) {
			$provider = Gulf_Breeze_Configuration::get( 'provider_number', '' );
		}
		return wp_parse_args( $saved, array(
			'provider_number' => sanitize_text_field( $provider ),
			'school_name' => 'Gulf Breeze Driving School',
			'instructor_first_name' => '',
			'instructor_last_name' => '',
			'instructor_license_number' => '',
			'chief_official_name' => '',
		) );
	}

	private function reporting_identity( $user, $student ) {
		$settings = $this->settings();
		$first = sanitize_text_field( get_user_meta( $user->ID, '_gb_cert_tdlr_first_name', true ) );
		$last = sanitize_text_field( get_user_meta( $user->ID, '_gb_cert_tdlr_last_name', true ) );
		$middle = strtoupper( substr( sanitize_text_field( get_user_meta( $user->ID, '_gb_cert_tdlr_middle_initial', true ) ), 0, 1 ) );
		$parts = preg_split( '/\s+/', trim( sanitize_text_field( $student['legal_name'] ?? '' ) ) );
		if ( ( ! $first || ! $last ) && 2 === count( $parts ) ) {
			$first = sanitize_text_field( $parts[0] );
			$last = sanitize_text_field( $parts[1] );
		}
		if ( ! $first || ! $last ) {
			return new WP_Error( 'gb_cert_name_review', 'The student legal name requires administrator review in the TDLR Reporting Identity section of the user profile.' );
		}
		$gender_source = strtolower( sanitize_text_field( $student['gender'] ?? '' ) );
		$gender = 'male' === $gender_source ? 'M' : ( 'female' === $gender_source ? 'F' : '' );
		$record = array(
			'student_first_name' => $first,
			'student_last_name' => $last,
			'student_middle_initial' => $middle,
			'student_gender' => $gender,
			'provider_number' => strtoupper( sanitize_text_field( $settings['provider_number'] ) ),
			'instructor_first_name' => sanitize_text_field( $settings['instructor_first_name'] ),
			'instructor_last_name' => sanitize_text_field( $settings['instructor_last_name'] ),
			'instructor_license_number' => sanitize_text_field( $settings['instructor_license_number'] ),
			'school_name' => sanitize_text_field( $settings['school_name'] ),
			'chief_official_name' => sanitize_text_field( $settings['chief_official_name'] ),
		);
		foreach ( $record as $field => $value ) {
			if ( '' === $value && 'student_middle_initial' !== $field ) {
				return new WP_Error( 'gb_cert_reporting_identity', 'Certificate reporting configuration or student identity is incomplete: ' . $field . '.' );
			}
			if ( false !== strpos( $value, ',' ) ) {
				return new WP_Error( 'gb_cert_reporting_comma', 'TDLR reporting fields cannot contain commas: ' . $field . '.' );
			}
		}
		if ( ! preg_match( '/^C[A-Z0-9-]+$/', $record['provider_number'] ) ) {
			return new WP_Error( 'gb_cert_provider', 'The TDLR provider number must begin with C.' );
		}
		return $record;
	}

	public function maybe_issue( $user_id, $course_id ) {
		global $wpdb;
		$user_id = absint( $user_id );
		$course_id = absint( $course_id );
		$key = $this->eligible_course_key( $course_id );
		if ( ! $user_id || ! $course_id || ! $key ) {
			return new WP_Error( 'gb_cert_scope', 'Only mapped Adult English or Spanish courses may issue ADEE test certificates.' );
		}
		$eligibility_key = hash( 'sha256', self::TYPE_ADEE . '|' . $user_id . '|' . $course_id );
		$existing = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . $this->issuance_table() . ' WHERE eligibility_key=%s LIMIT 1', $eligibility_key ), ARRAY_A );
		if ( $existing ) {
			return $existing;
		}
		$final = $this->final_evidence( $user_id, $course_id );
		if ( is_wp_error( $final ) ) {
			return $final;
		}
		$completed_utc = $this->completion_evidence( $user_id, $course_id );
		if ( is_wp_error( $completed_utc ) ) {
			return $completed_utc;
		}
		$order = $this->paid_enrollment_evidence( $user_id, $course_id );
		if ( is_wp_error( $order ) ) {
			return $order;
		}
		$contract_dates = $this->contract_dates( $order, true );
		if ( is_wp_error( $contract_dates ) ) {
			return $contract_dates;
		}
		$user = get_user_by( 'id', $user_id );
		if ( ! $user ) {
			return new WP_Error( 'gb_cert_user', 'Student account not found.' );
		}
		$snapshot = json_decode( (string) $order->get_meta( '_gb_ep_contract_snapshot_json' ), true );
		$student = is_array( $snapshot ) && isset( $snapshot['student'] ) && is_array( $snapshot['student'] ) ? $snapshot['student'] : array();
		$legal_name = sanitize_text_field( $student['legal_name'] ?? $user->display_name );
		$dob = sanitize_text_field( $student['dob'] ?? '' );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $dob ) || ! strtotime( $dob ) ) {
			return new WP_Error( 'gb_cert_dob', 'The signed enrollment record does not contain a valid date of birth.' );
		}
		$reporting = $this->reporting_identity( $user, $student );
		if ( is_wp_error( $reporting ) ) {
			return $reporting;
		}
		$locale = 'adult_es' === $key || 'es-US' === $order->get_meta( '_gb_ep_locale' ) ? 'es-US' : 'en-US';
		$now = current_time( 'mysql', true );
		$report_due = gmdate( 'Y-m-d H:i:s', strtotime( '+' . self::REPORTING_DAYS . ' days', strtotime( $now . ' UTC' ) ) );
		$serials = $this->serial_table();
		$issuances = $this->issuance_table();
		$wpdb->query( 'START TRANSACTION' );
		$serial = $wpdb->get_var( $wpdb->prepare( "SELECT serial_number FROM {$serials} WHERE certificate_type=%s AND status='available' ORDER BY serial_number ASC LIMIT 1 FOR UPDATE", self::TYPE_ADEE ) );
		if ( ! $serial ) {
			$wpdb->query( 'ROLLBACK' );
			return new WP_Error( 'gb_cert_inventory', 'No unused ADEE-1317 test serial numbers remain.' );
		}
		$inserted = $wpdb->insert( $issuances, array(
			'eligibility_key' => $eligibility_key,
			'certificate_type' => self::TYPE_ADEE,
			'serial_number' => $serial,
			'user_id' => $user_id,
			'course_id' => $course_id,
			'order_id' => $order->get_id(),
			'course_key' => $key,
			'locale' => $locale,
			'legal_name' => $legal_name,
			'student_dob' => $dob,
			'student_first_name' => $reporting['student_first_name'],
			'student_last_name' => $reporting['student_last_name'],
			'student_middle_initial' => $reporting['student_middle_initial'],
			'student_gender' => $reporting['student_gender'],
			'provider_number' => $reporting['provider_number'],
			'instructor_first_name' => $reporting['instructor_first_name'],
			'instructor_last_name' => $reporting['instructor_last_name'],
			'instructor_license_number' => $reporting['instructor_license_number'],
			'school_name' => $reporting['school_name'],
			'chief_official_name' => $reporting['chief_official_name'],
			'final_score' => $final['score'],
			'final_passed_utc' => $final['passed_utc'],
			'course_completed_utc' => $completed_utc,
			'issued_utc' => $now,
			'contract_signed_utc' => $contract_dates['signed_utc'],
			'student_download_until_utc' => $contract_dates['expires_utc'],
			'report_due_utc' => $report_due,
			'report_status' => 'pending',
			'email_recipient' => sanitize_email( $user->user_email ),
			'test_mode' => 1,
		), array(
			'%s', '%s', '%s', '%d', '%d', '%d', '%s', '%s', '%s', '%s',
			'%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s',
			'%f', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d',
		) );
		$issuance_id = absint( $wpdb->insert_id );
		$allocated = $inserted ? $wpdb->update( $serials, array(
			'status' => 'issued', 'issuance_id' => $issuance_id, 'issued_to_user' => $user_id, 'course_id' => $course_id, 'issued_utc' => $now,
		), array( 'certificate_type' => self::TYPE_ADEE, 'serial_number' => $serial, 'status' => 'available' ), array( '%s','%d','%d','%d','%s' ), array( '%s','%s','%s' ) ) : false;
		if ( ! $inserted || 1 !== $allocated ) {
			$wpdb->query( 'ROLLBACK' );
			$existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$issuances} WHERE eligibility_key=%s LIMIT 1", $eligibility_key ), ARRAY_A );
			return $existing ? $existing : new WP_Error( 'gb_cert_allocate', 'The certificate serial could not be allocated safely.' );
		}
		$wpdb->query( 'COMMIT' );
		$issuance = $this->issuance( $issuance_id );
		$pdf = $this->build_pdf_bytes( $issuance );
		if ( is_wp_error( $pdf ) ) {
			$wpdb->update( $issuances, array( 'email_status' => 'pdf_failed' ), array( 'id' => $issuance_id ), array( '%s' ), array( '%d' ) );
		} else {
			$template = $this->template_path( $issuance['locale'] );
			$wpdb->update( $issuances, array(
				'pdf_sha256' => hash( 'sha256', $pdf ),
				'template_sha256' => hash_file( 'sha256', $template ),
				'pdf_blob_b64' => base64_encode( $pdf ),
			), array( 'id' => $issuance_id ), array( '%s','%s','%s' ), array( '%d' ) );
			$this->send_certificate_email( $issuance_id );
		}
		return $this->issuance( $issuance_id );
	}

	private function issuance( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT ' . $this->issuance_columns( true ) . ' FROM ' . $this->issuance_table() . ' WHERE id=%d', absint( $id ) ), ARRAY_A );
	}

	public function reconcile_eligible_completions( $limit = 50 ) {
		global $wpdb;
		$issued = 0;
		foreach ( $this->adult_final_maps() as $map ) {
			$course_id = absint( $map['course_id'] );
			$state_key = '_gbcmg_state_' . $this->mapping_id( $map );
			$users = get_users( array( 'fields' => 'ids', 'meta_key' => $state_key, 'number' => min( 100, max( 1, absint( $limit ) ) ) ) );
			foreach ( $users as $user_id ) {
				$eligibility_key = hash( 'sha256', self::TYPE_ADEE . '|' . absint( $user_id ) . '|' . $course_id );
				$was_issued = (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . $this->issuance_table() . ' WHERE eligibility_key=%s LIMIT 1', $eligibility_key ) );
				$result = $this->maybe_issue( $user_id, $course_id );
				if ( ! $was_issued && ! is_wp_error( $result ) ) {
					$issued++;
				}
			}
		}
		return $issued;
	}

	public function import_mock_serials( $quantity = 200 ) {
		global $wpdb;
		$quantity = min( 1000, max( 1, absint( $quantity ) ) );
		$table = $this->serial_table();
		$highest = absint( $wpdb->get_var( $wpdb->prepare( "SELECT MAX(CAST(serial_number AS UNSIGNED)) FROM {$table} WHERE certificate_type=%s AND serial_number LIKE '9%%'", self::TYPE_ADEE ) ) );
		$next = max( 90000001, $highest + 1 );
		$added = 0;
		for ( $i = 0; $i < $quantity && $next <= 99999999; $i++, $next++ ) {
			$ok = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$table} (certificate_type,serial_number,status,created_utc) VALUES (%s,%s,'available',%s)", self::TYPE_ADEE, sprintf( '%08d', $next ), current_time( 'mysql', true ) ) );
			if ( $ok ) { $added++; }
		}
		return $added;
	}

	private function inventory_counts() {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT status, COUNT(*) AS total FROM ' . $this->serial_table() . ' WHERE certificate_type=%s GROUP BY status', self::TYPE_ADEE ), ARRAY_A );
		$out = array( 'available' => 0, 'issued' => 0, 'void' => 0 );
		foreach ( $rows as $row ) { $out[ sanitize_key( $row['status'] ) ] = absint( $row['total'] ); }
		return $out;
	}

	public function inventory_notice() {
		if ( ! current_user_can( 'manage_options' ) || get_option( 'gb_certificates_schema_version' ) !== self::SCHEMA_VERSION ) { return; }
		$count = $this->inventory_counts()['available'];
		if ( $count >= self::LOW_STOCK ) { return; }
		echo '<div class="notice notice-warning"><p><strong>Gulf Breeze test certificate inventory:</strong> ' . esc_html( $count ) . ' unused ADEE-1317 mock serials remain. Testing is blocked at zero; production issuance remains disabled.</p></div>';
	}

	public function admin_menu() {
		add_menu_page( 'Gulf Breeze Certificates', 'GB Certificates', 'manage_options', 'gb-certificates', array( $this, 'admin_page' ), 'dashicons-awards', 58 );
	}

	public function handle_save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Not allowed.' ); }
		check_admin_referer( 'gb_cert_save_settings' );
		$settings = array(
			'provider_number' => strtoupper( sanitize_text_field( wp_unslash( $_POST['provider_number'] ?? '' ) ) ),
			'school_name' => sanitize_text_field( wp_unslash( $_POST['school_name'] ?? '' ) ),
			'instructor_first_name' => sanitize_text_field( wp_unslash( $_POST['instructor_first_name'] ?? '' ) ),
			'instructor_last_name' => sanitize_text_field( wp_unslash( $_POST['instructor_last_name'] ?? '' ) ),
			'instructor_license_number' => sanitize_text_field( wp_unslash( $_POST['instructor_license_number'] ?? '' ) ),
			'chief_official_name' => sanitize_text_field( wp_unslash( $_POST['chief_official_name'] ?? '' ) ),
		);
		foreach ( $settings as $value ) {
			if ( false !== strpos( $value, ',' ) ) {
				wp_die( 'TDLR reporting fields cannot contain commas.' );
			}
		}
		if ( $settings['provider_number'] && ! preg_match( '/^C[A-Z0-9-]+$/', $settings['provider_number'] ) ) {
			wp_die( 'The TDLR provider number must begin with C.' );
		}
		update_option( 'gb_certificates_settings', $settings, false );
		wp_safe_redirect( add_query_arg( 'gb_cert_settings_saved', 1, admin_url( 'admin.php?page=gb-certificates' ) ) );
		exit;
	}

	private function report_row( $row ) {
		$completion_date = gmdate( 'm/d/Y', strtotime( $row['course_completed_utc'] . ' UTC' ) );
		$issue_date = gmdate( 'm/d/Y', strtotime( $row['issued_utc'] . ' UTC' ) );
		return array(
			'ADE', 'ADEE', $row['serial_number'], $row['provider_number'], 'ONLINE ADULT',
			$row['student_last_name'], $row['student_first_name'], $row['student_middle_initial'],
			gmdate( 'm/d/Y', strtotime( $row['student_dob'] . ' UTC' ) ), $row['student_gender'], '6',
			$completion_date, '', '', '', $issue_date, $row['instructor_last_name'],
			$row['instructor_first_name'], $row['instructor_license_number'], '', '',
		);
	}

	private function validate_report_row( $row ) {
		$values = $this->report_row( $row );
		if ( count( self::REPORT_HEADERS ) !== count( $values ) ) {
			return new WP_Error( 'gb_cert_report_shape', 'The report row does not match the official 21-column template.' );
		}
		foreach ( $values as $value ) {
			if ( false !== strpos( (string) $value, ',' ) || preg_match( '/[\r\n]/', (string) $value ) ) {
				return new WP_Error( 'gb_cert_report_value', 'A reporting value contains a comma or line break.' );
			}
		}
		if ( ! preg_match( '/^[1-9][0-9]{5,7}$/', $values[2] ) || ! preg_match( '/^C[A-Z0-9-]+$/', $values[3] ) || ! in_array( $values[9], array( 'M', 'F' ), true ) ) {
			return new WP_Error( 'gb_cert_report_format', 'Certificate number, provider number, or gender is invalid for TDLR reporting.' );
		}
		foreach ( array( 8, 11, 15 ) as $date_index ) {
			if ( ! preg_match( '/^\d{2}\/\d{2}\/\d{4}$/', $values[ $date_index ] ) ) {
				return new WP_Error( 'gb_cert_report_date', 'A TDLR report date is not formatted mm/dd/yyyy.' );
			}
		}
		return $values;
	}

	private function report_filename( $rows ) {
		$provider = preg_replace( '/[^A-Z0-9-]/', '', strtoupper( $rows[0]['provider_number'] ?? 'CUNSET' ) );
		return 'TEST-NOT-FOR-TDLR-' . $provider . gmdate( 'mdY-His' ) . '.csv';
	}

	public function handle_export_report() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Not allowed.' ); }
		check_admin_referer( 'gb_cert_export_report' );
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT " . $this->issuance_columns() . " FROM " . $this->issuance_table() . " WHERE test_mode=1 AND voided_utc IS NULL AND report_status IN ('pending','exported') ORDER BY issued_utc ASC, id ASC", ARRAY_A );
		if ( ! $rows ) { wp_die( 'No pending test certificate records are available.' ); }
		$filename = $this->report_filename( $rows );
		$stream = fopen( 'php://temp', 'w+b' );
		fwrite( $stream, "\xEF\xBB\xBF" );
		fputcsv( $stream, self::REPORT_HEADERS, ',', '"', '' );
		$ids = array();
		foreach ( $rows as $row ) {
			$values = $this->validate_report_row( $row );
			if ( is_wp_error( $values ) ) { fclose( $stream ); wp_die( esc_html( $values->get_error_message() ) ); }
			fputcsv( $stream, $values, ',', '"', '' );
			$ids[] = absint( $row['id'] );
		}
		$now = current_time( 'mysql', true );
		foreach ( $ids as $id ) {
			$wpdb->update( $this->issuance_table(), array( 'report_status' => 'exported', 'report_exported_utc' => $now, 'report_filename' => $filename ), array( 'id' => $id ), array( '%s','%s','%s' ), array( '%d' ) );
		}
		rewind( $stream );
		$csv = stream_get_contents( $stream );
		fclose( $stream );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=UTF-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Content-Length: ' . strlen( $csv ) );
		echo $csv;
		exit;
	}

	public function handle_mark_reported() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Not allowed.' ); }
		$id = absint( $_POST['issuance_id'] ?? 0 );
		check_admin_referer( 'gb_cert_mark_reported_' . $id );
		if ( self::MODE === 'test' ) {
			wp_die( 'Test-mode records cannot be marked as accepted by TDLR.' );
		}
		global $wpdb;
		$wpdb->update( $this->issuance_table(), array( 'report_status' => 'reported', 'reported_utc' => current_time( 'mysql', true ) ), array( 'id' => $id ), array( '%s','%s' ), array( '%d' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=gb-certificates' ) );
		exit;
	}

	public function admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) { return; }
		global $wpdb;
		$counts = $this->inventory_counts();
		$settings = $this->settings();
		$rows = $wpdb->get_results( 'SELECT ' . $this->issuance_columns() . ' FROM ' . $this->issuance_table() . ' ORDER BY id DESC LIMIT 100', ARRAY_A );
		$download_rows = $wpdb->get_results( 'SELECT id,issuance_id,certificate_type,serial_number,subject_user_id,actor_user_id,actor_role,outcome,reason,requested_utc FROM ' . $this->download_table() . ' ORDER BY id DESC LIMIT 200', ARRAY_A );
		?>
		<div class="wrap"><h1>Gulf Breeze Certificates</h1>
		<div class="notice notice-warning inline"><p><strong>TEST MODE — NOT VALID FOR DPS OR TDLR.</strong> Only mock eight-digit serials beginning with 9 may be generated by this revision. Real certificate issuance remains disabled until Gulf Breeze and its electronic template are approved.</p></div>
		<h2>TDLR reporting identity</h2><p>These values are frozen into each issuance. Complete them before reconciling. The provider number defaults from Gulf Breeze Configuration when available.</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="max-width:760px"><?php wp_nonce_field( 'gb_cert_save_settings' ); ?><input type="hidden" name="action" value="gb_cert_save_settings"><table class="form-table"><tbody>
		<tr><th><label for="gb-provider-number">Provider number</label></th><td><input class="regular-text" id="gb-provider-number" name="provider_number" value="<?php echo esc_attr( $settings['provider_number'] ); ?>" placeholder="C1234"><p class="description">Primary TDLR provider license number, including the leading C.</p></td></tr>
		<tr><th><label for="gb-school-name">Approved school name</label></th><td><input class="regular-text" id="gb-school-name" name="school_name" value="<?php echo esc_attr( $settings['school_name'] ); ?>"></td></tr>
		<tr><th><label for="gb-instructor-first">Instructor first name</label></th><td><input class="regular-text" id="gb-instructor-first" name="instructor_first_name" value="<?php echo esc_attr( $settings['instructor_first_name'] ); ?>"></td></tr>
		<tr><th><label for="gb-instructor-last">Instructor last name</label></th><td><input class="regular-text" id="gb-instructor-last" name="instructor_last_name" value="<?php echo esc_attr( $settings['instructor_last_name'] ); ?>"></td></tr>
		<tr><th><label for="gb-instructor-license">Instructor license number</label></th><td><input class="regular-text" id="gb-instructor-license" name="instructor_license_number" value="<?php echo esc_attr( $settings['instructor_license_number'] ); ?>"></td></tr>
		<tr><th><label for="gb-chief-official">Chief school official</label></th><td><input class="regular-text" id="gb-chief-official" name="chief_official_name" value="<?php echo esc_attr( $settings['chief_official_name'] ); ?>"><p class="description">Used as a typed test signature in test mode.</p></td></tr>
		</tbody></table><?php submit_button( 'Save Reporting Identity', 'secondary' ); ?></form>
		<h2>ADEE-1317 test inventory</h2><table class="widefat striped" style="max-width:700px"><tbody>
		<tr><th>Available</th><td><?php echo esc_html( $counts['available'] ); ?></td></tr><tr><th>Issued</th><td><?php echo esc_html( $counts['issued'] ); ?></td></tr><tr><th>Low-stock warning</th><td>Below <?php echo esc_html( self::LOW_STOCK ); ?></td></tr>
		</tbody></table>
		<p><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block;margin-right:10px"><?php wp_nonce_field( 'gb_cert_generate_mock' ); ?><input type="hidden" name="action" value="gb_cert_generate_mock"><input type="hidden" name="quantity" value="200"><?php submit_button( 'Generate 200 Mock Serials', 'secondary', 'submit', false ); ?></form>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block;margin-right:10px"><?php wp_nonce_field( 'gb_cert_reconcile' ); ?><input type="hidden" name="action" value="gb_cert_reconcile"><?php submit_button( 'Reconcile Eligible Completions', 'primary', 'submit', false ); ?></form>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block"><?php wp_nonce_field( 'gb_cert_export_report' ); ?><input type="hidden" name="action" value="gb_cert_export_report"><?php submit_button( 'Download TDLR-Format Test CSV', 'secondary', 'submit', false ); ?></form></p>
		<p><strong>Test export safety:</strong> the CSV uses the official 21 headers and Adult row structure, but its filename begins <code>TEST-NOT-FOR-TDLR</code>. Do not upload it to the licensing portal.</p>
		<h2>Issuance and reporting audit</h2><table class="widefat striped"><thead><tr><th>Issued UTC</th><th>Serial</th><th>Student</th><th>Course</th><th>Score</th><th>Language</th><th>Student access until UTC</th><th>Email</th><th>Report due UTC</th><th>Report state</th><th>PDF</th></tr></thead><tbody>
		<?php if ( ! $rows ) : ?><tr><td colspan="11">No test certificates issued.</td></tr><?php endif; ?>
		<?php foreach ( $rows as $row ) : ?><tr><td><?php echo esc_html( $row['issued_utc'] ); ?></td><td><?php echo esc_html( $row['serial_number'] ); ?></td><td><?php echo esc_html( $row['legal_name'] ); ?> (#<?php echo esc_html( $row['user_id'] ); ?>)</td><td><?php echo esc_html( get_the_title( $row['course_id'] ) ); ?></td><td><?php echo esc_html( $row['final_score'] ); ?>%</td><td><?php echo esc_html( $row['locale'] ); ?></td><td><?php echo esc_html( $row['student_download_until_utc'] ?: 'Unavailable' ); ?></td><td><?php echo esc_html( $row['email_status'] ); ?><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:6px"><?php wp_nonce_field( 'gb_cert_resend_email_' . absint( $row['id'] ) ); ?><input type="hidden" name="action" value="gb_cert_resend_email"><input type="hidden" name="issuance_id" value="<?php echo esc_attr( $row['id'] ); ?>"><?php submit_button( 'Resend', 'small', 'submit', false ); ?></form></td><td><?php echo esc_html( $row['report_due_utc'] ); ?></td><td><?php echo esc_html( $row['report_status'] ); ?></td><td><a href="<?php echo esc_url( $this->download_url( $row['id'] ) ); ?>">Download</a></td></tr><?php endforeach; ?>
		</tbody></table>
		<h2>Certificate download audit</h2><p>Successful and denied certificate requests are append-only application records. Student access expires at the frozen contract deadline; administrator access does not expire.</p>
		<table class="widefat striped"><thead><tr><th>Requested UTC</th><th>Certificate</th><th>Subject student</th><th>Actor</th><th>Outcome</th><th>Reason</th></tr></thead><tbody>
		<?php if ( ! $download_rows ) : ?><tr><td colspan="6">No certificate download requests recorded.</td></tr><?php endif; ?>
		<?php foreach ( $download_rows as $download ) : ?><tr><td><?php echo esc_html( $download['requested_utc'] ); ?></td><td><?php echo esc_html( $download['certificate_type'] . ' ' . $download['serial_number'] ); ?> (#<?php echo esc_html( $download['issuance_id'] ); ?>)</td><td>#<?php echo esc_html( $download['subject_user_id'] ); ?></td><td><?php echo esc_html( $download['actor_role'] ); ?> #<?php echo esc_html( $download['actor_user_id'] ); ?></td><td><?php echo esc_html( $download['outcome'] ); ?></td><td><code><?php echo esc_html( $download['reason'] ); ?></code></td></tr><?php endforeach; ?>
		</tbody></table></div><?php
	}

	public function handle_generate_mock() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Not allowed.' ); }
		check_admin_referer( 'gb_cert_generate_mock' );
		$added = $this->import_mock_serials( absint( $_POST['quantity'] ?? 200 ) );
		wp_safe_redirect( add_query_arg( 'gb_mock_added', $added, admin_url( 'admin.php?page=gb-certificates' ) ) ); exit;
	}

	public function handle_reconcile() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Not allowed.' ); }
		check_admin_referer( 'gb_cert_reconcile' );
		$issued = $this->reconcile_eligible_completions( 100 );
		wp_safe_redirect( add_query_arg( 'gb_cert_reconciled', $issued, admin_url( 'admin.php?page=gb-certificates' ) ) ); exit;
	}

	public function handle_resend_email() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Not allowed.' ); }
		$id = absint( $_POST['issuance_id'] ?? 0 );
		check_admin_referer( 'gb_cert_resend_email_' . $id );
		global $wpdb;
		$wpdb->update( $this->issuance_table(), array( 'email_status' => 'pending', 'email_sent_utc' => null ), array( 'id' => $id ), array( '%s','%s' ), array( '%d' ) );
		$sent = $this->send_certificate_email( $id );
		wp_safe_redirect( add_query_arg( 'gb_cert_email_resent', $sent ? 1 : 0, admin_url( 'admin.php?page=gb-certificates' ) ) );
		exit;
	}

	public function account_menu( $items, $endpoints = array() ) {
		$out = array();
		foreach ( $items as $key => $label ) {
			$out[ $key ] = $label;
			if ( 'my-courses' === $key ) { $out[ self::ACCOUNT_ENDPOINT ] = 'Certificates'; }
		}
		if ( ! isset( $out[ self::ACCOUNT_ENDPOINT ] ) ) { $out[ self::ACCOUNT_ENDPOINT ] = 'Certificates'; }
		return $out;
	}

	public function account_certificates() {
		global $wpdb;
		$user_id = get_current_user_id();
		$rows = $user_id ? $wpdb->get_results( $wpdb->prepare( 'SELECT ' . $this->issuance_columns() . ' FROM ' . $this->issuance_table() . ' WHERE user_id=%d AND voided_utc IS NULL ORDER BY id DESC', $user_id ), ARRAY_A ) : array();
		$is_es = 'es-US' === get_user_meta( $user_id, 'gb_preferred_locale', true );
		echo '<section class="gb-certificates"><h2>' . esc_html( $is_es ? 'Mis certificados' : 'My Certificates' ) . '</h2>';
		if ( ! $rows ) { echo '<p>' . esc_html( $is_es ? 'Todavía no hay un certificado disponible. Se emitirá solamente después de aprobar el examen final y completar todo el curso.' : 'No certificate is available yet. It will be issued only after you pass the final exam and complete the entire course.' ) . '</p></section>'; return; }
		foreach ( $rows as $row ) {
			$label = 'es-US' === $row['locale'] ? 'Descargar certificado de prueba' : 'Download test certificate';
			$row_es = 'es-US' === $row['locale'];
			$expires = $this->normalize_utc_mysql( $row['student_download_until_utc'] ?? '' );
			$deadline = $expires ? wp_date( $row_es ? 'd/m/Y g:i a T' : 'm/d/Y g:i a T', strtotime( $expires . ' UTC' ), wp_timezone() ) : '';
			$access = $this->student_download_access( $row, $user_id );
			echo '<article style="border:1px solid #ccd0d4;border-left:4px solid #0b6780;padding:16px;margin:0 0 16px"><h3>' . esc_html( self::TYPE_ADEE . ' — ' . get_the_title( $row['course_id'] ) ) . '</h3><p><strong>' . esc_html( $row_es ? 'Número de prueba:' : 'Test serial:' ) . '</strong> ' . esc_html( $row['serial_number'] ) . '<br><strong>' . esc_html( $row_es ? 'Emitido:' : 'Issued:' ) . '</strong> ' . esc_html( $row['issued_utc'] ) . ' UTC';
			if ( $deadline ) {
				echo '<br><strong>' . esc_html( $row_es ? 'Descarga disponible hasta:' : 'Download available until:' ) . '</strong> ' . esc_html( $deadline );
			}
			echo '</p>';
			if ( true === $access ) {
				echo '<p><a class="button" href="' . esc_url( $this->download_url( $row['id'] ) ) . '">' . esc_html( $label ) . '</a></p>';
			} else {
				$reason = $access->get_error_code();
				$message = 'contract_expired' === $reason
					? ( $row_es ? 'El período de descarga para estudiantes terminó. Comuníquese con Gulf Breeze si necesita ayuda.' : 'The student download period has ended. Contact Gulf Breeze if you need assistance.' )
					: ( $row_es ? 'La descarga de este certificado no está disponible para esta cuenta.' : 'This certificate download is not available to this account.' );
				echo '<p><strong>' . esc_html( $message ) . '</strong></p>';
			}
			echo '</article>';
		}
		echo '</section>';
	}

	private function download_url( $issuance_id ) {
		return wp_nonce_url( add_query_arg( array( 'action' => 'gb_cert_download', 'issuance_id' => absint( $issuance_id ) ), admin_url( 'admin-post.php' ) ), 'gb_cert_download_' . absint( $issuance_id ) );
	}

	public function handle_download() {
		$id = absint( $_GET['issuance_id'] ?? 0 );
		$row = $this->issuance( $id );
		$actor_user_id = get_current_user_id();
		$is_admin = current_user_can( 'manage_options' );
		$actor_role = $is_admin ? 'administrator' : ( $actor_user_id ? 'student' : 'anonymous' );
		$nonce = sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ?? '' ) );
		if ( ! $id || ! $nonce || ! wp_verify_nonce( $nonce, 'gb_cert_download_' . $id ) ) {
			$this->record_download_event( $row, $actor_user_id, $actor_role, 'denied', 'invalid_nonce' );
			wp_die( 'Certificate not found or access denied.', 'Access denied', array( 'response' => 403 ) );
		}
		if ( ! $row ) {
			$this->record_download_event( array(), $actor_user_id, $actor_role, 'denied', 'certificate_not_found' );
			wp_die( 'Certificate not found or access denied.', 'Access denied', array( 'response' => 403 ) );
		}
		$access = $is_admin ? true : $this->student_download_access( $row, $actor_user_id );
		if ( is_wp_error( $access ) ) {
			$this->record_download_event( $row, $actor_user_id, $actor_role, 'denied', $access->get_error_code() );
			wp_die( esc_html( $access->get_error_message() ), 'Access denied', array( 'response' => 403 ) );
		}
		$pdf = $this->pdf_bytes( $row );
		if ( is_wp_error( $pdf ) ) {
			$this->record_download_event( $row, $actor_user_id, $actor_role, 'denied', 'pdf_integrity_failed' );
			wp_die( esc_html( $pdf->get_error_message() ), 'Certificate unavailable', array( 'response' => 500 ) );
		}
		$success_reason = $is_admin ? 'administrator_permanent_access' : 'student_contract_active';
		if ( ! $this->record_download_event( $row, $actor_user_id, $actor_role, 'success', $success_reason ) ) {
			wp_die( 'The certificate download could not be recorded. No file was released.', 'Certificate unavailable', array( 'response' => 500 ) );
		}
		nocache_headers();
		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: attachment; filename="Gulf-Breeze-' . self::TYPE_ADEE . '-TEST-' . $row['serial_number'] . '.pdf"' );
		header( 'Content-Length: ' . strlen( $pdf ) );
		echo $pdf; exit;
	}

	private function localized_copy( $locale ) {
		if ( 'es-US' === $locale ) {
			return array(
			'title' => 'CERTIFICADO DE PRUEBA ADEE-1317',
			'notice' => 'MODO DE PRUEBA — NO ES VÁLIDO PARA DPS NI TDLR',
			'certifies' => 'Gulf Breeze Driving School certifica que',
			'completed' => 'completó el Curso de Educación Vial para Adultos de Seis Horas.',
			'serial' => 'Número de serie de prueba', 'date' => 'Fecha de finalización', 'score' => 'Calificación del examen final',
			'next' => 'Qué hacer después',
			'instructions' => array(
				'Guarde este certificado y lleve una copia impresa cuando se la soliciten.',
				'Después del curso, complete Impact Texas Adult Drivers (ITAD) antes del examen práctico.',
				'El certificado de ITAD debe estar fechado dentro de los 90 días anteriores al examen práctico.',
				'Para el examen práctico, lleve impresos este certificado y el certificado de ITAD, además de los documentos exigidos por DPS.',
				'Use la lista oficial de documentos de Texas DPS y programe la cita correspondiente.',
			),
			'email_subject' => 'Su certificado de prueba ADEE-1317 de Gulf Breeze',
			'email_intro' => 'Su certificado de prueba está adjunto. También puede descargarlo desde Mis certificados.',
			'test_reminder' => 'Este documento utiliza un número simulado de ocho dígitos para pruebas internas y no puede presentarse ante DPS o TDLR.',
			);
		}
		return array(
			'title' => 'ADEE-1317 TEST CERTIFICATE',
			'notice' => 'TEST MODE — NOT VALID FOR DPS OR TDLR',
			'certifies' => 'Gulf Breeze Driving School certifies that',
			'completed' => 'completed the Adult Six-Hour Driver Education Course.',
			'serial' => 'Mock serial number', 'date' => 'Completion date', 'score' => 'Final exam score',
			'next' => 'What to do next',
			'instructions' => array(
				'Keep this certificate and bring a printed copy whenever it is required.',
				'After the course, complete Impact Texas Adult Drivers (ITAD) before your driving skills test.',
				'Your ITAD certificate must be dated within 90 days before the driving skills test.',
				'For the driving test, bring printed copies of this certificate and your ITAD certificate, plus all documents required by DPS.',
				'Use the official Texas DPS document checklist and schedule the appropriate appointment.',
			),
			'email_subject' => 'Your Gulf Breeze ADEE-1317 test certificate',
			'email_intro' => 'Your test certificate is attached. You can also download it from My Certificates.',
			'test_reminder' => 'This document uses a simulated eight-digit number for internal testing and cannot be presented to DPS or TDLR.',
		);
	}

	public function send_certificate_email( $issuance_id ) {
		global $wpdb;
		$row = $this->issuance( $issuance_id );
		if ( ! $row || 'sent' === $row['email_status'] || ! is_email( $row['email_recipient'] ) ) { return false; }
		$copy = $this->localized_copy( $row['locale'] );
		$pdf = $this->pdf_bytes( $row );
		if ( is_wp_error( $pdf ) ) { return false; }
		$tmp = trailingslashit( get_temp_dir() ) . wp_unique_filename( get_temp_dir(), 'Gulf-Breeze-ADEE-TEST-' . $row['serial_number'] . '.pdf' );
		if ( ! $tmp || false === file_put_contents( $tmp, $pdf ) ) { return false; }
		$html = '<p>' . esc_html( $copy['email_intro'] ) . '</p><p><strong>' . esc_html( $copy['notice'] ) . '</strong></p><h3>' . esc_html( $copy['next'] ) . '</h3><ol>';
		foreach ( $copy['instructions'] as $instruction ) { $html .= '<li>' . esc_html( $instruction ) . '</li>'; }
		$html .= '</ol><p>' . esc_html( $copy['test_reminder'] ) . '</p>';
		$sent = wp_mail( $row['email_recipient'], $copy['email_subject'], $html, array( 'Content-Type: text/html; charset=UTF-8' ), array( $tmp ) );
		@unlink( $tmp );
		$wpdb->update( $this->issuance_table(), array( 'email_status' => $sent ? 'sent' : 'failed', 'email_sent_utc' => $sent ? current_time( 'mysql', true ) : null ), array( 'id' => $issuance_id ), array( '%s','%s' ), array( '%d' ) );
		return (bool) $sent;
	}

	private function template_path( $locale ) {
		$file = 'es-US' === $locale ? 'adee-1317-test-es.pdf' : 'adee-1317-test-en.pdf';
		return plugin_dir_path( __FILE__ ) . 'assets/' . $file;
	}

	private function template_tokens() {
		return array(
			'control' => 'GBCTRL00000000000000',
			'last' => 'GBLAST00000000000000000000000000',
			'first' => 'GBFIRST00000000000000000000000',
			'middle' => 'GBMID000',
			'month' => 'GBMON000',
			'day' => 'GBDAY000',
			'year' => 'GBYEAR00',
			'birth_month' => 'GBBMON00',
			'birth_day' => 'GBBDAY00',
			'birth_year' => 'GBBYEAR0',
			'male' => 'GENDERMA',
			'female' => 'GENDERFE',
			'instructor' => 'GBINSTRUCTOR000000000000000000000000000000',
			'instructor_license' => 'GBILICENSE000000',
			'school' => 'GBSCHOOL000000000000000000000000',
			'official' => 'GBOFFICIAL00000000000000000000000000000000',
			'school_number' => 'GBSNUMBER0000000',
			'issued' => 'GBDATE0000',
		);
	}

	private function fixed_pdf_value( $value, $length ) {
		$value = wp_strip_all_tags( (string) $value );
		$value = str_replace( array( "\r", "\n", "\t" ), ' ', $value );
		if ( function_exists( 'iconv' ) ) {
			$converted = iconv( 'UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $value );
			if ( false !== $converted ) { $value = $converted; }
		}
		$out = '';
		for ( $i = 0; $i < strlen( $value ); $i++ ) {
			$char = $value[ $i ];
			$piece = in_array( $char, array( '\\', '(', ')' ), true ) ? '\\' . $char : $char;
			if ( strlen( $out ) + strlen( $piece ) > $length ) { break; }
			$out .= $piece;
		}
		return str_pad( $out, $length, ' ' );
	}

	private function build_pdf_bytes( $row ) {
		$path = $this->template_path( $row['locale'] ?? 'en-US' );
		if ( ! is_readable( $path ) ) { return new WP_Error( 'gb_cert_template', 'The ADEE-1317 test template is unavailable.' ); }
		$pdf = file_get_contents( $path );
		if ( false === $pdf ) { return new WP_Error( 'gb_cert_template_read', 'The ADEE-1317 test template could not be read.' ); }
		$completed = strtotime( (string) ( $row['course_completed_utc'] ?? '' ) . ' UTC' );
		$issued = strtotime( (string) ( $row['issued_utc'] ?? '' ) . ' UTC' );
		$dob = strtotime( (string) ( $row['student_dob'] ?? '' ) . ' UTC' );
		if ( ! $completed || ! $issued || ! $dob ) { return new WP_Error( 'gb_cert_pdf_dates', 'Certificate dates are invalid.' ); }
		$tokens = $this->template_tokens();
		$values = array(
			'control' => 'ADEE' . ( $row['serial_number'] ?? '' ),
			'last' => $row['student_last_name'] ?? '',
			'first' => $row['student_first_name'] ?? '',
			'middle' => $row['student_middle_initial'] ?? '',
			'month' => gmdate( 'm', $completed ), 'day' => gmdate( 'd', $completed ), 'year' => gmdate( 'Y', $completed ),
			'birth_month' => gmdate( 'm', $dob ), 'birth_day' => gmdate( 'd', $dob ), 'birth_year' => gmdate( 'Y', $dob ),
			'male' => 'M' === ( $row['student_gender'] ?? '' ) ? 'X' : '',
			'female' => 'F' === ( $row['student_gender'] ?? '' ) ? 'X' : '',
			'instructor' => 'TEST SIGNATURE - ' . trim( ( $row['instructor_first_name'] ?? '' ) . ' ' . ( $row['instructor_last_name'] ?? '' ) ),
			'instructor_license' => $row['instructor_license_number'] ?? '',
			'school' => $row['school_name'] ?? 'Gulf Breeze Driving School',
			'official' => 'TEST SIGNATURE - ' . ( $row['chief_official_name'] ?? '' ),
			'school_number' => $row['provider_number'] ?? '',
			'issued' => gmdate( 'm/d/Y', $issued ),
		);
		foreach ( $tokens as $key => $token ) {
			$count = 0;
			$pdf = str_replace( $token, $this->fixed_pdf_value( $values[ $key ] ?? '', strlen( $token ) ), $pdf, $count );
			if ( 2 !== $count ) { return new WP_Error( 'gb_cert_pdf_token', 'The ADEE-1317 template token check failed: ' . $key . '.' ); }
		}
		return $pdf;
	}

	public function pdf_bytes( $row ) {
		if ( ! empty( $row['pdf_blob_b64'] ) ) {
			$pdf = base64_decode( $row['pdf_blob_b64'], true );
			if ( false !== $pdf && ( empty( $row['pdf_sha256'] ) || hash_equals( $row['pdf_sha256'], hash( 'sha256', $pdf ) ) ) ) { return $pdf; }
			return new WP_Error( 'gb_cert_pdf_integrity', 'The preserved certificate copy failed its integrity check.' );
		}
		$pdf = $this->build_pdf_bytes( $row );
		if ( is_wp_error( $pdf ) ) { return $pdf; }
		if ( ! empty( $row['id'] ) ) {
			global $wpdb;
			$path = $this->template_path( $row['locale'] ?? 'en-US' );
			$wpdb->update( $this->issuance_table(), array(
				'pdf_sha256' => hash( 'sha256', $pdf ),
				'template_sha256' => hash_file( 'sha256', $path ),
				'pdf_blob_b64' => base64_encode( $pdf ),
			), array( 'id' => absint( $row['id'] ) ), array( '%s','%s','%s' ), array( '%d' ) );
		}
		return $pdf;
	}
}

register_activation_hook( __FILE__, array( 'Gulf_Breeze_Certificates', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Gulf_Breeze_Certificates', 'deactivate' ) );
Gulf_Breeze_Certificates::instance();
