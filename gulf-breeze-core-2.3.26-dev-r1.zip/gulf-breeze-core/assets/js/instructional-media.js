( function () {
	'use strict';

	function activateStep( lab, targetId ) {
		var buttons = lab.querySelectorAll( '.gb-road-lab__button' );
		var panels = lab.querySelectorAll( '.gb-road-lab__panel' );

		buttons.forEach( function ( button ) {
			button.setAttribute( 'aria-pressed', button.getAttribute( 'aria-controls' ) === targetId ? 'true' : 'false' );
		} );

		panels.forEach( function ( panel ) {
			panel.hidden = panel.id !== targetId;
		} );
	}

	document.addEventListener( 'click', function ( event ) {
		var button = event.target.closest( '.gb-road-lab__button' );
		var lab;
		if ( ! button ) {
			return;
		}
		lab = button.closest( '.gb-road-lab' );
		if ( ! lab ) {
			return;
		}
		activateStep( lab, button.getAttribute( 'aria-controls' ) );
	} );
}() );
