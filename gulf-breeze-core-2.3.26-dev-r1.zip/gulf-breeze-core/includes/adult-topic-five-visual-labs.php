<?php
/**
 * Adult English Topic 4.1.5 interactive visual labs.
 * Gulf Breeze Driving School / Rodney Crawford.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class GB_Adult_Topic_Five_Visual_Labs {
	public static function render( $key ) {
		$labs = self::labs();
		if ( empty( $labs[ $key ] ) ) {
			return '';
		}

		$lab  = $labs[ $key ];
		$uid  = 'gb-road-skills-' . sanitize_html_class( $key );
		$html = '<section class="gb-road-lab" aria-labelledby="' . esc_attr( $uid ) . '-heading">';
		$html .= '<h2 class="gb-road-lab__heading" id="' . esc_attr( $uid ) . '-heading">' . esc_html( $lab['title'] ) . '</h2>';
		$html .= '<p class="gb-road-lab__intro">' . esc_html( $lab['intro'] ) . '</p>';
		$html .= '<div class="gb-road-lab__controls" role="group" aria-label="Choose a visual step">';
		foreach ( $lab['steps'] as $index => $step ) {
			$panel_id = $uid . '-panel-' . ( $index + 1 );
			$html .= '<button type="button" class="gb-road-lab__button" aria-controls="' . esc_attr( $panel_id ) . '" aria-pressed="' . ( 0 === $index ? 'true' : 'false' ) . '">' . esc_html( ( $index + 1 ) . '. ' . $step['label'] ) . '</button>';
		}
		$html .= '</div><div class="gb-road-lab__stage">';
		foreach ( $lab['steps'] as $index => $step ) {
			$panel_id = $uid . '-panel-' . ( $index + 1 );
			$html .= '<div class="gb-road-lab__panel" id="' . esc_attr( $panel_id ) . '"' . ( 0 === $index ? '' : ' hidden' ) . '>';
			$html .= '<figure class="gb-road-lab__figure">' . self::scene( $step['scene'] );
			$html .= '<figcaption class="gb-road-lab__caption"><strong>' . esc_html( $step['lead'] ) . '</strong> ' . esc_html( $step['caption'] ) . '</figcaption></figure></div>';
		}
		return $html . '</div></section>';
	}

	private static function labs() {
		return array(
			'adult_en_022' => array(
				'title' => 'Space Is Time to See, Decide, and Stop',
				'intro' => 'Use a roadside reference to check your following interval, understand every part of a stop, and add space whenever grip or visibility decreases.',
				'steps' => array(
					array( 'label' => 'Measure the interval', 'scene' => 'space_interval', 'lead' => 'Landmark check:', 'caption' => 'Begin counting when the vehicle ahead passes a fixed object. Your vehicle should reach it only after the handbook-recommended interval has passed.' ),
					array( 'label' => 'Build the stop', 'scene' => 'space_stopping', 'lead' => 'Total stopping distance:', 'caption' => 'Perception distance, reaction distance, and braking distance all consume roadway before the vehicle stops. Diagram is conceptual, not to scale.' ),
					array( 'label' => 'Add space for rain', 'scene' => 'space_rain', 'lead' => 'Low grip means more room:', 'caption' => 'Rain reduces visibility and traction. Increase the following interval, reduce speed smoothly, and begin decisions earlier.' ),
				),
			),
			'adult_en_023' => array(
				'title' => 'See the Space Mirrors Cannot Show',
				'intro' => 'Mirrors organize the search, but a quick shoulder check and a complete lane-change sequence protect the areas they cannot reveal.',
				'steps' => array(
					array( 'label' => 'Find blind zones', 'scene' => 'lane_blind_zones', 'lead' => 'Mirrors are not the whole search:', 'caption' => 'The shaded wedges are conceptual blind zones. Adjust mirrors, scan them, and make a quick shoulder check before moving.' ),
					array( 'label' => 'Sequence the change', 'scene' => 'lane_sequence', 'lead' => 'One complete process:', 'caption' => 'Search ahead, check mirrors, signal, check the blind spot, confirm a safe gap, move smoothly one lane, and cancel the signal.' ),
					array( 'label' => 'Respect truck no-zones', 'scene' => 'lane_truck_zones', 'lead' => 'Do not linger:', 'caption' => 'A large vehicle has broad areas beside and behind it that the driver may not see. Stay back, pass efficiently when lawful, and leave extra room.' ),
				),
			),
			'adult_en_024' => array(
				'title' => 'Communicate Early, Then Turn into the Lawful Lane',
				'intro' => 'A signal announces intention; it never creates the right-of-way. Select the correct lane, protect people, and finish in the lawful lane.',
				'steps' => array(
					array( 'label' => 'Choose the turn path', 'scene' => 'turn_paths', 'lead' => 'Hold the lawful path:', 'caption' => 'Approach in the proper lane, search the intersection, yield as required, and enter the lawful receiving lane without drifting across lanes.' ),
					array( 'label' => 'Signal continuously', 'scene' => 'turn_signal', 'lead' => 'Give useful notice:', 'caption' => 'In Texas, signal continuously for at least the last 100 feet before the turn. Do not wait until steering begins.' ),
					array( 'label' => 'Use communication correctly', 'scene' => 'turn_communication', 'lead' => 'Messages are not permission:', 'caption' => 'Signals show intention; the horn warns of immediate danger. A wave, eye contact, or headlight flash never replaces a lawful safety check.' ),
				),
			),
			'adult_en_025' => array(
				'title' => 'A Safe Pass Must Be Safe from Start to Finish',
				'intro' => 'Passing depends on law, markings, sight distance, speed, traffic, and enough space to return without forcing another road user to react.',
				'steps' => array(
					array( 'label' => 'Plan the whole pass', 'scene' => 'pass_sequence', 'lead' => 'See the complete maneuver:', 'caption' => 'Check markings and traffic, signal, verify the blind spot, pass with a safe speed difference, and return only with adequate clearance.' ),
					array( 'label' => 'Recognize hidden conflict', 'scene' => 'pass_sightline', 'lead' => 'No view means no pass:', 'caption' => 'A hillcrest or curve can hide oncoming traffic. Never begin when the distance needed to complete the maneuver is not clearly visible.' ),
					array( 'label' => 'Help a vehicle pass', 'scene' => 'pass_cooperate', 'lead' => 'Be predictable:', 'caption' => 'Hold a steady course, do not accelerate, preserve space ahead, and let the passing driver return safely.' ),
				),
			),
			'adult_en_026' => array(
				'title' => 'Complex Maneuvers Need a Complete Plan',
				'intro' => 'Backing, hill parking, freeway entry, breakdowns, and work zones become manageable when the driver searches early and protects an escape path.',
				'steps' => array(
					array( 'label' => 'Back with a full search', 'scene' => 'complex_backing', 'lead' => 'Cameras have limits:', 'caption' => 'Walk around first, look through the rear window and mirrors, back slowly, and stop if any part of the path becomes uncertain.' ),
					array( 'label' => 'Secure a hill park', 'scene' => 'complex_hill', 'lead' => 'Turn the wheels before leaving:', 'caption' => 'Downhill with a curb: toward the curb. Uphill with a curb: away from the curb. Without a curb: toward the roadway edge. Set the parking brake.' ),
					array( 'label' => 'Merge as one process', 'scene' => 'complex_merge', 'lead' => 'Use the full ramp:', 'caption' => 'Search early, match traffic speed when conditions allow, identify a gap, yield to freeway traffic, and merge smoothly without stopping unnecessarily.' ),
					array( 'label' => 'Protect the breakdown scene', 'scene' => 'complex_emergency', 'lead' => 'Move danger away from traffic:', 'caption' => 'If possible, move fully out of the travel lane, use hazard signals, seek help, and keep people away from moving traffic and work activity.' ),
				),
			),
		);
	}

	private static function scene( $scene ) {
		switch ( $scene ) {
			case 'space_interval': return self::scene_space_interval();
			case 'space_stopping': return self::scene_space_stopping();
			case 'space_rain': return self::scene_space_rain();
			case 'lane_blind_zones': return self::scene_lane_blind_zones();
			case 'lane_sequence': return self::scene_lane_sequence();
			case 'lane_truck_zones': return self::scene_lane_truck_zones();
			case 'turn_paths': return self::scene_turn_paths();
			case 'turn_signal': return self::scene_turn_signal();
			case 'turn_communication': return self::scene_turn_communication();
			case 'pass_sequence': return self::scene_pass_sequence();
			case 'pass_sightline': return self::scene_pass_sightline();
			case 'pass_cooperate': return self::scene_pass_cooperate();
			case 'complex_backing': return self::scene_complex_backing();
			case 'complex_hill': return self::scene_complex_hill();
			case 'complex_merge': return self::scene_complex_merge();
			case 'complex_emergency': return self::scene_complex_emergency();
			default: return '';
		}
	}

	private static function svg( $label, $content ) {
		return '<svg class="gb-road-svg" viewBox="0 0 720 520" role="img" aria-label="' . esc_attr( $label ) . '"><rect class="gb-ground" width="720" height="520"/>' . $content . '</svg>';
	}

	private static function car( $x, $y, $rotation, $label = 'A', $color = '#2d78c4' ) {
		return '<g transform="translate(' . (int) $x . ' ' . (int) $y . ') rotate(' . (int) $rotation . ')"><rect x="-34" y="-55" width="68" height="110" rx="20" fill="' . esc_attr( $color ) . '" stroke="#172b3a" stroke-width="3"/><rect x="-24" y="-38" width="48" height="40" rx="9" fill="#eaf3f8"/><circle cy="14" r="20" fill="#123b5d"/><text class="gb-label" x="0" y="15">' . esc_html( $label ) . '</text></g>';
	}

	private static function road_horizontal( $lanes = 2 ) {
		$c = '<rect class="gb-road" y="105" width="720" height="310"/>';
		if ( 2 === $lanes ) {
			$c .= '<line class="gb-center" x1="0" y1="260" x2="720" y2="260"/>';
		} else {
			$c .= '<line class="gb-lane" x1="0" y1="208" x2="720" y2="208"/><line class="gb-lane" x1="0" y1="312" x2="720" y2="312"/>';
		}
		return $c;
	}

	private static function note( $x, $y, $text ) {
		return '<text class="gb-note" x="' . (int) $x . '" y="' . (int) $y . '">' . esc_html( $text ) . '</text>';
	}

	private static function scene_space_interval() {
		$c = self::road_horizontal( 3 ) . '<rect x="500" y="48" width="24" height="90" fill="#7a4f2a"/><circle cx="512" cy="42" r="38" fill="#2c7a4b"/>' . self::car( 500, 260, 90, '1', '#d96b34' ) . self::car( 180, 260, 90, 'A' );
		$c .= '<path class="gb-path-a" d="M225 340 H475"/><circle cx="500" cy="340" r="12" class="gb-safe"/>' . self::note( 355, 380, 'LANDMARK → COUNT → REACH' );
		return self::svg( 'Two vehicles pass a fixed roadside tree; the following driver uses it to measure a safe time interval.', $c );
	}

	private static function scene_space_stopping() {
		$c = self::road_horizontal( 3 ) . self::car( 90, 260, 90 ) . '<rect x="130" y="170" width="150" height="180" rx="12" fill="#f2b134" opacity=".8"/><rect x="280" y="170" width="145" height="180" rx="12" fill="#5ba6d6" opacity=".85"/><rect x="425" y="170" width="230" height="180" rx="12" fill="#d96b34" opacity=".85"/>';
		$c .= self::note( 205, 225, 'PERCEIVE' ) . self::note( 352, 225, 'REACT' ) . self::note( 540, 225, 'BRAKE' ) . self::note( 360, 455, 'CONCEPTUAL — NOT TO SCALE' );
		return self::svg( 'A conceptual roadway stack shows perception, reaction, and braking as three parts of total stopping distance.', $c );
	}

	private static function scene_space_rain() {
		$c = '<rect class="gb-road" y="70" width="720" height="165"/><rect class="gb-road" y="285" width="720" height="165"/>' . self::car( 135, 150, 90, 'A' ) . self::car( 390, 150, 90, '1', '#d96b34' ) . self::car( 135, 365, 90, 'A' ) . self::car( 560, 365, 90, '1', '#d96b34' );
		$c .= self::note( 600, 135, 'DRY' ) . self::note( 600, 180, 'BASE SPACE' ) . self::note( 350, 322, 'RAIN' ) . self::note( 350, 410, 'MORE SPACE + LOWER SPEED' );
		for ( $x = 30; $x < 700; $x += 55 ) { $c .= '<line x1="' . $x . '" y1="255" x2="' . ( $x - 12 ) . '" y2="275" stroke="#1769aa" stroke-width="4"/>'; }
		return self::svg( 'Dry and rainy roadway rows compare a base following gap with a visibly larger wet-road gap.', $c );
	}

	private static function scene_lane_blind_zones() {
		$c = self::road_horizontal( 3 ) . self::car( 360, 260, 90 ) . '<path d="M325 220 L75 120 L75 220 Z" fill="#5ba6d6" opacity=".35"/><path d="M325 300 L75 400 L75 300 Z" fill="#5ba6d6" opacity=".35"/><path d="M395 205 L615 105 L615 195 Z" fill="#b42318" opacity=".32"/><path d="M395 315 L615 415 L615 325 Z" fill="#b42318" opacity=".32"/>';
		$c .= self::note( 165, 88, 'MIRROR FIELDS' ) . self::note( 600, 78, 'BLIND ZONES' ) . self::note( 570, 475, 'QUICK SHOULDER CHECK' );
		return self::svg( 'Overhead car view shows mirror fields behind the vehicle and conceptual blind zones beside it.', $c );
	}

	private static function scene_lane_sequence() {
		$c = self::road_horizontal( 3 ) . self::car( 100, 312, 90 ) . '<path class="gb-path-a" d="M145 312 C260 312 285 205 405 205 H630"/><polygon class="gb-safe" points="665,205 620,182 620,228"/>';
		$labels = array( 'SEARCH', 'MIRRORS', 'SIGNAL', 'BLIND SPOT', 'GAP', 'MOVE', 'CANCEL' );
		foreach ( $labels as $i => $label ) { $x = 55 + ( $i * 102 ); $c .= '<circle cx="' . $x . '" cy="465" r="27" fill="#123b5d"/><text class="gb-label" x="' . $x . '" y="465">' . ( $i + 1 ) . '</text>' . self::note( $x, 505, $label ); }
		return self::svg( 'A numbered sequence accompanies a smooth one-lane movement from search through signal cancellation.', $c );
	}

	private static function scene_lane_truck_zones() {
		$c = self::road_horizontal( 3 ) . '<g transform="translate(360 260) rotate(90)"><rect x="-55" y="-110" width="110" height="220" rx="14" fill="#657681" stroke="#172b3a" stroke-width="4"/><rect x="-48" y="-100" width="96" height="58" fill="#eaf3f8"/><text class="gb-large-label" x="0" y="35">TRUCK</text></g>';
		$c .= '<ellipse cx="190" cy="260" rx="95" ry="120" fill="#b42318" opacity=".28"/><ellipse cx="540" cy="260" rx="115" ry="150" fill="#b42318" opacity=".28"/>' . self::note( 160, 85, 'DO NOT LINGER' ) . self::note( 560, 465, 'LEAVE EXTRA ROOM' );
		return self::svg( 'A large truck is surrounded by broad conceptual no-zone areas beside and behind it.', $c );
	}

	private static function scene_turn_paths() {
		$c = '<rect class="gb-road" x="250" width="220" height="520"/><rect class="gb-road" y="150" width="720" height="220"/><line class="gb-lane" x1="360" y1="0" x2="360" y2="130"/><line class="gb-lane" x1="360" y1="390" x2="360" y2="520"/>' . self::car( 310, 455, 0, 'A' );
		$c .= '<path class="gb-path-a" d="M310 405 C310 265 250 205 105 205"/><polygon class="gb-safe" points="70,205 115,182 115,228"/><path class="gb-path-b" d="M410 405 C410 325 480 315 615 315"/><polygon points="650,315 605,292 605,338" fill="#d96b34"/>' . self::note( 180, 110, 'LEFT PATH' ) . self::note( 560, 430, 'RIGHT PATH' );
		return self::svg( 'Overhead intersection shows left and right turns remaining within lawful receiving lanes.', $c );
	}

	private static function scene_turn_signal() {
		$c = self::road_horizontal( 3 ) . self::car( 105, 260, 90, 'A' ) . '<path class="gb-path-a" d="M145 260 H600"/><polygon class="gb-safe" points="635,260 590,237 590,283"/><line x1="205" y1="125" x2="560" y2="125" stroke="#f2b134" stroke-width="14"/><line x1="205" y1="105" x2="205" y2="145" stroke="#172b3a" stroke-width="5"/><line x1="560" y1="105" x2="560" y2="145" stroke="#172b3a" stroke-width="5"/>';
		$c .= self::note( 382, 92, 'SIGNAL CONTINUOUSLY: AT LEAST 100 FEET' ) . self::note( 620, 410, 'TURN' );
		return self::svg( 'A labeled road segment shows a turn signal used continuously for at least 100 feet before a turn.', $c );
	}

	private static function scene_turn_communication() {
		$c = '<g transform="translate(120 225)"><circle r="78" fill="#2d78c4"/><text class="gb-large-label" y="-12">SIGNAL</text><text class="gb-label" y="28">INTENTION</text></g><g transform="translate(360 225)"><circle r="78" fill="#d96b34"/><text class="gb-large-label" y="-12">HORN</text><text class="gb-label" y="28">DANGER</text></g><g transform="translate(600 225)"><circle r="78" fill="#b42318"/><text class="gb-large-label" y="-12">WAVE</text><text class="gb-label" y="28">NOT PERMISSION</text></g>';
		$c .= self::note( 360, 410, 'VERIFY LAW, RIGHT-OF-WAY, PEOPLE, TRAFFIC, AND SPACE' );
		return self::svg( 'Three labeled communication circles distinguish intention, danger warning, and gestures that do not grant permission.', $c );
	}

	private static function scene_pass_sequence() {
		$c = self::road_horizontal( 2 ) . self::car( 145, 335, 90, 'A' ) . self::car( 325, 335, 90, '1', '#d96b34' ) . '<path class="gb-path-a" d="M175 335 C235 335 245 185 350 185 H510 C575 185 585 335 660 335"/><polygon class="gb-safe" points="690,335 645,312 645,358"/>';
		$c .= self::note( 125, 470, 'CHECK' ) . self::note( 285, 88, 'PASS' ) . self::note( 575, 470, 'RETURN WITH CLEARANCE' );
		return self::svg( 'A blue path shows the complete check, pass, and return sequence around a slower vehicle on a two-lane road.', $c );
	}

	private static function scene_pass_sightline() {
		$c = '<path d="M0 390 Q360 70 720 390" stroke="#3f4b54" stroke-width="165" fill="none"/><path d="M0 390 Q360 70 720 390" stroke="#f2b134" stroke-width="5" fill="none"/><path d="M165 330 L360 165" stroke="#b42318" stroke-width="8" stroke-dasharray="15 12"/><path d="M555 330 L360 165" stroke="#b42318" stroke-width="8" stroke-dasharray="15 12"/>' . self::car( 140, 352, 58, 'A' ) . self::car( 585, 352, -58, 'B', '#d96b34' );
		$c .= '<circle cx="360" cy="165" r="58" fill="#b42318" opacity=".28"/>' . self::note( 360, 75, 'HIDDEN CONFLICT' ) . self::note( 360, 485, 'NO CLEAR VIEW → NO PASS' );
		return self::svg( 'Two vehicles are hidden from one another by a hillcrest, showing why a pass cannot begin without a clear view.', $c );
	}

	private static function scene_pass_cooperate() {
		$c = self::road_horizontal( 3 ) . self::car( 320, 312, 90, '1', '#d96b34' ) . self::car( 440, 205, 90, 'A' ) . '<path class="gb-path-a" d="M475 205 H650"/><polygon class="gb-safe" points="680,205 635,182 635,228"/>';
		$c .= self::note( 125, 125, 'HOLD COURSE' ) . self::note( 125, 170, 'DO NOT ACCELERATE' ) . self::note( 140, 390, 'PRESERVE SPACE AHEAD' );
		return self::svg( 'One vehicle passes while the vehicle being passed holds a steady course and preserves space ahead.', $c );
	}

	private static function scene_complex_backing() {
		$c = '<rect class="gb-road" x="150" y="65" width="420" height="390"/>' . self::car( 360, 280, 0, 'A' ) . '<path d="M326 330 L235 450 H485 L394 330 Z" fill="#5ba6d6" opacity=".35"/><path d="M326 330 L290 405 H430 L394 330 Z" fill="#18794e" opacity=".45"/><circle cx="220" cy="390" r="30" fill="#b42318" opacity=".65"/>';
		$c .= self::note( 120, 45, 'WALK AROUND' ) . self::note( 600, 215, 'LOOK BACK' ) . self::note( 600, 260, '+ MIRRORS' ) . self::note( 360, 500, 'CAMERA VIEW DOES NOT SHOW EVERYTHING' );
		return self::svg( 'Backing view shows a camera field nested within a wider search area and an obstacle outside the camera view.', $c );
	}

	private static function scene_complex_hill() {
		$c = '<path d="M0 410 L720 110" stroke="#3f4b54" stroke-width="180"/><path d="M0 315 L720 15" stroke="#e8e0ce" stroke-width="18"/><path d="M0 505 L720 205" stroke="#e8e0ce" stroke-width="18"/>' . self::car( 190, 335, 68, 'D' ) . self::car( 525, 190, 68, 'U', '#d96b34' );
		$c .= '<path class="gb-path-a" d="M125 430 L72 455"/><path class="gb-path-b" d="M595 95 L653 67"/>' . self::note( 135, 105, 'DOWNHILL: TOWARD CURB' ) . self::note( 530, 460, 'UPHILL: AWAY FROM CURB' ) . self::note( 360, 500, 'NO CURB: TOWARD ROADWAY EDGE • SET PARKING BRAKE' );
		return self::svg( 'A sloped curbside road labels downhill wheels toward the curb and uphill wheels away from the curb.', $c );
	}

	private static function scene_complex_merge() {
		$c = '<rect class="gb-road" y="80" width="720" height="250"/><path d="M0 500 C210 500 255 365 405 300" stroke="#3f4b54" stroke-width="120" fill="none"/><line class="gb-lane" x1="0" y1="205" x2="720" y2="205"/>' . self::car( 190, 440, 70, 'A' ) . self::car( 330, 205, 90, '1', '#d96b34' ) . self::car( 590, 205, 90, '2', '#657681' );
		$c .= '<path class="gb-path-a" d="M225 410 C285 350 335 315 445 250"/><polygon class="gb-safe" points="475,235 430,230 453,274"/>' . self::note( 130, 380, 'SEARCH' ) . self::note( 360, 390, 'MATCH SPEED' ) . self::note( 535, 390, 'GAP • YIELD • MERGE' );
		return self::svg( 'An entrance ramp joins a freeway as the entering driver searches, matches speed, selects a gap, yields, and merges.', $c );
	}

	private static function scene_complex_emergency() {
		$c = '<rect class="gb-road" x="0" y="70" width="520" height="380"/><rect x="520" y="70" width="200" height="380" fill="#d5c6a8"/><line x1="520" y1="70" x2="520" y2="450" stroke="#ffffff" stroke-width="10"/>' . self::car( 610, 260, 0, 'A' ) . '<path d="M535 115 H700 V405 H535 Z" fill="#f2b134" opacity=".25"/><path d="M490 70 V450" stroke="#b42318" stroke-width="10" stroke-dasharray="18 12"/>';
		$c .= self::note( 200, 135, 'MOVING TRAFFIC' ) . self::note( 610, 105, 'SHOULDER' ) . self::note( 610, 440, 'HAZARDS • HELP • PEOPLE AWAY' );
		return self::svg( 'A disabled vehicle is fully on the shoulder with a marked traffic boundary and a protected area away from moving vehicles.', $c );
	}
}
