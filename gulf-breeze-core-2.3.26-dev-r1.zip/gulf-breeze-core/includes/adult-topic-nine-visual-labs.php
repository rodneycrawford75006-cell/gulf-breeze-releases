<?php
/** Mobile-first visual review labs for Adult English Topic 4.1.9. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class GB_Adult_Topic_Nine_Visual_Labs {
	public static function render( $key ) {
		$labs=self::labs(); if(empty($labs[$key])){return '';} $lab=$labs[$key]; $uid='gb-review-'.sanitize_html_class($key);
		$html='<section class="gb-road-lab" aria-labelledby="'.esc_attr($uid).'-heading"><h2 class="gb-road-lab__heading" id="'.esc_attr($uid).'-heading">'.esc_html($lab['title']).'</h2><p class="gb-road-lab__intro">'.esc_html($lab['intro']).'</p><div class="gb-road-lab__controls" role="group" aria-label="Choose a visual review step">';
		foreach($lab['steps'] as $i=>$step){$id=$uid.'-panel-'.($i+1);$html.='<button type="button" class="gb-road-lab__button" aria-controls="'.esc_attr($id).'" aria-pressed="'.(0===$i?'true':'false').'">'.esc_html(($i+1).'. '.$step[0]).'</button>';}
		$html.='</div><div class="gb-road-lab__stage">'; foreach($lab['steps'] as $i=>$step){$id=$uid.'-panel-'.($i+1);$html.='<div class="gb-road-lab__panel" id="'.esc_attr($id).'"'.(0===$i?'':' hidden').'><figure class="gb-road-lab__figure">'.self::scene($step[1]).'<figcaption class="gb-road-lab__caption"><strong>'.esc_html($step[2]).'</strong> '.esc_html($step[3]).'</figcaption></figure></div>';}
		return $html.'</div></section>';
	}
	private static function labs(){return array(
		'adult_en_044'=>array('title'=>'Turn Sign Recognition into an Early Driving Decision','intro'=>'The official sign gallery supplies the exact images. This lab practices the reasoning that must happen after recognition.','steps'=>array(
			array('Decode the complete message','sign_decode','Use more than the sign name:','Read shape, color, symbol or wording, placement, and roadway evidence before deciding which movement or lane it controls.'),
			array('Separate rule from warning','sign_response','Regulatory signs require compliance; warning signs require preparation:','Obey the rule, then preserve a safety margin. For a warning, adjust before reaching the hazard rather than reacting inside it.'),
			array('Follow the active system','sign_priority','Temporary controls can redefine the road:','An officer, flagger, active signal, temporary marking, or orange channelization can control the current path even when the permanent layout is familiar.'),
		)),
		'adult_en_045'=>array('title'=>'Apply Traffic Law to the Conflict in Front of You','intro'=>'Correct recall matters only when the driver can identify the conflict, choose the lawful response, and preserve room for another person’s mistake.','steps'=>array(
			array('Resolve intersection conflict','law_yield','Yielding is a conflict-management decision:','Stop where required, search every path, identify who must yield, and enter only when the full movement can clear safely.'),
			array('Choose speed for conditions','law_speed','The posted limit is not a target in poor conditions:','Rain, darkness, traffic, visibility, vehicle condition, and driver condition can require a substantial reduction below the maximum.'),
			array('Change lanes in sequence','law_lane','Signal does not create a gap:','Check mirrors, signal, check the blind area, judge the complete gap, move smoothly, and cancel the signal while continuing the search.'),
			array('Protect special roadway users','law_special','Recognize the duty early:','School buses, emergency and roadside vehicles, trains, workers, pedestrians, cyclists, and crash scenes each require specific space and lawful action.'),
		)),
		'adult_en_046'=>array('title'=>'Use One Repeatable Process for the Final Review','intro'=>'The final assessment varies the facts, but the strongest answer consistently satisfies the law and preserves the greatest practical safety margin.','steps'=>array(
			array('Run the five-step loop','ready_loop','Search, identify, predict, decide, act—then search again:','The loop prevents fixation on one sign, vehicle, or familiar answer while the roadway continues to change.'),
			array('Classify the question','ready_classify','First ask what is being tested:','Is it a legal requirement, a sign or marking meaning, or the safest reduced-risk response? Then eliminate answers that create a violation or reduce control.'),
			array('Check readiness by system','ready_matrix','Find the weak category before the scored assessment:','Review licensing, controls, right-of-way, vehicle handling, risk management, and roadway-user cooperation wherever your explanation is uncertain.'),
		)),
	);}
	private static function scene($name){$m=array(
		'sign_decode'=>array('DECODE THE WHOLE MESSAGE',array(array('SHAPE + COLOR','category'),array('SYMBOL + WORDS','exact meaning'),array('LOCATION','who / where'),array('ROAD EVIDENCE','confirm')),'Recognition must lead to action'),
		'sign_response'=>array('MATCH THE RESPONSE',array(array('REGULATORY','obey the rule'),array('WARNING','prepare early'),array('BOTH','search + margin')),'A sign never guarantees the path is clear'),
		'sign_priority'=>array('READ THE ACTIVE SYSTEM',array(array('OFFICER / FLAGGER','follow direction'),array('TEMPORARY CONTROL','follow active path'),array('PERMANENT CONTROL','use when active')),'Current conditions control the current road'),
		'law_yield'=>array('INTERSECTION DECISION',array(array('STOP','lawful point'),array('SEARCH','every path'),array('YIELD','resolve conflict'),array('CLEAR','complete movement')),'Right-of-way is given—not taken'),
		'law_speed'=>array('SAFE SPEED FILTER',array(array('LIMIT','maximum'),array('VISIBILITY','can you stop?'),array('TRACTION','can you steer?'),array('MARGIN','reduce early')),'Conditions can require less than the limit'),
		'law_lane'=>array('LANE-CHANGE SEQUENCE',array(array('MIRRORS','traffic picture'),array('SIGNAL','communicate'),array('BLIND AREA','turn head'),array('GAP + MOVE','smoothly')),'Signal does not create permission'),
		'law_special'=>array('SPECIAL DUTY SEARCH',array(array('BUS / TRAIN','stop rules'),array('EMERGENCY','yield / move'),array('WORKER / USER','space + protection')),'Identify the user before choosing the duty'),
		'ready_loop'=>array('REPEATABLE DECISION LOOP',array(array('SEARCH','whole scene'),array('IDENTIFY','controls + users'),array('PREDICT','what changes'),array('DECIDE + ACT','law + margin')),'Act smoothly, then search again'),
		'ready_classify'=>array('WHAT DOES THE QUESTION ASK?',array(array('LAW','required action'),array('CONTROL','meaning'),array('SAFEST','greatest margin')),'Reject answers that create a new violation'),
		'ready_matrix'=>array('READINESS SYSTEMS',array(array('LICENSE + VEHICLE','responsibility'),array('CONTROL + YIELD','road rules'),array('HANDLING + RISK','space / traction'),array('OTHER USERS','cooperate')),'Explain the decision—not just the answer'),
	);return self::diagram($name,$m[$name]);}
	private static function diagram($name,$data){$count=count($data[1]);$w=$count>3?150:($count===3?190:270);$gap=(680-$count*$w)/max(1,$count-1);$x=20;$c='<rect width="720" height="520" fill="#eef5f8"/><text x="360" y="55" fill="#172b3a" font-family="system-ui,sans-serif" font-size="27" font-weight="800" text-anchor="middle">'.esc_html($data[0]).'</text>';foreach($data[1] as $i=>$card){$color=$i===$count-1?'#18794e':'#123b5d';$c.='<rect x="'.(int)$x.'" y="145" width="'.$w.'" height="155" rx="18" fill="'.$color.'"/><text x="'.(int)($x+$w/2).'" y="205" fill="#fff" font-family="system-ui,sans-serif" font-size="19" font-weight="800" text-anchor="middle">'.esc_html($card[0]).'</text><text x="'.(int)($x+$w/2).'" y="250" fill="#fff" font-family="system-ui,sans-serif" font-size="16" font-weight="650" text-anchor="middle">'.esc_html($card[1]).'</text>';if($i<$count-1){$ax=$x+$w+8;$c.='<path d="M'.$ax.' 222 H'.(int)($ax+$gap-20).'" stroke="#f2b134" stroke-width="9"/><polygon points="'.(int)($ax+$gap-12).',222 '.(int)($ax+$gap-34).',208 '.(int)($ax+$gap-34).',236" fill="#f2b134"/>';}$x+=$w+$gap;}$c.='<rect x="50" y="370" width="620" height="86" rx="18" fill="#f2b134"/><text x="360" y="422" fill="#172b3a" font-family="system-ui,sans-serif" font-size="21" font-weight="800" text-anchor="middle">'.esc_html($data[2]).'</text>';return '<svg class="gb-road-svg" viewBox="0 0 720 520" role="img" aria-label="'.esc_attr($data[0].'. '.$data[2]).'" data-gb-scene="'.esc_attr($name).'">'.$c.'</svg>';}
}
