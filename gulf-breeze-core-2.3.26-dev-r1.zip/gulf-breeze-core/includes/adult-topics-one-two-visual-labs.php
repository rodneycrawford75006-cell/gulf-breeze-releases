<?php
/** Mobile-first visual support for Adult English Topics 4.1.1 and 4.1.2. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class GB_Adult_Topics_One_Two_Visual_Labs {
	public static function render( $key ) {
		$labs = self::labs();
		if ( empty( $labs[ $key ] ) ) { return ''; }
		$lab = $labs[ $key ];
		$uid = 'gb-foundation-' . sanitize_html_class( $key );
		$html = '<section class="gb-road-lab gb-guided-practice" aria-labelledby="' . esc_attr( $uid ) . '-heading"><h2 class="gb-road-lab__heading" id="' . esc_attr( $uid ) . '-heading">' . esc_html( $lab['title'] ) . '</h2><p class="gb-road-lab__intro">' . esc_html( $lab['intro'] ) . '</p><div class="gb-road-lab__controls" role="group" aria-label="Choose a visual lesson step">';
		foreach ( $lab['steps'] as $i => $step ) {
			$id = $uid . '-panel-' . ( $i + 1 );
			$html .= '<button type="button" class="gb-road-lab__button" aria-controls="' . esc_attr( $id ) . '" aria-pressed="' . ( 0 === $i ? 'true' : 'false' ) . '">' . esc_html( ( $i + 1 ) . '. ' . $step[0] ) . '</button>';
		}
		$html .= '</div><div class="gb-road-lab__stage">';
		foreach ( $lab['steps'] as $i => $step ) {
			$id = $uid . '-panel-' . ( $i + 1 );
			$html .= '<div class="gb-road-lab__panel" id="' . esc_attr( $id ) . '"' . ( 0 === $i ? '' : ' hidden' ) . '><figure class="gb-road-lab__figure">' . self::scene( $step[1] ) . '<figcaption class="gb-road-lab__caption"><strong>' . esc_html( $step[2] ) . '</strong> ' . esc_html( $step[3] ) . '</figcaption></figure></div>';
		}
		return $html . '</div></section>';
	}

	private static function labs() {
		return array(
			'adult_en_001' => array(
				'title' => 'Build the Four-Part Safe-Driver Foundation',
				'intro' => 'Course completion starts a continuing cycle of study, practice, reflection, and improvement.',
				'steps' => array(
					array( 'Connect the foundation', 'foundation_cycle', 'Each part supports the next:', 'Learn the rule, understand the risk it addresses, practice the skill lawfully, and use experience to identify the next learning goal.' ),
				),
			),
			'adult_en_002' => array(
				'title' => 'See How the Online Course Moves and Counts Time',
				'intro' => 'The ordered path and the regulated time ledger are related, but they answer different questions.',
				'steps' => array(
					array( 'Follow the course path', 'course_path', 'Progress is sequential:', 'Study the assigned lesson, earn its active time, complete the applicable check, and continue in order before taking the comprehensive final.' ),
					array( 'Separate the time ledger', 'time_ledger', 'Only active instruction fills the 330-minute ledger:', 'Three scheduled breaks are separate, and the comprehensive final examination adds no instructional minutes.' ),
				),
			),
			'adult_en_003' => array(
				'title' => 'Protect a Valid Course Record',
				'intro' => 'Identity, active participation, and independent answers work together to support a valid completion record.',
				'steps' => array(
					array( 'Link the evidence', 'record_chain', 'No single control proves completion by itself:', 'The enrolled person must be present, actively study for the required time, answer independently, and satisfy the assessment rules.' ),
					array( 'Know when time pauses', 'time_pause', 'An open page is not automatically active study:', 'Extended absence, another visible task, a scheduled break, or the final examination must not be counted as lesson instruction.' ),
				),
			),
			'adult_en_004' => array(
				'title' => 'Use One Reduced-Risk Decision Loop',
				'intro' => 'A legal privilege carries a continuing duty to recognize hazards and protect other people.',
				'steps' => array(
					array( 'Choose the safest legal action', 'responsibility_loop', 'Being legally correct is not permission to collide:', 'Identify the rule and hazard, consider everyone affected, create time and space, and take the safest lawful action available.' ),
				),
			),
			'adult_en_005' => array(
				'title' => 'Separate the Steps in the Texas Licensing Path',
				'intro' => 'Documents, education, testing, and lawful practice are separate requirements that must fit the applicant’s transaction.',
				'steps' => array(
					array( 'Prepare the transaction', 'license_path', 'Start with current DPS instructions:', 'Confirm the exact transaction, build the current document checklist, meet applicable education and testing requirements, and read the credential when issued.' ),
					array( 'Separate three legal questions', 'license_distinctions', 'One completed step does not answer the others:', 'Confirm the applicant is eligible, the person has lawful authority to practice or test, and the vehicle is registered, insured, equipped, and otherwise eligible.' ),
				),
			),
			'adult_en_006' => array(
				'title' => 'Read the Authority Printed on the Credential',
				'intro' => 'Class, restriction, and endorsement describe different parts of the driving privilege.',
				'steps' => array(
					array( 'Match driver and vehicle', 'credential_fit', 'Vehicle appearance is not the test:', 'Compare the license class and vehicle category, then confirm that every required endorsement is present and every restriction can be obeyed.' ),
					array( 'Distinguish the terms', 'credential_terms', 'Read the exact code and wording:', 'A class defines the vehicle category, a restriction limits the privilege, and an endorsement adds a qualified authorization.' ),
				),
			),
			'adult_en_007' => array(
				'title' => 'Verify Status Before Driving',
				'intro' => 'The physical card, the legal privilege, and eligibility to restore that privilege are not the same thing.',
				'steps' => array(
					array( 'Distinguish status actions', 'status_types', 'Each action has its own legal effect:', 'Suspension is temporary withdrawal; revocation terminates the privilege; cancellation withdraws an invalid credential; denial refuses issuance.' ),
					array( 'Complete the real restoration path', 'status_restore', 'A receipt or unexpired-looking card is not reinstatement:', 'Check the official record, satisfy every case-specific item, confirm restoration, and then obey renewal and address duties.' ),
				),
			),
			'adult_en_008' => array(
				'title' => 'Check Every Part of Legal Vehicle Readiness',
				'intro' => 'Driver authority and vehicle legality are separate systems; fixing one does not cure a problem in another.',
				'steps' => array(
					array( 'Run the pre-trip legal check', 'vehicle_readiness', 'All four parts must be current:', 'Confirm the driver’s authority, the vehicle’s registration, any applicable inspection or emissions requirement, and effective financial responsibility.' ),
					array( 'Understand liability coverage', 'insurance_scope', 'Minimum liability protects against covered amounts owed to others:', 'It does not automatically repair every loss to the insured driver or vehicle, and coverage must be confirmed before driving.' ),
				),
			),
			'adult_en_009' => array(
				'title' => 'Understand the Voluntary Communication Program',
				'intro' => 'The program can alert law enforcement to communication needs without changing traffic-law duties.',
				'steps' => array(
					array( 'Choose the correct pathway', 'disability_paths', 'The two voluntary pathways use different agencies:', 'A qualifying license or ID indicator is requested through DPS; a vehicle-registration disclosure uses the TxDMV process and can be available through TLETS.' ),
					array( 'Use the alert respectfully', 'disability_stop', 'An alert supports communication, not diagnosis or exemption:', 'Allow time, use the safest available communication method, keep hands visible, avoid sudden movement, and continue following lawful instructions.' ),
				),
			),
		);
	}

	private static function scene( $name ) {
		$scenes = array(
			'foundation_cycle' => array( 'SAFE-DRIVER FOUNDATION', array( array( 'KNOWLEDGE', 'learn law' ), array( 'UNDERSTAND', 'see the risk' ), array( 'SKILL', 'practice' ), array( 'EXPERIENCE', 'improve' ) ), 'Course completion begins the cycle' ),
			'course_path' => array( 'ORDERED COURSE PATH', array( array( 'STUDY', 'assigned lesson' ), array( 'ACTIVE TIME', 'earn minutes' ), array( 'CHECK', 'show learning' ), array( 'CONTINUE', 'in order' ) ), 'Final examination follows instruction' ),
			'time_ledger' => array( 'KEEP TIME CATEGORIES SEPARATE', array( array( 'INSTRUCTION', '330 minutes' ), array( 'BREAKS', '3 × 10' ), array( 'FINAL EXAM', '0 instruction' ) ), 'Total course ledger: 360 minutes plus final' ),
			'record_chain' => array( 'VALID COMPLETION RECORD', array( array( 'IDENTITY', 'enrolled person' ), array( 'ACTIVITY', 'present + visible' ), array( 'TIME', 'server confirmed' ), array( 'ANSWERS', 'independent' ) ), 'Every link supports the record' ),
			'time_pause' => array( 'DOES THIS COUNT AS INSTRUCTION?', array( array( 'VISIBLE STUDY', 'counts' ), array( 'AWAY / OTHER TASK', 'does not count' ), array( 'BREAK / FINAL', 'separate time' ) ), 'A page left open is not proof of study' ),
			'responsibility_loop' => array( 'REDUCED-RISK DECISION', array( array( 'RULE', 'what is legal?' ), array( 'HAZARD', 'what may change?' ), array( 'PEOPLE', 'who is affected?' ), array( 'ACTION', 'law + margin' ) ), 'Avoid preventable harm' ),
			'license_path' => array( 'TEXAS LICENSING PATH', array( array( 'TRANSACTION', 'current DPS list' ), array( 'DOCUMENTS', 'exact evidence' ), array( 'EDUCATION + TESTS', 'when required' ), array( 'CREDENTIAL', 'read limits' ) ), 'Requirements depend on the applicant' ),
			'license_distinctions' => array( 'THREE SEPARATE QUESTIONS', array( array( 'APPLICANT', 'eligible?' ), array( 'AUTHORITY', 'may practice?' ), array( 'VEHICLE', 'legal for test?' ) ), 'One yes does not make all three yes' ),
			'credential_fit' => array( 'MATCH AUTHORITY TO OPERATION', array( array( 'LICENSE CLASS', 'vehicle type' ), array( 'ENDORSEMENT', 'added authority' ), array( 'RESTRICTION', 'obey limits' ) ), 'Confirm before using an unfamiliar vehicle' ),
			'credential_terms' => array( 'READ THE CREDENTIAL', array( array( 'CLASS', 'category' ), array( 'RESTRICTION', 'limits' ), array( 'ENDORSEMENT', 'adds authority' ) ), 'Exact printed wording controls' ),
			'status_types' => array( 'LICENSE STATUS ACTIONS', array( array( 'SUSPEND', 'temporary' ), array( 'REVOKE', 'terminate' ), array( 'CANCEL', 'withdraw' ), array( 'DENY', 'refuse' ) ), 'Do not drive while ineligible' ),
			'status_restore' => array( 'RESTORATION PATH', array( array( 'CHECK RECORD', 'official status' ), array( 'SATISFY ITEMS', 'case specific' ), array( 'CONFIRM', 'restored' ), array( 'MAINTAIN', 'renew + update' ) ), 'A receipt alone does not restore authority' ),
			'vehicle_readiness' => array( 'LEGAL PRE-TRIP CHECK', array( array( 'DRIVER', 'valid authority' ), array( 'REGISTRATION', 'current' ), array( 'INSPECTION', 'if applicable' ), array( 'INSURANCE', 'effective' ) ), 'Every required part must be ready' ),
			'insurance_scope' => array( 'LIABILITY IS NOT EVERY LOSS', array( array( 'OTHER PEOPLE', 'covered liability' ), array( 'YOUR VEHICLE', 'check policy' ), array( 'EFFECTIVE DATE', 'confirm first' ) ), 'Know coverage, exclusions, and limits' ),
			'disability_paths' => array( 'TWO VOLUNTARY PATHWAYS', array( array( 'LICENSE / ID', 'DPS indicator' ), array( 'VEHICLE RECORD', 'TxDMV disclosure' ), array( 'OFFICER ALERT', 'TLETS / card' ) ), 'Participation does not reduce legal duties' ),
			'disability_stop' => array( 'SAFER COMMUNICATION', array( array( 'ALERT', 'allow time' ), array( 'DRIVER', 'hands visible' ), array( 'OFFICER', 'adapt method' ), array( 'BOTH', 'clear + lawful' ) ), 'Never diagnose from appearance' ),
		);
		return self::diagram( $name, $scenes[ $name ] );
	}

	private static function diagram( $name, $data ) {
		$count = count( $data[1] );
		$width = $count > 3 ? 150 : ( 3 === $count ? 190 : 270 );
		$gap = ( 680 - $count * $width ) / max( 1, $count - 1 );
		$x = 20;
		$content = '<rect width="720" height="520" fill="#eef5f8"/><text x="360" y="55" fill="#172b3a" font-family="system-ui,sans-serif" font-size="27" font-weight="800" text-anchor="middle">' . esc_html( $data[0] ) . '</text>';
		foreach ( $data[1] as $i => $card ) {
			$color = $i === $count - 1 ? '#18794e' : '#123b5d';
			$label_size = strlen( $card[0] ) > 14 ? 14 : 17;
			$detail_size = strlen( $card[1] ) > 17 ? 13 : 15;
			$content .= '<rect x="' . (int) $x . '" y="145" width="' . $width . '" height="155" rx="18" fill="' . $color . '"/><text x="' . (int) ( $x + $width / 2 ) . '" y="205" fill="#fff" font-family="system-ui,sans-serif" font-size="' . $label_size . '" font-weight="800" text-anchor="middle">' . esc_html( $card[0] ) . '</text><text x="' . (int) ( $x + $width / 2 ) . '" y="250" fill="#fff" font-family="system-ui,sans-serif" font-size="' . $detail_size . '" font-weight="650" text-anchor="middle">' . esc_html( $card[1] ) . '</text>';
			if ( $i < $count - 1 ) {
				$arrow_x = $x + $width + 8;
				$content .= '<path d="M' . $arrow_x . ' 222 H' . (int) ( $arrow_x + $gap - 20 ) . '" stroke="#f2b134" stroke-width="9"/><polygon points="' . (int) ( $arrow_x + $gap - 12 ) . ',222 ' . (int) ( $arrow_x + $gap - 34 ) . ',208 ' . (int) ( $arrow_x + $gap - 34 ) . ',236" fill="#f2b134"/>';
			}
			$x += $width + $gap;
		}
		$content .= '<rect x="50" y="370" width="620" height="86" rx="18" fill="#f2b134"/><text x="360" y="422" fill="#172b3a" font-family="system-ui,sans-serif" font-size="20" font-weight="800" text-anchor="middle">' . esc_html( $data[2] ) . '</text>';
		return '<svg class="gb-road-svg" viewBox="0 0 720 520" role="img" aria-label="' . esc_attr( $data[0] . '. ' . $data[2] ) . '" data-gb-scene="' . esc_attr( $name ) . '">' . $content . '</svg>';
	}
}
