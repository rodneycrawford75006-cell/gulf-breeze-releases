<?php
/**
 * Adult English Topic 4.1.4 interactive visual labs.
 * Gulf Breeze Driving School / Rodney Crawford.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class GB_Adult_Topic_Four_Visual_Labs {
	public static function render( $key ) {
		$labs = self::labs();
		if ( empty( $labs[ $key ] ) ) {
			return '';
		}

		$lab  = $labs[ $key ];
		$uid  = 'gb-device-' . sanitize_html_class( $key );
		$html = '<section class="gb-road-lab" aria-labelledby="' . esc_attr( $uid ) . '-heading">';
		$html .= '<h2 class="gb-road-lab__heading" id="' . esc_attr( $uid ) . '-heading">' . esc_html( $lab['title'] ) . '</h2>';
		$html .= '<p class="gb-road-lab__intro">' . esc_html( $lab['intro'] ) . '</p>';
		$html .= '<div class="gb-road-lab__controls" role="group" aria-label="Choose a visual step">';
		foreach ( $lab['steps'] as $index => $step ) {
			$panel_id = $uid . '-panel-' . ( $index + 1 );
			$html .= '<button type="button" class="gb-road-lab__button" aria-controls="' . esc_attr( $panel_id ) . '" aria-pressed="' . ( 0 === $index ? 'true' : 'false' ) . '">' . esc_html( ( $index + 1 ) . '. ' . $step['label'] ) . '</button>';
		}
		$html .= '</div><div class="gb-road-lab__stage">';
		foreach ( $lab['steps'] as $index => $step ) {
			$panel_id = $uid . '-panel-' . ( $index + 1 );
			$html .= '<div class="gb-road-lab__panel" id="' . esc_attr( $panel_id ) . '"' . ( 0 === $index ? '' : ' hidden' ) . '>';
			$html .= '<figure class="gb-road-lab__figure">' . self::scene( $step['scene'] );
			$html .= '<figcaption class="gb-road-lab__caption"><strong>' . esc_html( $step['lead'] ) . '</strong> ' . esc_html( $step['caption'] ) . '</figcaption></figure></div>';
		}
		$html .= '</div></section>';
		return $html;
	}

	private static function labs() {
		return array(
			'adult_en_016' => array(
				'title' => 'Read the Whole Control System',
				'intro' => 'Detect the device early, identify what it controls, interpret the complete message, and respond to the roadway—not only the symbol.',
				'steps' => array(
					array( 'label' => 'Detect every control', 'scene' => 'device-detect', 'lead' => 'Detect:', 'caption' => 'Vehicle A sees a red signal, stop line, crosswalk, and pedestrian before reaching the conflict area.' ),
					array( 'label' => 'Identify and interpret', 'scene' => 'device-interpret', 'lead' => 'Interpret:', 'caption' => 'The signal controls Vehicle A’s lane; the stop line sets the stop position, and the crosswalk protects the pedestrian path.' ),
					array( 'label' => 'Respond to the scene', 'scene' => 'device-respond', 'lead' => 'Respond:', 'caption' => 'Vehicle A stops behind the line and remains there until the signal permits movement and the crosswalk is completely clear.' ),
				),
			),
			'adult_en_017' => array(
				'title' => 'STOP Means Stop at the Lawful Position',
				'intro' => 'The sign requires the stop. Roadway markings and intersection visibility determine where the vehicle stops first.',
				'steps' => array(
					array( 'label' => 'Marked stop line', 'scene' => 'stop-line', 'lead' => 'Stop line present:', 'caption' => 'Stop before the marked line, leaving the line and crosswalk clear.' ),
					array( 'label' => 'Crosswalk, no line', 'scene' => 'stop-crosswalk', 'lead' => 'No stop line:', 'caption' => 'Stop before entering the crosswalk. Do not place the vehicle over the pedestrian path.' ),
					array( 'label' => 'Visibility point', 'scene' => 'stop-visibility', 'lead' => 'Neither marking present:', 'caption' => 'Stop at the point nearest the intersecting roadway where approaching traffic can be seen, before entering the intersection.' ),
				),
			),
			'adult_en_018' => array(
				'title' => 'A Curve Warning Starts the Decision Early',
				'intro' => 'The warning sign buys time. Finish the major speed adjustment before steering and preserve a smooth path through the curve.',
				'steps' => array(
					array( 'label' => 'Detect and search', 'scene' => 'curve-detect', 'lead' => 'Search:', 'caption' => 'Vehicle A recognizes the curve warning, checks behind, and searches through the available sight distance.' ),
					array( 'label' => 'Set speed before entry', 'scene' => 'curve-slow', 'lead' => 'Prepare:', 'caption' => 'Vehicle A reduces speed while the roadway is still straight, before steering load and limited sight distance combine.' ),
					array( 'label' => 'Track a smooth path', 'scene' => 'curve-track', 'lead' => 'Steer smoothly:', 'caption' => 'Vehicle A stays within its lane, looks through the curve, and avoids abrupt braking or steering.' ),
				),
			),
			'adult_en_019' => array(
				'title' => 'Color Identifies the Job; the Scene Sets the Action',
				'intro' => 'Guide, school, and temporary work-zone devices serve different purposes. Read the full device and prepare before the path changes.',
				'steps' => array(
					array( 'label' => 'Sort the device family', 'scene' => 'families', 'lead' => 'Recognize the family:', 'caption' => 'Green organizes routes, fluorescent yellow-green increases attention near schools and pedestrians, and orange marks temporary work activity.' ),
					array( 'label' => 'Follow the temporary path', 'scene' => 'work-shift', 'lead' => 'Temporary control:', 'caption' => 'Orange devices move traffic away from the closed lane. Vehicle A follows the channelized path without crossing the cone line.' ),
					array( 'label' => 'Obey the flagger', 'scene' => 'work-flagger', 'lead' => 'Human direction:', 'caption' => 'The authorized flagger displays STOP. Vehicle A remains stopped even if the usual lane appears open.' ),
				),
			),
			'adult_en_020' => array(
				'title' => 'Signal State Changes the Driver’s Duty',
				'intro' => 'Use position and label as well as color. Then check lanes, pedestrians, traffic, and space before moving.',
				'steps' => array(
					array( 'label' => 'Read steady signals', 'scene' => 'signal-steady', 'lead' => 'Steady indications:', 'caption' => 'Red requires a stop, yellow warns the green phase is ending, and green permits movement only when yielding duties and available space allow it.' ),
					array( 'label' => 'Compare flashing signals', 'scene' => 'signal-flashing', 'lead' => 'Flashing indications:', 'caption' => 'Flashing red requires a complete stop; flashing yellow requires slowing and cautious movement while searching for conflict.' ),
					array( 'label' => 'Handle a dark signal', 'scene' => 'signal-dark', 'lead' => 'Dark or failed signal:', 'caption' => 'Reduce speed early, identify every approach, follow current Texas law and temporary direction, and proceed only when safe.' ),
				),
			),
			'adult_en_021' => array(
				'title' => 'Read Pavement Markings as a Complete System',
				'intro' => 'Color, pattern, arrows, crosswalks, stop lines, and special-use areas work together to organize lawful movement.',
				'steps' => array(
					array( 'label' => 'Compare line systems', 'scene' => 'marking-lines', 'lead' => 'Line system:', 'caption' => 'Yellow generally separates opposing directions; white generally separates traffic moving in the same direction. Solid and broken patterns change the crossing rule.' ),
					array( 'label' => 'Use arrows and stop markings', 'scene' => 'marking-lane', 'lead' => 'Lane assignment:', 'caption' => 'Select the correct lane early, follow its arrow, and stop behind the line so the crosswalk remains open.' ),
					array( 'label' => 'Protect special-use areas', 'scene' => 'marking-special', 'lead' => 'Not ordinary travel space:', 'caption' => 'Do not drive across a painted gore or treat a reversible lane as open unless its lane-control signal permits travel.' ),
				),
			),
		);
	}

	private static function scene( $scene ) {
		switch ( $scene ) {
			case 'device-detect': return self::scene_device_detect();
			case 'device-interpret': return self::scene_device_interpret();
			case 'device-respond': return self::scene_device_respond();
			case 'stop-line': return self::scene_stop_line();
			case 'stop-crosswalk': return self::scene_stop_crosswalk();
			case 'stop-visibility': return self::scene_stop_visibility();
			case 'curve-detect': return self::scene_curve_detect();
			case 'curve-slow': return self::scene_curve_slow();
			case 'curve-track': return self::scene_curve_track();
			case 'families': return self::scene_families();
			case 'work-shift': return self::scene_work_shift();
			case 'work-flagger': return self::scene_work_flagger();
			case 'signal-steady': return self::scene_signal_steady();
			case 'signal-flashing': return self::scene_signal_flashing();
			case 'signal-dark': return self::scene_signal_dark();
			case 'marking-lines': return self::scene_marking_lines();
			case 'marking-lane': return self::scene_marking_lane();
			case 'marking-special': return self::scene_marking_special();
			default: return '';
		}
	}

	private static function svg( $label, $content ) {
		return '<svg class="gb-road-svg" viewBox="0 0 720 520" role="img" aria-label="' . esc_attr( $label ) . '"><rect class="gb-ground" width="720" height="520"/>' . $content . '</svg>';
	}

	private static function car( $x, $y, $rotation, $label = 'A', $color = '#2d78c4' ) {
		return '<g transform="translate(' . (int) $x . ' ' . (int) $y . ') rotate(' . (int) $rotation . ')"><rect x="-34" y="-55" width="68" height="110" rx="20" fill="' . esc_attr( $color ) . '" stroke="#172b3a" stroke-width="3"/><rect x="-24" y="-38" width="48" height="40" rx="9" fill="#eaf3f8" opacity=".9"/><circle cx="0" cy="14" r="20" fill="#123b5d"/><text class="gb-label" x="0" y="15">' . esc_html( $label ) . '</text></g>';
	}

	private static function person( $x, $y ) {
		return '<g transform="translate(' . (int) $x . ' ' . (int) $y . ')" stroke="#172b3a" stroke-width="8" stroke-linecap="round"><circle cy="-35" r="15" fill="#f2b134"/><line y1="-18" y2="32"/><line y1="0" x2="-24" y2="20"/><line y1="0" x2="24" y2="20"/><line y1="30" x2="-20" y2="65"/><line y1="30" x2="20" y2="65"/></g>';
	}

	private static function intersection() {
		return '<rect class="gb-road" x="250" width="220" height="520"/><rect class="gb-road" y="145" width="720" height="225"/><line class="gb-lane" x1="360" y1="0" x2="360" y2="125"/><line class="gb-lane" x1="360" y1="390" x2="360" y2="520"/><line class="gb-lane" x1="0" y1="260" x2="230" y2="260"/><line class="gb-lane" x1="490" y1="260" x2="720" y2="260"/>';
	}

	private static function crosswalk( $y = 350 ) {
		$html = '';
		for ( $x = 260; $x <= 440; $x += 36 ) {
			$html .= '<rect x="' . (int) $x . '" y="' . (int) $y . '" width="20" height="56" fill="#ffffff" opacity=".94"/>';
		}
		return $html;
	}

	private static function stop_line( $y = 420 ) {
		return '<line class="gb-stop-line" x1="260" y1="' . (int) $y . '" x2="350" y2="' . (int) $y . '"/>';
	}

	private static function signal( $x, $y, $active, $label ) {
		$colors = array( 'red' => '#c9342c', 'yellow' => '#f2b134', 'green' => '#168c5b' );
		$html = '<g transform="translate(' . (int) $x . ' ' . (int) $y . ')"><rect x="-38" y="-92" width="76" height="184" rx="18" fill="#172b3a" stroke="#ffffff" stroke-width="3"/>';
		foreach ( array( 'red' => -58, 'yellow' => 0, 'green' => 58 ) as $name => $cy ) {
			$fill = $name === $active ? $colors[ $name ] : '#5e6d78';
			$html .= '<circle cy="' . (int) $cy . '" r="23" fill="' . esc_attr( $fill ) . '" stroke="#ffffff" stroke-width="2"/>';
		}
		$html .= '<text class="gb-note" x="0" y="125">' . esc_html( $label ) . '</text></g>';
		return $html;
	}

	private static function stop_badge( $x, $y, $text = 'STOP' ) {
		return '<g transform="translate(' . (int) $x . ' ' . (int) $y . ')"><circle r="40" fill="#ffffff" stroke="#b42318" stroke-width="7"/><text class="gb-note" x="0" y="8">' . esc_html( $text ) . '</text></g>';
	}

	private static function scene_device_detect() {
		$c = self::intersection() . self::crosswalk( 342 ) . self::stop_line( 420 ) . self::car( 305, 475, 0 ) . self::person( 430, 330 ) . self::signal( 565, 110, 'red', 'RED' );
		$c .= '<circle class="gb-zone" cx="305" cy="420" r="40"/><circle class="gb-zone" cx="430" cy="350" r="45"/><circle class="gb-zone" cx="565" cy="110" r="55"/>';
		return self::svg( 'Vehicle A approaches a red signal, stop line, crosswalk, and pedestrian.', $c );
	}

	private static function scene_device_interpret() {
		$c = self::intersection() . self::crosswalk( 342 ) . self::stop_line( 420 ) . self::car( 305, 475, 0 ) . self::person( 430, 330 ) . self::signal( 565, 110, 'red', 'CONTROLS A' );
		$c .= '<path class="gb-path-a" d="M530 180 L350 405"/><text class="gb-note" x="560" y="255">STOP LINE</text><text class="gb-note" x="565" y="310">CROSSWALK</text>';
		return self::svg( 'Labels connect the signal to Vehicle A and identify the stop line and crosswalk.', $c );
	}

	private static function scene_device_respond() {
		$c = self::intersection() . self::crosswalk( 342 ) . self::stop_line( 420 ) . self::car( 305, 480, 0 ) . self::person( 390, 355 ) . self::signal( 565, 110, 'red', 'WAIT' ) . self::stop_badge( 145, 430 );
		return self::svg( 'Vehicle A remains behind the stop line while the signal is red and the pedestrian uses the crosswalk.', $c );
	}

	private static function stop_scene_base( $with_crosswalk = true ) {
		$c = self::intersection();
		if ( $with_crosswalk ) {
			$c .= self::crosswalk( 342 );
		}
		$c .= '<g transform="translate(540 410)"><polygon points="0,-50 42,-34 55,8 28,48 -28,48 -55,8 -42,-34" fill="#c9342c" stroke="#ffffff" stroke-width="7"/><text class="gb-label" x="0" y="5">STOP</text></g>';
		return $c;
	}

	private static function scene_stop_line() {
		$c = self::stop_scene_base() . self::stop_line( 420 ) . self::car( 305, 480, 0 ) . '<path class="gb-path-a" d="M180 430 L285 430"/><text class="gb-note" x="110" y="438">FIRST STOP</text>';
		return self::svg( 'Vehicle A stops before a marked stop line located before a crosswalk.', $c );
	}

	private static function scene_stop_crosswalk() {
		$c = self::stop_scene_base() . self::car( 305, 425, 0 ) . '<line class="gb-stop-line" x1="250" y1="414" x2="350" y2="414" opacity=".25"/><path class="gb-path-a" d="M155 414 L270 414"/><text class="gb-note" x="110" y="390">BEFORE</text><text class="gb-note" x="110" y="420">CROSSWALK</text>';
		return self::svg( 'Without a stop line, Vehicle A stops before entering the crosswalk.', $c );
	}

	private static function scene_stop_visibility() {
		$c = self::stop_scene_base( false ) . self::car( 305, 395, 0 ) . '<path d="M305 360 L110 150 L500 150 Z" fill="#f2b134" opacity=".22"/><path class="gb-path-a" d="M305 350 L115 210"/><text class="gb-note" x="115" y="185">VIEW LEFT</text><path class="gb-path-a" d="M305 350 L600 210"/><text class="gb-note" x="610" y="185">VIEW RIGHT</text>';
		return self::svg( 'With no stop line or crosswalk, Vehicle A stops before entering where approaching traffic can be seen.', $c );
	}

	private static function curve_road() {
		return '<path d="M225 520 C225 340 245 285 345 235 C450 182 490 130 500 0" stroke="#3f4b54" stroke-width="230" fill="none"/><path d="M340 520 C340 340 360 315 420 285 C525 230 605 145 615 0" stroke="#ffffff" stroke-width="5" stroke-dasharray="18 18" fill="none"/><path d="M110 520 C110 340 130 255 270 185 C345 147 375 100 385 0" stroke="#f2b134" stroke-width="5" fill="none"/>';
	}

	private static function curve_marker() {
		return '<g transform="translate(90 325)"><polygon points="0,-65 65,0 0,65 -65,0" fill="#f2b134" stroke="#172b3a" stroke-width="5"/><path d="M-15 38 C-15 5 26,-5 8,-42" stroke="#172b3a" stroke-width="12" fill="none" stroke-linecap="round"/></g>';
	}

	private static function scene_curve_detect() {
		$c = self::curve_road() . self::curve_marker() . self::car( 290, 455, 0 ) . '<path class="gb-path-a" d="M290 390 L260 270"/><text class="gb-note" x="140" y="450">MIRRORS</text><path class="gb-path-a" d="M205 435 L120 450"/>';
		return self::svg( 'Vehicle A sees a curve warning, checks mirrors, and searches through the bend.', $c );
	}

	private static function scene_curve_slow() {
		$c = self::curve_road() . self::curve_marker() . self::car( 290, 390, 0 ) . '<rect class="gb-zone" x="210" y="330" width="165" height="150" rx="18"/><text class="gb-note" x="520" y="410">SET SPEED</text><text class="gb-note" x="520" y="445">BEFORE CURVE</text>';
		return self::svg( 'Vehicle A completes the major speed reduction on the straight approach before steering.', $c );
	}

	private static function scene_curve_track() {
		$c = self::curve_road() . self::car( 365, 250, 38 ) . '<path class="gb-path-a" d="M290 465 C290 335 330 295 405 255 C500 205 550 125 560 45"/><polygon class="gb-safe" points="560,20 538,68 585,62"/><text class="gb-note" x="130" y="455">SMOOTH PATH</text>';
		return self::svg( 'Vehicle A follows a smooth path within its lane and looks through the curve.', $c );
	}

	private static function family_card( $x, $color, $top, $bottom, $ink = '#ffffff' ) {
		return '<g transform="translate(' . (int) $x . ' 200)"><rect x="-95" y="-90" width="190" height="180" rx="18" fill="' . esc_attr( $color ) . '" stroke="#172b3a" stroke-width="4"/><text x="0" y="-12" fill="' . esc_attr( $ink ) . '" font-family="system-ui,sans-serif" font-size="28" font-weight="700" text-anchor="middle">' . esc_html( $top ) . '</text><text x="0" y="30" fill="' . esc_attr( $ink ) . '" font-family="system-ui,sans-serif" font-size="22" font-weight="700" text-anchor="middle">' . esc_html( $bottom ) . '</text></g>';
	}

	private static function scene_families() {
		$c = self::family_card( 130, '#2c7a4b', 'GREEN', 'ROUTES' ) . self::family_card( 360, '#d8f000', 'FLUORESCENT', 'SCHOOL / PEOPLE', '#172b3a' ) . self::family_card( 590, '#f28c28', 'ORANGE', 'WORK ZONE', '#172b3a' );
		$c .= '<text class="gb-note" x="360" y="400">COLOR IDENTIFIES THE DEVICE FAMILY</text><text class="gb-note" x="360" y="442">SHAPE, WORDING, PLACEMENT, AND SCENE SET THE ACTION</text>';
		return self::svg( 'Three labeled color-family cards distinguish route guidance, school or pedestrian attention, and temporary work zones.', $c );
	}

	private static function cone( $x, $y ) {
		return '<g transform="translate(' . (int) $x . ' ' . (int) $y . ')"><polygon points="0,-28 22,26 -22,26" fill="#f28c28" stroke="#172b3a" stroke-width="3"/><rect x="-30" y="24" width="60" height="10" fill="#ffffff" stroke="#172b3a" stroke-width="2"/></g>';
	}

	private static function work_road() {
		return '<rect class="gb-road" x="125" width="470" height="520"/><line class="gb-lane" x1="282" y1="0" x2="282" y2="520"/><line class="gb-lane" x1="438" y1="0" x2="438" y2="520"/>';
	}

	private static function scene_work_shift() {
		$c = self::work_road() . '<rect x="130" y="40" width="145" height="230" fill="#b42318" opacity=".32"/><text class="gb-note" x="202" y="80">CLOSED</text>';
		foreach ( array( array( 280, 270 ), array( 255, 320 ), array( 230, 370 ), array( 205, 420 ) ) as $point ) {
			$c .= self::cone( $point[0], $point[1] );
		}
		$c .= self::car( 202, 470, 0 ) . '<path class="gb-path-a" d="M202 430 C220 355 280 305 360 270 L360 90"/><polygon class="gb-safe" points="360,55 337,100 383,100"/>';
		return self::svg( 'Vehicle A follows a channelized path around a work-zone lane closure without crossing the cones.', $c );
	}

	private static function flagger( $x, $y ) {
		return self::person( $x, $y ) . '<g transform="translate(' . (int) ( $x + 50 ) . ' ' . (int) ( $y - 55 ) . ')"><line x1="0" y1="0" x2="0" y2="95" stroke="#172b3a" stroke-width="8"/><circle r="42" fill="#c9342c" stroke="#ffffff" stroke-width="6"/><text class="gb-label" x="0" y="4">STOP</text></g>';
	}

	private static function scene_work_flagger() {
		$c = self::work_road() . self::car( 360, 440, 0 ) . self::flagger( 460, 215 ) . self::stop_badge( 145, 430 );
		$c .= '<line class="gb-stop-line" x1="290" y1="350" x2="430" y2="350"/><text class="gb-note" x="150" y="110">AUTHORIZED FLAGGER</text><text class="gb-note" x="150" y="145">OVERRIDES NORMAL FLOW</text>';
		return self::svg( 'Vehicle A waits at a work-zone stop point while an authorized flagger displays STOP.', $c );
	}

	private static function scene_signal_steady() {
		$c = self::signal( 130, 205, 'red', 'STOP' ) . self::signal( 360, 205, 'yellow', 'STOP IF SAFE' ) . self::signal( 590, 205, 'green', 'GO IF CLEAR' );
		$c .= '<text class="gb-note" x="130" y="420">TOP POSITION</text><text class="gb-note" x="360" y="420">MIDDLE POSITION</text><text class="gb-note" x="590" y="420">BOTTOM POSITION</text>';
		return self::svg( 'Steady red, yellow, and green signal heads are labeled by both position and required response.', $c );
	}

	private static function flash_head( $x, $color, $top, $bottom ) {
		return '<g transform="translate(' . (int) $x . ' 220)"><rect x="-62" y="-75" width="124" height="150" rx="22" fill="#172b3a"/><circle r="42" fill="' . esc_attr( $color ) . '" stroke="#ffffff" stroke-width="5"/><path d="M-78 -95 L-105 -125 M78 -95 L105 -125 M-105 0 L-140 0 M105 0 L140 0" stroke="#f2b134" stroke-width="8" stroke-linecap="round"/><text class="gb-note" x="0" y="125">' . esc_html( $top ) . '</text><text class="gb-note" x="0" y="162">' . esc_html( $bottom ) . '</text></g>';
	}

	private static function scene_signal_flashing() {
		$c = self::flash_head( 210, '#c9342c', 'FLASHING RED', 'STOP, THEN YIELD' ) . self::flash_head( 510, '#f2b134', 'FLASHING YELLOW', 'SLOW, USE CAUTION' );
		$c .= '<line x1="360" y1="55" x2="360" y2="465" stroke="#c8d5df" stroke-width="4"/>';
		return self::svg( 'Flashing red and flashing yellow signals are compared with written actions.', $c );
	}

	private static function scene_signal_dark() {
		$c = self::intersection() . self::car( 305, 450, 0 ) . self::car( 555, 310, -90, 'B', '#d96b34' ) . self::signal( 590, 105, 'dark', 'DARK' );
		$c .= self::stop_badge( 165, 430 ) . self::stop_badge( 625, 410 ) . '<text class="gb-note" x="360" y="95">SLOW • IDENTIFY • YIELD • PROCEED SAFELY</text>';
		return self::svg( 'Two vehicles approach an intersection with a dark signal and prepare to follow the applicable failure procedure.', $c );
	}

	private static function scene_marking_lines() {
		$c = '<rect class="gb-road" x="40" y="55" width="640" height="410" rx="18"/><line x1="360" y1="55" x2="360" y2="465" stroke="#f2b134" stroke-width="8"/><line x1="342" y1="55" x2="342" y2="465" stroke="#f2b134" stroke-width="8"/><line x1="190" y1="55" x2="190" y2="465" stroke="#ffffff" stroke-width="6" stroke-dasharray="20 18"/><line x1="530" y1="55" x2="530" y2="465" stroke="#ffffff" stroke-width="6" stroke-dasharray="20 18"/>';
		$c .= '<text class="gb-large-label" x="360" y="250" transform="rotate(-90 360 250)">DOUBLE SOLID YELLOW</text><text class="gb-label" x="190" y="250" transform="rotate(-90 190 250)">BROKEN WHITE</text><text class="gb-label" x="530" y="250" transform="rotate(-90 530 250)">BROKEN WHITE</text><text class="gb-note" x="150" y="500">SAME DIRECTION</text><text class="gb-note" x="570" y="500">SAME DIRECTION</text>';
		return self::svg( 'A roadway plate shows double solid yellow opposing-direction separation and broken white same-direction lane lines.', $c );
	}

	private static function turn_arrow( $x, $y ) {
		return '<path d="M' . (int) $x . ' ' . (int) ( $y + 70 ) . ' L' . (int) $x . ' ' . (int) ( $y - 25 ) . ' C' . (int) $x . ' ' . (int) ( $y - 65 ) . ' ' . (int) ( $x + 35 ) . ' ' . (int) ( $y - 80 ) . ' ' . (int) ( $x + 65 ) . ' ' . (int) ( $y - 80 ) . ' M' . (int) ( $x + 42 ) . ' ' . (int) ( $y - 105 ) . ' L' . (int) ( $x + 70 ) . ' ' . (int) ( $y - 80 ) . ' L' . (int) ( $x + 42 ) . ' ' . (int) ( $y - 55 ) . '" stroke="#ffffff" stroke-width="15" fill="none" stroke-linecap="round" stroke-linejoin="round"/>';
	}

	private static function scene_marking_lane() {
		$c = self::intersection() . self::crosswalk( 342 ) . self::stop_line( 420 ) . self::turn_arrow( 305, 400 ) . self::car( 305, 485, 0 );
		$c .= '<text class="gb-note" x="585" y="355">CROSSWALK</text><text class="gb-note" x="585" y="420">STOP LINE</text><path class="gb-path-a" d="M500 350 L450 360"/><path class="gb-path-a" d="M500 415 L450 420"/>';
		return self::svg( 'Vehicle A occupies a turn-only lane and stops behind the stop line, leaving the crosswalk open.', $c );
	}

	private static function scene_marking_special() {
		$c = '<rect class="gb-road" x="25" y="55" width="310" height="410" rx="16"/><path d="M85 440 L275 80" stroke="#ffffff" stroke-width="8"/><path d="M125 440 L315 80" stroke="#ffffff" stroke-width="8"/>';
		for ( $y = 130; $y <= 390; $y += 52 ) {
			$c .= '<line x1="' . (int) ( 292 - ( $y - 130 ) / 2 ) . '" y1="' . (int) $y . '" x2="' . (int) ( 330 - ( $y - 130 ) / 2 ) . '" y2="' . (int) ( $y + 28 ) . '" stroke="#ffffff" stroke-width="7"/>';
		}
		$c .= '<text class="gb-label" x="165" y="255" transform="rotate(-62 165 255)">PAINTED GORE — KEEP OUT</text>';
		$c .= '<rect class="gb-road" x="385" y="55" width="310" height="410" rx="16"/><line class="gb-lane" x1="540" y1="55" x2="540" y2="465"/><g transform="translate(540 135)"><rect x="-62" y="-48" width="124" height="96" rx="15" fill="#172b3a"/><path d="M-24 -20 L24 20 M24 -20 L-24 20" stroke="#c9342c" stroke-width="13"/></g><g transform="translate(540 330)"><rect x="-62" y="-48" width="124" height="96" rx="15" fill="#172b3a"/><path d="M-30 -12 L0 20 L30 -12" stroke="#168c5b" stroke-width="13" fill="none"/></g><text class="gb-note" x="540" y="215">RED X: CLOSED</text><text class="gb-note" x="540" y="410">GREEN ARROW: OPEN</text>';
		return self::svg( 'A split plate shows a painted gore as closed travel space and reversible-lane red X and green-arrow controls.', $c );
	}
}
