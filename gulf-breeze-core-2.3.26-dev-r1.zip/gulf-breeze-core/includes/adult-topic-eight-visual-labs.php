<?php
/** Mobile-first visual decision labs for Adult English Topic 4.1.8. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class GB_Adult_Topic_Eight_Visual_Labs {
	public static function render( $key ) {
		$labs = self::labs(); if ( empty( $labs[ $key ] ) ) { return ''; }
		$lab = $labs[ $key ]; $uid = 'gb-risk-' . sanitize_html_class( $key );
		$html = '<section class="gb-road-lab" aria-labelledby="' . esc_attr( $uid ) . '-heading"><h2 class="gb-road-lab__heading" id="' . esc_attr( $uid ) . '-heading">' . esc_html( $lab['title'] ) . '</h2><p class="gb-road-lab__intro">' . esc_html( $lab['intro'] ) . '</p><div class="gb-road-lab__controls" role="group" aria-label="Choose a visual step">';
		foreach ( $lab['steps'] as $i => $step ) { $id = $uid . '-panel-' . ( $i + 1 ); $html .= '<button type="button" class="gb-road-lab__button" aria-controls="' . esc_attr( $id ) . '" aria-pressed="' . ( 0 === $i ? 'true' : 'false' ) . '">' . esc_html( ( $i + 1 ) . '. ' . $step[0] ) . '</button>'; }
		$html .= '</div><div class="gb-road-lab__stage">';
		foreach ( $lab['steps'] as $i => $step ) { $id = $uid . '-panel-' . ( $i + 1 ); $html .= '<div class="gb-road-lab__panel" id="' . esc_attr( $id ) . '"' . ( 0 === $i ? '' : ' hidden' ) . '><figure class="gb-road-lab__figure">' . self::scene( $step[1] ) . '<figcaption class="gb-road-lab__caption"><strong>' . esc_html( $step[2] ) . '</strong> ' . esc_html( $step[3] ) . '</figcaption></figure></div>'; }
		return $html . '</div></section>';
	}

	private static function labs() {
		return array(
			'adult_en_038' => array( 'title'=>'Build a Risk Margin Before the Trip Builds a Crisis', 'intro'=>'Risk is dynamic. Read all four parts together, then choose a specific trigger for slowing, stopping, rerouting, or postponing.', 'steps'=>array(
				array('Read all four parts','risk_four','Use the whole picture:','Driver, vehicle, roadway, and environment interact; a weakness in one changes the safe response to every other part.'),
				array('Watch risks multiply','risk_multiply','Margins shrink together:','Fatigue plus worn tires plus darkness and rain is not a list of separate problems—it is a combined reason to reduce exposure early.'),
				array('Protect the child','risk_child','Look before you lock:','Park, remove the child, check every seat, lock the vehicle, and keep keys away. Never leave a child unattended in a vehicle.'),
			) ),
			'adult_en_039' => array( 'title'=>'Keep Attention on the Driving Task', 'intro'=>'The safest phone and fatigue decisions are made before urgency, habit, or sleep loss takes control.', 'steps'=>array(
				array('See the three distractions','attention_three','Texting can take all three:','Eyes leave the road, a hand leaves control, and the mind leaves the driving problem at the same time.'),
				array('Park before the phone','attention_park','Make the safe routine automatic:','Set navigation and do-not-disturb before moving. For any device task, leave traffic and park completely before touching it.'),
				array('Exit the fatigue spiral','attention_fatigue','Warning signs mean stop:','Heavy eyelids, drifting, missed signs, or forgotten miles require a safe stop, real rest, or another driver—not windows, music, or willpower.'),
			) ),
			'adult_en_040' => array( 'title'=>'Preserve Traction, Visibility, and Recovery Space', 'intro'=>'In darkness, weather, or a vehicle emergency, smooth inputs and a visible escape path matter more than maintaining speed.', 'steps'=>array(
				array('Stop inside what you see','weather_light','Your headlights set the limit:','Choose a speed that lets the vehicle stop inside the illuminated, visible path. Glare, curves, and rain shorten that path.'),
				array('Recover traction smoothly','weather_traction','Look where you want to go:','Ease off power, hold or steer toward the intended path, and avoid abrupt braking or steering until traction returns.'),
				array('Stabilize before returning','weather_emergency','One controlled sequence:','For a blowout or road departure, grip, hold direction, ease off, slow gradually, then leave or return to the pavement only when stable and safe.'),
			) ),
			'adult_en_041' => array( 'title'=>'Break the High-Risk Chain Early', 'intro'=>'Speed, aggression, racing, and improper restraint turn small mistakes into severe outcomes. Refuse the chain before options disappear.', 'steps'=>array(
				array('Break the chain','speed_chain','Interrupt the first link:','Leave time, accept a missed turn, increase space, and refuse competition before hurry becomes speed and speed becomes conflict.'),
				array('Route crash force safely','belt_path','Wear the belt on strong bones:','Place the lap belt low across the hips, shoulder belt across the chest, and sit upright. Air bags supplement the belt; they do not replace it.'),
			) ),
			'adult_en_042' => array( 'title'=>'Recognize Patterns and Report Without Escalating', 'intro'=>'No single sign proves trafficking. Observe objective behavior, protect the person’s privacy, and let trained responders decide what happens next.', 'steps'=>array(
				array('Look for a pattern','report_pattern','Indicators combine; stereotypes mislead:','Notice control of documents, money, movement, speech, work, threats, or a person who seems coached, fearful, or unable to leave.'),
				array('Choose the safe report','report_route','Do not confront or attempt a rescue:','Call 911 for immediate danger. Otherwise report location, time, vehicle, direction, people, and exact behavior through an appropriate hotline or iWatchTexas.'),
			) ),
		);
	}

	private static function scene( $name ) {
		$map = array(
			'risk_four'=>array('THE RISK PICTURE',array(array('DRIVER','attention • fatigue'),array('VEHICLE','tires • brakes'),array('ROADWAY','curve • surface'),array('ENVIRONMENT','dark • rain')),'All four change the margin'),
			'risk_multiply'=>array('COMBINED RISK',array(array('TIRED','slower response'),array('WORN TIRES','less grip'),array('DARK + WET','less sight + traction')),'Reduce exposure before options vanish'),
			'risk_child'=>array('LOOK BEFORE YOU LOCK',array(array('1. PARK','engine off'),array('2. REMOVE','child + essentials'),array('3. CHECK','every seat'),array('4. LOCK','keys secured')),'Never leave a child unattended'),
			'attention_three'=>array('TEXTING TAKES ALL THREE',array(array('VISUAL','eyes off road'),array('MANUAL','hand off control'),array('COGNITIVE','mind off driving')),'One task can remove every resource'),
			'attention_park'=>array('THE PHONE ROUTINE',array(array('BEFORE','set route + DND'),array('MOVING','hands off phone'),array('NEED PHONE?','exit traffic'),array('THEN','park completely')),'Parked first — task second'),
			'attention_fatigue'=>array('FATIGUE EXIT PLAN',array(array('NOTICE','yawn • drift'),array('DECIDE','leave roadway'),array('RECOVER','real rest'),array('RESTART','only when alert')),'Music and open windows are not rest'),
			'weather_light'=>array('VISIBLE PATH = STOPPING LIMIT',array(array('HEADLIGHTS','show the path'),array('SPEED','sets stopping need'),array('SAFE ONLY IF','stop fits inside')),'If the path shrinks, speed must shrink'),
			'weather_traction'=>array('TRACTION RECOVERY',array(array('EASE OFF','no sudden power'),array('LOOK','intended path'),array('STEER','smoothly'),array('WAIT','traction returns')),'Smooth inputs preserve the remaining grip'),
			'weather_emergency'=>array('BLOWOUT / ROAD DEPARTURE',array(array('GRIP','hold direction'),array('EASE OFF','no panic brake'),array('SLOW','gradually'),array('MOVE','only when stable')),'Stabilize first — leave or return second'),
			'speed_chain'=>array('BREAK THE CHAIN EARLY',array(array('HURRY','leave more time'),array('SPEED','ease off'),array('FRUSTRATION','add space'),array('CHALLENGE','refuse it')),'Every early exit protects later options'),
			'belt_path'=>array('CORRECT RESTRAINT PATH',array(array('LAP BELT','low on hips'),array('SHOULDER','across chest'),array('SEAT','upright'),array('AIR BAG','supplements belt')),'Strong bones manage force better'),
			'report_pattern'=>array('OBSERVE A PATTERN',array(array('CONTROL','ID • money • speech'),array('FEAR','coached • watched'),array('CONDITIONS','threat • debt • cannot leave')),'Record behavior — do not label a person'),
			'report_route'=>array('SAFE REPORTING ROUTE',array(array('DANGER NOW','call 911'),array('NO IMMEDIATE DANGER','hotline / iWatch'),array('REPORT','facts + location'),array('AVOID','confront • follow • photograph')),'Move to safety and let responders act'),
		); return self::diagram( $name, $map[ $name ] );
	}

	private static function diagram( $name, $data ) {
		$count=count($data[1]); $w=$count>3?150:($count===3?190:270); $gap=(680-($count*$w))/max(1,$count-1); $x=20; $c='<rect width="720" height="520" fill="#eef5f8"/><text x="360" y="55" fill="#172b3a" font-family="system-ui,sans-serif" font-size="27" font-weight="800" text-anchor="middle">'.esc_html($data[0]).'</text>';
		foreach($data[1] as $i=>$card){$color=$i===$count-1?'#18794e':'#123b5d';$c.='<rect x="'.(int)$x.'" y="145" width="'.$w.'" height="155" rx="18" fill="'.$color.'"/><text x="'.(int)($x+$w/2).'" y="205" fill="#fff" font-family="system-ui,sans-serif" font-size="20" font-weight="800" text-anchor="middle">'.esc_html($card[0]).'</text><text x="'.(int)($x+$w/2).'" y="250" fill="#fff" font-family="system-ui,sans-serif" font-size="16" font-weight="650" text-anchor="middle">'.esc_html($card[1]).'</text>';if($i<$count-1){$ax=$x+$w+8;$c.='<path d="M'.$ax.' 222 H'.(int)($ax+$gap-20).'" stroke="#f2b134" stroke-width="9"/><polygon points="'.(int)($ax+$gap-12).',222 '.(int)($ax+$gap-34).',208 '.(int)($ax+$gap-34).',236" fill="#f2b134"/>';}$x+=$w+$gap;}
		$c.='<rect x="50" y="370" width="620" height="86" rx="18" fill="#f2b134"/><text x="360" y="422" fill="#172b3a" font-family="system-ui,sans-serif" font-size="21" font-weight="800" text-anchor="middle">'.esc_html($data[2]).'</text>';
		return '<svg class="gb-road-svg" viewBox="0 0 720 520" role="img" aria-label="'.esc_attr($data[0].'. '.$data[2]).'" data-gb-scene="'.esc_attr($name).'">'.$c.'</svg>';
	}
}
