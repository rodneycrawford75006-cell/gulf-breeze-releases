<?php
/**
 * Adult English Topic 4.1.7 interactive visual labs.
 * Gulf Breeze Driving School / Rodney Crawford.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class GB_Adult_Topic_Seven_Visual_Labs {
	public static function render( $key ) {
		$labs = self::labs();
		if ( empty( $labs[ $key ] ) ) {
			return '';
		}
		$lab = $labs[ $key ];
		$uid = 'gb-road-sharing-' . sanitize_html_class( $key );
		$html = '<section class="gb-road-lab" aria-labelledby="' . esc_attr( $uid ) . '-heading">';
		$html .= '<h2 class="gb-road-lab__heading" id="' . esc_attr( $uid ) . '-heading">' . esc_html( $lab['title'] ) . '</h2>';
		$html .= '<p class="gb-road-lab__intro">' . esc_html( $lab['intro'] ) . '</p>';
		$html .= '<div class="gb-road-lab__controls" role="group" aria-label="Choose a visual step">';
		foreach ( $lab['steps'] as $index => $step ) {
			$panel_id = $uid . '-panel-' . ( $index + 1 );
			$html .= '<button type="button" class="gb-road-lab__button" aria-controls="' . esc_attr( $panel_id ) . '" aria-pressed="' . ( 0 === $index ? 'true' : 'false' ) . '">' . esc_html( ( $index + 1 ) . '. ' . $step['label'] ) . '</button>';
		}
		$html .= '</div><div class="gb-road-lab__stage">';
		foreach ( $lab['steps'] as $index => $step ) {
			$panel_id = $uid . '-panel-' . ( $index + 1 );
			$html .= '<div class="gb-road-lab__panel" id="' . esc_attr( $panel_id ) . '"' . ( 0 === $index ? '' : ' hidden' ) . '>';
			$html .= '<figure class="gb-road-lab__figure">' . self::scene( $step['scene'] );
			$html .= '<figcaption class="gb-road-lab__caption"><strong>' . esc_html( $step['lead'] ) . '</strong> ' . esc_html( $step['caption'] ) . '</figcaption></figure></div>';
		}
		return $html . '</div></section>';
	}

	private static function labs() {
		return array(
			'adult_en_032' => array(
				'title' => 'Share the Road by Protecting the Most Vulnerable User',
				'intro' => 'The safer driver detects each user early, predicts lawful or unexpected movement, and creates enough time and space for either person to make a mistake.',
				'steps' => array(
					array( 'label' => 'Search before turning', 'scene' => 'vulnerable_turn', 'lead' => 'Scan the whole crossing path:', 'caption' => 'Search sidewalks, both crosswalk ends, bicycle lanes, mirrors, and the blind area again immediately before the vehicle turns.' ),
					array( 'label' => 'Give cyclists room', 'scene' => 'vulnerable_cyclist', 'lead' => 'Expect lawful lateral movement:', 'caption' => 'A cyclist may move left around a drain, debris, parked door, or lane too narrow to share. Slow and wait for a fully clear passing path.' ),
					array( 'label' => 'Judge motorcycles twice', 'scene' => 'vulnerable_motorcycle', 'lead' => 'Small does not mean far away:', 'caption' => 'A motorcycle’s narrow profile can distort speed and distance. Look again, preserve a full lane, and accept only a clearly safe gap.' ),
				),
			),
			'adult_en_033' => array(
				'title' => 'Stay Visible and Never Compete with a Large Vehicle',
				'intro' => 'Trucks, buses, and oversize loads need more room to see, stop, turn, and recover. The smaller vehicle must stay out of the space the larger vehicle needs.',
				'steps' => array(
					array( 'label' => 'Escape the blind areas', 'scene' => 'truck_blind', 'lead' => 'See the driver or create distance:', 'caption' => 'If the truck driver is not visible in a side mirror, assume your vehicle may not be visible. Do not linger beside or follow closely.' ),
					array( 'label' => 'Protect the wide turn', 'scene' => 'truck_turn', 'lead' => 'The curb-side opening is a trap:', 'caption' => 'A long vehicle may move left before turning right while its rear wheels track toward the curb. Stay behind and never squeeze alongside.' ),
					array( 'label' => 'Wait behind an oversize load', 'scene' => 'truck_oversize', 'lead' => 'Uncertainty means wait:', 'caption' => 'Increase following space, read escort directions, and pass only when the complete path is legal, visible, and wide enough for the entire maneuver.' ),
				),
			),
			'adult_en_034' => array(
				'title' => 'Treat a Work Zone as a New Temporary Road',
				'intro' => 'Orange controls can change the lane, speed, surface, shoulder, and right-of-way pattern. Read the temporary system early and follow it instead of habit or navigation.',
				'steps' => array(
					array( 'label' => 'Read the temporary path', 'scene' => 'work_path', 'lead' => 'Orange controls redefine the road:', 'caption' => 'Slow before the queue, increase space, and follow the active signs, channelizers, barriers, markings, and flagger directions.' ),
					array( 'label' => 'Stop for the flagger', 'scene' => 'work_flagger', 'lead' => 'A visible opening is not permission:', 'caption' => 'Stop where directed and remain stopped until the flagger releases your movement. Hidden equipment or opposing traffic may control the gap.' ),
				),
			),
			'adult_en_035' => array(
				'title' => 'After a Crash: Protect Life Before Property or Proof',
				'intro' => 'A calm sequence prevents a second collision, gets trained help moving, and preserves the duties that must be completed after immediate danger is controlled.',
				'steps' => array(
					array( 'label' => 'Follow the response order', 'scene' => 'crash_order', 'lead' => 'Stop, protect, call, assist, exchange:', 'caption' => 'Stop close to the scene, protect people without entering moving lanes, call 911 when needed, render reasonable assistance, and exchange required information.' ),
					array( 'label' => 'Help within your training', 'scene' => 'crash_help', 'lead' => 'Good faith does not replace caution:', 'caption' => 'Follow dispatch instructions, avoid moving an injured person unless immediate danger requires it, and do not exceed your training.' ),
				),
			),
			'adult_en_036' => array(
				'title' => 'Prevent Escalation, Load Failure, and Invisible Exhaust Danger',
				'intro' => 'These risks look different, but the defensive pattern is the same: recognize the warning early, create space, and refuse to continue until the unsafe condition is removed.',
				'steps' => array(
					array( 'label' => 'Exit road-rage conflict', 'scene' => 'rage_exit', 'lead' => 'Distance is the objective:', 'caption' => 'Do not gesture, pursue, block, or brake-check. Create space, avoid driving home if followed, and call 911 hands-free when threatened.' ),
					array( 'label' => 'Complete the tow check', 'scene' => 'tow_check', 'lead' => 'Every connection matters:', 'caption' => 'Verify coupler, safety device, breakaway equipment, lights, load balance, ratings, and securement before moving—and recheck during the trip.' ),
					array( 'label' => 'Respond to carbon monoxide', 'scene' => 'carbon_monoxide', 'lead' => 'Symptoms require immediate action:', 'caption' => 'Headache, dizziness, weakness, nausea, or confusion can signal exhaust exposure. Stop safely, reach fresh air, call for help, and have the vehicle inspected.' ),
				),
			),
		);
	}

	private static function scene( $scene ) {
		switch ( $scene ) {
			case 'vulnerable_turn': return self::scene_vulnerable_turn();
			case 'vulnerable_cyclist': return self::scene_vulnerable_cyclist();
			case 'vulnerable_motorcycle': return self::scene_vulnerable_motorcycle();
			case 'truck_blind': return self::scene_truck_blind();
			case 'truck_turn': return self::scene_truck_turn();
			case 'truck_oversize': return self::scene_truck_oversize();
			case 'work_path': return self::scene_work_path();
			case 'work_flagger': return self::scene_work_flagger();
			case 'crash_order': return self::scene_crash_order();
			case 'crash_help': return self::scene_crash_help();
			case 'rage_exit': return self::scene_rage_exit();
			case 'tow_check': return self::scene_tow_check();
			case 'carbon_monoxide': return self::scene_carbon_monoxide();
			default: return '';
		}
	}

	private static function svg( $label, $content ) {
		return '<svg class="gb-road-svg" viewBox="0 0 720 520" role="img" aria-label="' . esc_attr( $label ) . '"><rect width="720" height="520" fill="#eef5f8"/>' . $content . '</svg>';
	}

	private static function note( $x, $y, $text, $size = 22, $fill = '#172b3a' ) {
		return '<text x="' . (int) $x . '" y="' . (int) $y . '" fill="' . esc_attr( $fill ) . '" font-family="system-ui,sans-serif" font-size="' . (int) $size . '" font-weight="750" text-anchor="middle">' . esc_html( $text ) . '</text>';
	}

	private static function card( $x, $y, $w, $h, $title, $detail, $color = '#123b5d' ) {
		return '<g><rect x="' . (int) $x . '" y="' . (int) $y . '" width="' . (int) $w . '" height="' . (int) $h . '" rx="18" fill="' . esc_attr( $color ) . '"/><text x="' . (int) ( $x + $w / 2 ) . '" y="' . (int) ( $y + 43 ) . '" fill="#fff" font-family="system-ui,sans-serif" font-size="22" font-weight="800" text-anchor="middle">' . esc_html( $title ) . '</text><text x="' . (int) ( $x + $w / 2 ) . '" y="' . (int) ( $y + 78 ) . '" fill="#fff" font-family="system-ui,sans-serif" font-size="17" font-weight="650" text-anchor="middle">' . esc_html( $detail ) . '</text></g>';
	}

	private static function arrow( $x1, $y1, $x2, $y2, $color = '#1769aa' ) {
		return '<path d="M' . (int) $x1 . ' ' . (int) $y1 . ' L' . (int) $x2 . ' ' . (int) $y2 . '" stroke="' . esc_attr( $color ) . '" stroke-width="10" stroke-linecap="round"/><polygon points="' . (int) $x2 . ',' . (int) $y2 . ' ' . (int) ( $x2 - 27 ) . ',' . (int) ( $y2 - 18 ) . ' ' . (int) ( $x2 - 27 ) . ',' . (int) ( $y2 + 18 ) . '" fill="' . esc_attr( $color ) . '"/>';
	}

	private static function car( $x, $y, $color = '#1769aa' ) {
		return '<g transform="translate(' . (int) $x . ' ' . (int) $y . ')"><rect x="0" y="24" width="112" height="52" rx="14" fill="' . esc_attr( $color ) . '"/><path d="M20 25 L38 4 H78 L96 25" fill="' . esc_attr( $color ) . '"/><circle cx="24" cy="78" r="13" fill="#172b3a"/><circle cx="88" cy="78" r="13" fill="#172b3a"/></g>';
	}

	private static function scene_vulnerable_turn() {
		$c = '<rect x="0" y="180" width="720" height="220" fill="#667784"/><rect x="270" y="180" width="180" height="220" fill="#3f4b54"/><g stroke="#fff" stroke-width="14">';
		for ( $x = 25; $x < 720; $x += 70 ) { $c .= '<path d="M' . $x . ' 250 h38"/>'; }
		$c .= '</g>' . self::car( 300, 330, '#1769aa' ) . '<circle cx="190" cy="135" r="25" fill="#f2b134"/><path d="M190 160 v80 m0 -50 l-35 45 m35 -45 l38 42 m-38 8 l-30 50 m30 -50 l32 50" stroke="#172b3a" stroke-width="13" stroke-linecap="round" fill="none"/>';
		$c .= '<circle cx="530" cy="235" r="72" fill="none" stroke="#f2b134" stroke-width="11"/>' . self::note( 530, 225, 'SCAN AGAIN', 20 ) . self::note( 530, 260, 'BEFORE TURN', 20 ) . self::arrow( 460, 365, 555, 310, '#18794e' );
		return self::svg( 'A car waits before a crosswalk while a pedestrian crosses; a highlighted search area shows where the driver must scan again before turning.', $c );
	}

	private static function scene_vulnerable_cyclist() {
		$c = '<rect y="290" width="720" height="230" fill="#667784"/><path d="M0 410 H720" stroke="#fff" stroke-width="10" stroke-dasharray="42 26"/><circle cx="300" cy="350" r="43" fill="none" stroke="#172b3a" stroke-width="10"/><circle cx="430" cy="350" r="43" fill="none" stroke="#172b3a" stroke-width="10"/><path d="M300 350 L350 275 L405 350 L345 350 L390 285" stroke="#1769aa" stroke-width="12" fill="none" stroke-linejoin="round"/><circle cx="365" cy="225" r="24" fill="#f2b134"/><path d="M365 250 l-15 42 l40 -7" stroke="#172b3a" stroke-width="12" fill="none" stroke-linecap="round"/>';
		$c .= '<rect x="470" y="295" width="80" height="28" rx="8" fill="#b8c7cf"/><circle cx="505" cy="309" r="8" fill="#667784"/>' . self::arrow( 350, 270, 270, 235, '#18794e' ) . self::card( 35, 70, 250, 115, 'HAZARD AHEAD', 'EXPECT MOVEMENT LEFT', '#d96b34' ) . self::card( 435, 70, 250, 115, 'DRIVER RESPONSE', 'SLOW • WAIT • PASS WIDE', '#18794e' );
		return self::svg( 'A cyclist moves left around a drain hazard while the driver response panel calls for slowing, waiting, and passing with ample room.', $c );
	}

	private static function scene_vulnerable_motorcycle() {
		$c = self::card( 35, 70, 265, 125, 'FIRST GLANCE', 'SMALL PROFILE', '#d96b34' ) . self::card( 420, 70, 265, 125, 'SECOND LOOK', 'SPEED + DISTANCE', '#18794e' ) . self::arrow( 310, 132, 405, 132 );
		$c .= '<path d="M80 440 L320 245 L640 440" fill="#3f4b54"/><path d="M360 440 L360 285" stroke="#fff" stroke-width="12" stroke-dasharray="35 25"/><circle cx="362" cy="308" r="20" fill="none" stroke="#f2b134" stroke-width="8"/><circle cx="400" cy="308" r="20" fill="none" stroke="#f2b134" stroke-width="8"/><path d="M362 308 l18 -30 l20 30 m-20 -30 l14 -20" stroke="#172b3a" stroke-width="7" fill="none"/>' . self::note( 360, 485, 'CLEAR GAP — NOT A GUESS', 24 );
		return self::svg( 'A roadway perspective makes a motorcycle look small, while a two-step panel instructs the driver to look again and judge speed and distance before accepting a gap.', $c );
	}

	private static function scene_truck_blind() {
		$c = '<rect y="365" width="720" height="155" fill="#667784"/><rect x="245" y="195" width="280" height="155" rx="14" fill="#123b5d"/><rect x="95" y="225" width="155" height="125" rx="16" fill="#1769aa"/><rect x="115" y="245" width="78" height="55" fill="#cfe7f1"/><circle cx="165" cy="365" r="30" fill="#172b3a"/><circle cx="310" cy="365" r="30" fill="#172b3a"/><circle cx="465" cy="365" r="30" fill="#172b3a"/>';
		$c .= '<path d="M80 190 L225 215 L195 90 Z" fill="#b42318" opacity=".78"/><path d="M505 210 L700 150 L700 300 Z" fill="#b42318" opacity=".78"/><path d="M255 180 L520 95 L570 180 Z" fill="#d96b34" opacity=".78"/><path d="M255 365 L560 500 L245 500 Z" fill="#d96b34" opacity=".78"/>' . self::note( 360, 58, 'RED / ORANGE = DO NOT LINGER', 25 );
		return self::svg( 'A tractor-trailer is surrounded by highlighted front, rear, and side blind areas, emphasizing that smaller vehicles must not linger there.', $c );
	}

	private static function scene_truck_turn() {
		$c = '<rect x="0" y="300" width="720" height="220" fill="#667784"/><rect x="500" y="0" width="220" height="520" fill="#667784"/><path d="M610 485 C610 300 540 260 350 260" stroke="#f2b134" stroke-width="18" fill="none" stroke-dasharray="34 20"/>';
		$c .= '<g transform="translate(380 155) rotate(8)"><rect width="245" height="90" rx="14" fill="#123b5d"/><rect x="205" y="0" width="90" height="90" rx="14" fill="#1769aa"/><circle cx="45" cy="94" r="18" fill="#172b3a"/><circle cx="205" cy="94" r="18" fill="#172b3a"/><circle cx="270" cy="94" r="18" fill="#172b3a"/></g>';
		$c .= '<path d="M485 285 L660 430 L565 475 L420 335 Z" fill="#b42318" opacity=".82"/>' . self::note( 535, 382, 'NO CAR HERE', 24, '#fff' ) . self::card( 25, 55, 300, 120, 'WIDE RIGHT TURN', 'STAY BEHIND THE TRUCK', '#18794e' );
		return self::svg( 'A long truck swings wide before a right turn; the curb-side tracking area is marked as a space where a car must never enter.', $c );
	}

	private static function scene_truck_oversize() {
		$c = '<rect y="340" width="720" height="180" fill="#667784"/><rect x="205" y="225" width="340" height="120" rx="12" fill="#d96b34"/><rect x="250" y="175" width="250" height="65" rx="12" fill="#f2b134"/><circle cx="265" cy="360" r="28" fill="#172b3a"/><circle cx="480" cy="360" r="28" fill="#172b3a"/>' . self::note( 375, 218, 'OVERSIZE LOAD', 24 );
		$c .= self::car( 35, 365, '#1769aa' ) . self::car( 575, 365, '#1769aa' ) . '<path d="M150 400 H195 M545 400 H570" stroke="#18794e" stroke-width="12" stroke-dasharray="16 10"/>' . self::card( 55, 55, 610, 110, 'PASS ONLY WITH A COMPLETE, LEGAL, VISIBLE PATH', 'READ ESCORT DIRECTIONS • ALLOW WIDTH • ALLOW TIME', '#123b5d' );
		return self::svg( 'An oversize load with escort vehicles occupies the roadway while the rule requires a complete, legal, visible path before passing.', $c );
	}

	private static function scene_work_path() {
		$c = '<rect y="230" width="720" height="290" fill="#667784"/><path d="M150 520 C180 390 250 300 360 230 M570 520 C520 390 470 300 360 230" stroke="#fff" stroke-width="11" fill="none"/>';
		for ( $i = 0; $i < 5; $i++ ) { $x = 85 + $i * 115; $y = 430 - $i * 42; $c .= '<g transform="translate(' . $x . ' ' . $y . ')"><path d="M0 42 L20 0 L40 42 Z" fill="#d96b34"/><rect x="-8" y="42" width="56" height="10" fill="#172b3a"/></g>'; }
		$c .= '<rect x="510" y="70" width="155" height="155" rx="12" fill="#d96b34" transform="rotate(45 588 148)"/>' . self::note( 588, 142, 'LANE', 22 ) . self::note( 588, 175, 'SHIFT', 22 ) . self::arrow( 210, 170, 350, 240, '#18794e' ) . self::card( 25, 55, 300, 110, 'SLOW BEFORE THE SHIFT', 'FOLLOW ORANGE CONTROLS', '#18794e' );
		return self::svg( 'Orange cones and a lane-shift sign create a new temporary roadway path, with instruction to slow before the shift and follow active controls.', $c );
	}

	private static function scene_work_flagger() {
		$c = '<rect y="340" width="720" height="180" fill="#667784"/><circle cx="360" cy="115" r="32" fill="#d59a73"/><path d="M360 150 v155 m0 -100 l-80 55 m80 -55 l78 55 m-78 45 l-55 90 m55 -90 l60 90" stroke="#172b3a" stroke-width="18" stroke-linecap="round" fill="none"/><path d="M315 165 L405 165 L430 285 L290 285 Z" fill="#f2b134" opacity=".9"/>';
		$c .= '<circle cx="225" cy="225" r="72" fill="#b42318" stroke="#fff" stroke-width="8"/>' . self::note( 225, 236, 'STOP', 31, '#fff' ) . self::car( 45, 375, '#1769aa' ) . '<path d="M168 420 H280" stroke="#fff" stroke-width="12"/>' . self::card( 455, 70, 230, 125, 'RELEASE CONTROLS', 'NOT THE OPEN VIEW', '#123b5d' );
		return self::svg( 'A flagger holds a stop paddle in front of a waiting car; the driver remains stopped because the flagger, not the apparent opening, controls movement.', $c );
	}

	private static function scene_crash_order() {
		$c = self::note( 360, 55, 'AFTER A CRASH — USE THE ORDER', 28 );
		$steps = array( array( 20, '1', 'STOP' ), array( 160, '2', 'PROTECT' ), array( 300, '3', 'CALL' ), array( 440, '4', 'ASSIST' ), array( 580, '5', 'EXCHANGE' ) );
		foreach ( $steps as $index => $step ) {
			$c .= '<circle cx="' . ( $step[0] + 60 ) . '" cy="250" r="54" fill="' . ( 2 === $index ? '#b42318' : '#123b5d' ) . '"/>' . self::note( $step[0] + 60, 262, $step[1], 32, '#fff' ) . self::note( $step[0] + 60, 340, $step[2], 18 );
			if ( $index < 4 ) { $c .= self::arrow( $step[0] + 116, 250, $step[0] + 142, 250, '#18794e' ); }
		}
		$c .= '<rect x="75" y="405" width="570" height="72" rx="18" fill="#f2b134"/>' . self::note( 360, 450, 'LIFE AND SCENE SAFETY COME BEFORE PHOTOS OR ARGUMENT', 18 );
		return self::svg( 'Five numbered steps show the crash-response order: stop, protect, call, assist, and exchange required information.', $c );
	}

	private static function scene_crash_help() {
		$c = self::card( 35, 80, 285, 135, 'IMMEDIATE DANGER', 'MOVE ONLY IF NEEDED', '#b42318' ) . self::card( 400, 80, 285, 135, 'NO IMMEDIATE DANGER', 'WAIT • REASSURE • GUIDE', '#18794e' );
		$c .= '<circle cx="360" cy="335" r="80" fill="#1769aa"/>' . self::note( 360, 325, 'CALL 911', 27, '#fff' ) . self::note( 360, 360, 'FOLLOW DISPATCH', 19, '#fff' ) . self::arrow( 210, 235, 315, 295 ) . self::arrow( 510, 235, 405, 295, '#18794e' ) . self::note( 360, 470, 'GOOD FAITH • WITHIN TRAINING • NO RECKLESS ACTION', 20 );
		return self::svg( 'Two branches distinguish immediate danger from no immediate danger, and both lead to calling 911 and following dispatch within the helper’s training.', $c );
	}

	private static function scene_rage_exit() {
		$c = self::car( 80, 220, '#b42318' ) . self::car( 250, 330, '#1769aa' ) . '<path d="M170 260 C250 250 275 275 300 330" stroke="#b42318" stroke-width="12" fill="none" stroke-dasharray="18 14"/>';
		$c .= self::arrow( 365, 380, 550, 300, '#18794e' ) . self::card( 455, 70, 230, 130, 'SAFE EXIT', 'PUBLIC PLACE / 911', '#18794e' ) . self::card( 35, 65, 300, 115, 'DO NOT ENGAGE', 'NO GESTURE • CHASE • BLOCK', '#123b5d' ) . self::note( 360, 475, 'CREATE SPACE — DO NOT DRIVE HOME IF FOLLOWED', 22 );
		return self::svg( 'A threatened driver creates distance from an aggressive vehicle and heads toward a safe public place while avoiding engagement and calling 911 if needed.', $c );
	}

	private static function scene_tow_check() {
		$c = self::note( 360, 55, 'BEFORE THE TRAILER MOVES', 28 );
		$items = array( array( 35, 95, 'COUPLER', 'LOCKED' ), array( 260, 95, 'CHAINS', 'CONNECTED' ), array( 485, 95, 'BREAKAWAY', 'ATTACHED' ), array( 35, 270, 'LIGHTS', 'TESTED' ), array( 260, 270, 'LOAD', 'LOW + SECURE' ), array( 485, 270, 'RATINGS', 'NOT EXCEEDED' ) );
		foreach ( $items as $item ) { $c .= self::card( $item[0], $item[1], 200, 125, $item[2], $item[3], '#18794e' ); }
		$c .= '<rect x="115" y="440" width="490" height="52" rx="16" fill="#f2b134"/>' . self::note( 360, 474, 'RECHECK CONNECTIONS AND SECUREMENT DURING THE TRIP', 18 );
		return self::svg( 'A six-item trailer checklist verifies the coupler, chains, breakaway system, lights, load, and ratings before movement.', $c );
	}

	private static function scene_carbon_monoxide() {
		$c = '<rect x="60" y="245" width="310" height="145" rx="24" fill="#1769aa"/><path d="M110 250 L165 180 H285 L335 250" fill="#1769aa"/><circle cx="130" cy="405" r="34" fill="#172b3a"/><circle cx="305" cy="405" r="34" fill="#172b3a"/><path d="M375 330 C450 295 440 245 500 235 C570 225 555 170 650 160" stroke="#667784" stroke-width="24" fill="none" opacity=".75"/>';
		$c .= self::card( 430, 300, 255, 135, 'SYMPTOMS', 'HEADACHE • DIZZY • WEAK', '#b42318' ) . self::card( 35, 55, 300, 115, '1. STOP SAFELY', 'EXIT TO FRESH AIR', '#18794e' ) . self::card( 385, 55, 300, 115, '2. GET HELP', 'CALL • INSPECT VEHICLE', '#123b5d' );
		return self::svg( 'Exhaust enters the area around a vehicle while the response panels direct occupants to stop safely, reach fresh air, call for help, and inspect the vehicle.', $c );
	}
}
