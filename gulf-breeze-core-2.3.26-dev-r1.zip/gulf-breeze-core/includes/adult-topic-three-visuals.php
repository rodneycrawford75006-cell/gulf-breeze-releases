<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class GB_Adult_Topic_Three_Visuals {
	public static function render( $key ) {
		$labs = self::labs();
		if ( empty( $labs[ $key ] ) ) {
			return '';
		}
		$lab = $labs[ $key ];
		$uid = 'gb-road-' . sanitize_html_class( $key );
		$html = '<section class="gb-road-lab" aria-labelledby="' . esc_attr( $uid ) . '-heading">';
		$html .= '<h2 class="gb-road-lab__heading" id="' . esc_attr( $uid ) . '-heading">' . esc_html( $lab['title'] ) . '</h2>';
		$html .= '<p class="gb-road-lab__intro">' . esc_html( $lab['intro'] ) . '</p>';
		$html .= '<div class="gb-road-lab__controls" role="group" aria-label="Choose a visual step">';
		foreach ( $lab['steps'] as $index => $step ) {
			$panel_id = $uid . '-panel-' . ( $index + 1 );
			$html .= '<button type="button" class="gb-road-lab__button" aria-controls="' . esc_attr( $panel_id ) . '" aria-pressed="' . ( 0 === $index ? 'true' : 'false' ) . '">' . esc_html( ( $index + 1 ) . '. ' . $step['label'] ) . '</button>';
		}
		$html .= '</div><div class="gb-road-lab__stage">';
		foreach ( $lab['steps'] as $index => $step ) {
			$panel_id = $uid . '-panel-' . ( $index + 1 );
			$html .= '<div class="gb-road-lab__panel" id="' . esc_attr( $panel_id ) . '"' . ( 0 === $index ? '' : ' hidden' ) . '>';
			$html .= '<figure class="gb-road-lab__figure">' . self::scene( $step['scene'] );
			$html .= '<figcaption class="gb-road-lab__caption"><strong>' . esc_html( $step['lead'] ) . '</strong> ' . esc_html( $step['caption'] ) . '</figcaption></figure></div>';
		}
		$html .= '</div></section>';
		return $html;
	}

	private static function labs() {
		return array(
			'adult_en_010' => array(
				'title' => 'See Right-of-Way as a Decision',
				'intro' => 'Use the steps to separate legal priority from the continuing duty to avoid a crash.',
				'steps' => array(
					array( 'label' => 'Identify the conflict', 'scene' => 'blocked-detect', 'lead' => 'Detect:', 'caption' => 'Vehicle A has permission to move, but Vehicle C still blocks the intersection.' ),
					array( 'label' => 'Wait and protect', 'scene' => 'blocked-wait', 'lead' => 'Yield to reality:', 'caption' => 'Vehicle A stays behind the stop line. A green signal never authorizes entering a blocked path.' ),
					array( 'label' => 'Proceed when clear', 'scene' => 'blocked-go', 'lead' => 'Accept cautiously:', 'caption' => 'Vehicle A proceeds only after Vehicle C clears and a fresh search confirms the complete path is open.' ),
				),
			),
			'adult_en_011' => array(
				'title' => 'Four-Way Stop: Arrival Order Controls',
				'intro' => 'Both vehicles stop completely. The first arrival normally proceeds first.',
				'steps' => array(
					array( 'label' => 'Compare arrivals', 'scene' => 'allway-arrive', 'lead' => 'Arrival:', 'caption' => 'Vehicle A reaches a complete stop first. Vehicle B reaches its stop line second.' ),
					array( 'label' => 'Apply the rule', 'scene' => 'allway-yield', 'lead' => 'Yield decision:', 'caption' => 'Vehicle B remains stopped because Vehicle A arrived first.' ),
					array( 'label' => 'Confirm and proceed', 'scene' => 'allway-go', 'lead' => 'Proceed:', 'caption' => 'Vehicle A searches again and crosses. Vehicle B waits until the conflict area is clear.' ),
				),
			),
			'adult_en_012' => array(
				'title' => 'Left Turn Across Approaching Traffic',
				'intro' => 'A turn signal communicates intent; it does not give the turning driver priority.',
				'steps' => array(
					array( 'label' => 'Find the conflict', 'scene' => 'leftturn-detect', 'lead' => 'Conflict:', 'caption' => 'Vehicle A intends to turn left across the path of approaching Vehicle B.' ),
					array( 'label' => 'Yield to approaching traffic', 'scene' => 'leftturn-wait', 'lead' => 'Yield:', 'caption' => 'Vehicle A waits because Vehicle B is close enough to be an immediate hazard.' ),
					array( 'label' => 'Turn into the lawful lane', 'scene' => 'leftturn-go', 'lead' => 'Turn:', 'caption' => 'After Vehicle B passes and the path is clear, Vehicle A turns smoothly into the lawful lane.' ),
				),
			),
			'adult_en_013' => array(
				'title' => 'The Pedestrian Hidden by a Stopped Vehicle',
				'intro' => 'A stopped vehicle at a crosswalk is a warning to slow and search, not an invitation to pass.',
				'steps' => array(
					array( 'label' => 'Notice the stopped vehicle', 'scene' => 'ped-hidden', 'lead' => 'Warning:', 'caption' => 'Vehicle B is stopped before the crosswalk. Its body blocks Vehicle A’s view of the pedestrian.' ),
					array( 'label' => 'Slow and uncover the view', 'scene' => 'ped-detect', 'lead' => 'Search:', 'caption' => 'Vehicle A slows and stays back until the reason for the stop becomes visible.' ),
					array( 'label' => 'Wait until fully clear', 'scene' => 'ped-wait', 'lead' => 'Protect:', 'caption' => 'Both vehicles remain stopped until the pedestrian has cleared the complete conflict area.' ),
				),
			),
			'adult_en_014' => array(
				'title' => 'Protected Vehicles: Read the Roadway First',
				'intro' => 'The vehicle, its signals, and the roadway division determine the driver’s duty.',
				'steps' => array(
					array( 'label' => 'Undivided roadway', 'scene' => 'bus-undivided', 'lead' => 'Stop both directions:', 'caption' => 'On this undivided roadway, traffic approaching the bus from either direction stops for activated red bus signals.' ),
					array( 'label' => 'Physically divided roadway', 'scene' => 'bus-divided', 'lead' => 'Read the separation:', 'caption' => 'A physical median separates the opposite roadway. Do not confuse a painted center lane with this physical division.' ),
					array( 'label' => 'Move over or slow down', 'scene' => 'move-over', 'lead' => 'Create space:', 'caption' => 'Vehicle A moves out of the closest lane when safe. If it cannot, it slows as Texas law requires.' ),
				),
			),
			'adult_en_015' => array(
				'title' => 'Railroad Crossing: Decide Before the Tracks',
				'intro' => 'Never begin crossing unless the entire vehicle can clear every rail without stopping.',
				'steps' => array(
					array( 'label' => 'Stop in the legal zone', 'scene' => 'rail-stop', 'lead' => 'Stop:', 'caption' => 'When a stop is required, remain between 15 and 50 feet from the nearest rail.' ),
					array( 'label' => 'Verify far-side clearance', 'scene' => 'rail-blocked', 'lead' => 'Wait before the tracks:', 'caption' => 'Traffic blocks the far side. Vehicle A does not enter even though no train is visible.' ),
					array( 'label' => 'Escape toward the train', 'scene' => 'rail-escape', 'lead' => 'If trapped:', 'caption' => 'Exit immediately and move away from the tracks toward the approaching train so debris travels away from you.' ),
				),
			),
		);
	}

	private static function scene( $scene ) {
		switch ( $scene ) {
			case 'blocked-detect': return self::scene_blocked_detect();
			case 'blocked-wait': return self::scene_blocked_wait();
			case 'blocked-go': return self::scene_blocked_go();
			case 'allway-arrive': return self::scene_allway_arrive();
			case 'allway-yield': return self::scene_allway_yield();
			case 'allway-go': return self::scene_allway_go();
			case 'leftturn-detect': return self::scene_leftturn_detect();
			case 'leftturn-wait': return self::scene_leftturn_wait();
			case 'leftturn-go': return self::scene_leftturn_go();
			case 'ped-hidden': return self::scene_ped_hidden();
			case 'ped-detect': return self::scene_ped_detect();
			case 'ped-wait': return self::scene_ped_wait();
			case 'bus-undivided': return self::scene_bus_undivided();
			case 'bus-divided': return self::scene_bus_divided();
			case 'move-over': return self::scene_move_over();
			case 'rail-stop': return self::scene_rail_stop();
			case 'rail-blocked': return self::scene_rail_blocked();
			case 'rail-escape': return self::scene_rail_escape();
			default: return '';
		}
	}

	private static function svg( $label, $content ) {
		return '<svg class="gb-road-svg" viewBox="0 0 720 520" role="img" aria-label="' . esc_attr( $label ) . '"><rect class="gb-ground" width="720" height="520"/>' . $content . '</svg>';
	}

	private static function intersection() {
		return '<rect class="gb-road" x="255" width="210" height="520"/><rect class="gb-road" y="155" width="720" height="210"/><line class="gb-lane" x1="360" y1="0" x2="360" y2="135"/><line class="gb-lane" x1="360" y1="385" x2="360" y2="520"/><line class="gb-lane" x1="0" y1="260" x2="235" y2="260"/><line class="gb-lane" x1="485" y1="260" x2="720" y2="260"/><line class="gb-stop-line" x1="265" y1="390" x2="350" y2="390"/><line class="gb-stop-line" x1="470" y1="285" x2="470" y2="355"/>';
	}

	private static function vertical_road() {
		return '<rect class="gb-road" x="165" width="390" height="520"/><line class="gb-center" x1="360" y1="0" x2="360" y2="520"/><line class="gb-lane" x1="260" y1="0" x2="260" y2="520"/><line class="gb-lane" x1="460" y1="0" x2="460" y2="520"/>';
	}

	private static function car( $x, $y, $rotation, $label, $color = '#2d78c4', $length = 110 ) {
		$half = (int) round( $length / 2 );
		return '<g transform="translate(' . (int) $x . ' ' . (int) $y . ') rotate(' . (int) $rotation . ')"><rect x="-34" y="-' . $half . '" width="68" height="' . (int) $length . '" rx="20" fill="' . esc_attr( $color ) . '" stroke="#172b3a" stroke-width="3"/><rect x="-24" y="-' . ( $half - 16 ) . '" width="48" height="44" rx="9" fill="#eaf3f8" opacity=".86"/><circle cx="0" cy="8" r="20" fill="#123b5d"/><text class="gb-label" x="0" y="9">' . esc_html( $label ) . '</text></g>';
	}

	private static function stop_badge( $x, $y, $text = 'WAIT' ) {
		return '<g transform="translate(' . (int) $x . ' ' . (int) $y . ')"><circle r="38" fill="#ffffff" stroke="#b42318" stroke-width="7"/><text class="gb-note" x="0" y="8">' . esc_html( $text ) . '</text></g>';
	}

	private static function scene_blocked_detect() {
		$c = self::intersection() . self::car( 305, 450, 0, 'A' ) . self::car( 380, 250, 90, 'C', '#d96b34', 150 ) . '<rect class="gb-zone" x="255" y="155" width="210" height="210" rx="8"/>';
		return self::svg( 'Vehicle A waits south of an intersection that is blocked by Vehicle C.', $c );
	}

	private static function scene_blocked_wait() {
		$c = self::intersection() . self::car( 305, 450, 0, 'A' ) . self::car( 380, 250, 90, 'C', '#d96b34', 150 ) . self::stop_badge( 175, 420 );
		return self::svg( 'Vehicle A remains behind the stop line while Vehicle C blocks the intersection.', $c );
	}

	private static function scene_blocked_go() {
		$c = self::intersection() . self::car( 305, 335, 0, 'A' ) . self::car( 610, 250, 90, 'C', '#d96b34', 150 ) . '<path class="gb-path-a" d="M305 465 L305 205"/><polygon class="gb-safe" points="305,170 282,215 328,215"/>';
		return self::svg( 'Vehicle C has cleared the intersection and Vehicle A proceeds after checking again.', $c );
	}

	private static function scene_allway_arrive() {
		$c = self::intersection() . self::car( 305, 450, 0, 'A' ) . self::car( 555, 310, -90, 'B', '#d96b34' ) . '<circle cx="220" cy="445" r="30" fill="#123b5d"/><text class="gb-label" x="220" y="447">1</text><circle cx="625" cy="310" r="30" fill="#8a5b00"/><text class="gb-label" x="625" y="312">2</text>';
		return self::svg( 'Vehicle A arrived first and Vehicle B arrived second at a four-way stop.', $c );
	}

	private static function scene_allway_yield() {
		$c = self::intersection() . self::car( 305, 450, 0, 'A' ) . self::car( 555, 310, -90, 'B', '#d96b34' ) . '<path class="gb-path-a" d="M305 395 L305 210"/><polygon class="gb-safe" points="305,175 282,220 328,220"/>' . self::stop_badge( 620, 410 );
		return self::svg( 'Vehicle B waits while Vehicle A prepares to proceed first.', $c );
	}

	private static function scene_allway_go() {
		$c = self::intersection() . self::car( 305, 235, 0, 'A' ) . self::car( 555, 310, -90, 'B', '#d96b34' ) . '<path class="gb-path-a" d="M305 430 L305 90"/><polygon class="gb-safe" points="305,55 282,100 328,100"/>' . self::stop_badge( 620, 410 );
		return self::svg( 'Vehicle A crosses the intersection while Vehicle B remains stopped.', $c );
	}

	private static function scene_leftturn_detect() {
		$c = self::intersection() . self::car( 305, 450, 0, 'A' ) . self::car( 410, 70, 180, 'B', '#d96b34' ) . '<path class="gb-path-a" d="M305 400 C305 305 350 260 480 260"/><path class="gb-path-b" d="M410 125 L410 380"/>';
		return self::svg( 'Vehicle A plans a left turn across the path of approaching Vehicle B.', $c );
	}

	private static function scene_leftturn_wait() {
		$c = self::intersection() . self::car( 305, 430, 0, 'A' ) . self::car( 410, 210, 180, 'B', '#d96b34' ) . self::stop_badge( 205, 420 ) . '<path class="gb-path-b" d="M410 100 L410 390"/>';
		return self::svg( 'Vehicle A waits while approaching Vehicle B passes through.', $c );
	}

	private static function scene_leftturn_go() {
		$c = self::intersection() . self::car( 405, 260, 90, 'A' ) . self::car( 410, 455, 180, 'B', '#d96b34' ) . '<path class="gb-path-a" d="M305 420 C305 310 350 260 555 260"/><polygon class="gb-safe" points="590,260 545,237 545,283"/>';
		return self::svg( 'After Vehicle B passes, Vehicle A completes the left turn into the lawful lane.', $c );
	}

	private static function crosswalk() {
		$bars = '';
		for ( $x = 270; $x <= 440; $x += 34 ) {
			$bars .= '<rect x="' . $x . '" y="225" width="18" height="70" fill="#ffffff" opacity=".92"/>';
		}
		return '<rect class="gb-road" y="150" width="720" height="220"/><line class="gb-center" x1="0" y1="260" x2="720" y2="260"/>' . $bars;
	}

	private static function person( $x, $y ) {
		return '<g transform="translate(' . (int) $x . ' ' . (int) $y . ')" stroke="#172b3a" stroke-width="8" stroke-linecap="round"><circle cy="-35" r="15" fill="#f2b134"/><line y1="-18" y2="32"/><line y1="0" x2="-24" y2="20"/><line y1="0" x2="24" y2="20"/><line y1="30" x2="-20" y2="65"/><line y1="30" x2="20" y2="65"/></g>';
	}

	private static function scene_ped_hidden() {
		$c = self::crosswalk() . self::car( 350, 330, -90, 'B', '#d96b34', 150 ) . self::car( 530, 205, 90, 'A' ) . self::person( 350, 135 ) . '<path d="M440 145 L510 245 L440 345 Z" fill="#b42318" opacity=".22"/>';
		return self::svg( 'Vehicle B hides a pedestrian from approaching Vehicle A near a crosswalk.', $c );
	}

	private static function scene_ped_detect() {
		$c = self::crosswalk() . self::car( 350, 330, -90, 'B', '#d96b34', 150 ) . self::car( 560, 205, 90, 'A' ) . self::person( 350, 195 ) . self::stop_badge( 610, 100, 'SLOW' );
		return self::svg( 'Vehicle A slows and stays back until the hidden pedestrian becomes visible.', $c );
	}

	private static function scene_ped_wait() {
		$c = self::crosswalk() . self::car( 350, 330, -90, 'B', '#d96b34', 150 ) . self::car( 560, 205, 90, 'A' ) . self::person( 350, 260 ) . self::stop_badge( 610, 100 );
		return self::svg( 'Both vehicles remain stopped while the pedestrian crosses.', $c );
	}

	private static function bus( $x, $y, $rotation ) {
		return '<g transform="translate(' . (int) $x . ' ' . (int) $y . ') rotate(' . (int) $rotation . ')"><rect x="-42" y="-90" width="84" height="180" rx="18" fill="#f2b134" stroke="#172b3a" stroke-width="4"/><rect x="-31" y="-68" width="62" height="34" rx="6" fill="#d9f0f7"/><text class="gb-note" x="0" y="18">BUS</text><circle cx="-26" cy="-82" r="8" fill="#b42318"/><circle cx="26" cy="-82" r="8" fill="#b42318"/></g>';
	}

	private static function scene_bus_undivided() {
		$c = self::vertical_road() . self::bus( 260, 260, 0 ) . self::car( 260, 440, 0, 'A' ) . self::car( 460, 90, 180, 'B', '#d96b34' ) . self::stop_badge( 90, 425 ) . self::stop_badge( 630, 95 );
		return self::svg( 'On an undivided roadway, vehicles in both directions stop for a school bus displaying red signals.', $c );
	}

	private static function scene_bus_divided() {
		$c = '<rect class="gb-road" x="85" width="235" height="520"/><rect class="gb-road" x="400" width="235" height="520"/><rect x="320" width="80" height="520" fill="#8eb88f"/><line class="gb-lane" x1="200" y1="0" x2="200" y2="520"/><line class="gb-lane" x1="520" y1="0" x2="520" y2="520"/>' . self::bus( 200, 260, 0 ) . self::car( 200, 440, 0, 'A' ) . self::car( 520, 110, 180, 'B', '#d96b34' ) . self::stop_badge( 70, 430 ) . '<path class="gb-path-b" d="M520 80 L520 390"/><polygon class="gb-safe" points="520,430 496,385 544,385"/>';
		return self::svg( 'A raised physical median separates the opposite roadway from the stopped school bus.', $c );
	}

	private static function scene_move_over() {
		$c = self::vertical_road() . self::car( 260, 410, 0, 'A' ) . self::car( 260, 115, 0, 'E', '#b42318', 130 ) . '<rect class="gb-zone" x="175" y="30" width="180" height="185" rx="14"/><path class="gb-path-a" d="M260 345 C260 290 320 260 460 230"/><polygon class="gb-safe" points="480,225 437,207 446,252"/><circle cx="235" cy="62" r="12" fill="#2d78c4"/><circle cx="285" cy="62" r="12" fill="#b42318"/>';
		return self::svg( 'Vehicle A changes out of the closest lane before passing a protected stopped vehicle.', $c );
	}

	private static function rails() {
		return '<rect class="gb-road" x="210" width="300" height="520"/><line class="gb-center" x1="360" y1="0" x2="360" y2="520"/><rect x="0" y="190" width="720" height="140" fill="#c5b69b"/><line x1="0" y1="220" x2="720" y2="220" stroke="#5b4636" stroke-width="13"/><line x1="0" y1="300" x2="720" y2="300" stroke="#5b4636" stroke-width="13"/>';
	}

	private static function scene_rail_stop() {
		$c = self::rails() . self::car( 305, 405, 0, 'A' ) . '<rect class="gb-zone" x="225" y="335" width="270" height="115" rx="12"/><line class="gb-stop-line" x1="225" y1="345" x2="350" y2="345"/><text class="gb-note" x="565" y="385">15–50 FT</text>';
		return self::svg( 'Vehicle A stops in the marked 15-to-50-foot zone before the nearest railroad rail.', $c );
	}

	private static function scene_rail_blocked() {
		$c = self::rails() . self::car( 305, 405, 0, 'A' ) . self::car( 305, 95, 0, 'C', '#d96b34', 125 ) . self::stop_badge( 560, 420 ) . '<rect class="gb-zone" x="215" y="25" width="290" height="145" rx="12"/>';
		return self::svg( 'Traffic beyond the railroad crossing leaves no room for Vehicle A to clear every rail.', $c );
	}

	private static function scene_rail_escape() {
		$c = self::rails() . self::car( 305, 260, 0, 'A' ) . '<g transform="translate(100 260)"><rect x="-110" y="-48" width="220" height="96" rx="20" fill="#d96b34" stroke="#172b3a" stroke-width="4"/><text class="gb-large-label" x="0" y="2">TRAIN</text></g>' . self::person( 390, 130 ) . '<path class="gb-path-a" d="M365 235 C410 175 465 135 545 95"/><polygon class="gb-safe" points="575,75 525,86 553,123"/>';
		return self::svg( 'An occupant leaves a stalled vehicle and moves away from the tracks toward the approaching train.', $c );
	}
}
