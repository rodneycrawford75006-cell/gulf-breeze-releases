<?php
/**
 * Adult English Topic 4.1.6 interactive visual labs and optional enrichment.
 * Gulf Breeze Driving School / Rodney Crawford.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class GB_Adult_Topic_Six_Visual_Labs {
	public static function render( $key ) {
		$labs = self::labs();
		if ( empty( $labs[ $key ] ) ) {
			return '';
		}

		$lab  = $labs[ $key ];
		$uid  = 'gb-impaired-driving-' . sanitize_html_class( $key );
		$html = '<section class="gb-road-lab" aria-labelledby="' . esc_attr( $uid ) . '-heading">';
		$html .= '<h2 class="gb-road-lab__heading" id="' . esc_attr( $uid ) . '-heading">' . esc_html( $lab['title'] ) . '</h2>';
		$html .= '<p class="gb-road-lab__intro">' . esc_html( $lab['intro'] ) . '</p>';
		$html .= '<div class="gb-road-lab__controls" role="group" aria-label="Choose a visual step">';
		foreach ( $lab['steps'] as $index => $step ) {
			$panel_id = $uid . '-panel-' . ( $index + 1 );
			$html .= '<button type="button" class="gb-road-lab__button" aria-controls="' . esc_attr( $panel_id ) . '" aria-pressed="' . ( 0 === $index ? 'true' : 'false' ) . '">' . esc_html( ( $index + 1 ) . '. ' . $step['label'] ) . '</button>';
		}
		$html .= '</div><div class="gb-road-lab__stage">';
		foreach ( $lab['steps'] as $index => $step ) {
			$panel_id = $uid . '-panel-' . ( $index + 1 );
			$html .= '<div class="gb-road-lab__panel" id="' . esc_attr( $panel_id ) . '"' . ( 0 === $index ? '' : ' hidden' ) . '>';
			$html .= '<figure class="gb-road-lab__figure">' . self::scene( $step['scene'] );
			$html .= '<figcaption class="gb-road-lab__caption"><strong>' . esc_html( $step['lead'] ) . '</strong> ' . esc_html( $step['caption'] ) . '</figcaption></figure></div>';
		}
		$html .= '</div></section>';
		if ( 'adult_en_028' === $key ) {
			$html .= self::optional_madd_video();
		}
		return $html;
	}

	private static function labs() {
		return array(
			'adult_en_027' => array(
				'title' => 'Make the Transportation Decision While Sober',
				'intro' => 'A strong plan separates substance use from vehicle operation before judgment can be affected and includes a backup that does not depend on an impaired person.',
				'steps' => array(
					array( 'label' => 'Build the sober plan', 'scene' => 'zero_plan', 'lead' => 'Choose before use:', 'caption' => 'Select a completely sober driver, rideshare or taxi, transit, sober pickup, or a safe overnight stay—and keep control of your own safe transportation.' ),
					array( 'label' => 'Activate the backup', 'scene' => 'zero_backup', 'lead' => 'When the first plan fails:', 'caption' => 'Do not bargain with distance or confidence. Replace the transportation method, involve sober help, and call 911 when driving creates immediate danger.' ),
				),
			),
			'adult_en_028' => array(
				'title' => 'Impairment Reaches Every Part of the Driving Task',
				'intro' => 'Safe driving requires mental and physical faculties at the same time. A BAC number is evidence—not a personal permission gauge.',
				'steps' => array(
					array( 'label' => 'Trace the driving losses', 'scene' => 'bac_faculties', 'lead' => 'One delay spreads forward:', 'caption' => 'Reduced judgment, vision, attention, reaction, and coordination can remove the time and control needed for every later driving decision.' ),
					array( 'label' => 'Read both legal definitions', 'scene' => 'bac_definitions', 'lead' => 'Texas uses two independent paths:', 'caption' => 'Loss of normal mental or physical faculties can establish intoxication; an alcohol concentration of 0.08 or more is a separate definition. Neither is a safe-driving target.' ),
					array( 'label' => 'See the human reach', 'scene' => 'bac_impact', 'lead' => 'The consequence does not stop with the driver:', 'caption' => 'One impaired-driving decision can affect passengers, families, responders, employers, and people who never agreed to share the risk.' ),
				),
			),
			'adult_en_029' => array(
				'title' => 'Legal Medicine Can Still Make Driving Unsafe',
				'intro' => 'The practical question is whether a substance or combination can reduce the functions needed to drive—not whether the product was prescribed or sold legally.',
				'steps' => array(
					array( 'label' => 'Compare impairment patterns', 'scene' => 'drug_effects', 'lead' => 'Different paths, same driving risk:', 'caption' => 'Sedation, slowed reaction, altered perception, overconfidence, and unstable attention can each disrupt lane control, hazard detection, speed choice, or braking.' ),
					array( 'label' => 'Use the label routine', 'scene' => 'drug_labels', 'lead' => 'Read, ask, plan, recheck:', 'caption' => 'Read every warning, ask a pharmacist or prescriber about driving and combinations, arrange transportation, and recheck after any medication, dose, health, or sleep change.' ),
				),
			),
			'adult_en_030' => array(
				'title' => 'One Event Can Create Several Separate Consequences',
				'intro' => 'Criminal court, DPS licensing action, alcohol-law consequences, civil loss, and personal harm can proceed on different tracks from the same event.',
				'steps' => array(
					array( 'label' => 'Map the separate processes', 'scene' => 'law_processes', 'lead' => 'Do not confuse the branches:', 'caption' => 'A stop or crash may lead to a criminal case, a separate DPS administrative action, and financial or civil consequences. The official notice controls each deadline.' ),
					array( 'label' => 'Distinguish under 21', 'scene' => 'law_under_twenty_one', 'lead' => 'Zero tolerance is a separate rule:', 'caption' => 'A person under 21 may face the minor alcohol-driving offense without adult-level intoxication and may also face DWI or another offense when those elements are present.' ),
					array( 'label' => 'Follow the consequence chain', 'scene' => 'law_consequences', 'lead' => 'The judgment is not the endpoint:', 'caption' => 'License restrictions, court requirements, insurance, employment, injury, family loss, and future enhancements can continue after the roadside event.' ),
				),
			),
			'adult_en_031' => array(
				'title' => 'Intervention Must Be Safe and Workable',
				'intro' => 'A useful intervention separates the person from driving, supplies a real alternative, protects the helper, and escalates when immediate danger remains.',
				'steps' => array(
					array( 'label' => 'Prepare the ride ladder', 'scene' => 'ride_checklist', 'lead' => 'Primary plus backup:', 'caption' => 'Choose the ride and backup, charge the phone, budget for transportation or lodging, identify a sober contact, and decide where the vehicle can remain legally.' ),
					array( 'label' => 'Intervene without escalating', 'scene' => 'ride_intervention', 'lead' => 'Clear words and safe actions:', 'caption' => 'State that driving will not happen, offer the arranged ride, recruit sober help, avoid a dangerous confrontation, and call 911 when an impaired person drives or danger is immediate.' ),
				),
			),
		);
	}

	private static function optional_madd_video() {
		$url = 'https://www.youtube.com/watch?v=M5faKg5Fz-g&t=91s';
		return '<aside class="gb-optional-media" aria-labelledby="gb-madd-video-title"><p class="gb-optional-media__eyebrow">Optional enrichment — outside required seat time</p><h2 id="gb-madd-video-title">MADD — Lives Affected</h2><p>This 26:44 human-impact presentation begins at 1:31. It is not required for lesson completion and is not counted in the eight-minute instructional timer.</p><div class="gb-optional-media__frame"><iframe src="https://www.youtube-nocookie.com/embed/M5faKg5Fz-g?start=91&amp;rel=0" title="MADD — Lives Affected, optional enrichment" loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div><p><a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer">Open MADD — Lives Affected on YouTube if the player does not load.</a></p></aside>';
	}

	private static function scene( $scene ) {
		switch ( $scene ) {
			case 'zero_plan': return self::scene_zero_plan();
			case 'zero_backup': return self::scene_zero_backup();
			case 'bac_faculties': return self::scene_bac_faculties();
			case 'bac_definitions': return self::scene_bac_definitions();
			case 'bac_impact': return self::scene_bac_impact();
			case 'drug_effects': return self::scene_drug_effects();
			case 'drug_labels': return self::scene_drug_labels();
			case 'law_processes': return self::scene_law_processes();
			case 'law_under_twenty_one': return self::scene_law_under_twenty_one();
			case 'law_consequences': return self::scene_law_consequences();
			case 'ride_checklist': return self::scene_ride_checklist();
			case 'ride_intervention': return self::scene_ride_intervention();
			default: return '';
		}
	}

	private static function svg( $label, $content ) {
		return '<svg class="gb-road-svg" viewBox="0 0 720 520" role="img" aria-label="' . esc_attr( $label ) . '"><rect width="720" height="520" fill="#eef5f8"/>' . $content . '</svg>';
	}

	private static function note( $x, $y, $text, $size = 22 ) {
		return '<text x="' . (int) $x . '" y="' . (int) $y . '" fill="#172b3a" font-family="system-ui,sans-serif" font-size="' . (int) $size . '" font-weight="700" text-anchor="middle">' . esc_html( $text ) . '</text>';
	}

	private static function card( $x, $y, $w, $h, $title, $detail, $color = '#123b5d' ) {
		return '<g><rect x="' . (int) $x . '" y="' . (int) $y . '" width="' . (int) $w . '" height="' . (int) $h . '" rx="18" fill="' . esc_attr( $color ) . '"/><text x="' . (int) ( $x + $w / 2 ) . '" y="' . (int) ( $y + 45 ) . '" fill="#fff" font-family="system-ui,sans-serif" font-size="24" font-weight="800" text-anchor="middle">' . esc_html( $title ) . '</text><text x="' . (int) ( $x + $w / 2 ) . '" y="' . (int) ( $y + 82 ) . '" fill="#fff" font-family="system-ui,sans-serif" font-size="18" font-weight="650" text-anchor="middle">' . esc_html( $detail ) . '</text></g>';
	}

	private static function arrow( $x1, $y1, $x2, $y2, $color = '#1769aa' ) {
		return '<path d="M' . (int) $x1 . ' ' . (int) $y1 . ' L' . (int) $x2 . ' ' . (int) $y2 . '" stroke="' . esc_attr( $color ) . '" stroke-width="10" stroke-linecap="round"/><polygon points="' . (int) $x2 . ',' . (int) $y2 . ' ' . (int) ( $x2 - 28 ) . ',' . (int) ( $y2 - 18 ) . ' ' . (int) ( $x2 - 28 ) . ',' . (int) ( $y2 + 18 ) . '" fill="' . esc_attr( $color ) . '"/>';
	}

	private static function scene_zero_plan() {
		$c = self::note( 360, 52, 'DECIDE WHILE SOBER' ) . self::card( 45, 105, 190, 115, 'SOBER DRIVER', 'NO IMPAIRING USE', '#18794e' ) . self::card( 265, 105, 190, 115, 'RIDE', 'TAXI / TRANSIT', '#1769aa' ) . self::card( 485, 105, 190, 115, 'STAY', 'SAFE OVERNIGHT', '#6b4c9a' );
		$c .= self::arrow( 360, 245, 360, 350, '#18794e' ) . '<rect x="175" y="350" width="370" height="105" rx="52" fill="#123b5d"/>' . self::note( 360, 408, 'NO IMPAIRED DRIVING', 28 );
		return self::svg( 'A sober decision branches to a sober driver, arranged ride, or overnight stay, all leading to no impaired driving.', $c );
	}

	private static function scene_zero_backup() {
		$c = self::card( 45, 80, 205, 120, 'PLAN A FAILED', 'DO NOT BARGAIN', '#b42318' ) . self::arrow( 265, 140, 400, 140 ) . self::card( 420, 80, 255, 120, 'ACTIVATE BACKUP', 'SOBER RIDE OR STAY', '#18794e' );
		$c .= self::card( 75, 300, 250, 120, 'SOBER HELP', 'HOST / FAMILY / FRIEND', '#1769aa' ) . self::card( 395, 300, 250, 120, 'IMMEDIATE DANGER', 'CALL 911 SAFELY', '#b42318' );
		return self::svg( 'A failed transportation plan leads to a sober backup, sober assistance, or emergency help when danger is immediate.', $c );
	}

	private static function scene_bac_faculties() {
		$c = self::card( 25, 70, 155, 105, 'JUDGMENT', 'RISK CHOICE', '#6b4c9a' ) . self::card( 200, 70, 155, 105, 'VISION', 'HAZARD SEARCH', '#1769aa' ) . self::card( 375, 70, 155, 105, 'REACTION', 'LATE RESPONSE', '#d96b34' ) . self::card( 550, 70, 145, 105, 'CONTROL', 'STEER / BRAKE', '#b42318' );
		$c .= self::arrow( 105, 210, 580, 350, '#b42318' ) . '<rect x="165" y="325" width="390" height="120" rx="18" fill="#3f4b54"/>' . self::note( 360, 382, 'DRIVING TASK BREAKS DOWN', 27 ) . self::note( 360, 420, 'ONE LOSS AFFECTS THE NEXT STEP', 19 );
		return self::svg( 'Judgment, vision, reaction, and vehicle control feed the same driving task, showing how one impairment affects later steps.', $c );
	}

	private static function scene_bac_definitions() {
		$c = self::card( 50, 105, 275, 190, 'PATH 1', 'LOSS OF NORMAL FACULTIES', '#6b4c9a' ) . self::card( 395, 105, 275, 190, 'PATH 2', '0.08 OR MORE', '#b42318' );
		$c .= self::note( 360, 355, 'INDEPENDENT TEXAS DEFINITIONS', 27 ) . '<rect x="130" y="395" width="460" height="78" rx="16" fill="#f2b134"/>' . self::note( 360, 443, 'NEITHER PATH IS A SAFE-DRIVING TARGET', 21 );
		return self::svg( 'Two independent Texas intoxication definitions are shown side by side, with a warning that neither is a safe-driving target.', $c );
	}

	private static function scene_bac_impact() {
		$c = '<circle cx="360" cy="255" r="92" fill="#b42318"/>' . self::note( 360, 238, 'ONE IMPAIRED', 23 ) . self::note( 360, 275, 'DRIVING DECISION', 23 );
		$items = array( array( 100, 95, 'PASSENGERS' ), array( 360, 62, 'FAMILIES' ), array( 620, 95, 'ROAD USERS' ), array( 100, 430, 'RESPONDERS' ), array( 360, 465, 'WORK / SCHOOL' ), array( 620, 430, 'COMMUNITY' ) );
		foreach ( $items as $item ) { $c .= '<circle cx="' . $item[0] . '" cy="' . $item[1] . '" r="58" fill="#123b5d"/>' . self::note( $item[0], $item[1] + 7, $item[2], 16 ); }
		return self::svg( 'One impaired-driving decision is connected to passengers, families, road users, responders, work or school, and the community.', $c );
	}

	private static function scene_drug_effects() {
		$c = self::card( 35, 65, 200, 130, 'SEDATION', 'DROWSY / SLOW', '#6b4c9a' ) . self::card( 260, 65, 200, 130, 'PERCEPTION', 'TIME / DISTANCE', '#1769aa' ) . self::card( 485, 65, 200, 130, 'STIMULATION', 'RISK / AGITATION', '#d96b34' );
		$c .= self::arrow( 135, 230, 310, 370, '#b42318' ) . self::arrow( 360, 230, 360, 370, '#b42318' ) . self::arrow( 585, 230, 410, 370, '#b42318' ) . '<rect x="205" y="365" width="310" height="100" rx="18" fill="#3f4b54"/>' . self::note( 360, 425, 'UNSAFE DRIVING FUNCTION', 24 );
		return self::svg( 'Sedation, altered perception, and stimulation converge on unsafe driving function.', $c );
	}

	private static function scene_drug_labels() {
		$c = self::card( 20, 180, 150, 120, '1. READ', 'LABEL + GUIDE', '#123b5d' ) . self::arrow( 175, 240, 220, 240 ) . self::card( 225, 180, 150, 120, '2. ASK', 'PHARMACIST', '#1769aa' ) . self::arrow( 380, 240, 425, 240 ) . self::card( 430, 180, 125, 120, '3. PLAN', 'NO DRIVE', '#18794e' ) . self::arrow( 560, 240, 600, 240 ) . self::card( 605, 180, 95, 120, '4.', 'RECHECK', '#6b4c9a' );
		$c .= self::note( 360, 90, 'MEDICATION SAFETY ROUTINE', 30 ) . self::note( 360, 390, 'NEW DOSE • NEW MEDICINE • NEW COMBINATION • HEALTH OR SLEEP CHANGE', 18 );
		return self::svg( 'A four-step medication routine reads the warning, asks a professional, plans not to drive, and rechecks after changes.', $c );
	}

	private static function scene_law_processes() {
		$c = '<circle cx="125" cy="260" r="80" fill="#b42318"/>' . self::note( 125, 252, 'STOP /', 22 ) . self::note( 125, 286, 'CRASH', 22 );
		$c .= self::arrow( 210, 210, 335, 115 ) . self::arrow( 215, 260, 335, 260 ) . self::arrow( 210, 310, 335, 405 );
		$c .= self::card( 360, 55, 310, 120, 'CRIMINAL COURT', 'OFFENSE + SENTENCE', '#6b4c9a' ) . self::card( 360, 200, 310, 120, 'DPS ADMINISTRATIVE', 'LICENSE PROCESS', '#1769aa' ) . self::card( 360, 345, 310, 120, 'CIVIL / FINANCIAL', 'INJURY + INSURANCE', '#d96b34' );
		return self::svg( 'A stop or crash branches into separate criminal court, DPS administrative, and civil or financial processes.', $c );
	}

	private static function scene_law_under_twenty_one() {
		$c = self::card( 45, 75, 285, 175, 'UNDER 21 PATH', 'ALCOHOL DETECTED WHILE DRIVING', '#1769aa' ) . self::card( 390, 75, 285, 175, 'ANY-AGE PATH', 'DWI ELEMENTS PRESENT', '#b42318' );
		$c .= self::note( 360, 320, 'DISTINCT RULES CAN APPLY TO THE SAME EVENT', 24 ) . '<rect x="105" y="370" width="510" height="90" rx="18" fill="#f2b134"/>' . self::note( 360, 424, 'UNDER 21 DOES NOT CREATE A SAFE BAC TARGET', 20 );
		return self::svg( 'An under-21 zero-tolerance path and an any-age DWI path are shown as distinct rules that can apply to the same event.', $c );
	}

	private static function scene_law_consequences() {
		$c = self::card( 25, 70, 155, 110, 'LICENSE', 'LOSS / LIMIT', '#1769aa' ) . self::card( 195, 70, 155, 110, 'COURT', 'FINE / JAIL', '#6b4c9a' ) . self::card( 365, 70, 155, 110, 'INSURANCE', 'COST / ACCESS', '#d96b34' ) . self::card( 535, 70, 160, 110, 'FUTURE', 'ENHANCEMENT', '#b42318' );
		$c .= self::arrow( 360, 210, 360, 315, '#b42318' ) . '<rect x="95" y="315" width="530" height="130" rx="20" fill="#123b5d"/>' . self::note( 360, 372, 'INJURY • DEATH • FAMILY LOSS • LOST WORK', 22 ) . self::note( 360, 410, 'SOME CONSEQUENCES CANNOT BE UNDONE', 19 );
		return self::svg( 'License, court, insurance, and future consequences lead to a larger human-impact panel.', $c );
	}

	private static function scene_ride_checklist() {
		$c = self::note( 360, 52, 'BEFORE THE EVENT', 30 );
		$rows = array( array( 90, 'PRIMARY SOBER RIDE' ), array( 180, 'BACKUP RIDE OR STAY' ), array( 270, 'CHARGED PHONE + PAYMENT' ), array( 360, 'SOBER CONTACT + VEHICLE PLAN' ) );
		foreach ( $rows as $row ) { $c .= '<rect x="95" y="' . $row[0] . '" width="54" height="54" rx="8" fill="#18794e"/><path d="M108 ' . ( $row[0] + 27 ) . ' l14 14 l25 -31" stroke="#fff" stroke-width="8" fill="none"/>' . self::note( 410, $row[0] + 36, $row[1], 22 ); }
		return self::svg( 'A four-item safe-ride checklist covers the primary ride, backup, phone and payment, sober contact, and vehicle plan.', $c );
	}

	private static function scene_ride_intervention() {
		$c = self::card( 25, 180, 145, 120, '1. STATE', 'YOU ARE NOT DRIVING', '#123b5d' ) . self::arrow( 175, 240, 220, 240 ) . self::card( 225, 180, 145, 120, '2. OFFER', 'SAFE RIDE', '#18794e' ) . self::arrow( 375, 240, 420, 240 ) . self::card( 425, 180, 125, 120, '3. GET', 'SOBER HELP', '#1769aa' ) . self::arrow( 555, 240, 600, 240 ) . self::card( 605, 180, 95, 120, '4.', '911 IF DANGER', '#b42318' );
		$c .= self::note( 360, 90, 'CLEAR • PRACTICAL • NONJUDGMENTAL • SAFE', 24 ) . self::note( 360, 390, 'DO NOT RIDE ALONG • DO NOT START A DANGEROUS CONFRONTATION', 18 );
		return self::svg( 'A four-step intervention states the boundary, offers a ride, gets sober help, and calls 911 if danger remains.', $c );
	}
}
