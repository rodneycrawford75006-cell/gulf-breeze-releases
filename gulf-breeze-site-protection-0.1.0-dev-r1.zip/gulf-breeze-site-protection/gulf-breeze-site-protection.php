<?php
/**
 * Plugin Name: Gulf Breeze Site Protection
 * Description: Logged-out-only construction protection with unrestricted authenticated access and safe commerce infrastructure exemptions.
 * Version: 0.1.0-dev-r1
 * Author: Gulf Breeze Driving School / Rodney Crawford
 * Text Domain: gulf-breeze-site-protection
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Gulf_Breeze_Site_Protection {
	const VERSION = '0.1.0-dev-r1';
	const OPTION = 'gb_site_protection_settings';
	const PAGE = 'gulf-breeze-site-protection';

	private static $instance;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'template_redirect', array( $this, 'protect_logged_out_request' ), 0 );
		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'admin_post_gbsp_save', array( $this, 'handle_save' ) );
		add_action( 'admin_post_gbsp_open_window', array( $this, 'handle_open_window' ) );
		add_action( 'admin_post_gbsp_close_window', array( $this, 'handle_close_window' ) );
	}

	public static function activate() {
		if ( false === get_option( self::OPTION, false ) ) {
			add_option( self::OPTION, array(
				'enabled' => 1,
				'public_open_until' => 0,
			), '', false );
		}
	}

	private function settings() {
		$saved = get_option( self::OPTION, array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), array(
			'enabled' => 1,
			'public_open_until' => 0,
		) );
	}

	private function protection_is_active() {
		$settings = $this->settings();
		if ( empty( $settings['enabled'] ) ) {
			return false;
		}
		$open_until = absint( $settings['public_open_until'] );
		return ! $open_until || time() >= $open_until;
	}

	private function request_path() {
		$path = wp_parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '/' ), PHP_URL_PATH );
		return '/' . ltrim( is_string( $path ) ? $path : '/', '/' );
	}

	private function infrastructure_request() {
		if ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) {
			return true;
		}
		if ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) {
			return true;
		}
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return true;
		}
		if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
			return true;
		}
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			return true;
		}
		if ( isset( $_GET['wc-api'] ) || isset( $_GET['wc-ajax'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return true;
		}

		$path = $this->request_path();
		foreach ( array( '/wp-login.php', '/wp-admin/', '/wp-cron.php', '/wp-json/', '/wc-api/' ) as $allowed ) {
			if ( 0 === strpos( $path, $allowed ) ) {
				return true;
			}
		}
		return false;
	}

	public function protect_logged_out_request() {
		if ( is_user_logged_in() || ! $this->protection_is_active() || $this->infrastructure_request() ) {
			return;
		}
		$this->render_construction_page();
	}

	private function render_construction_page() {
		status_header( 503 );
		nocache_headers();
		header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private', true );
		header( 'Retry-After: 3600', true );
		header( 'X-Robots-Tag: noindex, nofollow, noarchive', true );
		$login_url = wp_login_url( home_url( '/my-account/' ) );
		?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo esc_html__( 'Gulf Breeze Driving School — Preparing for Launch', 'gulf-breeze-site-protection' ); ?></title>
	<style>
		:root{color-scheme:light;--navy:#073b5c;--aqua:#0fa3b1;--sand:#fff7df;--coral:#f26b4f;--white:#fff}
		*{box-sizing:border-box}body{margin:0;min-height:100vh;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:var(--navy);background:linear-gradient(180deg,#dff8ff 0 48%,#8bd7df 48% 58%,var(--sand) 58% 100%);display:grid;place-items:center;padding:24px}
		main{width:min(760px,100%);background:rgba(255,255,255,.94);border:1px solid rgba(7,59,92,.12);border-radius:28px;box-shadow:0 22px 70px rgba(7,59,92,.18);padding:clamp(28px,6vw,62px);text-align:center}
		.mark{display:inline-grid;place-items:center;width:76px;height:76px;border-radius:50%;background:var(--aqua);color:var(--white);font-size:42px;box-shadow:inset 0 -8px 0 rgba(0,0,0,.08)}
		h1{font-size:clamp(2rem,6vw,3.7rem);line-height:1.02;margin:22px 0 16px}p{font-size:clamp(1rem,2.5vw,1.2rem);line-height:1.65;margin:12px auto;max-width:620px}
		.es{padding-top:20px;margin-top:24px;border-top:1px solid rgba(7,59,92,.14)}
		a{display:inline-block;margin-top:28px;padding:14px 24px;border-radius:999px;background:var(--coral);color:var(--white);font-weight:800;text-decoration:none;box-shadow:0 8px 20px rgba(242,107,79,.28)}a:focus,a:hover{background:#d9573d;outline:3px solid rgba(15,163,177,.35);outline-offset:3px}
		.small{font-size:.9rem;opacity:.78;margin-top:18px}
	</style>
</head>
<body>
	<main>
		<div class="mark" aria-hidden="true">☀</div>
		<h1><?php echo esc_html__( 'Something bright is on the horizon.', 'gulf-breeze-site-protection' ); ?></h1>
		<p><?php echo esc_html__( 'Gulf Breeze Driving School is preparing its online courses. Current students can continue by signing in below.', 'gulf-breeze-site-protection' ); ?></p>
		<div class="es" lang="es">
			<p><strong>Algo nuevo está por llegar.</strong></p>
			<p>Gulf Breeze Driving School está preparando sus cursos en línea. Los estudiantes actuales pueden continuar iniciando sesión abajo.</p>
		</div>
		<a href="<?php echo esc_url( $login_url ); ?>"><?php echo esc_html__( 'Student sign in / Iniciar sesión', 'gulf-breeze-site-protection' ); ?></a>
		<p class="small"><?php echo esc_html__( 'Please check back soon. / Vuelva a visitarnos pronto.', 'gulf-breeze-site-protection' ); ?></p>
	</main>
</body>
</html><?php
		exit;
	}

	public function admin_menu() {
		add_options_page(
			__( 'Gulf Breeze Site Protection', 'gulf-breeze-site-protection' ),
			__( 'Site Protection', 'gulf-breeze-site-protection' ),
			'manage_options',
			self::PAGE,
			array( $this, 'settings_page' )
		);
	}

	private function require_admin_action( $nonce_action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die(
				esc_html__( 'You are not allowed to manage site protection.', 'gulf-breeze-site-protection' ),
				'',
				array( 'response' => 403 )
			);
		}
		check_admin_referer( $nonce_action );
	}

	private function redirect_to_settings( $message ) {
		wp_safe_redirect( add_query_arg( 'gbsp_message', sanitize_key( $message ), admin_url( 'options-general.php?page=' . self::PAGE ) ) );
		exit;
	}

	public function handle_save() {
		$this->require_admin_action( 'gbsp_save' );
		$enabled = isset( $_POST['enabled'] ) ? 1 : 0;
		update_option( self::OPTION, array(
			'enabled' => $enabled,
			'public_open_until' => 0,
		), false );
		$this->redirect_to_settings( $enabled ? 'enabled' : 'disabled' );
	}

	public function handle_open_window() {
		$this->require_admin_action( 'gbsp_open_window' );
		$duration = absint( $_POST['duration'] ?? 30 );
		if ( ! in_array( $duration, array( 15, 30, 60, 120 ), true ) ) {
			$duration = 30;
		}
		update_option( self::OPTION, array(
			'enabled' => 1,
			'public_open_until' => time() + ( $duration * MINUTE_IN_SECONDS ),
		), false );
		$this->redirect_to_settings( 'window_opened' );
	}

	public function handle_close_window() {
		$this->require_admin_action( 'gbsp_close_window' );
		update_option( self::OPTION, array(
			'enabled' => 1,
			'public_open_until' => 0,
		), false );
		$this->redirect_to_settings( 'enabled' );
	}

	public function settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$settings = $this->settings();
		$open_until = absint( $settings['public_open_until'] );
		$window_open = ! empty( $settings['enabled'] ) && $open_until > time();
		$active = $this->protection_is_active();
		$message = sanitize_key( $_GET['gbsp_message'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		?>
		<div class="wrap">
			<h1><?php echo esc_html__( 'Gulf Breeze Site Protection', 'gulf-breeze-site-protection' ); ?></h1>
			<?php if ( $message ) : ?>
				<div class="notice notice-success inline"><p><?php echo esc_html__( 'Site protection settings were updated.', 'gulf-breeze-site-protection' ); ?></p></div>
			<?php endif; ?>
			<div style="max-width:760px;background:#fff;border:1px solid #c3c4c7;border-radius:8px;padding:22px;margin:20px 0">
				<h2 style="margin-top:0"><?php echo esc_html__( 'Current public status', 'gulf-breeze-site-protection' ); ?></h2>
				<p style="font-size:18px"><strong><?php echo $active ? esc_html__( 'PROTECTED — logged-out visitors see the construction page', 'gulf-breeze-site-protection' ) : esc_html__( 'OPEN — logged-out visitors can use the site', 'gulf-breeze-site-protection' ); ?></strong></p>
				<p><?php echo esc_html__( 'Every logged-in account always sees the full site. This plugin never adds an administrator or student notice.', 'gulf-breeze-site-protection' ); ?></p>
				<?php if ( $window_open ) : ?>
					<p><?php printf( esc_html__( 'The timed public enrollment window closes automatically at %s.', 'gulf-breeze-site-protection' ), esc_html( wp_date( 'F j, Y g:i a T', $open_until ) ) ); ?></p>
				<?php endif; ?>
			</div>

			<h2><?php echo esc_html__( 'Standard on/off control', 'gulf-breeze-site-protection' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'gbsp_save' ); ?>
				<input type="hidden" name="action" value="gbsp_save">
				<label><input type="checkbox" name="enabled" value="1" <?php checked( ! empty( $settings['enabled'] ) ); ?>> <?php echo esc_html__( 'Protect the site from logged-out visitors', 'gulf-breeze-site-protection' ); ?></label>
				<?php submit_button( __( 'Save Protection Setting', 'gulf-breeze-site-protection' ) ); ?>
			</form>

			<h2><?php echo esc_html__( 'Timed public enrollment window', 'gulf-breeze-site-protection' ); ?></h2>
			<p><?php echo esc_html__( 'Temporarily open the public site for enrollment. Protection turns back on automatically.', 'gulf-breeze-site-protection' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block;margin-right:10px">
				<?php wp_nonce_field( 'gbsp_open_window' ); ?>
				<input type="hidden" name="action" value="gbsp_open_window">
				<select name="duration" aria-label="<?php echo esc_attr__( 'Enrollment window duration', 'gulf-breeze-site-protection' ); ?>">
					<option value="15">15 minutes</option><option value="30" selected>30 minutes</option><option value="60">60 minutes</option><option value="120">2 hours</option>
				</select>
				<?php submit_button( __( 'Open Public Enrollment Temporarily', 'gulf-breeze-site-protection' ), 'secondary', 'submit', false ); ?>
			</form>
			<?php if ( $window_open || empty( $settings['enabled'] ) ) : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block">
					<?php wp_nonce_field( 'gbsp_close_window' ); ?>
					<input type="hidden" name="action" value="gbsp_close_window">
					<?php submit_button( __( 'Protect the Public Site Now', 'gulf-breeze-site-protection' ), 'primary', 'submit', false ); ?>
				</form>
			<?php endif; ?>
		</div>
		<?php
	}
}

register_activation_hook( __FILE__, array( 'Gulf_Breeze_Site_Protection', 'activate' ) );
Gulf_Breeze_Site_Protection::instance();
