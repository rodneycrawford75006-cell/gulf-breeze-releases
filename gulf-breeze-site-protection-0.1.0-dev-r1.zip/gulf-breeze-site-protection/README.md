# Gulf Breeze Site Protection 0.1.0-dev-r1

Logged-out-only construction protection for Gulf Breeze Driving School.

- Defaults to protected on first activation.
- Every authenticated account bypasses protection completely, regardless of role.
- Adds no toolbar indicator, dashboard warning, global administrator notice, or student notice.
- Keeps WordPress login and password recovery reachable while protection is active.
- Exempts WordPress REST, AJAX, cron, XML-RPC, WP-CLI, WooCommerce AJAX, WC API, and webhook infrastructure.
- Serves a bilingual Gulf Breeze construction page with a student sign-in link and no administrator information.
- Sends a 503 response with no-store/no-cache and noindex headers to protected logged-out page requests.
- Provides a standard on/off setting and 15-, 30-, 60-, or 120-minute public enrollment windows that close automatically.
- Does not change course, order, student, payment, MFA, certificate, or existing Under Construction plugin data.

## Safe replacement sequence

1. Install and activate this plugin while the existing Under Construction plugin remains active.
2. Confirm **Settings → Site Protection** reports `PROTECTED`.
3. Disable the old Under Construction plugin.
4. Verify a logged-out visitor receives the Gulf Breeze construction page.
5. Verify an administrator and a disposable student receive the full site without a protection notice.

Keep the public site protected until licensing and launch approval.

