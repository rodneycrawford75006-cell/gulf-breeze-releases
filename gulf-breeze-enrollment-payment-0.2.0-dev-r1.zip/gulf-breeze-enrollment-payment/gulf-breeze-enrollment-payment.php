<?php
/**
 * Plugin Name: Gulf Breeze Enrollment & Payment
 * Description: Native WooCommerce checkout agreement, paid-only student enrollment, and refund access control for Gulf Breeze Driving School.
 * Version: 0.2.0-dev-r1
 * Author: Gulf Breeze Driving School / Rodney Crawford
 * Text Domain: gulf-breeze-enrollment-payment
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Gulf_Breeze_Enrollment_Payment {
	const VERSION = '0.2.0-dev-r1';
	const CONTRACT_VERSION = 'GB-DEV-0.2.0';
	const META_REQUIRED = '_gb_ep_contract_required';
	const META_SNAPSHOT = '_gb_ep_contract_snapshot_json';
	const META_HASH = '_gb_ep_contract_snapshot_hash';
	const META_SIGNED_AT = '_gb_ep_contract_signed_at_utc';
	const META_COURSE_ID = '_gb_ep_course_id';
	const META_LOCALE = '_gb_ep_locale';
	const META_STUDENT_EMAIL = '_gb_ep_student_email';
	const META_STUDENT_USER_ID = '_gb_ep_student_user_id';
	const META_PROCESSED = '_gb_ep_enrollment_processed';
	const META_REVOKED = '_gb_ep_access_revoked';
	const META_STATE = '_gb_ep_state';

	private static $instance;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'dependency_notice' ) );
		add_action( 'plugins_loaded', array( $this, 'take_checkout_control' ), 20 );
		add_action( 'woocommerce_checkout_before_customer_details', array( $this, 'render_agreement' ), 5 );
		add_filter( 'woocommerce_checkout_registration_required', array( $this, 'course_checkout_registration_not_required' ), 20 );
		add_filter( 'woocommerce_checkout_registration_enabled', array( $this, 'course_checkout_registration_disabled' ), 20 );
		add_filter( 'woocommerce_checkout_posted_data', array( $this, 'keep_course_checkout_guest_until_paid' ), 20 );
		add_filter( 'woocommerce_checkout_customer_id', array( $this, 'keep_course_order_unassigned_until_paid' ), 20 );
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'validate_agreement' ), 20, 2 );
		add_action( 'woocommerce_checkout_create_order', array( $this, 'save_agreement_to_order' ), 20, 2 );
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'guard_classic_order' ), 20, 3 );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'guard_store_api_order' ), 20, 1 );
		add_action( 'woocommerce_payment_complete', array( $this, 'process_paid_order' ), 1 );
		add_action( 'woocommerce_order_status_processing', array( $this, 'process_paid_order' ), 1 );
		add_action( 'woocommerce_order_status_completed', array( $this, 'process_paid_order' ), 1 );
		add_action( 'woocommerce_order_refunded', array( $this, 'handle_refund' ), 10, 2 );
		add_action( 'woocommerce_order_status_refunded', array( $this, 'handle_refunded_status' ), 10, 1 );
		add_action( 'woocommerce_order_status_cancelled', array( $this, 'handle_reversal_status' ), 10, 1 );
		add_action( 'woocommerce_order_status_failed', array( $this, 'handle_reversal_status' ), 10, 1 );
		add_action( 'woocommerce_admin_order_data_after_billing_address', array( $this, 'admin_order_panel' ), 20, 1 );
		add_action( 'wp_enqueue_scripts', array( $this, 'assets' ) );
	}

	public function dependency_notice() {
		if ( ! is_admin() || ( class_exists( 'WooCommerce' ) && function_exists( 'gb_core_provider_profile' ) ) ) {
			return;
		}
		add_action(
			'admin_notices',
			function() {
				echo '<div class="notice notice-error"><p><strong>Gulf Breeze Enrollment &amp; Payment:</strong> WooCommerce and Gulf Breeze Core are required.</p></div>';
			}
		);
	}

	public function take_checkout_control() {
		if ( ! class_exists( 'Gulf_Breeze_Catalog_Cart' ) ) {
			return;
		}
		$catalog = Gulf_Breeze_Catalog_Cart::instance();
		remove_action( 'template_redirect', array( $catalog, 'block_checkout_stage' ), 2 );
		remove_action( 'wp_loaded', array( $catalog, 'block_payment_ajax' ), -999 );
		remove_action( 'woocommerce_checkout_process', array( $catalog, 'reject_locked_checkout' ) );
		remove_action( 'woocommerce_after_checkout_validation', array( $catalog, 'reject_locked_checkout_validation' ), 10 );
		remove_filter( 'woocommerce_available_payment_gateways', array( $catalog, 'disable_payment_gateways' ), PHP_INT_MAX );
		remove_filter( 'woocommerce_cart_needs_payment', array( $catalog, 'disable_cart_payment_requirement' ), PHP_INT_MAX );
		remove_filter( 'rest_pre_dispatch', array( $catalog, 'block_store_api_checkout' ), 10 );
		remove_filter( 'render_block', array( $catalog, 'render_checkout_lock' ), 20 );
		remove_action( 'wp_head', array( $catalog, 'checkout_lock_styles' ), 99 );
		remove_action( 'wp_footer', array( $catalog, 'checkout_lock_script' ), 99 );
	}

	private function is_mapped_product( $product_id ) {
		$product_id = absint( $product_id );
		if ( ! $product_id ) {
			return false;
		}
		$course_id = absint( get_post_meta( $product_id, '_gb_learnpress_course_id', true ) );
		$catalog_key = sanitize_key( get_post_meta( $product_id, '_gb_catalog_key', true ) );
		$locale = sanitize_text_field( get_post_meta( $product_id, '_gb_enrollment_locale', true ) );
		return $course_id && $catalog_key && in_array( $locale, array( 'en-US', 'es-US' ), true );
	}

	private function product_context( $product_id ) {
		$product_id = absint( $product_id );
		if ( ! $this->is_mapped_product( $product_id ) ) {
			return false;
		}
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return false;
		}
		return array(
			'product_id' => $product_id,
			'course_id' => absint( get_post_meta( $product_id, '_gb_learnpress_course_id', true ) ),
			'catalog_key' => sanitize_key( get_post_meta( $product_id, '_gb_catalog_key', true ) ),
			'locale' => sanitize_text_field( get_post_meta( $product_id, '_gb_enrollment_locale', true ) ),
			'product' => $product,
		);
	}

	private function cart_context() {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return false;
		}
		if ( ! function_exists( 'WC' ) || ! WC() || ! WC()->cart ) {
			return false;
		}
		$cart_items = WC()->cart->get_cart();
		if ( 1 !== count( $cart_items ) ) {
			return false;
		}
		$mapped = array();
		foreach ( $cart_items as $item ) {
			if ( 1 !== absint( isset( $item['quantity'] ) ? $item['quantity'] : 0 ) ) {
				return false;
			}
			$context = $this->product_context( absint( isset( $item['product_id'] ) ? $item['product_id'] : 0 ) );
			if ( $context ) {
				$mapped[] = $context;
			}
		}
		return 1 === count( $mapped ) ? reset( $mapped ) : false;
	}

	private function order_context( $order ) {
		if ( ! $order || ! is_a( $order, 'WC_Order' ) ) {
			return false;
		}
		$line_items = $order->get_items( 'line_item' );
		if ( 1 !== count( $line_items ) ) {
			return false;
		}
		$mapped = array();
		foreach ( $line_items as $item ) {
			if ( 1 !== absint( $item->get_quantity() ) ) {
				return false;
			}
			$context = $this->product_context( $item->get_product_id() );
			if ( $context ) {
				$mapped[] = $context;
			}
		}
		return 1 === count( $mapped ) ? reset( $mapped ) : false;
	}

	private function tr( $locale, $english, $spanish ) {
		return 'es-US' === $locale ? $spanish : $english;
	}

	public function course_checkout_registration_not_required( $required ) {
		return $this->cart_context() ? false : $required;
	}

	public function course_checkout_registration_disabled( $enabled ) {
		return $this->cart_context() ? false : $enabled;
	}

	public function keep_course_checkout_guest_until_paid( $data ) {
		if ( $this->cart_context() ) {
			$data['createaccount'] = 0;
			unset( $data['account_username'], $data['account_password'] );
		}
		return $data;
	}

	public function keep_course_order_unassigned_until_paid( $customer_id ) {
		return $this->cart_context() ? 0 : $customer_id;
	}

	private function posted( $key ) {
		return isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
	}

	private function posted_email( $key ) {
		return isset( $_POST[ $key ] ) ? sanitize_email( wp_unslash( $_POST[ $key ] ) ) : '';
	}

	private function valid_date( $date ) {
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $date ) ) {
			return false;
		}
		$parts = explode( '-', $date );
		return checkdate( (int) $parts[1], (int) $parts[2], (int) $parts[0] );
	}

	private function age( $date ) {
		if ( ! $this->valid_date( $date ) ) {
			return null;
		}
		try {
			$birth = new DateTimeImmutable( $date, new DateTimeZone( 'UTC' ) );
			$today = new DateTimeImmutable( gmdate( 'Y-m-d' ), new DateTimeZone( 'UTC' ) );
			return (int) $birth->diff( $today )->y;
		} catch ( Exception $error ) {
			return null;
		}
	}

	private function normalize_name( $name ) {
		$name = strtolower( trim( (string) $name ) );
		return preg_replace( '/\s+/', ' ', $name );
	}

	private function agreement_values() {
		return array(
			'student_name' => $this->posted( 'gb_ep_student_name' ),
			'student_email' => $this->posted_email( 'gb_ep_student_email' ),
			'student_dob' => $this->posted( 'gb_ep_student_dob' ),
			'student_gender' => $this->posted( 'gb_ep_student_gender' ),
			'student_phone' => $this->posted( 'gb_ep_student_phone' ),
			'student_address_1' => $this->posted( 'gb_ep_student_address_1' ),
			'student_city' => $this->posted( 'gb_ep_student_city' ),
			'student_state' => strtoupper( $this->posted( 'gb_ep_student_state' ) ),
			'student_postcode' => $this->posted( 'gb_ep_student_postcode' ),
			'student_signature' => $this->posted( 'gb_ep_student_signature' ),
			'guardian_name' => $this->posted( 'gb_ep_guardian_name' ),
			'guardian_relationship' => $this->posted( 'gb_ep_guardian_relationship' ),
			'guardian_signature' => $this->posted( 'gb_ep_guardian_signature' ),
			'purchaser_is_student' => ! empty( $_POST['gb_ep_purchaser_is_student'] ),
			'consent' => ! empty( $_POST['gb_ep_consent'] ),
		);
	}

	private function field( $key, $label, $type, $required, $value = '', $extra = array() ) {
		$args = array_merge(
			array(
				'type' => $type,
				'label' => $label,
				'required' => $required,
				'class' => array( 'form-row-wide' ),
				'input_class' => array( 'gb-ep-input' ),
			),
			$extra
		);
		woocommerce_form_field( $key, $args, $value );
	}

	public function render_agreement() {
		$context = $this->cart_context();
		if ( ! $context ) {
			return;
		}
		$locale = $context['locale'];
		$values = $this->agreement_values();
		$product = $context['product'];
		$profile = function_exists( 'gb_core_provider_profile' ) ? gb_core_provider_profile() : array();
		?>
		<section id="gb-ep-agreement" class="gb-ep" lang="<?php echo 'es-US' === $locale ? 'es' : 'en'; ?>">
			<div class="gb-ep-banner">DEVELOPMENT / SAMPLE DATA &middot; PAYPAL SANDBOX</div>
			<h2><?php echo esc_html( $this->tr( $locale, 'Step 1: Student and enrollment agreement', 'Paso 1: Estudiante y contrato de inscripción' ) ); ?></h2>
			<p><?php echo esc_html( $this->tr( $locale, 'Complete and sign this section. Billing and PayPal follow on this same checkout page—nothing is entered twice.', 'Complete y firme esta sección. La facturación y PayPal continúan en esta misma página de pago; no tendrá que ingresar nada dos veces.' ) ); ?></p>
			<div class="gb-ep-summary"><strong><?php echo esc_html( $product->get_name() ); ?></strong><br><?php echo wp_kses_post( $product->get_price_html() ); ?><br><?php echo esc_html( isset( $profile['public_name'] ) ? $profile['public_name'] : 'Gulf Breeze Driving School' ); ?></div>
			<?php wp_nonce_field( 'gb_ep_checkout_agreement', 'gb_ep_agreement_nonce' ); ?>
			<div class="gb-ep-grid">
				<?php
				$this->field( 'gb_ep_student_name', $this->tr( $locale, 'Student full legal name', 'Nombre legal completo del estudiante' ), 'text', true, $values['student_name'], array( 'autocomplete' => 'name' ) );
				$this->field( 'gb_ep_student_email', $this->tr( $locale, 'Student email', 'Correo electrónico del estudiante' ), 'email', true, $values['student_email'], array( 'autocomplete' => 'email' ) );
				$this->field( 'gb_ep_student_dob', $this->tr( $locale, 'Date of birth', 'Fecha de nacimiento' ), 'date', true, $values['student_dob'] );
				$this->field( 'gb_ep_student_gender', $this->tr( $locale, 'Gender for the certificate record', 'Sexo para el registro del certificado' ), 'select', true, $values['student_gender'], array( 'options' => array( '' => $this->tr( $locale, 'Select', 'Seleccione' ), 'Male' => $this->tr( $locale, 'Male', 'Masculino' ), 'Female' => $this->tr( $locale, 'Female', 'Femenino' ) ) ) );
				$this->field( 'gb_ep_student_phone', $this->tr( $locale, 'Student phone', 'Teléfono del estudiante' ), 'tel', true, $values['student_phone'], array( 'autocomplete' => 'tel' ) );
				$this->field( 'gb_ep_student_address_1', $this->tr( $locale, 'Student street address', 'Dirección del estudiante' ), 'text', true, $values['student_address_1'], array( 'autocomplete' => 'street-address' ) );
				$this->field( 'gb_ep_student_city', $this->tr( $locale, 'City', 'Ciudad' ), 'text', true, $values['student_city'], array( 'autocomplete' => 'address-level2' ) );
				$this->field( 'gb_ep_student_state', $this->tr( $locale, 'State', 'Estado' ), 'text', true, $values['student_state'] ? $values['student_state'] : 'TX', array( 'autocomplete' => 'address-level1', 'maxlength' => 2 ) );
				$this->field( 'gb_ep_student_postcode', $this->tr( $locale, 'ZIP code', 'Código postal' ), 'text', true, $values['student_postcode'], array( 'autocomplete' => 'postal-code' ) );
				?>
			</div>
			<div class="gb-ep-terms" tabindex="0"><?php echo wp_kses_post( $this->contract_text( $locale, $profile, $product ) ); ?></div>
			<?php
			$this->field( 'gb_ep_consent', $this->tr( $locale, 'I consent to electronic records and signatures and agree to this enrollment agreement.', 'Acepto los registros y las firmas electrónicas y este contrato de inscripción.' ), 'checkbox', true, $values['consent'] ? 1 : 0 );
			$this->field( 'gb_ep_student_signature', $this->tr( $locale, 'Student electronic signature—type the full legal name exactly', 'Firma electrónica del estudiante—escriba exactamente el nombre legal completo' ), 'text', true, $values['student_signature'] );
			?>
			<div id="gb-ep-guardian" class="gb-ep-guardian">
				<h3><?php echo esc_html( $this->tr( $locale, 'Parent or guardian (required when the student is under 18)', 'Padre, madre o tutor (obligatorio si el estudiante es menor de 18 años)' ) ); ?></h3>
				<div class="gb-ep-grid">
					<?php
					$this->field( 'gb_ep_guardian_name', $this->tr( $locale, 'Parent/guardian full legal name', 'Nombre legal completo del padre, madre o tutor' ), 'text', false, $values['guardian_name'] );
					$this->field( 'gb_ep_guardian_relationship', $this->tr( $locale, 'Relationship to student', 'Relación con el estudiante' ), 'text', false, $values['guardian_relationship'] );
					$this->field( 'gb_ep_guardian_signature', $this->tr( $locale, 'Parent/guardian electronic signature', 'Firma electrónica del padre, madre o tutor' ), 'text', false, $values['guardian_signature'] );
					?>
				</div>
			</div>
			<?php $this->field( 'gb_ep_purchaser_is_student', $this->tr( $locale, 'The purchaser is the student—copy this information into billing.', 'El comprador es el estudiante—copiar esta información a la facturación.' ), 'checkbox', false, $values['purchaser_is_student'] ? 1 : 0 ); ?>
			<p class="gb-ep-next"><strong><?php echo esc_html( $this->tr( $locale, 'Next:', 'Siguiente:' ) ); ?></strong> <?php echo esc_html( $this->tr( $locale, 'Enter purchaser/billing information once, then approve the Sandbox payment through PayPal.', 'Ingrese una sola vez la información del comprador/facturación y después apruebe el pago de prueba mediante PayPal.' ) ); ?></p>
		</section>
		<?php
	}

	private function contract_text( $locale, $profile, $product ) {
		$name = esc_html( isset( $profile['public_name'] ) ? $profile['public_name'] : 'Gulf Breeze Driving School' );
		$provider = esc_html( isset( $profile['provider_number'] ) ? $profile['provider_number'] : '' );
		$phone = esc_html( isset( $profile['support_phone'] ) ? $profile['support_phone'] : '' );
		$email = esc_html( isset( $profile['support_email'] ) ? $profile['support_email'] : '' );
		$course = esc_html( $product->get_name() );
		$price = wp_kses_post( $product->get_price_html() );
		$complaint = esc_html( 'es-US' === $locale ? ( isset( $profile['tdlr_complaint_text_es'] ) ? $profile['tdlr_complaint_text_es'] : '' ) : ( isset( $profile['tdlr_complaint_text_en'] ) ? $profile['tdlr_complaint_text_en'] : '' ) );
		if ( 'es-US' === $locale ) {
			return "<p><strong>{$name}</strong> &middot; Proveedor {$provider} &middot; {$phone} &middot; {$email}</p><p>Curso: <strong>{$course}</strong>. Precio total actual: {$price}. El curso, idioma, precio y asignación quedan guardados con esta inscripción.</p><p>El acceso se concede solamente después de que WooCommerce confirme el pago de PayPal. El estudiante debe completar personalmente la instrucción, el tiempo, las verificaciones de identidad y las evaluaciones.</p><p>Se incorporan las políticas vigentes de cancelación, reembolso, privacidad y quejas. Un reembolso total, contracargo o reversión elimina el acceso al curso, pero conserva los registros administrativos y de cumplimiento. Aviso de quejas: {$complaint}</p>";
		}
		return "<p><strong>{$name}</strong> &middot; Provider {$provider} &middot; {$phone} &middot; {$email}</p><p>Course: <strong>{$course}</strong>. Current total price: {$price}. The course, language, price, and assignment are stored with this enrollment.</p><p>Access is granted only after WooCommerce confirms the PayPal payment. The student must personally complete the instruction, required time, identity checks, and assessments.</p><p>The current cancellation, refund, privacy, and grievance policies are incorporated. A full refund, chargeback, or reversal removes course access while preserving administrative and compliance records. Complaint notice: {$complaint}</p>";
	}

	public function validate_agreement( $data, $errors ) {
		$context = $this->cart_context();
		if ( ! $context ) {
			return;
		}
		$locale = $context['locale'];
		if ( empty( $_POST['gb_ep_agreement_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['gb_ep_agreement_nonce'] ) ), 'gb_ep_checkout_agreement' ) ) {
			$errors->add( 'gb_ep_nonce', $this->tr( $locale, 'The enrollment agreement expired. Refresh checkout and complete it again.', 'El contrato de inscripción venció. Actualice la página de pago y complételo nuevamente.' ) );
			return;
		}
		$v = $this->agreement_values();
		$required = array( 'student_name', 'student_email', 'student_dob', 'student_gender', 'student_phone', 'student_address_1', 'student_city', 'student_state', 'student_postcode', 'student_signature' );
		foreach ( $required as $key ) {
			if ( '' === trim( (string) $v[ $key ] ) ) {
				$errors->add( 'gb_ep_required_' . $key, $this->tr( $locale, 'Complete every required student and agreement field.', 'Complete todos los campos obligatorios del estudiante y del contrato.' ) );
				break;
			}
		}
		if ( ! is_email( $v['student_email'] ) ) {
			$errors->add( 'gb_ep_student_email', $this->tr( $locale, 'Enter a valid student email address.', 'Ingrese un correo electrónico válido para el estudiante.' ) );
		}
		$age = $this->age( $v['student_dob'] );
		if ( null === $age ) {
			$errors->add( 'gb_ep_student_dob', $this->tr( $locale, 'Enter a valid date of birth.', 'Ingrese una fecha de nacimiento válida.' ) );
		} elseif ( $age < 18 && ( ! $v['guardian_name'] || ! $v['guardian_relationship'] || ! $v['guardian_signature'] ) ) {
			$errors->add( 'gb_ep_guardian', $this->tr( $locale, 'A parent or guardian must complete and sign the guardian section for a student under 18.', 'Un padre, madre o tutor debe completar y firmar la sección correspondiente cuando el estudiante sea menor de 18 años.' ) );
		}
		if ( ! in_array( $v['student_gender'], array( 'Male', 'Female' ), true ) ) {
			$errors->add( 'gb_ep_student_gender', $this->tr( $locale, 'Select the student gender for the certificate record.', 'Seleccione el sexo del estudiante para el registro del certificado.' ) );
		}
		if ( ! $v['consent'] ) {
			$errors->add( 'gb_ep_consent', $this->tr( $locale, 'Electronic-record and signature consent is required.', 'Se requiere el consentimiento para registros y firmas electrónicas.' ) );
		}
		if ( $this->normalize_name( $v['student_signature'] ) !== $this->normalize_name( $v['student_name'] ) ) {
			$errors->add( 'gb_ep_signature', $this->tr( $locale, 'The student signature must match the student legal name.', 'La firma del estudiante debe coincidir con su nombre legal.' ) );
		}
		if ( $this->has_active_paid_enrollment( $v['student_email'], $context['course_id'] ) ) {
			$errors->add( 'gb_ep_duplicate', $this->tr( $locale, 'This student already has active paid access to this course. Do not pay again; contact the administrator.', 'Este estudiante ya tiene acceso pagado activo a este curso. No pague nuevamente; comuníquese con el administrador.' ) );
		}
	}

	private function purchaser_from_order( $order ) {
		return array(
			'first_name' => $order->get_billing_first_name(),
			'last_name' => $order->get_billing_last_name(),
			'email' => $order->get_billing_email(),
			'phone' => $order->get_billing_phone(),
			'address_1' => $order->get_billing_address_1(),
			'address_2' => $order->get_billing_address_2(),
			'city' => $order->get_billing_city(),
			'state' => $order->get_billing_state(),
			'postcode' => $order->get_billing_postcode(),
			'country' => $order->get_billing_country(),
		);
	}

	public function save_agreement_to_order( $order, $data ) {
		$context = $this->cart_context();
		if ( ! $context ) {
			return;
		}
		$v = $this->agreement_values();
		$profile = function_exists( 'gb_core_provider_profile' ) ? gb_core_provider_profile() : array();
		$snapshot = array(
			'schema_version' => '2.0',
			'contract_version' => self::CONTRACT_VERSION,
			'locale' => $context['locale'],
			'provider' => $profile,
			'catalog' => array(
				'catalog_key' => $context['catalog_key'],
				'product_id' => $context['product_id'],
				'course_id' => $context['course_id'],
				'course_name' => $context['product']->get_name(),
				'order_total' => wc_format_decimal( $order->get_total(), 2 ),
				'currency' => $order->get_currency(),
			),
			'student' => array(
				'legal_name' => $v['student_name'],
				'email' => $v['student_email'],
				'dob' => $v['student_dob'],
				'gender' => $v['student_gender'],
				'phone' => $v['student_phone'],
				'address_1' => $v['student_address_1'],
				'city' => $v['student_city'],
				'state' => $v['student_state'],
				'postcode' => $v['student_postcode'],
			),
			'purchaser' => $this->purchaser_from_order( $order ),
			'signatures' => array(
				'student' => $v['student_signature'],
				'guardian_name' => $v['guardian_name'],
				'guardian_relationship' => $v['guardian_relationship'],
				'guardian' => $v['guardian_signature'],
				'purchaser_is_student' => $v['purchaser_is_student'],
			),
			'terms_html' => $this->contract_text( $context['locale'], $profile, $context['product'] ),
			'evidence' => array(
				'signed_at_utc' => gmdate( 'c' ),
				'ip_hash' => hash_hmac( 'sha256', sanitize_text_field( isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : '' ), wp_salt( 'auth' ) ),
				'user_agent_hash' => hash( 'sha256', sanitize_text_field( isset( $_SERVER['HTTP_USER_AGENT'] ) ? $_SERVER['HTTP_USER_AGENT'] : '' ) ),
			),
		);
		$json = wp_json_encode( $snapshot, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		$order->update_meta_data( self::META_REQUIRED, 'yes' );
		$order->update_meta_data( self::META_SNAPSHOT, $json );
		$order->update_meta_data( self::META_HASH, hash( 'sha256', $json ) );
		$order->update_meta_data( self::META_SIGNED_AT, $snapshot['evidence']['signed_at_utc'] );
		$order->update_meta_data( self::META_COURSE_ID, $context['course_id'] );
		$order->update_meta_data( self::META_LOCALE, $context['locale'] );
		$order->update_meta_data( self::META_STUDENT_EMAIL, $v['student_email'] );
		$order->update_meta_data( self::META_STATE, 'signed_awaiting_payment' );
	}

	private function order_has_valid_agreement( $order ) {
		$json = (string) $order->get_meta( self::META_SNAPSHOT );
		$hash = (string) $order->get_meta( self::META_HASH );
		return 'yes' === $order->get_meta( self::META_REQUIRED ) && $json && $hash && hash_equals( $hash, hash( 'sha256', $json ) ) && $order->get_meta( self::META_SIGNED_AT );
	}

	public function guard_classic_order( $order_id, $posted_data, $order ) {
		if ( ! $this->order_context( $order ) ) {
			return;
		}
		if ( ! $this->order_has_valid_agreement( $order ) ) {
			$order->update_status( 'failed', 'Gulf Breeze blocked payment because the required signed agreement snapshot was absent or invalid.' );
			throw new Exception( 'Complete and electronically sign the enrollment agreement before payment.' );
		}
	}

	public function guard_store_api_order( $order ) {
		if ( ! $this->order_context( $order ) ) {
			return;
		}
		if ( ! $this->order_has_valid_agreement( $order ) ) {
			$order->update_status( 'failed', 'Gulf Breeze blocked Store API / express payment because the signed agreement snapshot was absent.' );
			throw new Exception( 'Use the standard Gulf Breeze checkout and sign the enrollment agreement before payment.' );
		}
	}

	private function has_active_paid_enrollment( $email, $course_id ) {
		$user = get_user_by( 'email', sanitize_email( $email ) );
		if ( ! $user ) {
			return false;
		}
		$order_id = absint( get_user_meta( $user->ID, '_gb_ep_active_course_' . absint( $course_id ), true ) );
		$order = $order_id ? wc_get_order( $order_id ) : false;
		return $order && $order->is_paid() && 'yes' !== $order->get_meta( self::META_REVOKED );
	}

	private function split_name( $name ) {
		$parts = preg_split( '/\s+/', trim( (string) $name ) );
		$first = $parts ? array_shift( $parts ) : '';
		$last = $parts ? implode( ' ', $parts ) : '';
		return array( $first, $last );
	}

	private function enroll_course( $user_id, $course_id, $order_id ) {
		if ( ! class_exists( '\\LearnPress\\Models\\UserItems\\UserCourseModel' ) || ! defined( 'LP_COURSE_CPT' ) ) {
			return false;
		}
		try {
			$class = '\\LearnPress\\Models\\UserItems\\UserCourseModel';
			$existing = $class::find( $user_id, $course_id, true );
			if ( $existing && method_exists( $existing, 'has_enrolled_or_finished' ) && $existing->has_enrolled_or_finished() ) {
				return true;
			}
			$item = new $class();
			$item->user_id = $user_id;
			$item->item_id = $course_id;
			$item->item_type = LP_COURSE_CPT;
			$item->status = 'enrolled';
			$item->graduation = 'in-progress';
			$item->ref_id = $order_id;
			$item->ref_type = 'woocommerce_order';
			$item->start_time = gmdate( 'Y-m-d H:i:s' );
			$item->save();
			return $item->get_user_item_id() > 0;
		} catch ( Throwable $error ) {
			return false;
		}
	}

	public function process_paid_order( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || 'yes' === $order->get_meta( self::META_PROCESSED ) || ! $this->order_context( $order ) ) {
			return;
		}
		if ( ! $order->is_paid() || ! $this->order_has_valid_agreement( $order ) ) {
			return;
		}
		if ( ! in_array( $order->get_payment_method(), array( 'ppcp-gateway', 'ppcp-credit-card-gateway' ), true ) || ! $order->get_transaction_id() ) {
			$order->update_meta_data( self::META_STATE, 'paid_paypal_verification_failed' );
			$order->add_order_note( 'Gulf Breeze did not enroll the student because the paid order lacks an approved PayPal gateway or transaction reference.' );
			$order->save();
			return;
		}
		$json = (string) $order->get_meta( self::META_SNAPSHOT );
		$snapshot = json_decode( $json, true );
		$email = sanitize_email( isset( $snapshot['student']['email'] ) ? $snapshot['student']['email'] : '' );
		$name = sanitize_text_field( isset( $snapshot['student']['legal_name'] ) ? $snapshot['student']['legal_name'] : '' );
		$course_id = absint( $order->get_meta( self::META_COURSE_ID ) );
		if ( ! $email || ! $name || ! $course_id ) {
			$order->update_meta_data( self::META_STATE, 'paid_student_record_invalid' );
			$order->add_order_note( 'Gulf Breeze could not create enrollment because the signed student record was incomplete.' );
			$order->save();
			return;
		}
		$user = get_user_by( 'email', $email );
		$created = false;
		if ( $user && user_can( $user, 'manage_options' ) ) {
			$order->update_meta_data( self::META_STATE, 'paid_admin_email_blocked' );
			$order->add_order_note( 'Gulf Breeze blocked student linking because the student email belongs to an administrator.' );
			$order->save();
			return;
		}
		if ( ! $user ) {
			$user_id = wc_create_new_customer( $email, '', wp_generate_password( 24, true ) );
			if ( is_wp_error( $user_id ) ) {
				$order->update_meta_data( self::META_STATE, 'paid_account_creation_failed' );
				$order->add_order_note( 'Gulf Breeze student account creation failed: ' . $user_id->get_error_message() );
				$order->save();
				return;
			}
			$user = get_user_by( 'id', $user_id );
			$created = true;
		}
		$user_id = absint( $user->ID );
		list( $first_name, $last_name ) = $this->split_name( $name );
		wp_update_user( array( 'ID' => $user_id, 'first_name' => $first_name, 'last_name' => $last_name, 'display_name' => $name ) );
		update_user_meta( $user_id, 'gb_preferred_locale', sanitize_text_field( $order->get_meta( self::META_LOCALE ) ) );
		update_user_meta( $user_id, '_gb_ep_active_course_' . $course_id, $order_id );
		update_user_meta( $user_id, '_gb_ep_account_state', 'active' );
		$order->set_customer_id( $user_id );
		$order->update_meta_data( self::META_STUDENT_USER_ID, $user_id );
		if ( ! $this->enroll_course( $user_id, $course_id, $order_id ) ) {
			delete_user_meta( $user_id, '_gb_ep_active_course_' . $course_id );
			update_user_meta( $user_id, '_gb_ep_account_state', 'dormant' );
			$order->update_meta_data( self::META_STATE, 'paid_learnpress_enrollment_failed' );
			$order->add_order_note( 'Payment is confirmed, but LearnPress enrollment failed. Manual administrator review is required.' );
			$order->save();
			return;
		}
		$order->update_meta_data( self::META_PROCESSED, 'yes' );
		$order->update_meta_data( self::META_REVOKED, 'no' );
		$order->update_meta_data( self::META_STATE, 'paid_enrolled' );
		$order->add_order_note( sprintf( 'Gulf Breeze student account %s after confirmed payment. Student user ID: %d; course ID: %d.', $created ? 'created' : 'linked', $user_id, $course_id ) );
		$order->save();
	}

	public function handle_refund( $order_id, $refund_id ) {
		$order = wc_get_order( $order_id );
		if ( $order && (float) $order->get_remaining_refund_amount() <= 0.009 ) {
			$this->revoke_access( $order, 'full_refund', absint( $refund_id ) );
		}
	}

	public function handle_refunded_status( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( $order ) {
			$this->revoke_access( $order, 'refunded_status', 0 );
		}
	}

	public function handle_reversal_status( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( $order && 'yes' === $order->get_meta( self::META_PROCESSED ) ) {
			$this->revoke_access( $order, 'payment_reversal_' . $order->get_status(), 0 );
		}
	}

	private function revoke_access( $order, $reason, $evidence_id ) {
		if ( 'yes' === $order->get_meta( self::META_REVOKED ) ) {
			return;
		}
		$user_id = absint( $order->get_meta( self::META_STUDENT_USER_ID ) );
		$course_id = absint( $order->get_meta( self::META_COURSE_ID ) );
		if ( ! $user_id || ! $course_id ) {
			return;
		}
		$learnpress_revoked = false;
		if ( class_exists( '\\LearnPress\\Models\\UserItems\\UserCourseModel' ) ) {
			try {
				$class = '\\LearnPress\\Models\\UserItems\\UserCourseModel';
				$item = $class::find( $user_id, $course_id, false );
				if ( ! $item || ! method_exists( $item, 'has_enrolled_or_finished' ) || ! $item->has_enrolled_or_finished() ) {
					$learnpress_revoked = true;
				} else {
					$item->status = 'cancel';
					$item->end_time = gmdate( 'Y-m-d H:i:s' );
					$item->save();
					$verify = $class::find( $user_id, $course_id, false );
					$learnpress_revoked = ! $verify || ! $verify->has_enrolled_or_finished();
				}
			} catch ( Throwable $error ) {
				$learnpress_revoked = false;
			}
		}
		if ( ! $learnpress_revoked ) {
			$order->update_meta_data( self::META_STATE, 'access_revocation_failed' );
			$order->add_order_note( 'Gulf Breeze could not confirm LearnPress access revocation. Immediate administrator review is required.' );
			$order->save();
			return;
		}
		delete_user_meta( $user_id, '_gb_ep_active_course_' . $course_id );
		update_user_meta( $user_id, '_gb_ep_account_state', 'dormant' );
		$order->update_meta_data( self::META_REVOKED, 'yes' );
		$order->update_meta_data( self::META_STATE, 'access_revoked' );
		$order->update_meta_data( '_gb_ep_revocation_reason', sanitize_key( $reason ) );
		$order->update_meta_data( '_gb_ep_revocation_evidence_id', absint( $evidence_id ) );
		$order->add_order_note( 'Gulf Breeze course access revoked. Reason: ' . sanitize_text_field( $reason ) . '. The student account and administrative record were retained, and repurchase is allowed.' );
		$order->save();
	}

	public function admin_order_panel( $order ) {
		if ( ! $order || 'yes' !== $order->get_meta( self::META_REQUIRED ) ) {
			return;
		}
		echo '<div class="gb-ep-admin"><h3>Gulf Breeze Enrollment</h3>';
		echo '<p><strong>State:</strong> ' . esc_html( $order->get_meta( self::META_STATE ) ) . '<br>';
		echo '<strong>Course ID:</strong> ' . esc_html( $order->get_meta( self::META_COURSE_ID ) ) . '<br>';
		echo '<strong>Student user ID:</strong> ' . esc_html( $order->get_meta( self::META_STUDENT_USER_ID ) ) . '<br>';
		echo '<strong>Agreement signed:</strong> ' . esc_html( $order->get_meta( self::META_SIGNED_AT ) ) . '<br>';
		echo '<strong>Agreement hash:</strong> <code>' . esc_html( $order->get_meta( self::META_HASH ) ) . '</code></p></div>';
	}

	public function assets() {
		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() || ( function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( 'order-received' ) ) ) {
			return;
		}
		if ( ! $this->cart_context() ) {
			return;
		}
		wp_enqueue_style( 'gb-ep-checkout', plugins_url( 'assets/checkout.css', __FILE__ ), array(), self::VERSION );
		wp_enqueue_script( 'gb-ep-checkout', plugins_url( 'assets/checkout.js', __FILE__ ), array(), self::VERSION, true );
	}
}

Gulf_Breeze_Enrollment_Payment::instance();
