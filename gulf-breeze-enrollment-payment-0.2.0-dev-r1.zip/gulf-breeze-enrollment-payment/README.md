# Gulf Breeze Enrollment & Payment 0.2.0-dev-r1

Architectural reset based on a proven native WooCommerce checkout boundary.

## Transaction ownership

- WooCommerce owns the cart, checkout form, order creation, PayPal handoff, and confirmation URL.
- PayPal Payments owns button placement and gateway behavior through its settings.
- This plugin renders and validates the bilingual agreement inside classic WooCommerce checkout.
- The plugin assumes payment responsibility by removing the Catalog plugin's known development-stage payment locks after both plugins load; it does not change catalog mappings or cart data.
- The agreement snapshot is written atomically to the WooCommerce order. There is no separate agreement-page redirect, reusable contract cookie, checkout URL filter, cart initialization, or PayPal-location filter.
- Student account creation and LearnPress enrollment occur only after WooCommerce confirms payment.
- Full refunds and payment reversals revoke course access but retain the user and order records, allowing a later repurchase with the same email.

## Deliberately deferred

MFA is not part of this checkpoint. It will be attached only after the native contract-to-payment path passes one protected-site Sandbox purchase. This keeps identity security downstream from payment instead of coupling it to checkout.

## Required site configuration before purchase testing

- WooCommerce Checkout page uses `[woocommerce_checkout]`.
- WooCommerce PayPal Payments Sandbox mode is enabled.
- PayPal button locations are limited to Checkout; Cart, Mini Cart, Product, and Express placements are disabled.
- Under Construction remains enabled.
